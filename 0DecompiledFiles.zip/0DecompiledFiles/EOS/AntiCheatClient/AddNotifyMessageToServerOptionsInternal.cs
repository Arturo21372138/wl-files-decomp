﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007AB RID: 1963
	internal struct AddNotifyMessageToServerOptionsInternal : ISettable<AddNotifyMessageToServerOptions>, IDisposable
	{
		// Token: 0x06002082 RID: 8322 RVA: 0x00026A62 File Offset: 0x00024C62
		public void Set(ref AddNotifyMessageToServerOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002083 RID: 8323 RVA: 0x00026A71 File Offset: 0x00024C71
		public void Dispose()
		{
		}

		// Token: 0x0400159B RID: 5531
		private int m_ApiVersion;
	}
}
