﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E5 RID: 229
	public enum RenderingMaps
	{
		// Token: 0x04000597 RID: 1431
		Standard,
		// Token: 0x04000598 RID: 1432
		Custom
	}
}
