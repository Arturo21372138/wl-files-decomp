﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F4 RID: 2036
	internal struct DefinitionV2Internal : IGettable<DefinitionV2>
	{
		// Token: 0x0600218F RID: 8591 RVA: 0x00028068 File Offset: 0x00026268
		public void Get(out DefinitionV2 other)
		{
			other = default(DefinitionV2);
			Utf8String utf8String;
			Helper.Get(this.m_AchievementId, out utf8String);
			other.AchievementId = utf8String;
			Utf8String utf8String2;
			Helper.Get(this.m_UnlockedDisplayName, out utf8String2);
			other.UnlockedDisplayName = utf8String2;
			Utf8String utf8String3;
			Helper.Get(this.m_UnlockedDescription, out utf8String3);
			other.UnlockedDescription = utf8String3;
			Utf8String utf8String4;
			Helper.Get(this.m_LockedDisplayName, out utf8String4);
			other.LockedDisplayName = utf8String4;
			Utf8String utf8String5;
			Helper.Get(this.m_LockedDescription, out utf8String5);
			other.LockedDescription = utf8String5;
			Utf8String utf8String6;
			Helper.Get(this.m_FlavorText, out utf8String6);
			other.FlavorText = utf8String6;
			Utf8String utf8String7;
			Helper.Get(this.m_UnlockedIconURL, out utf8String7);
			other.UnlockedIconURL = utf8String7;
			Utf8String utf8String8;
			Helper.Get(this.m_LockedIconURL, out utf8String8);
			other.LockedIconURL = utf8String8;
			bool flag;
			Helper.Get(this.m_IsHidden, out flag);
			other.IsHidden = flag;
			StatThresholds[] array;
			Helper.Get<StatThresholdsInternal, StatThresholds>(this.m_StatThresholds, out array, this.m_StatThresholdsCount, false);
			other.StatThresholds = array;
		}

		// Token: 0x04001670 RID: 5744
		private int m_ApiVersion;

		// Token: 0x04001671 RID: 5745
		private IntPtr m_AchievementId;

		// Token: 0x04001672 RID: 5746
		private IntPtr m_UnlockedDisplayName;

		// Token: 0x04001673 RID: 5747
		private IntPtr m_UnlockedDescription;

		// Token: 0x04001674 RID: 5748
		private IntPtr m_LockedDisplayName;

		// Token: 0x04001675 RID: 5749
		private IntPtr m_LockedDescription;

		// Token: 0x04001676 RID: 5750
		private IntPtr m_FlavorText;

		// Token: 0x04001677 RID: 5751
		private IntPtr m_UnlockedIconURL;

		// Token: 0x04001678 RID: 5752
		private IntPtr m_LockedIconURL;

		// Token: 0x04001679 RID: 5753
		private int m_IsHidden;

		// Token: 0x0400167A RID: 5754
		private uint m_StatThresholdsCount;

		// Token: 0x0400167B RID: 5755
		private IntPtr m_StatThresholds;
	}
}
