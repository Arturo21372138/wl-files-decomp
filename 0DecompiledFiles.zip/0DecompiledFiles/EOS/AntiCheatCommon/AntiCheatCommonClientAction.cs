﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000769 RID: 1897
	public enum AntiCheatCommonClientAction
	{
		// Token: 0x04001469 RID: 5225
		Invalid,
		// Token: 0x0400146A RID: 5226
		RemovePlayer
	}
}
