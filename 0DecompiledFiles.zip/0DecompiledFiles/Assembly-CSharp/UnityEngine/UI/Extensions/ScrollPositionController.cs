﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200008C RID: 140
	public class ScrollPositionController : UIBehaviour, IBeginDragHandler, IEventSystemHandler, IEndDragHandler, IDragHandler
	{
		// Token: 0x06000435 RID: 1077 RVA: 0x0001955C File Offset: 0x0001775C
		public void OnUpdatePosition(Action<float> onUpdatePosition)
		{
			this.onUpdatePosition = onUpdatePosition;
		}

		// Token: 0x06000436 RID: 1078 RVA: 0x00019565 File Offset: 0x00017765
		public void OnItemSelected(Action<int> onItemSelected)
		{
			this.onItemSelected = onItemSelected;
		}

		// Token: 0x06000437 RID: 1079 RVA: 0x0001956E File Offset: 0x0001776E
		public void SetDataCount(int dataCount)
		{
			this.dataCount = dataCount;
		}

		// Token: 0x06000438 RID: 1080 RVA: 0x00019578 File Offset: 0x00017778
		public void ScrollTo(int index, float duration)
		{
			this.autoScrollState.Reset();
			this.autoScrollState.Enable = true;
			this.autoScrollState.Duration = duration;
			this.autoScrollState.StartTime = Time.unscaledTime;
			this.autoScrollState.EndScrollPosition = (float)this.CalculateDestinationIndex(index);
			this.velocity = 0f;
			this.dragStartScrollPosition = this.currentScrollPosition;
			this.ItemSelected(Mathf.RoundToInt(this.GetCircularPosition(this.autoScrollState.EndScrollPosition, this.dataCount)));
		}

		// Token: 0x06000439 RID: 1081 RVA: 0x00019604 File Offset: 0x00017804
		public void JumpTo(int index)
		{
			this.autoScrollState.Reset();
			this.velocity = 0f;
			this.dragging = false;
			index = this.CalculateDestinationIndex(index);
			this.ItemSelected(index);
			this.UpdatePosition((float)index);
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x0001963C File Offset: 0x0001783C
		void IBeginDragHandler.OnBeginDrag(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.pointerStartLocalPosition = Vector2.zero;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.viewport, eventData.position, eventData.pressEventCamera, out this.pointerStartLocalPosition);
			this.dragStartScrollPosition = this.currentScrollPosition;
			this.dragging = true;
			this.autoScrollState.Reset();
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0001969C File Offset: 0x0001789C
		void IDragHandler.OnDrag(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			if (!this.dragging)
			{
				return;
			}
			Vector2 vector;
			if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(this.viewport, eventData.position, eventData.pressEventCamera, out vector))
			{
				return;
			}
			Vector2 vector2 = vector - this.pointerStartLocalPosition;
			float num = ((this.directionOfRecognize == ScrollPositionController.ScrollDirection.Horizontal) ? (-vector2.x) : vector2.y) / this.GetViewportSize() * this.scrollSensitivity + this.dragStartScrollPosition;
			float num2 = this.CalculateOffset(num);
			num += num2;
			if (this.movementType == ScrollPositionController.MovementType.Elastic && num2 != 0f)
			{
				num -= this.RubberDelta(num2, this.scrollSensitivity);
			}
			this.UpdatePosition(num);
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x00019746 File Offset: 0x00017946
		void IEndDragHandler.OnEndDrag(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.dragging = false;
		}

		// Token: 0x0600043D RID: 1085 RVA: 0x00019758 File Offset: 0x00017958
		private float GetViewportSize()
		{
			if (this.directionOfRecognize != ScrollPositionController.ScrollDirection.Horizontal)
			{
				return this.viewport.rect.size.y;
			}
			return this.viewport.rect.size.x;
		}

		// Token: 0x0600043E RID: 1086 RVA: 0x0001979F File Offset: 0x0001799F
		private float CalculateOffset(float position)
		{
			if (this.movementType == ScrollPositionController.MovementType.Unrestricted)
			{
				return 0f;
			}
			if (position < 0f)
			{
				return -position;
			}
			if (position > (float)(this.dataCount - 1))
			{
				return (float)(this.dataCount - 1) - position;
			}
			return 0f;
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x000197D7 File Offset: 0x000179D7
		private void UpdatePosition(float position)
		{
			this.currentScrollPosition = position;
			if (this.onUpdatePosition != null)
			{
				this.onUpdatePosition(this.currentScrollPosition);
			}
		}

		// Token: 0x06000440 RID: 1088 RVA: 0x000197F9 File Offset: 0x000179F9
		private void ItemSelected(int index)
		{
			if (this.onItemSelected != null)
			{
				this.onItemSelected(index);
			}
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0001980F File Offset: 0x00017A0F
		private float RubberDelta(float overStretching, float viewSize)
		{
			return (1f - 1f / (Mathf.Abs(overStretching) * 0.55f / viewSize + 1f)) * viewSize * Mathf.Sign(overStretching);
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0001983C File Offset: 0x00017A3C
		private void Update()
		{
			float unscaledDeltaTime = Time.unscaledDeltaTime;
			float num = this.CalculateOffset(this.currentScrollPosition);
			if (this.autoScrollState.Enable)
			{
				float num3;
				if (this.autoScrollState.Elastic)
				{
					float num2 = this.velocity;
					num3 = Mathf.SmoothDamp(this.currentScrollPosition, this.currentScrollPosition + num, ref num2, this.elasticity, float.PositiveInfinity, unscaledDeltaTime);
					this.velocity = num2;
					if (Mathf.Abs(this.velocity) < 0.01f)
					{
						num3 = (float)Mathf.Clamp(Mathf.RoundToInt(num3), 0, this.dataCount - 1);
						this.velocity = 0f;
						this.autoScrollState.Reset();
					}
				}
				else
				{
					float num4 = Mathf.Clamp01((Time.unscaledTime - this.autoScrollState.StartTime) / Mathf.Max(this.autoScrollState.Duration, float.Epsilon));
					num3 = Mathf.Lerp(this.dragStartScrollPosition, this.autoScrollState.EndScrollPosition, this.EaseInOutCubic(0f, 1f, num4));
					if (Mathf.Approximately(num4, 1f))
					{
						this.autoScrollState.Reset();
					}
				}
				this.UpdatePosition(num3);
			}
			else if (!this.dragging && (!Mathf.Approximately(num, 0f) || !Mathf.Approximately(this.velocity, 0f)))
			{
				float num5 = this.currentScrollPosition;
				if (this.movementType == ScrollPositionController.MovementType.Elastic && !Mathf.Approximately(num, 0f))
				{
					this.autoScrollState.Reset();
					this.autoScrollState.Enable = true;
					this.autoScrollState.Elastic = true;
					this.ItemSelected(Mathf.Clamp(Mathf.RoundToInt(num5), 0, this.dataCount - 1));
				}
				else if (this.inertia)
				{
					this.velocity *= Mathf.Pow(this.decelerationRate, unscaledDeltaTime);
					if (Mathf.Abs(this.velocity) < 0.001f)
					{
						this.velocity = 0f;
					}
					num5 += this.velocity * unscaledDeltaTime;
					if (this.snap.Enable && Mathf.Abs(this.velocity) < this.snap.VelocityThreshold)
					{
						this.ScrollTo(Mathf.RoundToInt(this.currentScrollPosition), this.snap.Duration);
					}
				}
				else
				{
					this.velocity = 0f;
				}
				if (!Mathf.Approximately(this.velocity, 0f))
				{
					if (this.movementType == ScrollPositionController.MovementType.Clamped)
					{
						num = this.CalculateOffset(num5);
						num5 += num;
						if (Mathf.Approximately(num5, 0f) || Mathf.Approximately(num5, (float)this.dataCount - 1f))
						{
							this.velocity = 0f;
							this.ItemSelected(Mathf.RoundToInt(num5));
						}
					}
					this.UpdatePosition(num5);
				}
			}
			if (!this.autoScrollState.Enable && this.dragging && this.inertia)
			{
				float num6 = (this.currentScrollPosition - this.prevScrollPosition) / unscaledDeltaTime;
				this.velocity = Mathf.Lerp(this.velocity, num6, unscaledDeltaTime * 10f);
			}
			if (this.currentScrollPosition != this.prevScrollPosition)
			{
				this.prevScrollPosition = this.currentScrollPosition;
			}
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x00019B68 File Offset: 0x00017D68
		private int CalculateDestinationIndex(int index)
		{
			if (this.movementType != ScrollPositionController.MovementType.Unrestricted)
			{
				return Mathf.Clamp(index, 0, this.dataCount - 1);
			}
			return this.CalculateClosestIndex(index);
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x00019B8C File Offset: 0x00017D8C
		private int CalculateClosestIndex(int index)
		{
			float num = this.GetCircularPosition((float)index, this.dataCount) - this.GetCircularPosition(this.currentScrollPosition, this.dataCount);
			if (Mathf.Abs(num) > (float)this.dataCount * 0.5f)
			{
				num = Mathf.Sign(-num) * ((float)this.dataCount - Mathf.Abs(num));
			}
			return Mathf.RoundToInt(num + this.currentScrollPosition);
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x00019BF4 File Offset: 0x00017DF4
		private float GetCircularPosition(float position, int length)
		{
			if (position >= 0f)
			{
				return position % (float)length;
			}
			return (float)(length - 1) + (position + 1f) % (float)length;
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x00019C14 File Offset: 0x00017E14
		private float EaseInOutCubic(float start, float end, float value)
		{
			value /= 0.5f;
			end -= start;
			if (value < 1f)
			{
				return end * 0.5f * value * value * value + start;
			}
			value -= 2f;
			return end * 0.5f * (value * value * value + 2f) + start;
		}

		// Token: 0x04000319 RID: 793
		[SerializeField]
		private RectTransform viewport;

		// Token: 0x0400031A RID: 794
		[SerializeField]
		private ScrollPositionController.ScrollDirection directionOfRecognize;

		// Token: 0x0400031B RID: 795
		[SerializeField]
		private ScrollPositionController.MovementType movementType = ScrollPositionController.MovementType.Elastic;

		// Token: 0x0400031C RID: 796
		[SerializeField]
		private float elasticity = 0.1f;

		// Token: 0x0400031D RID: 797
		[SerializeField]
		private float scrollSensitivity = 1f;

		// Token: 0x0400031E RID: 798
		[SerializeField]
		private bool inertia = true;

		// Token: 0x0400031F RID: 799
		[SerializeField]
		[Tooltip("Only used when inertia is enabled")]
		private float decelerationRate = 0.03f;

		// Token: 0x04000320 RID: 800
		[SerializeField]
		[Tooltip("Only used when inertia is enabled")]
		private ScrollPositionController.Snap snap = new ScrollPositionController.Snap
		{
			Enable = true,
			VelocityThreshold = 0.5f,
			Duration = 0.3f
		};

		// Token: 0x04000321 RID: 801
		[SerializeField]
		private int dataCount;

		// Token: 0x04000322 RID: 802
		private readonly ScrollPositionController.AutoScrollState autoScrollState = new ScrollPositionController.AutoScrollState();

		// Token: 0x04000323 RID: 803
		private Action<float> onUpdatePosition;

		// Token: 0x04000324 RID: 804
		private Action<int> onItemSelected;

		// Token: 0x04000325 RID: 805
		private Vector2 pointerStartLocalPosition;

		// Token: 0x04000326 RID: 806
		private float dragStartScrollPosition;

		// Token: 0x04000327 RID: 807
		private float prevScrollPosition;

		// Token: 0x04000328 RID: 808
		private float currentScrollPosition;

		// Token: 0x04000329 RID: 809
		private bool dragging;

		// Token: 0x0400032A RID: 810
		private float velocity;

		// Token: 0x02000135 RID: 309
		private enum ScrollDirection
		{
			// Token: 0x04000678 RID: 1656
			Vertical,
			// Token: 0x04000679 RID: 1657
			Horizontal
		}

		// Token: 0x02000136 RID: 310
		private enum MovementType
		{
			// Token: 0x0400067B RID: 1659
			Unrestricted,
			// Token: 0x0400067C RID: 1660
			Elastic,
			// Token: 0x0400067D RID: 1661
			Clamped
		}

		// Token: 0x02000137 RID: 311
		[Serializable]
		private struct Snap
		{
			// Token: 0x0400067E RID: 1662
			public bool Enable;

			// Token: 0x0400067F RID: 1663
			public float VelocityThreshold;

			// Token: 0x04000680 RID: 1664
			public float Duration;
		}

		// Token: 0x02000138 RID: 312
		private class AutoScrollState
		{
			// Token: 0x06000801 RID: 2049 RVA: 0x0002C25F File Offset: 0x0002A45F
			public void Reset()
			{
				this.Enable = false;
				this.Elastic = false;
				this.Duration = 0f;
				this.StartTime = 0f;
				this.EndScrollPosition = 0f;
			}

			// Token: 0x04000681 RID: 1665
			public bool Enable;

			// Token: 0x04000682 RID: 1666
			public bool Elastic;

			// Token: 0x04000683 RID: 1667
			public float Duration;

			// Token: 0x04000684 RID: 1668
			public float StartTime;

			// Token: 0x04000685 RID: 1669
			public float EndScrollPosition;
		}
	}
}
