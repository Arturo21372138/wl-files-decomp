﻿using System;
using UnityEngine;
using UnitySA.Utility;

namespace UnitySA.Characters.FirstPerson
{
	// Token: 0x0200001B RID: 27
	[RequireComponent(typeof(CharacterController))]
	[RequireComponent(typeof(AudioSource))]
	public class FPCtrl : MonoBehaviour
	{
		// Token: 0x06000046 RID: 70 RVA: 0x00003A28 File Offset: 0x00001C28
		private void Start()
		{
			this.m_CharacterController = base.GetComponent<CharacterController>();
			this.m_Camera = Camera.main;
			this.m_OriginalCameraPosition = this.m_Camera.transform.localPosition;
			this.m_FovKick.Setup(this.m_Camera);
			this.m_HeadBob.Setup(this.m_Camera, this.m_StepInterval);
			this.m_StepCycle = 0f;
			this.m_NextStep = this.m_StepCycle / 2f;
			this.m_Jumping = false;
			this.m_MouseLook.Init(base.transform, this.m_Camera.transform);
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00003ACC File Offset: 0x00001CCC
		private void Update()
		{
			this.RotateView();
			if (!this.m_Jump)
			{
				this.m_Jump = Input.GetButtonDown("Jump");
			}
			if (!this.m_PreviouslyGrounded && this.m_CharacterController.isGrounded)
			{
				base.StartCoroutine(this.m_JumpBob.DoBobCycle());
				this.m_MoveDir.y = 0f;
				this.m_Jumping = false;
			}
			if (!this.m_CharacterController.isGrounded && !this.m_Jumping && this.m_PreviouslyGrounded)
			{
				this.m_MoveDir.y = 0f;
			}
			this.m_PreviouslyGrounded = this.m_CharacterController.isGrounded;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003B74 File Offset: 0x00001D74
		private void FixedUpdate()
		{
			float num;
			this.GetInput(out num);
			Vector3 vector = base.transform.forward * this.m_Input.y + base.transform.right * this.m_Input.x;
			RaycastHit raycastHit;
			Physics.SphereCast(base.transform.position, this.m_CharacterController.radius, Vector3.down, out raycastHit, this.m_CharacterController.height / 2f, -1, QueryTriggerInteraction.Ignore);
			vector = Vector3.ProjectOnPlane(vector, raycastHit.normal).normalized;
			this.m_MoveDir.x = vector.x * num;
			this.m_MoveDir.z = vector.z * num;
			if (this.m_CharacterController.isGrounded)
			{
				this.m_MoveDir.y = -this.m_StickToGroundForce;
				if (this.m_Jump)
				{
					this.m_MoveDir.y = this.m_JumpSpeed;
					this.m_Jump = false;
					this.m_Jumping = true;
				}
			}
			else
			{
				this.m_MoveDir += Physics.gravity * this.m_GravityMultiplier * Time.fixedDeltaTime;
			}
			this.m_CollisionFlags = this.m_CharacterController.Move(this.m_MoveDir * Time.fixedDeltaTime);
			this.ProgressStepCycle(num);
			this.UpdateCameraPosition(num);
			this.m_MouseLook.UpdateCursorLock();
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00003CE4 File Offset: 0x00001EE4
		private void ProgressStepCycle(float speed)
		{
			if (this.m_CharacterController.velocity.sqrMagnitude > 0f && (this.m_Input.x != 0f || this.m_Input.y != 0f))
			{
				this.m_StepCycle += (this.m_CharacterController.velocity.magnitude + speed * (this.m_IsWalking ? 1f : this.m_RunstepLenghten)) * Time.fixedDeltaTime;
			}
			if (this.m_StepCycle <= this.m_NextStep)
			{
				return;
			}
			this.m_NextStep = this.m_StepCycle + this.m_StepInterval;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00003D90 File Offset: 0x00001F90
		private void UpdateCameraPosition(float speed)
		{
			if (!this.m_UseHeadBob)
			{
				return;
			}
			Vector3 vector;
			if (this.m_CharacterController.velocity.magnitude > 0f && this.m_CharacterController.isGrounded)
			{
				this.m_Camera.transform.localPosition = this.m_HeadBob.DoHeadBob(this.m_CharacterController.velocity.magnitude + speed * (this.m_IsWalking ? 1f : this.m_RunstepLenghten));
				vector = this.m_Camera.transform.localPosition;
				vector.y = this.m_Camera.transform.localPosition.y - this.m_JumpBob.Offset();
			}
			else
			{
				vector = this.m_Camera.transform.localPosition;
				vector.y = this.m_OriginalCameraPosition.y - this.m_JumpBob.Offset();
			}
			this.m_Camera.transform.localPosition = vector;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00003E94 File Offset: 0x00002094
		private void GetInput(out float speed)
		{
			float axis = Input.GetAxis("Horizontal");
			float axis2 = Input.GetAxis("Vertical");
			bool isWalking = this.m_IsWalking;
			this.m_IsWalking = !Input.GetKey(KeyCode.LeftShift);
			speed = (this.m_IsWalking ? this.m_WalkSpeed : this.m_RunSpeed);
			this.m_Input = new Vector2(axis, axis2);
			if (this.m_Input.sqrMagnitude > 1f)
			{
				this.m_Input.Normalize();
			}
			if (this.m_IsWalking != isWalking && this.m_UseFovKick && this.m_CharacterController.velocity.sqrMagnitude > 0f)
			{
				base.StopAllCoroutines();
				base.StartCoroutine((!this.m_IsWalking) ? this.m_FovKick.FOVKickUp() : this.m_FovKick.FOVKickDown());
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00003F6B File Offset: 0x0000216B
		private void RotateView()
		{
			this.m_MouseLook.LookRotation(base.transform, this.m_Camera.transform);
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00003F8C File Offset: 0x0000218C
		private void OnControllerColliderHit(ControllerColliderHit hit)
		{
			Rigidbody attachedRigidbody = hit.collider.attachedRigidbody;
			if (this.m_CollisionFlags == CollisionFlags.Below)
			{
				return;
			}
			if (attachedRigidbody == null || attachedRigidbody.isKinematic)
			{
				return;
			}
			attachedRigidbody.AddForceAtPosition(this.m_CharacterController.velocity * 0.1f, hit.point, ForceMode.Impulse);
		}

		// Token: 0x04000053 RID: 83
		[SerializeField]
		private bool m_IsWalking;

		// Token: 0x04000054 RID: 84
		[SerializeField]
		private float m_WalkSpeed;

		// Token: 0x04000055 RID: 85
		[SerializeField]
		private float m_RunSpeed;

		// Token: 0x04000056 RID: 86
		[SerializeField]
		[Range(0f, 1f)]
		private float m_RunstepLenghten;

		// Token: 0x04000057 RID: 87
		[SerializeField]
		private float m_JumpSpeed;

		// Token: 0x04000058 RID: 88
		[SerializeField]
		private float m_StickToGroundForce;

		// Token: 0x04000059 RID: 89
		[SerializeField]
		private float m_GravityMultiplier;

		// Token: 0x0400005A RID: 90
		[SerializeField]
		private MLook m_MouseLook;

		// Token: 0x0400005B RID: 91
		[SerializeField]
		private bool m_UseFovKick;

		// Token: 0x0400005C RID: 92
		[SerializeField]
		private FOVZoom m_FovKick = new FOVZoom();

		// Token: 0x0400005D RID: 93
		[SerializeField]
		private bool m_UseHeadBob;

		// Token: 0x0400005E RID: 94
		[SerializeField]
		private CurveCtrlBob m_HeadBob = new CurveCtrlBob();

		// Token: 0x0400005F RID: 95
		[SerializeField]
		private LerpCtrlBob m_JumpBob = new LerpCtrlBob();

		// Token: 0x04000060 RID: 96
		[SerializeField]
		private float m_StepInterval;

		// Token: 0x04000061 RID: 97
		private Camera m_Camera;

		// Token: 0x04000062 RID: 98
		private bool m_Jump;

		// Token: 0x04000063 RID: 99
		private float m_YRotation;

		// Token: 0x04000064 RID: 100
		private Vector2 m_Input;

		// Token: 0x04000065 RID: 101
		private Vector3 m_MoveDir = Vector3.zero;

		// Token: 0x04000066 RID: 102
		private CharacterController m_CharacterController;

		// Token: 0x04000067 RID: 103
		private CollisionFlags m_CollisionFlags;

		// Token: 0x04000068 RID: 104
		private bool m_PreviouslyGrounded;

		// Token: 0x04000069 RID: 105
		private Vector3 m_OriginalCameraPosition;

		// Token: 0x0400006A RID: 106
		private float m_StepCycle;

		// Token: 0x0400006B RID: 107
		private float m_NextStep;

		// Token: 0x0400006C RID: 108
		private bool m_Jumping;
	}
}
