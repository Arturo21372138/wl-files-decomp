﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000EA RID: 234
	public enum TextureScale
	{
		// Token: 0x040005B7 RID: 1463
		Full = 1,
		// Token: 0x040005B8 RID: 1464
		Half,
		// Token: 0x040005B9 RID: 1465
		Quarter = 4,
		// Token: 0x040005BA RID: 1466
		Eighth = 8
	}
}
