﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007FB RID: 2043
	// (Invoke) Token: 0x0600219B RID: 8603
	public delegate void OnAchievementsUnlockedCallback(ref OnAchievementsUnlockedCallbackInfo data);
}
