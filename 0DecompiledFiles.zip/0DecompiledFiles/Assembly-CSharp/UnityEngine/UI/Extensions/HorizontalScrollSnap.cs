﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000089 RID: 137
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("Layout/Extensions/Horizontal Scroll Snap")]
	public class HorizontalScrollSnap : ScrollSnapBase
	{
		// Token: 0x0600041A RID: 1050 RVA: 0x00018C14 File Offset: 0x00016E14
		private void Start()
		{
			this._isVertical = false;
			this._childAnchorPoint = new Vector2(0f, 0.5f);
			this._currentPage = this.StartingScreen;
			this.panelDimensions = base.gameObject.GetComponent<RectTransform>().rect;
			this.UpdateLayout();
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00018C68 File Offset: 0x00016E68
		private void Update()
		{
			this.updated = false;
			if (!this._lerp && this._scroll_rect.velocity == Vector2.zero && this._scroll_rect.inertia)
			{
				if (!this._settled && !this._pointerDown && !base.IsRectSettledOnaPage(this._screensContainer.anchoredPosition))
				{
					base.ScrollToClosestElement();
				}
				return;
			}
			if (this._lerp)
			{
				this._screensContainer.anchoredPosition = Vector3.Lerp(this._screensContainer.anchoredPosition, this._lerp_target, this.transitionSpeed * (this.UseTimeScale ? Time.deltaTime : Time.unscaledDeltaTime));
				if (Vector3.Distance(this._screensContainer.anchoredPosition, this._lerp_target) < 0.2f)
				{
					this._screensContainer.anchoredPosition = this._lerp_target;
					this._lerp = false;
					base.EndScreenChange();
				}
			}
			if (this.UseHardSwipe)
			{
				return;
			}
			base.CurrentPage = base.GetPageforPosition(this._screensContainer.anchoredPosition);
			if (!this._pointerDown && ((double)this._scroll_rect.velocity.x > 0.01 || (double)this._scroll_rect.velocity.x < -0.01) && this.IsRectMovingSlowerThanThreshold(0f))
			{
				base.ScrollToClosestElement();
			}
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00018DE8 File Offset: 0x00016FE8
		private bool IsRectMovingSlowerThanThreshold(float startingSpeed)
		{
			return (this._scroll_rect.velocity.x > startingSpeed && this._scroll_rect.velocity.x < (float)this.SwipeVelocityThreshold) || (this._scroll_rect.velocity.x < startingSpeed && this._scroll_rect.velocity.x > (float)(-(float)this.SwipeVelocityThreshold));
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x00018E54 File Offset: 0x00017054
		public void DistributePages()
		{
			this._screens = this._screensContainer.childCount;
			this._scroll_rect.horizontalNormalizedPosition = 0f;
			float num = 0f;
			Rect rect = base.gameObject.GetComponent<RectTransform>().rect;
			float num2 = 0f;
			float num3 = (this._childSize = (float)((int)rect.width) * ((this.PageStep == 0f) ? 3f : this.PageStep));
			for (int i = 0; i < this._screensContainer.transform.childCount; i++)
			{
				RectTransform component = this._screensContainer.transform.GetChild(i).gameObject.GetComponent<RectTransform>();
				num2 = num + (float)i * num3;
				component.sizeDelta = new Vector2(rect.width, rect.height);
				component.anchoredPosition = new Vector2(num2, 0f);
				component.anchorMin = (component.anchorMax = (component.pivot = this._childAnchorPoint));
			}
			float num4 = num2 + num * -1f;
			this._screensContainer.GetComponent<RectTransform>().offsetMax = new Vector2(num4, 0f);
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x00018F8D File Offset: 0x0001718D
		public void AddChild(GameObject GO)
		{
			this.AddChild(GO, false);
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x00018F98 File Offset: 0x00017198
		public void AddChild(GameObject GO, bool WorldPositionStays)
		{
			this._scroll_rect.horizontalNormalizedPosition = 0f;
			GO.transform.SetParent(this._screensContainer, WorldPositionStays);
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			this.SetScrollContainerPosition();
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x00018FEC File Offset: 0x000171EC
		public void RemoveChild(int index, out GameObject ChildRemoved)
		{
			this.RemoveChild(index, false, out ChildRemoved);
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x00018FF8 File Offset: 0x000171F8
		public void RemoveChild(int index, bool WorldPositionStays, out GameObject ChildRemoved)
		{
			ChildRemoved = null;
			if (index < 0 || index > this._screensContainer.childCount)
			{
				return;
			}
			this._scroll_rect.horizontalNormalizedPosition = 0f;
			Transform child = this._screensContainer.transform.GetChild(index);
			child.SetParent(null, WorldPositionStays);
			ChildRemoved = child.gameObject;
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			if (this._currentPage > this._screens - 1)
			{
				base.CurrentPage = this._screens - 1;
			}
			this.SetScrollContainerPosition();
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00019090 File Offset: 0x00017290
		public void RemoveAllChildren(out GameObject[] ChildrenRemoved)
		{
			this.RemoveAllChildren(false, out ChildrenRemoved);
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x0001909C File Offset: 0x0001729C
		public void RemoveAllChildren(bool WorldPositionStays, out GameObject[] ChildrenRemoved)
		{
			int childCount = this._screensContainer.childCount;
			ChildrenRemoved = new GameObject[childCount];
			for (int i = childCount - 1; i >= 0; i--)
			{
				ChildrenRemoved[i] = this._screensContainer.GetChild(i).gameObject;
				ChildrenRemoved[i].transform.SetParent(null, WorldPositionStays);
			}
			this._scroll_rect.horizontalNormalizedPosition = 0f;
			base.CurrentPage = 0;
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x00019126 File Offset: 0x00017326
		private void SetScrollContainerPosition()
		{
			this._scrollStartPosition = this._screensContainer.anchoredPosition.x;
			this._scroll_rect.horizontalNormalizedPosition = (float)this._currentPage / (float)(this._screens - 1);
			base.OnCurrentScreenChange(this._currentPage);
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x00019166 File Offset: 0x00017366
		public void UpdateLayout()
		{
			this._lerp = false;
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			this.SetScrollContainerPosition();
			base.OnCurrentScreenChange(this._currentPage);
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0001919A File Offset: 0x0001739A
		private void OnRectTransformDimensionsChange()
		{
			if (this._childAnchorPoint != Vector2.zero)
			{
				this.UpdateLayout();
			}
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x000191B4 File Offset: 0x000173B4
		private void OnEnable()
		{
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			if (this.JumpOnEnable || !this.RestartOnEnable)
			{
				this.SetScrollContainerPosition();
			}
			if (this.RestartOnEnable)
			{
				base.GoToScreen(this.StartingScreen);
			}
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0001920C File Offset: 0x0001740C
		public override void OnEndDrag(PointerEventData eventData)
		{
			if (this.updated)
			{
				return;
			}
			this.updated = true;
			this._pointerDown = false;
			if (this._scroll_rect.horizontal)
			{
				if (this.UseSwipeDeltaThreshold && Math.Abs(eventData.delta.x) < this.SwipeDeltaThreshold)
				{
					base.ScrollToClosestElement();
					return;
				}
				float num = Vector3.Distance(this._startPosition, this._screensContainer.anchoredPosition);
				if (this.UseHardSwipe)
				{
					this._scroll_rect.velocity = Vector3.zero;
					if (num <= (float)this.FastSwipeThreshold)
					{
						base.ScrollToClosestElement();
						return;
					}
					if (this._startPosition.x - this._screensContainer.anchoredPosition.x > 0f)
					{
						base.NextScreen();
						return;
					}
					base.PreviousScreen();
					return;
				}
				else if (this.UseFastSwipe && num < this.panelDimensions.width && num >= (float)this.FastSwipeThreshold)
				{
					this._scroll_rect.velocity = Vector3.zero;
					if (this._startPosition.x - this._screensContainer.anchoredPosition.x > 0f)
					{
						if (this._startPosition.x - this._screensContainer.anchoredPosition.x > this._childSize / 3f)
						{
							base.ScrollToClosestElement();
							return;
						}
						base.NextScreen();
						return;
					}
					else
					{
						if (this._startPosition.x - this._screensContainer.anchoredPosition.x < -this._childSize / 3f)
						{
							base.ScrollToClosestElement();
							return;
						}
						base.PreviousScreen();
					}
				}
			}
		}

		// Token: 0x04000313 RID: 787
		private bool updated = true;
	}
}
