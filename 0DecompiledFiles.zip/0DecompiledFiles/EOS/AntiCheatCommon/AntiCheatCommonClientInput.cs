﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200076D RID: 1901
	public enum AntiCheatCommonClientInput
	{
		// Token: 0x0400147F RID: 5247
		Unknown,
		// Token: 0x04001480 RID: 5248
		MouseKeyboard,
		// Token: 0x04001481 RID: 5249
		Gamepad,
		// Token: 0x04001482 RID: 5250
		TouchInput
	}
}
