﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D1 RID: 209
	public class ColorPickerPresets : MonoBehaviour
	{
		// Token: 0x1700012C RID: 300
		// (get) Token: 0x060006EE RID: 1774 RVA: 0x000276DC File Offset: 0x000258DC
		public virtual string JsonFilePath
		{
			get
			{
				return Application.persistentDataPath + "/" + this.playerPrefsKey + ".json";
			}
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x000276F8 File Offset: 0x000258F8
		protected virtual void Reset()
		{
			this.playerPrefsKey = "colorpicker_" + base.GetInstanceID().ToString();
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x00027724 File Offset: 0x00025924
		protected virtual void Awake()
		{
			this.picker.onHSVChanged.AddListener(new UnityAction<float, float, float>(this.HSVChanged));
			this.picker.onValueChanged.AddListener(new UnityAction<Color>(this.ColorChanged));
			this.picker.CurrentColor = Color.white;
			this.presetPrefab.SetActive(false);
			this.presets.AddRange(this.predefinedPresets);
			this.LoadPresets(this.saveMode);
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x000277A4 File Offset: 0x000259A4
		public virtual void CreatePresetButton()
		{
			this.CreatePreset(this.picker.CurrentColor);
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x000277B8 File Offset: 0x000259B8
		public virtual void LoadPresets(ColorPickerPresets.SaveType saveType)
		{
			string text = "";
			switch (saveType)
			{
			case ColorPickerPresets.SaveType.None:
				break;
			case ColorPickerPresets.SaveType.PlayerPrefs:
				if (PlayerPrefs.HasKey(this.playerPrefsKey))
				{
					text = PlayerPrefs.GetString(this.playerPrefsKey);
				}
				break;
			case ColorPickerPresets.SaveType.JsonFile:
				if (File.Exists(this.JsonFilePath))
				{
					text = File.ReadAllText(this.JsonFilePath);
				}
				break;
			default:
				throw new NotImplementedException(saveType.ToString());
			}
			if (!string.IsNullOrEmpty(text))
			{
				try
				{
					ColorPickerPresets.JsonColor jsonColor = JsonUtility.FromJson<ColorPickerPresets.JsonColor>(text);
					this.presets.AddRange(jsonColor.GetColors());
				}
				catch (Exception ex)
				{
					Debug.LogException(ex);
				}
			}
			foreach (Color color in this.presets)
			{
				this.CreatePreset(color, true);
			}
		}

		// Token: 0x060006F3 RID: 1779 RVA: 0x000278A4 File Offset: 0x00025AA4
		public virtual void SavePresets(ColorPickerPresets.SaveType saveType)
		{
			if (this.presets == null || this.presets.Count <= 0)
			{
				Debug.LogError("presets cannot be null or empty: " + ((this.presets == null) ? "NULL" : "EMPTY"));
				return;
			}
			ColorPickerPresets.JsonColor jsonColor = new ColorPickerPresets.JsonColor();
			jsonColor.SetColors(this.presets.ToArray());
			string text = JsonUtility.ToJson(jsonColor);
			switch (saveType)
			{
			case ColorPickerPresets.SaveType.None:
				Debug.LogWarning("Called SavePresets with SaveType = None...");
				return;
			case ColorPickerPresets.SaveType.PlayerPrefs:
				PlayerPrefs.SetString(this.playerPrefsKey, text);
				return;
			case ColorPickerPresets.SaveType.JsonFile:
				File.WriteAllText(this.JsonFilePath, text);
				return;
			default:
				throw new NotImplementedException(saveType.ToString());
			}
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x00027954 File Offset: 0x00025B54
		public virtual void CreatePreset(Color color, bool loading)
		{
			this.createButton.gameObject.SetActive(this.presets.Count < this.maxPresets);
			GameObject gameObject = Object.Instantiate<GameObject>(this.presetPrefab, this.presetPrefab.transform.parent);
			gameObject.transform.SetAsLastSibling();
			gameObject.SetActive(true);
			gameObject.GetComponent<Image>().color = color;
			this.createPresetImage.color = Color.white;
			if (!loading)
			{
				this.presets.Add(color);
				this.SavePresets(this.saveMode);
			}
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x000279E7 File Offset: 0x00025BE7
		public virtual void CreatePreset(Color color)
		{
			this.CreatePreset(color, false);
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x000279F1 File Offset: 0x00025BF1
		public virtual void PresetSelect(Image sender)
		{
			this.picker.CurrentColor = sender.color;
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x00027A04 File Offset: 0x00025C04
		protected virtual void HSVChanged(float h, float s, float v)
		{
			this.createPresetImage.color = HSVUtil.ConvertHsvToRgb((double)(h * 360f), (double)s, (double)v, 1f);
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x00027A27 File Offset: 0x00025C27
		protected virtual void ColorChanged(Color color)
		{
			this.createPresetImage.color = color;
		}

		// Token: 0x0400051B RID: 1307
		public ColorPickerControl picker;

		// Token: 0x0400051C RID: 1308
		[SerializeField]
		protected GameObject presetPrefab;

		// Token: 0x0400051D RID: 1309
		[SerializeField]
		protected int maxPresets = 16;

		// Token: 0x0400051E RID: 1310
		[SerializeField]
		protected Color[] predefinedPresets;

		// Token: 0x0400051F RID: 1311
		protected List<Color> presets = new List<Color>();

		// Token: 0x04000520 RID: 1312
		public Image createPresetImage;

		// Token: 0x04000521 RID: 1313
		public Transform createButton;

		// Token: 0x04000522 RID: 1314
		[SerializeField]
		public ColorPickerPresets.SaveType saveMode;

		// Token: 0x04000523 RID: 1315
		[SerializeField]
		protected string playerPrefsKey;

		// Token: 0x02000159 RID: 345
		public enum SaveType
		{
			// Token: 0x040006DB RID: 1755
			None,
			// Token: 0x040006DC RID: 1756
			PlayerPrefs,
			// Token: 0x040006DD RID: 1757
			JsonFile
		}

		// Token: 0x0200015A RID: 346
		protected class JsonColor
		{
			// Token: 0x06000842 RID: 2114 RVA: 0x0002C95C File Offset: 0x0002AB5C
			public void SetColors(Color[] colorsIn)
			{
				this.colors = new Color32[colorsIn.Length];
				for (int i = 0; i < colorsIn.Length; i++)
				{
					this.colors[i] = colorsIn[i];
				}
			}

			// Token: 0x06000843 RID: 2115 RVA: 0x0002C9A0 File Offset: 0x0002ABA0
			public Color[] GetColors()
			{
				Color[] array = new Color[this.colors.Length];
				for (int i = 0; i < this.colors.Length; i++)
				{
					array[i] = this.colors[i];
				}
				return array;
			}

			// Token: 0x040006DE RID: 1758
			public Color32[] colors;
		}
	}
}
