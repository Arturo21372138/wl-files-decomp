﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000061 RID: 97
	[AddComponentMenu("UI/Effects/Extensions/UIScreenEffect")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class UIScreenEffect : MonoBehaviour
	{
		// Token: 0x060002EA RID: 746 RVA: 0x000124BB File Offset: 0x000106BB
		private void Start()
		{
			this.SetMaterial();
		}

		// Token: 0x060002EB RID: 747 RVA: 0x000124C4 File Offset: 0x000106C4
		public void SetMaterial()
		{
			this.mGraphic = base.GetComponent<MaskableGraphic>();
			if (this.mGraphic != null)
			{
				if (this.mGraphic.material == null || this.mGraphic.material.name == "Default UI Material")
				{
					this.mGraphic.material = new Material(ShaderLibrary.GetShaderInstance("UI Extensions/UIScreen"));
					return;
				}
			}
			else
			{
				Debug.LogError("Please attach component to a Graphical UI component");
			}
		}

		// Token: 0x060002EC RID: 748 RVA: 0x0001253F File Offset: 0x0001073F
		public void OnValidate()
		{
			this.SetMaterial();
		}

		// Token: 0x04000242 RID: 578
		private MaskableGraphic mGraphic;
	}
}
