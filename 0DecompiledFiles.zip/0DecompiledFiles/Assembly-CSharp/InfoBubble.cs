﻿using System;
using UnityEngine;

// Token: 0x0200000E RID: 14
public class InfoBubble : MonoBehaviour
{
	// Token: 0x06000020 RID: 32 RVA: 0x00002AFC File Offset: 0x00000CFC
	private void Start()
	{
		this.startOffsetTarget = base.transform.position - this.TrackTarget.position;
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002B20 File Offset: 0x00000D20
	private void Update()
	{
		Vector3 vector = Mathf.Sin(this.WobbleFrequency * Time.timeSinceLevelLoad) * this.WobbleAxis * this.WobbleAmplitude;
		base.transform.Rotate(vector);
		base.transform.position = this.TrackTarget.position + this.startOffsetTarget;
	}

	// Token: 0x0400001E RID: 30
	public Vector3 WobbleAxis = Vector3.one;

	// Token: 0x0400001F RID: 31
	public float WobbleFrequency = 1f;

	// Token: 0x04000020 RID: 32
	public float WobbleAmplitude = 0.25f;

	// Token: 0x04000021 RID: 33
	public Transform TrackTarget;

	// Token: 0x04000022 RID: 34
	private Vector3 startOffsetTarget;
}
