﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D2 RID: 2002
	public struct ReceiveMessageFromServerOptions
	{
		// Token: 0x1700082D RID: 2093
		// (get) Token: 0x06002101 RID: 8449 RVA: 0x000273C9 File Offset: 0x000255C9
		// (set) Token: 0x06002102 RID: 8450 RVA: 0x000273D1 File Offset: 0x000255D1
		public ArraySegment<byte> Data { readonly get; set; }
	}
}
