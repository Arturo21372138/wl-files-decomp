﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C4 RID: 1988
	public struct OnMessageToServerCallbackInfo : ICallbackInfo
	{
		// Token: 0x17000823 RID: 2083
		// (get) Token: 0x060020D5 RID: 8405 RVA: 0x000271C9 File Offset: 0x000253C9
		// (set) Token: 0x060020D6 RID: 8406 RVA: 0x000271D1 File Offset: 0x000253D1
		public object ClientData { readonly get; set; }

		// Token: 0x17000824 RID: 2084
		// (get) Token: 0x060020D7 RID: 8407 RVA: 0x000271DA File Offset: 0x000253DA
		// (set) Token: 0x060020D8 RID: 8408 RVA: 0x000271E2 File Offset: 0x000253E2
		public ArraySegment<byte> MessageData { readonly get; set; }

		// Token: 0x060020D9 RID: 8409 RVA: 0x000271EB File Offset: 0x000253EB
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060020DA RID: 8410 RVA: 0x000271F4 File Offset: 0x000253F4
		public Result? GetResultCode()
		{
			return null;
		}
	}
}
