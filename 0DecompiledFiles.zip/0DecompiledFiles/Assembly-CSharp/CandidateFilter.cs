﻿using System;
using System.Collections.Generic;
using ch.sycoforge.Decal;
using ch.sycoforge.Decal.Projectors;
using UnityEngine;

// Token: 0x0200000C RID: 12
[RequireComponent(typeof(EasyDecal))]
public class CandidateFilter : MonoBehaviour
{
	// Token: 0x0600001B RID: 27 RVA: 0x000029E0 File Offset: 0x00000BE0
	private void Start()
	{
		this.decal = base.GetComponent<EasyDecal>();
		ch.sycoforge.Decal.Projectors.Projector projector = this.decal.Projector;
		if (projector != null && projector is BoxProjector)
		{
			(projector as BoxProjector).OnCandidatesProcessed += this.bp_OnCandidatesProcessed;
		}
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002A28 File Offset: 0x00000C28
	private void bp_OnCandidatesProcessed(List<Collider> colliders)
	{
		List<Collider> list = new List<Collider>();
		foreach (Collider collider in colliders)
		{
			if (!collider.gameObject.Equals(this.ExclusiveReceiver))
			{
				list.Add(collider);
			}
		}
		foreach (Collider collider2 in list)
		{
			colliders.Remove(collider2);
		}
	}

	// Token: 0x0400001C RID: 28
	public GameObject ExclusiveReceiver;

	// Token: 0x0400001D RID: 29
	private EasyDecal decal;
}
