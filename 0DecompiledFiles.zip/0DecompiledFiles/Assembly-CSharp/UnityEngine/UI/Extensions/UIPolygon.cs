﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A0 RID: 160
	[AddComponentMenu("UI/Extensions/Primitives/UI Polygon")]
	public class UIPolygon : UIPrimitiveBase
	{
		// Token: 0x06000556 RID: 1366 RVA: 0x000202AC File Offset: 0x0001E4AC
		public void DrawPolygon(int _sides)
		{
			this.sides = _sides;
			this.VerticesDistances = new float[_sides + 1];
			for (int i = 0; i < _sides; i++)
			{
				this.VerticesDistances[i] = 1f;
			}
			this.rotation = 0f;
			this.SetAllDirty();
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x000202F8 File Offset: 0x0001E4F8
		public void DrawPolygon(int _sides, float[] _VerticesDistances)
		{
			this.sides = _sides;
			this.VerticesDistances = _VerticesDistances;
			this.rotation = 0f;
			this.SetAllDirty();
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x00020319 File Offset: 0x0001E519
		public void DrawPolygon(int _sides, float[] _VerticesDistances, float _rotation)
		{
			this.sides = _sides;
			this.VerticesDistances = _VerticesDistances;
			this.rotation = _rotation;
			this.SetAllDirty();
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00020338 File Offset: 0x0001E538
		private void Update()
		{
			this.size = base.rectTransform.rect.width;
			if (base.rectTransform.rect.width > base.rectTransform.rect.height)
			{
				this.size = base.rectTransform.rect.height;
			}
			else
			{
				this.size = base.rectTransform.rect.width;
			}
			this.thickness = Mathf.Clamp(this.thickness, 0f, this.size / 2f);
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x000203E0 File Offset: 0x0001E5E0
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			vh.Clear();
			Vector2 vector = Vector2.zero;
			Vector2 vector2 = Vector2.zero;
			Vector2 vector3 = new Vector2(0f, 0f);
			Vector2 vector4 = new Vector2(0f, 1f);
			Vector2 vector5 = new Vector2(1f, 1f);
			Vector2 vector6 = new Vector2(1f, 0f);
			float num = 360f / (float)this.sides;
			int num2 = this.sides + 1;
			if (this.VerticesDistances.Length != num2)
			{
				this.VerticesDistances = new float[num2];
				for (int i = 0; i < num2 - 1; i++)
				{
					this.VerticesDistances[i] = 1f;
				}
			}
			this.VerticesDistances[num2 - 1] = this.VerticesDistances[0];
			for (int j = 0; j < num2; j++)
			{
				float num3 = -base.rectTransform.pivot.x * this.size * this.VerticesDistances[j];
				float num4 = -base.rectTransform.pivot.x * this.size * this.VerticesDistances[j] + this.thickness;
				float num5 = 0.017453292f * ((float)j * num + this.rotation);
				float num6 = Mathf.Cos(num5);
				float num7 = Mathf.Sin(num5);
				vector3 = new Vector2(0f, 1f);
				vector4 = new Vector2(1f, 1f);
				vector5 = new Vector2(1f, 0f);
				vector6 = new Vector2(0f, 0f);
				Vector2 vector7 = vector;
				Vector2 vector8 = new Vector2(num3 * num6, num3 * num7);
				Vector2 zero;
				Vector2 vector9;
				if (this.fill)
				{
					zero = Vector2.zero;
					vector9 = Vector2.zero;
				}
				else
				{
					zero = new Vector2(num4 * num6, num4 * num7);
					vector9 = vector2;
				}
				vector = vector8;
				vector2 = zero;
				vh.AddUIVertexQuad(base.SetVbo(new Vector2[] { vector7, vector8, zero, vector9 }, new Vector2[] { vector3, vector4, vector5, vector6 }));
			}
		}

		// Token: 0x040003F2 RID: 1010
		public bool fill = true;

		// Token: 0x040003F3 RID: 1011
		public float thickness = 5f;

		// Token: 0x040003F4 RID: 1012
		[Range(3f, 360f)]
		public int sides = 3;

		// Token: 0x040003F5 RID: 1013
		[Range(0f, 360f)]
		public float rotation;

		// Token: 0x040003F6 RID: 1014
		[Range(0f, 1f)]
		public float[] VerticesDistances = new float[3];

		// Token: 0x040003F7 RID: 1015
		private float size;
	}
}
