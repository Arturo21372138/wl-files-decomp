﻿using System;
using UnityEngine.Events;
using UnityEngine.UI.Extensions.Tweens;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200002E RID: 46
	[RequireComponent(typeof(RectTransform), typeof(LayoutElement))]
	[AddComponentMenu("UI/Extensions/Accordion/Accordion Element")]
	public class AccordionElement : Toggle
	{
		// Token: 0x17000008 RID: 8
		// (get) Token: 0x060000AB RID: 171 RVA: 0x000055F0 File Offset: 0x000037F0
		public float MinHeight
		{
			get
			{
				return this.m_MinHeight;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x060000AC RID: 172 RVA: 0x000055F8 File Offset: 0x000037F8
		public float MinWidth
		{
			get
			{
				return this.m_MinWidth;
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00005600 File Offset: 0x00003800
		protected AccordionElement()
		{
			if (this.m_FloatTweenRunner == null)
			{
				this.m_FloatTweenRunner = new TweenRunner<FloatTween>();
			}
			this.m_FloatTweenRunner.Init(this);
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00005640 File Offset: 0x00003840
		protected override void Awake()
		{
			base.Awake();
			base.transition = Selectable.Transition.None;
			this.toggleTransition = Toggle.ToggleTransition.None;
			this.m_Accordion = base.gameObject.GetComponentInParent<Accordion>();
			this.m_RectTransform = base.transform as RectTransform;
			this.m_LayoutElement = base.gameObject.GetComponent<LayoutElement>();
			this.onValueChanged.AddListener(new UnityAction<bool>(this.OnValueChanged));
		}

		// Token: 0x060000AF RID: 175 RVA: 0x000056AC File Offset: 0x000038AC
		public void OnValueChanged(bool state)
		{
			if (this.m_LayoutElement == null)
			{
				return;
			}
			Accordion.Transition transition = ((this.m_Accordion != null) ? this.m_Accordion.transition : Accordion.Transition.Instant);
			if (transition != Accordion.Transition.Instant)
			{
				if (transition == Accordion.Transition.Tween)
				{
					if (state)
					{
						if (this.m_Accordion.ExpandVerticval)
						{
							this.StartTween(this.m_MinHeight, this.GetExpandedHeight());
							return;
						}
						this.StartTween(this.m_MinWidth, this.GetExpandedWidth());
						return;
					}
					else
					{
						if (this.m_Accordion.ExpandVerticval)
						{
							this.StartTween(this.m_RectTransform.rect.height, this.m_MinHeight);
							return;
						}
						this.StartTween(this.m_RectTransform.rect.width, this.m_MinWidth);
					}
				}
				return;
			}
			if (state)
			{
				if (this.m_Accordion.ExpandVerticval)
				{
					this.m_LayoutElement.preferredHeight = -1f;
					return;
				}
				this.m_LayoutElement.preferredWidth = -1f;
				return;
			}
			else
			{
				if (this.m_Accordion.ExpandVerticval)
				{
					this.m_LayoutElement.preferredHeight = this.m_MinHeight;
					return;
				}
				this.m_LayoutElement.preferredWidth = this.m_MinWidth;
				return;
			}
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x000057D4 File Offset: 0x000039D4
		protected float GetExpandedHeight()
		{
			if (this.m_LayoutElement == null)
			{
				return this.m_MinHeight;
			}
			float preferredHeight = this.m_LayoutElement.preferredHeight;
			this.m_LayoutElement.preferredHeight = -1f;
			float preferredHeight2 = LayoutUtility.GetPreferredHeight(this.m_RectTransform);
			this.m_LayoutElement.preferredHeight = preferredHeight;
			return preferredHeight2;
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x0000582C File Offset: 0x00003A2C
		protected float GetExpandedWidth()
		{
			if (this.m_LayoutElement == null)
			{
				return this.m_MinWidth;
			}
			float preferredWidth = this.m_LayoutElement.preferredWidth;
			this.m_LayoutElement.preferredWidth = -1f;
			float preferredWidth2 = LayoutUtility.GetPreferredWidth(this.m_RectTransform);
			this.m_LayoutElement.preferredWidth = preferredWidth;
			return preferredWidth2;
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00005884 File Offset: 0x00003A84
		protected void StartTween(float startFloat, float targetFloat)
		{
			float num = ((this.m_Accordion != null) ? this.m_Accordion.transitionDuration : 0.3f);
			FloatTween floatTween = new FloatTween
			{
				duration = num,
				startFloat = startFloat,
				targetFloat = targetFloat
			};
			if (this.m_Accordion.ExpandVerticval)
			{
				floatTween.AddOnChangedCallback(new UnityAction<float>(this.SetHeight));
			}
			else
			{
				floatTween.AddOnChangedCallback(new UnityAction<float>(this.SetWidth));
			}
			floatTween.ignoreTimeScale = true;
			this.m_FloatTweenRunner.StartTween(floatTween);
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0000591D File Offset: 0x00003B1D
		protected void SetHeight(float height)
		{
			if (this.m_LayoutElement == null)
			{
				return;
			}
			this.m_LayoutElement.preferredHeight = height;
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x0000593A File Offset: 0x00003B3A
		protected void SetWidth(float width)
		{
			if (this.m_LayoutElement == null)
			{
				return;
			}
			this.m_LayoutElement.preferredWidth = width;
		}

		// Token: 0x040000BA RID: 186
		[SerializeField]
		private float m_MinHeight = 18f;

		// Token: 0x040000BB RID: 187
		[SerializeField]
		private float m_MinWidth = 40f;

		// Token: 0x040000BC RID: 188
		private Accordion m_Accordion;

		// Token: 0x040000BD RID: 189
		private RectTransform m_RectTransform;

		// Token: 0x040000BE RID: 190
		private LayoutElement m_LayoutElement;

		// Token: 0x040000BF RID: 191
		[NonSerialized]
		private readonly TweenRunner<FloatTween> m_FloatTweenRunner;
	}
}
