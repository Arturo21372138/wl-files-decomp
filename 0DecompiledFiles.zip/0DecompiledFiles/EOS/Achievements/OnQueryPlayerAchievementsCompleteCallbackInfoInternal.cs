﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200080E RID: 2062
	internal struct OnQueryPlayerAchievementsCompleteCallbackInfoInternal : ICallbackInfoInternal, IGettable<OnQueryPlayerAchievementsCompleteCallbackInfo>
	{
		// Token: 0x17000871 RID: 2161
		// (get) Token: 0x060021EA RID: 8682 RVA: 0x00028536 File Offset: 0x00026736
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x060021EB RID: 8683 RVA: 0x00028540 File Offset: 0x00026740
		public void Get(out OnQueryPlayerAchievementsCompleteCallbackInfo other)
		{
			other = default(OnQueryPlayerAchievementsCompleteCallbackInfo);
			other.ResultCode = this.m_ResultCode;
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
			ProductUserId productUserId;
			Helper.Get<ProductUserId>(this.m_TargetUserId, out productUserId);
			other.TargetUserId = productUserId;
			ProductUserId productUserId2;
			Helper.Get<ProductUserId>(this.m_LocalUserId, out productUserId2);
			other.LocalUserId = productUserId2;
		}

		// Token: 0x0400169E RID: 5790
		private Result m_ResultCode;

		// Token: 0x0400169F RID: 5791
		private IntPtr m_ClientData;

		// Token: 0x040016A0 RID: 5792
		private IntPtr m_TargetUserId;

		// Token: 0x040016A1 RID: 5793
		private IntPtr m_LocalUserId;
	}
}
