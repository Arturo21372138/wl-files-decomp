﻿using System;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200003F RID: 63
	[RequireComponent(typeof(RectTransform), typeof(LayoutElement))]
	public class ReorderableListElement : MonoBehaviour, IDragHandler, IEventSystemHandler, IBeginDragHandler, IEndDragHandler
	{
		// Token: 0x17000043 RID: 67
		// (get) Token: 0x060001AD RID: 429 RVA: 0x000096A0 File Offset: 0x000078A0
		// (set) Token: 0x060001AE RID: 430 RVA: 0x000096A8 File Offset: 0x000078A8
		public bool IsTransferable
		{
			get
			{
				return this._isTransferable;
			}
			set
			{
				this._canvasGroup = base.gameObject.GetOrAddComponent<CanvasGroup>();
				this._canvasGroup.blocksRaycasts = value;
				this._isTransferable = value;
			}
		}

		// Token: 0x060001AF RID: 431 RVA: 0x000096D0 File Offset: 0x000078D0
		public void OnBeginDrag(PointerEventData eventData)
		{
			if (!this._canvasGroup)
			{
				this._canvasGroup = base.gameObject.GetOrAddComponent<CanvasGroup>();
			}
			this._canvasGroup.blocksRaycasts = false;
			this.isValid = true;
			if (this._reorderableList == null)
			{
				return;
			}
			if (!this._reorderableList.IsDraggable || !this.IsGrabbable)
			{
				this._draggingObject = null;
				return;
			}
			if (!this._reorderableList.CloneDraggedObject)
			{
				this._draggingObject = this._rect;
				this._fromIndex = this._rect.GetSiblingIndex();
				this._displacedFromIndex = -1;
				if (this._reorderableList.OnElementRemoved != null)
				{
					UnityEvent<ReorderableList.ReorderableListEventStruct> onElementRemoved = this._reorderableList.OnElementRemoved;
					ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
					{
						DroppedObject = this._draggingObject.gameObject,
						IsAClone = this._reorderableList.CloneDraggedObject,
						SourceObject = (this._reorderableList.CloneDraggedObject ? base.gameObject : this._draggingObject.gameObject),
						FromList = this._reorderableList,
						FromIndex = this._fromIndex
					};
					onElementRemoved.Invoke(reorderableListEventStruct);
				}
				if (!this.isValid)
				{
					this._draggingObject = null;
					return;
				}
			}
			else
			{
				GameObject gameObject = Object.Instantiate<GameObject>(base.gameObject);
				this._draggingObject = gameObject.GetComponent<RectTransform>();
			}
			this._draggingObjectOriginalSize = base.gameObject.GetComponent<RectTransform>().rect.size;
			this._draggingObjectLE = this._draggingObject.GetComponent<LayoutElement>();
			this._draggingObject.SetParent(this._reorderableList.DraggableArea, true);
			this._draggingObject.SetAsLastSibling();
			this._reorderableList.Refresh();
			this._fakeElement = new GameObject("Fake").AddComponent<RectTransform>();
			this._fakeElementLE = this._fakeElement.gameObject.AddComponent<LayoutElement>();
			this.RefreshSizes();
			if (this._reorderableList.OnElementGrabbed != null)
			{
				UnityEvent<ReorderableList.ReorderableListEventStruct> onElementGrabbed = this._reorderableList.OnElementGrabbed;
				ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
				{
					DroppedObject = this._draggingObject.gameObject,
					IsAClone = this._reorderableList.CloneDraggedObject,
					SourceObject = (this._reorderableList.CloneDraggedObject ? base.gameObject : this._draggingObject.gameObject),
					FromList = this._reorderableList,
					FromIndex = this._fromIndex
				};
				onElementGrabbed.Invoke(reorderableListEventStruct);
				if (!this.isValid)
				{
					this.CancelDrag();
					return;
				}
			}
			this._isDragging = true;
		}

		// Token: 0x060001B0 RID: 432 RVA: 0x00009954 File Offset: 0x00007B54
		public void OnDrag(PointerEventData eventData)
		{
			if (!this._isDragging)
			{
				return;
			}
			if (!this.isValid)
			{
				this.CancelDrag();
				return;
			}
			Canvas componentInParent = this._draggingObject.GetComponentInParent<Canvas>();
			Vector3 vector;
			RectTransformUtility.ScreenPointToWorldPointInRectangle(componentInParent.GetComponent<RectTransform>(), eventData.position, (componentInParent.renderMode != RenderMode.ScreenSpaceOverlay) ? componentInParent.worldCamera : null, out vector);
			this._draggingObject.position = vector;
			ReorderableList currentReorderableListRaycasted = this._currentReorderableListRaycasted;
			EventSystem.current.RaycastAll(eventData, this._raycastResults);
			for (int i = 0; i < this._raycastResults.Count; i++)
			{
				this._currentReorderableListRaycasted = this._raycastResults[i].gameObject.GetComponent<ReorderableList>();
				if (this._currentReorderableListRaycasted != null)
				{
					break;
				}
			}
			if (this._currentReorderableListRaycasted == null || !this._currentReorderableListRaycasted.IsDropable || (((this._fakeElement.parent == this._currentReorderableListRaycasted.Content) ? (this._currentReorderableListRaycasted.Content.childCount - 1) : this._currentReorderableListRaycasted.Content.childCount) >= this._currentReorderableListRaycasted.maxItems && !this._currentReorderableListRaycasted.IsDisplacable) || this._currentReorderableListRaycasted.maxItems <= 0)
			{
				this.RefreshSizes();
				this._fakeElement.transform.SetParent(this._reorderableList.DraggableArea, false);
				if (this._displacedObject != null)
				{
					this.revertDisplacedElement();
					return;
				}
			}
			else
			{
				if (this._currentReorderableListRaycasted.Content.childCount < this._currentReorderableListRaycasted.maxItems && this._fakeElement.parent != this._currentReorderableListRaycasted.Content)
				{
					this._fakeElement.SetParent(this._currentReorderableListRaycasted.Content, false);
				}
				float num = float.PositiveInfinity;
				int num2 = 0;
				float num3 = 0f;
				for (int j = 0; j < this._currentReorderableListRaycasted.Content.childCount; j++)
				{
					RectTransform component = this._currentReorderableListRaycasted.Content.GetChild(j).GetComponent<RectTransform>();
					if (this._currentReorderableListRaycasted.ContentLayout is VerticalLayoutGroup)
					{
						num3 = Mathf.Abs(component.position.y - vector.y);
					}
					else if (this._currentReorderableListRaycasted.ContentLayout is HorizontalLayoutGroup)
					{
						num3 = Mathf.Abs(component.position.x - vector.x);
					}
					else if (this._currentReorderableListRaycasted.ContentLayout is GridLayoutGroup)
					{
						num3 = Mathf.Abs(component.position.x - vector.x) + Mathf.Abs(component.position.y - vector.y);
					}
					if (num3 < num)
					{
						num = num3;
						num2 = j;
					}
				}
				if ((this._currentReorderableListRaycasted != currentReorderableListRaycasted || num2 != this._displacedFromIndex) && this._currentReorderableListRaycasted.Content.childCount == this._currentReorderableListRaycasted.maxItems)
				{
					Transform child = this._currentReorderableListRaycasted.Content.GetChild(num2);
					if (this._displacedObject != null)
					{
						this.revertDisplacedElement();
						if (this._currentReorderableListRaycasted.Content.childCount > this._currentReorderableListRaycasted.maxItems)
						{
							this.displaceElement(num2, child);
						}
					}
					else if (this._fakeElement.parent != this._currentReorderableListRaycasted.Content)
					{
						this._fakeElement.SetParent(this._currentReorderableListRaycasted.Content, false);
						this.displaceElement(num2, child);
					}
				}
				this.RefreshSizes();
				this._fakeElement.SetSiblingIndex(num2);
				this._fakeElement.gameObject.SetActive(true);
			}
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x00009D10 File Offset: 0x00007F10
		private void displaceElement(int targetIndex, Transform displaced)
		{
			this._displacedFromIndex = targetIndex;
			this._displacedObjectOriginList = this._currentReorderableListRaycasted;
			this._displacedObject = displaced.GetComponent<RectTransform>();
			this._displacedObjectLE = this._displacedObject.GetComponent<LayoutElement>();
			this._displacedObjectOriginalSize = this._displacedObject.rect.size;
			ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
			{
				DroppedObject = this._displacedObject.gameObject,
				FromList = this._currentReorderableListRaycasted,
				FromIndex = targetIndex
			};
			int num = ((this._fakeElement.parent == this._reorderableList.Content) ? (this._reorderableList.Content.childCount - 1) : this._reorderableList.Content.childCount);
			if (this._reorderableList.IsDropable && num < this._reorderableList.maxItems && this._displacedObject.GetComponent<ReorderableListElement>().IsTransferable)
			{
				this._displacedObjectLE.preferredWidth = this._draggingObjectOriginalSize.x;
				this._displacedObjectLE.preferredHeight = this._draggingObjectOriginalSize.y;
				this._displacedObject.SetParent(this._reorderableList.Content, false);
				this._displacedObject.rotation = this._reorderableList.transform.rotation;
				this._displacedObject.SetSiblingIndex(this._fromIndex);
				this._reorderableList.Refresh();
				this._currentReorderableListRaycasted.Refresh();
				reorderableListEventStruct.ToList = this._reorderableList;
				reorderableListEventStruct.ToIndex = this._fromIndex;
				this._reorderableList.OnElementDisplacedTo.Invoke(reorderableListEventStruct);
				this._reorderableList.OnElementAdded.Invoke(reorderableListEventStruct);
			}
			else if (this._displacedObject.GetComponent<ReorderableListElement>().isDroppableInSpace)
			{
				this._displacedObject.SetParent(this._currentReorderableListRaycasted.DraggableArea, true);
				this._currentReorderableListRaycasted.Refresh();
				this._displacedObject.position += new Vector3(this._draggingObjectOriginalSize.x / 2f, this._draggingObjectOriginalSize.y / 2f, 0f);
			}
			else
			{
				this._displacedObject.SetParent(null, true);
				this._displacedObjectOriginList.Refresh();
				this._displacedObject.gameObject.SetActive(false);
			}
			this._displacedObjectOriginList.OnElementDisplacedFrom.Invoke(reorderableListEventStruct);
			this._reorderableList.OnElementRemoved.Invoke(reorderableListEventStruct);
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x00009F98 File Offset: 0x00008198
		private void revertDisplacedElement()
		{
			ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
			{
				DroppedObject = this._displacedObject.gameObject,
				FromList = this._displacedObjectOriginList,
				FromIndex = this._displacedFromIndex
			};
			if (this._displacedObject.parent != null)
			{
				reorderableListEventStruct.ToList = this._reorderableList;
				reorderableListEventStruct.ToIndex = this._fromIndex;
			}
			this._displacedObjectLE.preferredWidth = this._displacedObjectOriginalSize.x;
			this._displacedObjectLE.preferredHeight = this._displacedObjectOriginalSize.y;
			this._displacedObject.SetParent(this._displacedObjectOriginList.Content, false);
			this._displacedObject.rotation = this._displacedObjectOriginList.transform.rotation;
			this._displacedObject.SetSiblingIndex(this._displacedFromIndex);
			this._displacedObject.gameObject.SetActive(true);
			this._reorderableList.Refresh();
			this._displacedObjectOriginList.Refresh();
			if (reorderableListEventStruct.ToList != null)
			{
				this._reorderableList.OnElementDisplacedToReturned.Invoke(reorderableListEventStruct);
				this._reorderableList.OnElementRemoved.Invoke(reorderableListEventStruct);
			}
			this._displacedObjectOriginList.OnElementDisplacedFromReturned.Invoke(reorderableListEventStruct);
			this._displacedObjectOriginList.OnElementAdded.Invoke(reorderableListEventStruct);
			this._displacedFromIndex = -1;
			this._displacedObjectOriginList = null;
			this._displacedObject = null;
			this._displacedObjectLE = null;
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x0000A10C File Offset: 0x0000830C
		public void finishDisplacingElement()
		{
			if (this._displacedObject.parent == null)
			{
				Object.Destroy(this._displacedObject.gameObject);
			}
			this._displacedFromIndex = -1;
			this._displacedObjectOriginList = null;
			this._displacedObject = null;
			this._displacedObjectLE = null;
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x0000A158 File Offset: 0x00008358
		public void OnEndDrag(PointerEventData eventData)
		{
			this._isDragging = false;
			if (this._draggingObject != null)
			{
				if (this._currentReorderableListRaycasted != null && this._fakeElement.parent == this._currentReorderableListRaycasted.Content)
				{
					ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
					{
						DroppedObject = this._draggingObject.gameObject,
						IsAClone = this._reorderableList.CloneDraggedObject,
						SourceObject = (this._reorderableList.CloneDraggedObject ? base.gameObject : this._draggingObject.gameObject),
						FromList = this._reorderableList,
						FromIndex = this._fromIndex,
						ToList = this._currentReorderableListRaycasted,
						ToIndex = this._fakeElement.GetSiblingIndex()
					};
					ReorderableList.ReorderableListEventStruct reorderableListEventStruct2 = reorderableListEventStruct;
					if (this._reorderableList && this._reorderableList.OnElementDropped != null)
					{
						this._reorderableList.OnElementDropped.Invoke(reorderableListEventStruct2);
					}
					if (!this.isValid)
					{
						this.CancelDrag();
						return;
					}
					this.RefreshSizes();
					this._draggingObject.SetParent(this._currentReorderableListRaycasted.Content, false);
					this._draggingObject.rotation = this._currentReorderableListRaycasted.transform.rotation;
					this._draggingObject.SetSiblingIndex(this._fakeElement.GetSiblingIndex());
					if (this.IsTransferable)
					{
						this._draggingObject.GetComponent<CanvasGroup>().blocksRaycasts = true;
					}
					this._reorderableList.Refresh();
					this._currentReorderableListRaycasted.Refresh();
					this._reorderableList.OnElementAdded.Invoke(reorderableListEventStruct2);
					if (this._displacedObject != null)
					{
						this.finishDisplacingElement();
					}
					if (!this.isValid)
					{
						throw new Exception("It's too late to cancel the Transfer! Do so in OnElementDropped!");
					}
				}
				else
				{
					if (this.isDroppableInSpace)
					{
						UnityEvent<ReorderableList.ReorderableListEventStruct> onElementDropped = this._reorderableList.OnElementDropped;
						ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
						{
							DroppedObject = this._draggingObject.gameObject,
							IsAClone = this._reorderableList.CloneDraggedObject,
							SourceObject = (this._reorderableList.CloneDraggedObject ? base.gameObject : this._draggingObject.gameObject),
							FromList = this._reorderableList,
							FromIndex = this._fromIndex
						};
						onElementDropped.Invoke(reorderableListEventStruct);
					}
					else
					{
						this.CancelDrag();
					}
					if (this._currentReorderableListRaycasted != null && ((this._currentReorderableListRaycasted.Content.childCount >= this._currentReorderableListRaycasted.maxItems && !this._currentReorderableListRaycasted.IsDisplacable) || this._currentReorderableListRaycasted.maxItems <= 0))
					{
						GameObject gameObject = this._draggingObject.gameObject;
						UnityEvent<ReorderableList.ReorderableListEventStruct> onElementDroppedWithMaxItems = this._reorderableList.OnElementDroppedWithMaxItems;
						ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
						{
							DroppedObject = gameObject,
							IsAClone = this._reorderableList.CloneDraggedObject,
							SourceObject = (this._reorderableList.CloneDraggedObject ? base.gameObject : gameObject),
							FromList = this._reorderableList,
							ToList = this._currentReorderableListRaycasted,
							FromIndex = this._fromIndex
						};
						onElementDroppedWithMaxItems.Invoke(reorderableListEventStruct);
					}
				}
			}
			if (this._fakeElement != null)
			{
				Object.Destroy(this._fakeElement.gameObject);
				this._fakeElement = null;
			}
			this._canvasGroup.blocksRaycasts = true;
		}

		// Token: 0x060001B5 RID: 437 RVA: 0x0000A4C0 File Offset: 0x000086C0
		private void CancelDrag()
		{
			this._isDragging = false;
			if (this._reorderableList.CloneDraggedObject)
			{
				Object.Destroy(this._draggingObject.gameObject);
			}
			else
			{
				this.RefreshSizes();
				this._draggingObject.SetParent(this._reorderableList.Content, false);
				this._draggingObject.rotation = this._reorderableList.Content.transform.rotation;
				this._draggingObject.SetSiblingIndex(this._fromIndex);
				ReorderableList.ReorderableListEventStruct reorderableListEventStruct = new ReorderableList.ReorderableListEventStruct
				{
					DroppedObject = this._draggingObject.gameObject,
					IsAClone = this._reorderableList.CloneDraggedObject,
					SourceObject = (this._reorderableList.CloneDraggedObject ? base.gameObject : this._draggingObject.gameObject),
					FromList = this._reorderableList,
					FromIndex = this._fromIndex,
					ToList = this._reorderableList,
					ToIndex = this._fromIndex
				};
				this._reorderableList.Refresh();
				this._reorderableList.OnElementAdded.Invoke(reorderableListEventStruct);
				if (!this.isValid)
				{
					throw new Exception("Transfer is already Canceled.");
				}
			}
			if (this._fakeElement != null)
			{
				Object.Destroy(this._fakeElement.gameObject);
				this._fakeElement = null;
			}
			if (this._displacedObject != null)
			{
				this.revertDisplacedElement();
			}
			this._canvasGroup.blocksRaycasts = true;
		}

		// Token: 0x060001B6 RID: 438 RVA: 0x0000A644 File Offset: 0x00008844
		private void RefreshSizes()
		{
			Vector2 vector = this._draggingObjectOriginalSize;
			if (this._currentReorderableListRaycasted != null && this._currentReorderableListRaycasted.IsDropable && this._currentReorderableListRaycasted.Content.childCount > 0 && this._currentReorderableListRaycasted.EqualizeSizesOnDrag)
			{
				Transform child = this._currentReorderableListRaycasted.Content.GetChild(0);
				if (child != null)
				{
					vector = child.GetComponent<RectTransform>().rect.size;
				}
			}
			this._draggingObject.sizeDelta = vector;
			this._fakeElementLE.preferredHeight = (this._draggingObjectLE.preferredHeight = vector.y);
			this._fakeElementLE.preferredWidth = (this._draggingObjectLE.preferredWidth = vector.x);
			this._fakeElement.GetComponent<RectTransform>().sizeDelta = vector;
		}

		// Token: 0x060001B7 RID: 439 RVA: 0x0000A71D File Offset: 0x0000891D
		public void Init(ReorderableList reorderableList)
		{
			this._reorderableList = reorderableList;
			this._rect = base.GetComponent<RectTransform>();
			this._canvasGroup = base.gameObject.GetOrAddComponent<CanvasGroup>();
		}

		// Token: 0x04000180 RID: 384
		[Tooltip("Can this element be dragged?")]
		[SerializeField]
		private bool IsGrabbable = true;

		// Token: 0x04000181 RID: 385
		[Tooltip("Can this element be transfered to another list")]
		[SerializeField]
		private bool _isTransferable = true;

		// Token: 0x04000182 RID: 386
		[Tooltip("Can this element be dropped in space?")]
		[SerializeField]
		private bool isDroppableInSpace;

		// Token: 0x04000183 RID: 387
		private readonly List<RaycastResult> _raycastResults = new List<RaycastResult>();

		// Token: 0x04000184 RID: 388
		private ReorderableList _currentReorderableListRaycasted;

		// Token: 0x04000185 RID: 389
		private int _fromIndex;

		// Token: 0x04000186 RID: 390
		private RectTransform _draggingObject;

		// Token: 0x04000187 RID: 391
		private LayoutElement _draggingObjectLE;

		// Token: 0x04000188 RID: 392
		private Vector2 _draggingObjectOriginalSize;

		// Token: 0x04000189 RID: 393
		private RectTransform _fakeElement;

		// Token: 0x0400018A RID: 394
		private LayoutElement _fakeElementLE;

		// Token: 0x0400018B RID: 395
		private int _displacedFromIndex;

		// Token: 0x0400018C RID: 396
		private RectTransform _displacedObject;

		// Token: 0x0400018D RID: 397
		private LayoutElement _displacedObjectLE;

		// Token: 0x0400018E RID: 398
		private Vector2 _displacedObjectOriginalSize;

		// Token: 0x0400018F RID: 399
		private ReorderableList _displacedObjectOriginList;

		// Token: 0x04000190 RID: 400
		private bool _isDragging;

		// Token: 0x04000191 RID: 401
		private RectTransform _rect;

		// Token: 0x04000192 RID: 402
		private ReorderableList _reorderableList;

		// Token: 0x04000193 RID: 403
		private CanvasGroup _canvasGroup;

		// Token: 0x04000194 RID: 404
		internal bool isValid;
	}
}
