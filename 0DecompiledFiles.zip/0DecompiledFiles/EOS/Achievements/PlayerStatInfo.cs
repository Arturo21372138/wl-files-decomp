﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000816 RID: 2070
	public struct PlayerStatInfo
	{
		// Token: 0x17000880 RID: 2176
		// (get) Token: 0x06002213 RID: 8723 RVA: 0x000287D2 File Offset: 0x000269D2
		// (set) Token: 0x06002214 RID: 8724 RVA: 0x000287DA File Offset: 0x000269DA
		public Utf8String Name { readonly get; set; }

		// Token: 0x17000881 RID: 2177
		// (get) Token: 0x06002215 RID: 8725 RVA: 0x000287E3 File Offset: 0x000269E3
		// (set) Token: 0x06002216 RID: 8726 RVA: 0x000287EB File Offset: 0x000269EB
		public int CurrentValue { readonly get; set; }

		// Token: 0x17000882 RID: 2178
		// (get) Token: 0x06002217 RID: 8727 RVA: 0x000287F4 File Offset: 0x000269F4
		// (set) Token: 0x06002218 RID: 8728 RVA: 0x000287FC File Offset: 0x000269FC
		public int ThresholdValue { readonly get; set; }
	}
}
