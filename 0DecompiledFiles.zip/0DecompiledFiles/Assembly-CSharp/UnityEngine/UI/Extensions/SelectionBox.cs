﻿using System;
using System.Collections.Generic;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000047 RID: 71
	[RequireComponent(typeof(Canvas))]
	[AddComponentMenu("UI/Extensions/Selection Box")]
	public class SelectionBox : MonoBehaviour
	{
		// Token: 0x060001FF RID: 511 RVA: 0x0000B740 File Offset: 0x00009940
		private void ValidateCanvas()
		{
			if (base.gameObject.GetComponent<Canvas>().renderMode != RenderMode.ScreenSpaceOverlay)
			{
				throw new Exception("SelectionBox component must be placed on a canvas in Screen Space Overlay mode.");
			}
			CanvasScaler component = base.gameObject.GetComponent<CanvasScaler>();
			if (component && component.enabled && (!Mathf.Approximately(component.scaleFactor, 1f) || component.uiScaleMode != CanvasScaler.ScaleMode.ConstantPixelSize))
			{
				Object.Destroy(component);
				Debug.LogWarning("SelectionBox component is on a gameObject with a Canvas Scaler component. As of now, Canvas Scalers without the default settings throw off the coordinates of the selection box. Canvas Scaler has been removed.");
			}
		}

		// Token: 0x06000200 RID: 512 RVA: 0x0000B7B0 File Offset: 0x000099B0
		private void SetSelectableGroup(IEnumerable<MonoBehaviour> behaviourCollection)
		{
			if (behaviourCollection == null)
			{
				this.selectableGroup = null;
				return;
			}
			List<MonoBehaviour> list = new List<MonoBehaviour>();
			foreach (MonoBehaviour monoBehaviour in behaviourCollection)
			{
				if (monoBehaviour is IBoxSelectable)
				{
					list.Add(monoBehaviour);
				}
			}
			this.selectableGroup = list.ToArray();
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0000B820 File Offset: 0x00009A20
		private void CreateBoxRect()
		{
			GameObject gameObject = new GameObject();
			gameObject.name = "Selection Box";
			gameObject.transform.parent = base.transform;
			gameObject.AddComponent<Image>();
			this.boxRect = gameObject.transform as RectTransform;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x0000B868 File Offset: 0x00009A68
		private void ResetBoxRect()
		{
			Image component = this.boxRect.GetComponent<Image>();
			component.color = this.color;
			component.sprite = this.art;
			this.origin = Vector2.zero;
			this.boxRect.anchoredPosition = Vector2.zero;
			this.boxRect.sizeDelta = Vector2.zero;
			this.boxRect.anchorMax = Vector2.zero;
			this.boxRect.anchorMin = Vector2.zero;
			this.boxRect.pivot = Vector2.zero;
			this.boxRect.gameObject.SetActive(false);
		}

		// Token: 0x06000203 RID: 515 RVA: 0x0000B904 File Offset: 0x00009B04
		private void BeginSelection()
		{
			if (!UIExtensionsInputManager.GetMouseButtonDown(0))
			{
				return;
			}
			this.boxRect.gameObject.SetActive(true);
			this.origin = new Vector2(UIExtensionsInputManager.MousePosition.x, UIExtensionsInputManager.MousePosition.y);
			if (!this.PointIsValidAgainstSelectionMask(this.origin))
			{
				this.ResetBoxRect();
				return;
			}
			this.boxRect.anchoredPosition = this.origin;
			MonoBehaviour[] array;
			if (this.selectableGroup == null)
			{
				array = Object.FindObjectsOfType<MonoBehaviour>();
			}
			else
			{
				array = this.selectableGroup;
			}
			List<IBoxSelectable> list = new List<IBoxSelectable>();
			MonoBehaviour[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				IBoxSelectable boxSelectable = array2[i] as IBoxSelectable;
				if (boxSelectable != null)
				{
					list.Add(boxSelectable);
					if (!UIExtensionsInputManager.GetKey(KeyCode.LeftShift))
					{
						boxSelectable.selected = false;
					}
				}
			}
			this.selectables = list.ToArray();
			this.clickedBeforeDrag = this.GetSelectableAtMousePosition();
		}

		// Token: 0x06000204 RID: 516 RVA: 0x0000B9E0 File Offset: 0x00009BE0
		private bool PointIsValidAgainstSelectionMask(Vector2 screenPoint)
		{
			if (!this.selectionMask)
			{
				return true;
			}
			Camera screenPointCamera = this.GetScreenPointCamera(this.selectionMask);
			return RectTransformUtility.RectangleContainsScreenPoint(this.selectionMask, screenPoint, screenPointCamera);
		}

		// Token: 0x06000205 RID: 517 RVA: 0x0000BA18 File Offset: 0x00009C18
		private IBoxSelectable GetSelectableAtMousePosition()
		{
			if (!this.PointIsValidAgainstSelectionMask(UIExtensionsInputManager.MousePosition))
			{
				return null;
			}
			foreach (IBoxSelectable boxSelectable in this.selectables)
			{
				RectTransform rectTransform = boxSelectable.transform as RectTransform;
				if (rectTransform)
				{
					Camera screenPointCamera = this.GetScreenPointCamera(rectTransform);
					if (RectTransformUtility.RectangleContainsScreenPoint(rectTransform, UIExtensionsInputManager.MousePosition, screenPointCamera))
					{
						return boxSelectable;
					}
				}
				else
				{
					float magnitude = boxSelectable.transform.GetComponent<Renderer>().bounds.extents.magnitude;
					if (Vector2.Distance(this.GetScreenPointOfSelectable(boxSelectable), UIExtensionsInputManager.MousePosition) <= magnitude)
					{
						return boxSelectable;
					}
				}
			}
			return null;
		}

		// Token: 0x06000206 RID: 518 RVA: 0x0000BACC File Offset: 0x00009CCC
		private void DragSelection()
		{
			if (!UIExtensionsInputManager.GetMouseButton(0) || !this.boxRect.gameObject.activeSelf)
			{
				return;
			}
			Vector2 vector = new Vector2(UIExtensionsInputManager.MousePosition.x, UIExtensionsInputManager.MousePosition.y);
			Vector2 vector2 = vector - this.origin;
			Vector2 vector3 = this.origin;
			if (vector2.x < 0f)
			{
				vector3.x = vector.x;
				vector2.x = -vector2.x;
			}
			if (vector2.y < 0f)
			{
				vector3.y = vector.y;
				vector2.y = -vector2.y;
			}
			this.boxRect.anchoredPosition = vector3;
			this.boxRect.sizeDelta = vector2;
			foreach (IBoxSelectable boxSelectable in this.selectables)
			{
				Vector3 vector4 = this.GetScreenPointOfSelectable(boxSelectable);
				boxSelectable.preSelected = RectTransformUtility.RectangleContainsScreenPoint(this.boxRect, vector4, null) && this.PointIsValidAgainstSelectionMask(vector4);
			}
			if (this.clickedBeforeDrag != null)
			{
				this.clickedBeforeDrag.preSelected = true;
			}
		}

		// Token: 0x06000207 RID: 519 RVA: 0x0000BBFC File Offset: 0x00009DFC
		private void ApplySingleClickDeselection()
		{
			if (this.clickedBeforeDrag == null)
			{
				return;
			}
			if (this.clickedAfterDrag != null && this.clickedBeforeDrag.selected && this.clickedBeforeDrag.transform == this.clickedAfterDrag.transform)
			{
				this.clickedBeforeDrag.selected = false;
				this.clickedBeforeDrag.preSelected = false;
			}
		}

		// Token: 0x06000208 RID: 520 RVA: 0x0000BC5C File Offset: 0x00009E5C
		private void ApplyPreSelections()
		{
			foreach (IBoxSelectable boxSelectable in this.selectables)
			{
				if (boxSelectable.preSelected)
				{
					boxSelectable.selected = true;
					boxSelectable.preSelected = false;
				}
			}
		}

		// Token: 0x06000209 RID: 521 RVA: 0x0000BC98 File Offset: 0x00009E98
		private Vector2 GetScreenPointOfSelectable(IBoxSelectable selectable)
		{
			RectTransform rectTransform = selectable.transform as RectTransform;
			if (rectTransform)
			{
				return RectTransformUtility.WorldToScreenPoint(this.GetScreenPointCamera(rectTransform), selectable.transform.position);
			}
			return Camera.main.WorldToScreenPoint(selectable.transform.position);
		}

		// Token: 0x0600020A RID: 522 RVA: 0x0000BCEC File Offset: 0x00009EEC
		private Camera GetScreenPointCamera(RectTransform rectTransform)
		{
			RectTransform rectTransform2 = rectTransform;
			Canvas canvas;
			do
			{
				canvas = rectTransform2.GetComponent<Canvas>();
				if (canvas && !canvas.isRootCanvas)
				{
					canvas = null;
				}
				rectTransform2 = (RectTransform)rectTransform2.parent;
			}
			while (canvas == null);
			switch (canvas.renderMode)
			{
			case RenderMode.ScreenSpaceOverlay:
				return null;
			case RenderMode.ScreenSpaceCamera:
				if (!canvas.worldCamera)
				{
					return Camera.main;
				}
				return canvas.worldCamera;
			}
			return Camera.main;
		}

		// Token: 0x0600020B RID: 523 RVA: 0x0000BD68 File Offset: 0x00009F68
		public IBoxSelectable[] GetAllSelected()
		{
			if (this.selectables == null)
			{
				return new IBoxSelectable[0];
			}
			List<IBoxSelectable> list = new List<IBoxSelectable>();
			foreach (IBoxSelectable boxSelectable in this.selectables)
			{
				if (boxSelectable.selected)
				{
					list.Add(boxSelectable);
				}
			}
			return list.ToArray();
		}

		// Token: 0x0600020C RID: 524 RVA: 0x0000BDB8 File Offset: 0x00009FB8
		private void EndSelection()
		{
			if (!UIExtensionsInputManager.GetMouseButtonUp(0) || !this.boxRect.gameObject.activeSelf)
			{
				return;
			}
			this.clickedAfterDrag = this.GetSelectableAtMousePosition();
			this.ApplySingleClickDeselection();
			this.ApplyPreSelections();
			this.ResetBoxRect();
			this.onSelectionChange.Invoke(this.GetAllSelected());
		}

		// Token: 0x0600020D RID: 525 RVA: 0x0000BE0F File Offset: 0x0000A00F
		private void Start()
		{
			this.ValidateCanvas();
			this.CreateBoxRect();
			this.ResetBoxRect();
		}

		// Token: 0x0600020E RID: 526 RVA: 0x0000BE23 File Offset: 0x0000A023
		private void Update()
		{
			this.BeginSelection();
			this.DragSelection();
			this.EndSelection();
		}

		// Token: 0x040001B6 RID: 438
		public Color color;

		// Token: 0x040001B7 RID: 439
		public Sprite art;

		// Token: 0x040001B8 RID: 440
		private Vector2 origin;

		// Token: 0x040001B9 RID: 441
		public RectTransform selectionMask;

		// Token: 0x040001BA RID: 442
		private RectTransform boxRect;

		// Token: 0x040001BB RID: 443
		private IBoxSelectable[] selectables;

		// Token: 0x040001BC RID: 444
		private MonoBehaviour[] selectableGroup;

		// Token: 0x040001BD RID: 445
		private IBoxSelectable clickedBeforeDrag;

		// Token: 0x040001BE RID: 446
		private IBoxSelectable clickedAfterDrag;

		// Token: 0x040001BF RID: 447
		public SelectionBox.SelectionEvent onSelectionChange = new SelectionBox.SelectionEvent();

		// Token: 0x0200011C RID: 284
		public class SelectionEvent : UnityEvent<IBoxSelectable[]>
		{
		}
	}
}
