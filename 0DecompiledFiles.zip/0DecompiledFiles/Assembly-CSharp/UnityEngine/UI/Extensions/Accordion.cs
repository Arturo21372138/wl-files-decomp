﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200002D RID: 45
	[RequireComponent(typeof(HorizontalOrVerticalLayoutGroup), typeof(ContentSizeFitter), typeof(ToggleGroup))]
	[AddComponentMenu("UI/Extensions/Accordion/Accordion Group")]
	public class Accordion : MonoBehaviour
	{
		// Token: 0x17000005 RID: 5
		// (get) Token: 0x060000A4 RID: 164 RVA: 0x0000558C File Offset: 0x0000378C
		[HideInInspector]
		public bool ExpandVerticval
		{
			get
			{
				return this.m_expandVertical;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x00005594 File Offset: 0x00003794
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x0000559C File Offset: 0x0000379C
		public Accordion.Transition transition
		{
			get
			{
				return this.m_Transition;
			}
			set
			{
				this.m_Transition = value;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x000055A5 File Offset: 0x000037A5
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x000055AD File Offset: 0x000037AD
		public float transitionDuration
		{
			get
			{
				return this.m_TransitionDuration;
			}
			set
			{
				this.m_TransitionDuration = value;
			}
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x000055B6 File Offset: 0x000037B6
		private void Awake()
		{
			this.m_expandVertical = !base.GetComponent<HorizontalLayoutGroup>();
			base.GetComponent<ToggleGroup>();
		}

		// Token: 0x040000B7 RID: 183
		private bool m_expandVertical = true;

		// Token: 0x040000B8 RID: 184
		[SerializeField]
		private Accordion.Transition m_Transition;

		// Token: 0x040000B9 RID: 185
		[SerializeField]
		private float m_TransitionDuration = 0.3f;

		// Token: 0x02000104 RID: 260
		public enum Transition
		{
			// Token: 0x04000611 RID: 1553
			Instant,
			// Token: 0x04000612 RID: 1554
			Tween
		}
	}
}
