﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000096 RID: 150
	[AddComponentMenu("UI/Extensions/Menu Manager")]
	[DisallowMultipleComponent]
	public class MenuManager : MonoBehaviour
	{
		// Token: 0x170000CF RID: 207
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x0001CF0A File Offset: 0x0001B10A
		// (set) Token: 0x060004D9 RID: 1241 RVA: 0x0001CF12 File Offset: 0x0001B112
		public Menu[] MenuScreens
		{
			get
			{
				return this.menuScreens;
			}
			set
			{
				this.menuScreens = value;
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x0001CF1B File Offset: 0x0001B11B
		// (set) Token: 0x060004DB RID: 1243 RVA: 0x0001CF23 File Offset: 0x0001B123
		public int StartScreen
		{
			get
			{
				return this.startScreen;
			}
			set
			{
				this.startScreen = value;
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x0001CF2C File Offset: 0x0001B12C
		// (set) Token: 0x060004DD RID: 1245 RVA: 0x0001CF33 File Offset: 0x0001B133
		public static MenuManager Instance { get; set; }

		// Token: 0x060004DE RID: 1246 RVA: 0x0001CF3C File Offset: 0x0001B13C
		private void Start()
		{
			MenuManager.Instance = this;
			if (this.MenuScreens.Length > this.StartScreen)
			{
				GameObject gameObject = this.CreateInstance(this.MenuScreens[this.StartScreen].name);
				this.OpenMenu(gameObject.GetMenu());
				return;
			}
			Debug.LogError("Not enough Menu Screens configured");
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0001CF8F File Offset: 0x0001B18F
		private void OnDestroy()
		{
			MenuManager.Instance = null;
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0001CF97 File Offset: 0x0001B197
		public GameObject CreateInstance(string MenuName)
		{
			return Object.Instantiate<GameObject>(this.GetPrefab(MenuName), base.transform);
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x0001CFAC File Offset: 0x0001B1AC
		public void CreateInstance(string MenuName, out GameObject menuInstance)
		{
			GameObject prefab = this.GetPrefab(MenuName);
			menuInstance = Object.Instantiate<GameObject>(prefab, base.transform);
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x0001CFD0 File Offset: 0x0001B1D0
		public void OpenMenu(Menu menuInstance)
		{
			if (this.menuStack.Count > 0)
			{
				if (menuInstance.DisableMenusUnderneath)
				{
					foreach (Menu menu in this.menuStack)
					{
						menu.gameObject.SetActive(false);
						if (menu.DisableMenusUnderneath)
						{
							break;
						}
					}
				}
				Canvas component = menuInstance.GetComponent<Canvas>();
				Canvas component2 = this.menuStack.Peek().GetComponent<Canvas>();
				component.sortingOrder = component2.sortingOrder + 1;
			}
			this.menuStack.Push(menuInstance);
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x0001D078 File Offset: 0x0001B278
		private GameObject GetPrefab(string PrefabName)
		{
			for (int i = 0; i < this.MenuScreens.Length; i++)
			{
				if (this.MenuScreens[i].name == PrefabName)
				{
					return this.MenuScreens[i].gameObject;
				}
			}
			throw new MissingReferenceException("Prefab not found for " + PrefabName);
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x0001D0CC File Offset: 0x0001B2CC
		public void CloseMenu(Menu menu)
		{
			if (this.menuStack.Count == 0)
			{
				Debug.LogErrorFormat(menu, "{0} cannot be closed because menu stack is empty", new object[] { menu.GetType() });
				return;
			}
			if (this.menuStack.Peek() != menu)
			{
				Debug.LogErrorFormat(menu, "{0} cannot be closed because it is not on top of stack", new object[] { menu.GetType() });
				return;
			}
			this.CloseTopMenu();
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x0001D138 File Offset: 0x0001B338
		public void CloseTopMenu()
		{
			Menu menu = this.menuStack.Pop();
			if (menu.DestroyWhenClosed)
			{
				Object.Destroy(menu.gameObject);
			}
			else
			{
				menu.gameObject.SetActive(false);
			}
			foreach (Menu menu2 in this.menuStack)
			{
				menu2.gameObject.SetActive(true);
				if (menu2.DisableMenusUnderneath)
				{
					break;
				}
			}
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x0001D1C8 File Offset: 0x0001B3C8
		private void Update()
		{
			if (UIExtensionsInputManager.GetKeyDown(KeyCode.Escape) && this.menuStack.Count > 0)
			{
				this.menuStack.Peek().OnBackPressed();
			}
		}

		// Token: 0x0400039C RID: 924
		[SerializeField]
		private Menu[] menuScreens;

		// Token: 0x0400039D RID: 925
		[SerializeField]
		private int startScreen;

		// Token: 0x0400039E RID: 926
		private Stack<Menu> menuStack = new Stack<Menu>();
	}
}
