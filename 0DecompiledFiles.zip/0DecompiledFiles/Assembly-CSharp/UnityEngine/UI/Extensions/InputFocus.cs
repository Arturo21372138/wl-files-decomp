﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000038 RID: 56
	[RequireComponent(typeof(InputField))]
	[AddComponentMenu("UI/Extensions/InputFocus")]
	public class InputFocus : MonoBehaviour
	{
		// Token: 0x06000146 RID: 326 RVA: 0x00008259 File Offset: 0x00006459
		private void Start()
		{
			this._inputField = base.GetComponent<InputField>();
		}

		// Token: 0x06000147 RID: 327 RVA: 0x00008267 File Offset: 0x00006467
		private void Update()
		{
			if (UIExtensionsInputManager.GetKeyUp(KeyCode.Return) && !this._inputField.isFocused)
			{
				if (this._ignoreNextActivation)
				{
					this._ignoreNextActivation = false;
					return;
				}
				this._inputField.Select();
				this._inputField.ActivateInputField();
			}
		}

		// Token: 0x06000148 RID: 328 RVA: 0x000082A5 File Offset: 0x000064A5
		public void buttonPressed()
		{
			bool flag = this._inputField.text == "";
			this._inputField.text = "";
			if (!flag)
			{
				this._inputField.Select();
				this._inputField.ActivateInputField();
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x000082E4 File Offset: 0x000064E4
		public void OnEndEdit(string textString)
		{
			if (!UIExtensionsInputManager.GetKeyDown(KeyCode.Return))
			{
				return;
			}
			bool flag = this._inputField.text == "";
			this._inputField.text = "";
			if (flag)
			{
				this._ignoreNextActivation = true;
			}
		}

		// Token: 0x0400013C RID: 316
		protected InputField _inputField;

		// Token: 0x0400013D RID: 317
		public bool _ignoreNextActivation;
	}
}
