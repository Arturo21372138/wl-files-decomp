﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007A6 RID: 1958
	public struct AddNotifyClientIntegrityViolatedOptions
	{
	}
}
