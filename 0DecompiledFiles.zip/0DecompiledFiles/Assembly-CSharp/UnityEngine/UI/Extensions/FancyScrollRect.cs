﻿using System;
using System.Collections.Generic;
using UnityEngine.UI.Extensions.EasingCore;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000082 RID: 130
	[RequireComponent(typeof(Scroller))]
	public abstract class FancyScrollRect<TItemData, TContext> : FancyScrollView<TItemData, TContext> where TContext : class, IFancyScrollRectContext, new()
	{
		// Token: 0x170000AE RID: 174
		// (get) Token: 0x060003DF RID: 991
		protected abstract float CellSize { get; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x060003E0 RID: 992 RVA: 0x00017B96 File Offset: 0x00015D96
		protected virtual bool Scrollable
		{
			get
			{
				return this.MaxScrollPosition > 0f;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x060003E1 RID: 993 RVA: 0x00017BA8 File Offset: 0x00015DA8
		protected Scroller Scroller
		{
			get
			{
				Scroller scroller;
				if ((scroller = this.cachedScroller) == null)
				{
					scroller = (this.cachedScroller = base.GetComponent<Scroller>());
				}
				return scroller;
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x060003E2 RID: 994 RVA: 0x00017BCE File Offset: 0x00015DCE
		private float ScrollLength
		{
			get
			{
				return 1f / Mathf.Max(this.cellInterval, 0.01f) - 1f;
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x060003E3 RID: 995 RVA: 0x00017BEC File Offset: 0x00015DEC
		private float ViewportLength
		{
			get
			{
				return this.ScrollLength - this.reuseCellMarginCount * 2f;
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x060003E4 RID: 996 RVA: 0x00017C01 File Offset: 0x00015E01
		private float PaddingHeadLength
		{
			get
			{
				return (this.paddingHead - this.spacing * 0.5f) / (this.CellSize + this.spacing);
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x060003E5 RID: 997 RVA: 0x00017C24 File Offset: 0x00015E24
		private float MaxScrollPosition
		{
			get
			{
				return (float)base.ItemsSource.Count - this.ScrollLength + this.reuseCellMarginCount * 2f + (this.paddingHead + this.paddingTail - this.spacing) / (this.CellSize + this.spacing);
			}
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x00017C74 File Offset: 0x00015E74
		protected override void Initialize()
		{
			base.Initialize();
			base.Context.ScrollDirection = this.Scroller.ScrollDirection;
			base.Context.CalculateScrollSize = delegate
			{
				float num = this.CellSize + this.spacing;
				float num2 = num * this.reuseCellMarginCount;
				return new ValueTuple<float, float>(this.Scroller.ViewportSize + num + num2 * 2f, num2);
			};
			this.AdjustCellIntervalAndScrollOffset();
			this.Scroller.OnValueChanged(new Action<float>(this.OnScrollerValueChanged));
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00017CDC File Offset: 0x00015EDC
		private void OnScrollerValueChanged(float p)
		{
			base.UpdatePosition(this.Scrollable ? this.ToFancyScrollViewPosition(p) : 0f);
			if (this.Scroller.Scrollbar)
			{
				if (p > (float)(base.ItemsSource.Count - 1))
				{
					this.ShrinkScrollbar(p - (float)(base.ItemsSource.Count - 1));
					return;
				}
				if (p < 0f)
				{
					this.ShrinkScrollbar(-p);
				}
			}
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x00017D50 File Offset: 0x00015F50
		private void ShrinkScrollbar(float offset)
		{
			float num = 1f - this.ToFancyScrollViewPosition(offset) / (this.ViewportLength - this.PaddingHeadLength);
			this.UpdateScrollbarSize((this.ViewportLength - this.PaddingHeadLength) * num);
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x00017D8E File Offset: 0x00015F8E
		protected override void Refresh()
		{
			this.AdjustCellIntervalAndScrollOffset();
			this.RefreshScroller();
			base.Refresh();
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x00017DA2 File Offset: 0x00015FA2
		protected override void Relayout()
		{
			this.AdjustCellIntervalAndScrollOffset();
			this.RefreshScroller();
			base.Relayout();
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x00017DB8 File Offset: 0x00015FB8
		protected void RefreshScroller()
		{
			this.Scroller.Draggable = this.Scrollable;
			this.Scroller.ScrollSensitivity = this.ToScrollerPosition(this.ViewportLength - this.PaddingHeadLength);
			this.Scroller.Position = this.ToScrollerPosition(this.currentPosition);
			if (this.Scroller.Scrollbar)
			{
				this.Scroller.Scrollbar.gameObject.SetActive(this.Scrollable);
				this.UpdateScrollbarSize(this.ViewportLength);
			}
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x00017E44 File Offset: 0x00016044
		protected override void UpdateContents(IList<TItemData> items)
		{
			this.AdjustCellIntervalAndScrollOffset();
			base.UpdateContents(items);
			this.Scroller.SetTotalCount(items.Count);
			this.RefreshScroller();
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x00017E6A File Offset: 0x0001606A
		protected new void UpdatePosition(float position)
		{
			this.Scroller.Position = this.ToScrollerPosition(position, 0.5f);
		}

		// Token: 0x060003EE RID: 1006 RVA: 0x00017E83 File Offset: 0x00016083
		protected virtual void JumpTo(int itemIndex, float alignment = 0.5f)
		{
			this.Scroller.Position = this.ToScrollerPosition((float)itemIndex, alignment);
		}

		// Token: 0x060003EF RID: 1007 RVA: 0x00017E99 File Offset: 0x00016099
		protected virtual void ScrollTo(int index, float duration, float alignment = 0.5f, Action onComplete = null)
		{
			this.Scroller.ScrollTo(this.ToScrollerPosition((float)index, alignment), duration, onComplete);
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x00017EB2 File Offset: 0x000160B2
		protected virtual void ScrollTo(int index, float duration, Ease easing, float alignment = 0.5f, Action onComplete = null)
		{
			this.Scroller.ScrollTo(this.ToScrollerPosition((float)index, alignment), duration, easing, onComplete);
		}

		// Token: 0x060003F1 RID: 1009 RVA: 0x00017ED0 File Offset: 0x000160D0
		protected void UpdateScrollbarSize(float viewportLength)
		{
			float num = Mathf.Max((float)base.ItemsSource.Count + (this.paddingHead + this.paddingTail - this.spacing) / (this.CellSize + this.spacing), 1f);
			this.Scroller.Scrollbar.size = (this.Scrollable ? Mathf.Clamp01(viewportLength / num) : 1f);
		}

		// Token: 0x060003F2 RID: 1010 RVA: 0x00017F3E File Offset: 0x0001613E
		protected float ToFancyScrollViewPosition(float position)
		{
			return position / (float)Mathf.Max(base.ItemsSource.Count - 1, 1) * this.MaxScrollPosition - this.PaddingHeadLength;
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x00017F64 File Offset: 0x00016164
		protected float ToScrollerPosition(float position)
		{
			return (position + this.PaddingHeadLength) / this.MaxScrollPosition * (float)Mathf.Max(base.ItemsSource.Count - 1, 1);
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x00017F8C File Offset: 0x0001618C
		protected float ToScrollerPosition(float position, float alignment = 0.5f)
		{
			float num = alignment * (this.ScrollLength - (1f + this.reuseCellMarginCount * 2f)) + (1f - alignment - 0.5f) * this.spacing / (this.CellSize + this.spacing);
			return this.ToScrollerPosition(Mathf.Clamp(position - num, 0f, this.MaxScrollPosition));
		}

		// Token: 0x060003F5 RID: 1013 RVA: 0x00017FF4 File Offset: 0x000161F4
		protected void AdjustCellIntervalAndScrollOffset()
		{
			float num = this.Scroller.ViewportSize + (this.CellSize + this.spacing) * (1f + this.reuseCellMarginCount * 2f);
			this.cellInterval = (this.CellSize + this.spacing) / num;
			this.scrollOffset = this.cellInterval * (1f + this.reuseCellMarginCount);
		}

		// Token: 0x060003F6 RID: 1014 RVA: 0x0001805C File Offset: 0x0001625C
		protected virtual void OnValidate()
		{
			this.AdjustCellIntervalAndScrollOffset();
			if (this.loop)
			{
				this.loop = false;
				Debug.LogError("Loop is currently not supported in FancyScrollRect.");
			}
			if (this.Scroller.SnapEnabled)
			{
				this.Scroller.SnapEnabled = false;
				Debug.LogError("Snap is currently not supported in FancyScrollRect.");
			}
			if (this.Scroller.MovementType == MovementType.Unrestricted)
			{
				this.Scroller.MovementType = MovementType.Elastic;
				Debug.LogError("MovementType.Unrestricted is currently not supported in FancyScrollRect.");
			}
		}

		// Token: 0x04000302 RID: 770
		[SerializeField]
		protected float reuseCellMarginCount;

		// Token: 0x04000303 RID: 771
		[SerializeField]
		protected float paddingHead;

		// Token: 0x04000304 RID: 772
		[SerializeField]
		protected float paddingTail;

		// Token: 0x04000305 RID: 773
		[SerializeField]
		protected float spacing;

		// Token: 0x04000306 RID: 774
		private Scroller cachedScroller;
	}
}
