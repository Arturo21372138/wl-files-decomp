﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C8 RID: 1992
	internal static class OnPeerActionRequiredCallbackInternalImplementation
	{
		// Token: 0x17000826 RID: 2086
		// (get) Token: 0x060020E5 RID: 8421 RVA: 0x00027256 File Offset: 0x00025456
		public static OnPeerActionRequiredCallbackInternal Delegate
		{
			get
			{
				if (OnPeerActionRequiredCallbackInternalImplementation.s_Delegate == null)
				{
					OnPeerActionRequiredCallbackInternalImplementation.s_Delegate = new OnPeerActionRequiredCallbackInternal(OnPeerActionRequiredCallbackInternalImplementation.EntryPoint);
				}
				return OnPeerActionRequiredCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060020E6 RID: 8422 RVA: 0x00027278 File Offset: 0x00025478
		[MonoPInvokeCallback(typeof(OnPeerActionRequiredCallbackInternal))]
		public static void EntryPoint(ref OnClientActionRequiredCallbackInfoInternal data)
		{
			OnPeerActionRequiredCallback onPeerActionRequiredCallback;
			OnClientActionRequiredCallbackInfo onClientActionRequiredCallbackInfo;
			if (Helper.TryGetCallback<OnClientActionRequiredCallbackInfoInternal, OnPeerActionRequiredCallback, OnClientActionRequiredCallbackInfo>(ref data, out onPeerActionRequiredCallback, out onClientActionRequiredCallbackInfo))
			{
				onPeerActionRequiredCallback(ref onClientActionRequiredCallbackInfo);
			}
		}

		// Token: 0x040015E0 RID: 5600
		private static OnPeerActionRequiredCallbackInternal s_Delegate;
	}
}
