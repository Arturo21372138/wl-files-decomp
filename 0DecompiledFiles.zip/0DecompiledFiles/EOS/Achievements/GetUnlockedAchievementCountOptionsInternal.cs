﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007FA RID: 2042
	internal struct GetUnlockedAchievementCountOptionsInternal : ISettable<GetUnlockedAchievementCountOptions>, IDisposable
	{
		// Token: 0x06002198 RID: 8600 RVA: 0x000281B1 File Offset: 0x000263B1
		public void Set(ref GetUnlockedAchievementCountOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.UserId, ref this.m_UserId);
		}

		// Token: 0x06002199 RID: 8601 RVA: 0x000281D1 File Offset: 0x000263D1
		public void Dispose()
		{
			Helper.Dispose(ref this.m_UserId);
		}

		// Token: 0x04001681 RID: 5761
		private int m_ApiVersion;

		// Token: 0x04001682 RID: 5762
		private IntPtr m_UserId;
	}
}
