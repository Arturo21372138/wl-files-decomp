﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E4 RID: 228
	[Flags]
	public enum DeferredBuffers
	{
		// Token: 0x04000592 RID: 1426
		AlbedoAlpha = 1,
		// Token: 0x04000593 RID: 1427
		SpecularSmoothness = 2,
		// Token: 0x04000594 RID: 1428
		NormalDepth = 4,
		// Token: 0x04000595 RID: 1429
		EmissionOcclusion = 8
	}
}
