﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200009A RID: 154
	[AddComponentMenu("UI/Extensions/Primitives/UI Circle")]
	public class UICircle : UIPrimitiveBase
	{
		// Token: 0x060004F6 RID: 1270 RVA: 0x0001D420 File Offset: 0x0001B620
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			int num = (this.ArcInvert ? (-1) : 1);
			float num2 = ((base.rectTransform.rect.width < base.rectTransform.rect.height) ? base.rectTransform.rect.width : base.rectTransform.rect.height) - (float)this.Padding;
			float num3 = -base.rectTransform.pivot.x * num2;
			float num4 = -base.rectTransform.pivot.x * num2 + this.Thickness;
			vh.Clear();
			this.indices.Clear();
			this.vertices.Clear();
			int num5 = 0;
			int num6 = 1;
			float num7 = this.Arc * 360f / (float)this.ArcSteps;
			this._progress = (float)this.ArcSteps * this.Progress;
			float num8 = (float)num * 0.017453292f * (float)this.ArcRotation;
			float num9 = Mathf.Cos(num8);
			float num10 = Mathf.Sin(num8);
			UIVertex simpleVert = UIVertex.simpleVert;
			simpleVert.color = ((this._progress > 0f) ? this.ProgressColor : this.color);
			simpleVert.position = new Vector2(num3 * num9, num3 * num10);
			simpleVert.uv0 = new Vector2(simpleVert.position.x / num2 + 0.5f, simpleVert.position.y / num2 + 0.5f);
			this.vertices.Add(simpleVert);
			Vector2 zero = new Vector2(num4 * num9, num4 * num10);
			if (this.Fill)
			{
				zero = Vector2.zero;
			}
			simpleVert.position = zero;
			simpleVert.uv0 = (this.Fill ? this.uvCenter : new Vector2(simpleVert.position.x / num2 + 0.5f, simpleVert.position.y / num2 + 0.5f));
			this.vertices.Add(simpleVert);
			for (int i = 1; i <= this.ArcSteps; i++)
			{
				float num11 = (float)num * 0.017453292f * ((float)i * num7 + (float)this.ArcRotation);
				num9 = Mathf.Cos(num11);
				num10 = Mathf.Sin(num11);
				simpleVert.color = (((float)i > this._progress) ? this.color : this.ProgressColor);
				simpleVert.position = new Vector2(num3 * num9, num3 * num10);
				simpleVert.uv0 = new Vector2(simpleVert.position.x / num2 + 0.5f, simpleVert.position.y / num2 + 0.5f);
				this.vertices.Add(simpleVert);
				if (!this.Fill)
				{
					simpleVert.position = new Vector2(num4 * num9, num4 * num10);
					simpleVert.uv0 = new Vector2(simpleVert.position.x / num2 + 0.5f, simpleVert.position.y / num2 + 0.5f);
					this.vertices.Add(simpleVert);
					int num12 = num6;
					this.indices.Add(num5);
					this.indices.Add(num6 + 1);
					this.indices.Add(num6);
					num6++;
					num5 = num6;
					num6++;
					this.indices.Add(num5);
					this.indices.Add(num6);
					this.indices.Add(num12);
				}
				else
				{
					this.indices.Add(num5);
					this.indices.Add(num6 + 1);
					if ((float)i > this._progress)
					{
						this.indices.Add(this.ArcSteps + 2);
					}
					else
					{
						this.indices.Add(1);
					}
					num6++;
					num5 = num6;
				}
			}
			if (this.Fill)
			{
				simpleVert.position = zero;
				simpleVert.color = this.color;
				simpleVert.uv0 = this.uvCenter;
				this.vertices.Add(simpleVert);
			}
			vh.AddUIVertexStream(this.vertices, this.indices);
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x0001D883 File Offset: 0x0001BA83
		public void SetProgress(float progress)
		{
			this.Progress = progress;
			this.SetVerticesDirty();
		}

		// Token: 0x060004F8 RID: 1272 RVA: 0x0001D892 File Offset: 0x0001BA92
		public void SetArcSteps(int steps)
		{
			this.ArcSteps = steps;
			this.SetVerticesDirty();
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x0001D8A1 File Offset: 0x0001BAA1
		public void SetInvertArc(bool invert)
		{
			this.ArcInvert = invert;
			this.SetVerticesDirty();
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x0001D8B0 File Offset: 0x0001BAB0
		public void SetArcRotation(int rotation)
		{
			this.ArcRotation = rotation;
			this.SetVerticesDirty();
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x0001D8BF File Offset: 0x0001BABF
		public void SetFill(bool fill)
		{
			this.Fill = fill;
			this.SetVerticesDirty();
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x0001D8CE File Offset: 0x0001BACE
		public void SetBaseColor(Color color)
		{
			this.color = color;
			this.SetVerticesDirty();
		}

		// Token: 0x060004FD RID: 1277 RVA: 0x0001D8E0 File Offset: 0x0001BAE0
		public void UpdateBaseAlpha(float value)
		{
			Color color = this.color;
			color.a = value;
			this.color = color;
			this.SetVerticesDirty();
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x0001D909 File Offset: 0x0001BB09
		public void SetProgressColor(Color color)
		{
			this.ProgressColor = color;
			this.SetVerticesDirty();
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0001D918 File Offset: 0x0001BB18
		public void UpdateProgressAlpha(float value)
		{
			this.ProgressColor.a = value;
			this.SetVerticesDirty();
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x0001D92C File Offset: 0x0001BB2C
		public void SetPadding(int padding)
		{
			this.Padding = padding;
			this.SetVerticesDirty();
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x0001D93B File Offset: 0x0001BB3B
		public void SetThickness(int thickness)
		{
			this.Thickness = (float)thickness;
			this.SetVerticesDirty();
		}

		// Token: 0x040003A4 RID: 932
		[Tooltip("The Arc Invert property will invert the construction of the Arc.")]
		public bool ArcInvert = true;

		// Token: 0x040003A5 RID: 933
		[Tooltip("The Arc property is a percentage of the entire circumference of the circle.")]
		[Range(0f, 1f)]
		public float Arc = 1f;

		// Token: 0x040003A6 RID: 934
		[Tooltip("The Arc Steps property defines the number of segments that the Arc will be divided into.")]
		[Range(0f, 1000f)]
		public int ArcSteps = 100;

		// Token: 0x040003A7 RID: 935
		[Tooltip("The Arc Rotation property permits adjusting the geometry orientation around the Z axis.")]
		[Range(0f, 360f)]
		public int ArcRotation;

		// Token: 0x040003A8 RID: 936
		[Tooltip("The Progress property allows the primitive to be used as a progression indicator.")]
		[Range(0f, 1f)]
		public float Progress;

		// Token: 0x040003A9 RID: 937
		private float _progress;

		// Token: 0x040003AA RID: 938
		public Color ProgressColor = new Color(255f, 255f, 255f, 255f);

		// Token: 0x040003AB RID: 939
		public bool Fill = true;

		// Token: 0x040003AC RID: 940
		public float Thickness = 5f;

		// Token: 0x040003AD RID: 941
		public int Padding;

		// Token: 0x040003AE RID: 942
		private List<int> indices = new List<int>();

		// Token: 0x040003AF RID: 943
		private List<UIVertex> vertices = new List<UIVertex>();

		// Token: 0x040003B0 RID: 944
		private Vector2 uvCenter = new Vector2(0.5f, 0.5f);
	}
}
