﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200008E RID: 142
	public class ScrollSnapBase : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IDragHandler, IEndDragHandler, IScrollSnap, IPointerClickHandler
	{
		// Token: 0x170000BE RID: 190
		// (get) Token: 0x0600045F RID: 1119 RVA: 0x0001A917 File Offset: 0x00018B17
		// (set) Token: 0x06000460 RID: 1120 RVA: 0x0001A920 File Offset: 0x00018B20
		public int CurrentPage
		{
			get
			{
				return this._currentPage;
			}
			internal set
			{
				if (this._isInfinite)
				{
					float num = (float)value / (float)this._screensContainer.childCount;
					if (num < 0f)
					{
						this._infiniteWindow = (int)Math.Floor((double)num);
					}
					else
					{
						this._infiniteWindow = value / this._screensContainer.childCount;
					}
					this._infiniteWindow = ((value < 0) ? (-this._infiniteWindow) : this._infiniteWindow);
					value %= this._screensContainer.childCount;
					if (value < 0)
					{
						value = this._screensContainer.childCount + value;
					}
					else if (value > this._screensContainer.childCount - 1)
					{
						value -= this._screensContainer.childCount;
					}
				}
				if ((value != this._currentPage && value >= 0 && value < this._screensContainer.childCount) || (value == 0 && this._screensContainer.childCount == 0))
				{
					this._previousPage = this._currentPage;
					this._currentPage = value;
					if (this.MaskArea)
					{
						this.UpdateVisible();
					}
					if (!this._lerp)
					{
						this.ScreenChange();
					}
					this.OnCurrentScreenChange(this._currentPage);
				}
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000461 RID: 1121 RVA: 0x0001AA3A File Offset: 0x00018C3A
		// (set) Token: 0x06000462 RID: 1122 RVA: 0x0001AA42 File Offset: 0x00018C42
		public ScrollSnapBase.SelectionChangeStartEvent OnSelectionChangeStartEvent
		{
			get
			{
				return this.m_OnSelectionChangeStartEvent;
			}
			set
			{
				this.m_OnSelectionChangeStartEvent = value;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000463 RID: 1123 RVA: 0x0001AA4B File Offset: 0x00018C4B
		// (set) Token: 0x06000464 RID: 1124 RVA: 0x0001AA53 File Offset: 0x00018C53
		public ScrollSnapBase.SelectionPageChangedEvent OnSelectionPageChangedEvent
		{
			get
			{
				return this.m_OnSelectionPageChangedEvent;
			}
			set
			{
				this.m_OnSelectionPageChangedEvent = value;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000465 RID: 1125 RVA: 0x0001AA5C File Offset: 0x00018C5C
		// (set) Token: 0x06000466 RID: 1126 RVA: 0x0001AA64 File Offset: 0x00018C64
		public ScrollSnapBase.SelectionChangeEndEvent OnSelectionChangeEndEvent
		{
			get
			{
				return this.m_OnSelectionChangeEndEvent;
			}
			set
			{
				this.m_OnSelectionChangeEndEvent = value;
			}
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0001AA70 File Offset: 0x00018C70
		private void Awake()
		{
			if (this._scroll_rect == null)
			{
				this._scroll_rect = base.gameObject.GetComponent<ScrollRect>();
			}
			if (this._scroll_rect.horizontalScrollbar && this._scroll_rect.horizontal)
			{
				this._scroll_rect.horizontalScrollbar.gameObject.AddComponent<ScrollSnapScrollbarHelper>().ss = this;
			}
			if (this._scroll_rect.verticalScrollbar && this._scroll_rect.vertical)
			{
				this._scroll_rect.verticalScrollbar.gameObject.AddComponent<ScrollSnapScrollbarHelper>().ss = this;
			}
			this.panelDimensions = base.gameObject.GetComponent<RectTransform>().rect;
			if (this.StartingScreen < 0)
			{
				this.StartingScreen = 0;
			}
			this._screensContainer = this._scroll_rect.content;
			this.InitialiseChildObjects();
			if (this.NextButton)
			{
				this.NextButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.NextScreen();
				});
			}
			if (this.PrevButton)
			{
				this.PrevButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.PreviousScreen();
				});
			}
			this._isInfinite = base.GetComponent<UI_InfiniteScroll>() != null;
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x0001ABBC File Offset: 0x00018DBC
		internal void InitialiseChildObjects()
		{
			if (this.ChildObjects != null && this.ChildObjects.Length != 0)
			{
				if (this._screensContainer.transform.childCount > 0)
				{
					Debug.LogError("ScrollRect Content has children, this is not supported when using managed Child Objects\n Either remove the ScrollRect Content children or clear the ChildObjects array");
					return;
				}
				this.InitialiseChildObjectsFromArray();
				if (base.GetComponent<UI_InfiniteScroll>() != null)
				{
					base.GetComponent<UI_InfiniteScroll>().Init();
					return;
				}
			}
			else
			{
				this.InitialiseChildObjectsFromScene();
			}
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x0001AC20 File Offset: 0x00018E20
		internal void InitialiseChildObjectsFromScene()
		{
			int childCount = this._screensContainer.childCount;
			this.ChildObjects = new GameObject[childCount];
			for (int i = 0; i < childCount; i++)
			{
				this.ChildObjects[i] = this._screensContainer.transform.GetChild(i).gameObject;
				if (this.MaskArea && this.ChildObjects[i].activeSelf)
				{
					this.ChildObjects[i].SetActive(false);
				}
			}
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x0001AC9C File Offset: 0x00018E9C
		internal void InitialiseChildObjectsFromArray()
		{
			int num = this.ChildObjects.Length;
			for (int i = 0; i < num; i++)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.ChildObjects[i]);
				if (this.UseParentTransform)
				{
					RectTransform component = gameObject.GetComponent<RectTransform>();
					component.rotation = this._screensContainer.rotation;
					component.localScale = this._screensContainer.localScale;
					component.position = this._screensContainer.position;
				}
				gameObject.transform.SetParent(this._screensContainer.transform);
				this.ChildObjects[i] = gameObject;
				if (this.MaskArea && this.ChildObjects[i].activeSelf)
				{
					this.ChildObjects[i].SetActive(false);
				}
			}
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x0001AD5C File Offset: 0x00018F5C
		internal void UpdateVisible()
		{
			if (!this.MaskArea || this.ChildObjects == null || this.ChildObjects.Length < 1 || this._screensContainer.childCount < 1)
			{
				return;
			}
			this._maskSize = (this._isVertical ? this.MaskArea.rect.height : this.MaskArea.rect.width);
			this._halfNoVisibleItems = (int)Math.Round((double)(this._maskSize / (this._childSize * this.MaskBuffer)), MidpointRounding.AwayFromZero) / 2;
			this._bottomItem = (this._topItem = 0);
			for (int i = this._halfNoVisibleItems + 1; i > 0; i--)
			{
				this._bottomItem = ((this._currentPage - i < 0) ? 0 : i);
				if (this._bottomItem > 0)
				{
					break;
				}
			}
			for (int j = this._halfNoVisibleItems + 1; j > 0; j--)
			{
				this._topItem = ((this._screensContainer.childCount - this._currentPage - j < 0) ? 0 : j);
				if (this._topItem > 0)
				{
					break;
				}
			}
			for (int k = this.CurrentPage - this._bottomItem; k < this.CurrentPage + this._topItem; k++)
			{
				try
				{
					this.ChildObjects[k].SetActive(true);
				}
				catch
				{
					Debug.Log("Failed to setactive child [" + k.ToString() + "]");
				}
			}
			if (this._currentPage > this._halfNoVisibleItems)
			{
				this.ChildObjects[this.CurrentPage - this._bottomItem].SetActive(false);
			}
			if (this._screensContainer.childCount - this._currentPage > this._topItem)
			{
				this.ChildObjects[this.CurrentPage + this._topItem].SetActive(false);
			}
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0001AF34 File Offset: 0x00019134
		public void NextScreen()
		{
			if (this._currentPage < this._screens - 1 || this._isInfinite)
			{
				if (!this._lerp)
				{
					this.StartScreenChange();
				}
				this._lerp = true;
				if (this._isInfinite)
				{
					this.CurrentPage = this.GetPageforPosition(this._screensContainer.anchoredPosition) + 1;
				}
				else
				{
					this.CurrentPage = this._currentPage + 1;
				}
				this.GetPositionforPage(this._currentPage, ref this._lerp_target);
				this.ScreenChange();
			}
		}

		// Token: 0x0600046D RID: 1133 RVA: 0x0001AFBC File Offset: 0x000191BC
		public void PreviousScreen()
		{
			if (this._currentPage > 0 || this._isInfinite)
			{
				if (!this._lerp)
				{
					this.StartScreenChange();
				}
				this._lerp = true;
				if (this._isInfinite)
				{
					this.CurrentPage = this.GetPageforPosition(this._screensContainer.anchoredPosition) - 1;
				}
				else
				{
					this.CurrentPage = this._currentPage - 1;
				}
				this.GetPositionforPage(this._currentPage, ref this._lerp_target);
				this.ScreenChange();
			}
		}

		// Token: 0x0600046E RID: 1134 RVA: 0x0001B040 File Offset: 0x00019240
		public void GoToScreen(int screenIndex)
		{
			if (screenIndex <= this._screens - 1 && screenIndex >= 0)
			{
				if (!this._lerp)
				{
					this.StartScreenChange();
				}
				this._lerp = true;
				this.CurrentPage = screenIndex;
				this.GetPositionforPage(this._currentPage, ref this._lerp_target);
				this.ScreenChange();
			}
		}

		// Token: 0x0600046F RID: 1135 RVA: 0x0001B090 File Offset: 0x00019290
		internal int GetPageforPosition(Vector3 pos)
		{
			if (!this._isVertical)
			{
				return (int)Math.Round((double)((this._scrollStartPosition - pos.x) / this._childSize));
			}
			return (int)Math.Round((double)((this._scrollStartPosition - pos.y) / this._childSize));
		}

		// Token: 0x06000470 RID: 1136 RVA: 0x0001B0DC File Offset: 0x000192DC
		internal bool IsRectSettledOnaPage(Vector3 pos)
		{
			if (!this._isVertical)
			{
				return -((pos.x - this._scrollStartPosition) / this._childSize) == (float)(-(float)((int)Math.Round((double)((pos.x - this._scrollStartPosition) / this._childSize))));
			}
			return -((pos.y - this._scrollStartPosition) / this._childSize) == (float)(-(float)((int)Math.Round((double)((pos.y - this._scrollStartPosition) / this._childSize))));
		}

		// Token: 0x06000471 RID: 1137 RVA: 0x0001B15C File Offset: 0x0001935C
		internal void GetPositionforPage(int page, ref Vector3 target)
		{
			this._childPos = -this._childSize * (float)page;
			if (this._isVertical)
			{
				this._infiniteOffset = ((this._screensContainer.anchoredPosition.y < 0f) ? (-this._screensContainer.sizeDelta.y * (float)this._infiniteWindow) : (this._screensContainer.sizeDelta.y * (float)this._infiniteWindow));
				this._infiniteOffset = ((this._infiniteOffset == 0f) ? 0f : ((this._infiniteOffset < 0f) ? (this._infiniteOffset - this._childSize * (float)this._infiniteWindow) : (this._infiniteOffset + this._childSize * (float)this._infiniteWindow)));
				target.y = this._childPos + this._scrollStartPosition + this._infiniteOffset;
				return;
			}
			this._infiniteOffset = ((this._screensContainer.anchoredPosition.x < 0f) ? (-this._screensContainer.sizeDelta.x * (float)this._infiniteWindow) : (this._screensContainer.sizeDelta.x * (float)this._infiniteWindow));
			this._infiniteOffset = ((this._infiniteOffset == 0f) ? 0f : ((this._infiniteOffset < 0f) ? (this._infiniteOffset - this._childSize * (float)this._infiniteWindow) : (this._infiniteOffset + this._childSize * (float)this._infiniteWindow)));
			target.x = this._childPos + this._scrollStartPosition + this._infiniteOffset;
		}

		// Token: 0x06000472 RID: 1138 RVA: 0x0001B300 File Offset: 0x00019500
		internal void ScrollToClosestElement()
		{
			this._lerp = true;
			this.CurrentPage = this.GetPageforPosition(this._screensContainer.anchoredPosition);
			this.GetPositionforPage(this._currentPage, ref this._lerp_target);
			this.OnCurrentScreenChange(this._currentPage);
		}

		// Token: 0x06000473 RID: 1139 RVA: 0x0001B34E File Offset: 0x0001954E
		internal void OnCurrentScreenChange(int currentScreen)
		{
			this.ChangeBulletsInfo(currentScreen);
			this.ToggleNavigationButtons(currentScreen);
		}

		// Token: 0x06000474 RID: 1140 RVA: 0x0001B360 File Offset: 0x00019560
		private void ChangeBulletsInfo(int targetScreen)
		{
			if (this.Pagination)
			{
				for (int i = 0; i < this.Pagination.transform.childCount; i++)
				{
					this.Pagination.transform.GetChild(i).GetComponent<Toggle>().isOn = targetScreen == i;
				}
			}
		}

		// Token: 0x06000475 RID: 1141 RVA: 0x0001B3B8 File Offset: 0x000195B8
		private void ToggleNavigationButtons(int targetScreen)
		{
			if (!this._isInfinite)
			{
				if (this.PrevButton)
				{
					this.PrevButton.GetComponent<Button>().interactable = targetScreen > 0;
				}
				if (this.NextButton)
				{
					this.NextButton.GetComponent<Button>().interactable = targetScreen < this._screensContainer.transform.childCount - 1;
				}
			}
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0001B420 File Offset: 0x00019620
		private void OnValidate()
		{
			if (this._scroll_rect == null)
			{
				this._scroll_rect = base.GetComponent<ScrollRect>();
			}
			if (!this._scroll_rect.horizontal && !this._scroll_rect.vertical)
			{
				Debug.LogError("ScrollRect has to have a direction, please select either Horizontal OR Vertical with the appropriate control.");
			}
			if (this._scroll_rect.horizontal && this._scroll_rect.vertical)
			{
				Debug.LogError("ScrollRect has to be unidirectional, only use either Horizontal or Vertical on the ScrollRect, NOT both.");
			}
			RectTransform content = base.gameObject.GetComponent<ScrollRect>().content;
			if (content != null)
			{
				int childCount = content.childCount;
				if (childCount != 0 || this.ChildObjects != null)
				{
					int num = ((this.ChildObjects == null || this.ChildObjects.Length == 0) ? childCount : this.ChildObjects.Length);
					if (this.StartingScreen > num - 1)
					{
						this.StartingScreen = num - 1;
					}
					if (this.StartingScreen < 0)
					{
						this.StartingScreen = 0;
					}
				}
			}
			if (this.MaskBuffer <= 0f)
			{
				this.MaskBuffer = 1f;
			}
			if (this.PageStep < 0f)
			{
				this.PageStep = 0f;
			}
			if (this.PageStep > 8f)
			{
				this.PageStep = 9f;
			}
			UI_InfiniteScroll component = base.GetComponent<UI_InfiniteScroll>();
			if (this.ChildObjects != null && this.ChildObjects.Length != 0 && component != null && !component.InitByUser)
			{
				Debug.LogError("[" + base.gameObject.name + "]When using procedural children with a ScrollSnap (Adding Prefab ChildObjects) and the Infinite Scroll component\nYou must set the 'InitByUser' option to true, to enable late initialising");
			}
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0001B58C File Offset: 0x0001978C
		public void StartScreenChange()
		{
			if (!this._startEventCalled)
			{
				this._suspendEvents = true;
				this._startEventCalled = true;
				this._endEventCalled = false;
				this.OnSelectionChangeStartEvent.Invoke();
			}
		}

		// Token: 0x06000478 RID: 1144 RVA: 0x0001B5B6 File Offset: 0x000197B6
		internal void ScreenChange()
		{
			this.OnSelectionPageChangedEvent.Invoke(this._currentPage);
		}

		// Token: 0x06000479 RID: 1145 RVA: 0x0001B5C9 File Offset: 0x000197C9
		internal void EndScreenChange()
		{
			if (!this._endEventCalled)
			{
				this._suspendEvents = false;
				this._endEventCalled = true;
				this._startEventCalled = false;
				this._settled = true;
				this.OnSelectionChangeEndEvent.Invoke(this._currentPage);
			}
		}

		// Token: 0x0600047A RID: 1146 RVA: 0x0001B600 File Offset: 0x00019800
		public Transform CurrentPageObject()
		{
			return this._screensContainer.GetChild(this.CurrentPage);
		}

		// Token: 0x0600047B RID: 1147 RVA: 0x0001B613 File Offset: 0x00019813
		public void CurrentPageObject(out Transform returnObject)
		{
			returnObject = this._screensContainer.GetChild(this.CurrentPage);
		}

		// Token: 0x0600047C RID: 1148 RVA: 0x0001B628 File Offset: 0x00019828
		public void OnBeginDrag(PointerEventData eventData)
		{
			this._pointerDown = true;
			this._settled = false;
			this.StartScreenChange();
			this._startPosition = this._screensContainer.anchoredPosition;
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x0001B654 File Offset: 0x00019854
		public void OnDrag(PointerEventData eventData)
		{
			this._lerp = false;
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0001B65D File Offset: 0x0001985D
		public virtual void OnEndDrag(PointerEventData eventData)
		{
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0001B660 File Offset: 0x00019860
		int IScrollSnap.CurrentPage()
		{
			return this.CurrentPage = this.GetPageforPosition(this._screensContainer.anchoredPosition);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0001B68C File Offset: 0x0001988C
		public void SetLerp(bool value)
		{
			this._lerp = value;
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0001B695 File Offset: 0x00019895
		public void ChangePage(int page)
		{
			this.GoToScreen(page);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x0001B69E File Offset: 0x0001989E
		public void OnPointerClick(PointerEventData eventData)
		{
			Vector2 anchoredPosition = this._screensContainer.anchoredPosition;
		}

		// Token: 0x0400034B RID: 843
		internal Rect panelDimensions;

		// Token: 0x0400034C RID: 844
		internal RectTransform _screensContainer;

		// Token: 0x0400034D RID: 845
		internal bool _isVertical;

		// Token: 0x0400034E RID: 846
		internal int _screens = 1;

		// Token: 0x0400034F RID: 847
		internal float _scrollStartPosition;

		// Token: 0x04000350 RID: 848
		internal float _childSize;

		// Token: 0x04000351 RID: 849
		private float _childPos;

		// Token: 0x04000352 RID: 850
		private float _maskSize;

		// Token: 0x04000353 RID: 851
		internal Vector2 _childAnchorPoint;

		// Token: 0x04000354 RID: 852
		internal ScrollRect _scroll_rect;

		// Token: 0x04000355 RID: 853
		internal Vector3 _lerp_target;

		// Token: 0x04000356 RID: 854
		internal bool _lerp;

		// Token: 0x04000357 RID: 855
		internal bool _pointerDown;

		// Token: 0x04000358 RID: 856
		internal bool _settled = true;

		// Token: 0x04000359 RID: 857
		internal Vector3 _startPosition;

		// Token: 0x0400035A RID: 858
		[Tooltip("The currently active page")]
		internal int _currentPage;

		// Token: 0x0400035B RID: 859
		internal int _previousPage;

		// Token: 0x0400035C RID: 860
		internal int _halfNoVisibleItems;

		// Token: 0x0400035D RID: 861
		internal bool _isInfinite;

		// Token: 0x0400035E RID: 862
		internal int _infiniteWindow;

		// Token: 0x0400035F RID: 863
		internal float _infiniteOffset;

		// Token: 0x04000360 RID: 864
		private int _bottomItem;

		// Token: 0x04000361 RID: 865
		private int _topItem;

		// Token: 0x04000362 RID: 866
		internal bool _startEventCalled;

		// Token: 0x04000363 RID: 867
		internal bool _endEventCalled;

		// Token: 0x04000364 RID: 868
		internal bool _suspendEvents;

		// Token: 0x04000365 RID: 869
		[Tooltip("The screen / page to start the control on\n*Note, this is a 0 indexed array")]
		[SerializeField]
		public int StartingScreen;

		// Token: 0x04000366 RID: 870
		[Tooltip("The distance between two pages based on page height, by default pages are next to each other")]
		[SerializeField]
		[Range(0f, 8f)]
		public float PageStep = 1f;

		// Token: 0x04000367 RID: 871
		[Tooltip("The gameobject that contains toggles which suggest pagination. (optional)")]
		public GameObject Pagination;

		// Token: 0x04000368 RID: 872
		[Tooltip("Button to go to the previous page. (optional)")]
		public GameObject PrevButton;

		// Token: 0x04000369 RID: 873
		[Tooltip("Button to go to the next page. (optional)")]
		public GameObject NextButton;

		// Token: 0x0400036A RID: 874
		[Tooltip("Transition speed between pages. (optional)")]
		public float transitionSpeed = 7.5f;

		// Token: 0x0400036B RID: 875
		[Tooltip("Hard Swipe forces to swiping to the next / previous page (optional)")]
		public bool UseHardSwipe;

		// Token: 0x0400036C RID: 876
		[Tooltip("Fast Swipe makes swiping page next / previous (optional)")]
		public bool UseFastSwipe;

		// Token: 0x0400036D RID: 877
		[Tooltip("Swipe Delta Threshold looks at the speed of input to decide if a swipe will be initiated (optional)")]
		public bool UseSwipeDeltaThreshold;

		// Token: 0x0400036E RID: 878
		[Tooltip("Offset for how far a swipe has to travel to initiate a page change (optional)")]
		public int FastSwipeThreshold = 100;

		// Token: 0x0400036F RID: 879
		[Tooltip("Speed at which the ScrollRect will keep scrolling before slowing down and stopping (optional)")]
		public int SwipeVelocityThreshold = 100;

		// Token: 0x04000370 RID: 880
		[Tooltip("Threshold for swipe speed to initiate a swipe, below threshold will return to closest page (optional)")]
		public float SwipeDeltaThreshold = 5f;

		// Token: 0x04000371 RID: 881
		[Tooltip("Use time scale instead of unscaled time (optional)")]
		public bool UseTimeScale = true;

		// Token: 0x04000372 RID: 882
		[Tooltip("The visible bounds area, controls which items are visible/enabled. *Note Should use a RectMask. (optional)")]
		public RectTransform MaskArea;

		// Token: 0x04000373 RID: 883
		[Tooltip("Pixel size to buffer around Mask Area. (optional)")]
		public float MaskBuffer = 1f;

		// Token: 0x04000374 RID: 884
		[Tooltip("By default the container will lerp to the start when enabled in the scene, this option overrides this and forces it to simply jump without lerping")]
		public bool JumpOnEnable;

		// Token: 0x04000375 RID: 885
		[Tooltip("By default the container will return to the original starting page when enabled, this option overrides this behaviour and stays on the current selection")]
		public bool RestartOnEnable;

		// Token: 0x04000376 RID: 886
		[Tooltip("(Experimental)\nBy default, child array objects will use the parent transform\nHowever you can disable this for some interesting effects")]
		public bool UseParentTransform = true;

		// Token: 0x04000377 RID: 887
		[Tooltip("Scroll Snap children. (optional)\nEither place objects in the scene as children OR\nPrefabs in this array, NOT BOTH")]
		public GameObject[] ChildObjects;

		// Token: 0x04000378 RID: 888
		[SerializeField]
		[Tooltip("Event fires when a user starts to change the selection")]
		private ScrollSnapBase.SelectionChangeStartEvent m_OnSelectionChangeStartEvent = new ScrollSnapBase.SelectionChangeStartEvent();

		// Token: 0x04000379 RID: 889
		[SerializeField]
		[Tooltip("Event fires as the page changes, while dragging or jumping")]
		private ScrollSnapBase.SelectionPageChangedEvent m_OnSelectionPageChangedEvent = new ScrollSnapBase.SelectionPageChangedEvent();

		// Token: 0x0400037A RID: 890
		[SerializeField]
		[Tooltip("Event fires when the page settles after a user has dragged")]
		private ScrollSnapBase.SelectionChangeEndEvent m_OnSelectionChangeEndEvent = new ScrollSnapBase.SelectionChangeEndEvent();

		// Token: 0x0200013B RID: 315
		[Serializable]
		public class SelectionChangeStartEvent : UnityEvent
		{
		}

		// Token: 0x0200013C RID: 316
		[Serializable]
		public class SelectionPageChangedEvent : UnityEvent<int>
		{
		}

		// Token: 0x0200013D RID: 317
		[Serializable]
		public class SelectionChangeEndEvent : UnityEvent<int>
		{
		}
	}
}
