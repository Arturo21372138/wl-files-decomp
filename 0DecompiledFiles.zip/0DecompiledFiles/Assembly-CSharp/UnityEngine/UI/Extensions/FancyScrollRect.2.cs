﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000083 RID: 131
	public abstract class FancyScrollRect<TItemData> : FancyScrollRect<TItemData, FancyScrollRectContext>
	{
	}
}
