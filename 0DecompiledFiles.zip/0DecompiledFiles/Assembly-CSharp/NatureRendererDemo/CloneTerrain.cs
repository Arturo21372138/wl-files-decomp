﻿using System;
using UnityEngine;

namespace NatureRendererDemo
{
	// Token: 0x02000015 RID: 21
	public class CloneTerrain : MonoBehaviour
	{
		// Token: 0x06000032 RID: 50 RVA: 0x00003496 File Offset: 0x00001696
		private void Awake()
		{
			this.CloneTerrainData();
		}

		// Token: 0x06000033 RID: 51 RVA: 0x000034A0 File Offset: 0x000016A0
		private void CloneTerrainData()
		{
			TerrainData terrainData = Object.Instantiate<TerrainData>(this.Terrain.terrainData);
			this.Terrain.terrainData = terrainData;
			this.Terrain.GetComponent<TerrainCollider>().terrainData = terrainData;
		}

		// Token: 0x04000029 RID: 41
		public Terrain Terrain;
	}
}
