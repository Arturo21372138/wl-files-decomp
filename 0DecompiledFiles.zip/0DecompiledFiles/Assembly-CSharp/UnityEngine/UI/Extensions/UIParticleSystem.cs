﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000067 RID: 103
	[ExecuteInEditMode]
	[RequireComponent(typeof(CanvasRenderer), typeof(ParticleSystem))]
	[AddComponentMenu("UI/Effects/Extensions/UIParticleSystem")]
	public class UIParticleSystem : MaskableGraphic
	{
		// Token: 0x17000083 RID: 131
		// (get) Token: 0x0600030B RID: 779 RVA: 0x00013108 File Offset: 0x00011308
		public override Texture mainTexture
		{
			get
			{
				return this.currentTexture;
			}
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00013110 File Offset: 0x00011310
		protected bool Initialize()
		{
			if (this._transform == null)
			{
				this._transform = base.transform;
			}
			if (this.pSystem == null)
			{
				this.pSystem = base.GetComponent<ParticleSystem>();
				if (this.pSystem == null)
				{
					return false;
				}
				this.mainModule = this.pSystem.main;
				if (this.pSystem.main.maxParticles > 14000)
				{
					this.mainModule.maxParticles = 14000;
				}
				this.pRenderer = this.pSystem.GetComponent<ParticleSystemRenderer>();
				if (this.pRenderer != null)
				{
					this.pRenderer.enabled = false;
				}
				if (this.material == null)
				{
					Shader shaderInstance = ShaderLibrary.GetShaderInstance("UI Extensions/Particles/Additive");
					if (shaderInstance)
					{
						this.material = new Material(shaderInstance);
					}
				}
				this.currentMaterial = this.material;
				if (this.currentMaterial && this.currentMaterial.HasProperty("_MainTex"))
				{
					this.currentTexture = this.currentMaterial.mainTexture;
					if (this.currentTexture == null)
					{
						this.currentTexture = Texture2D.whiteTexture;
					}
				}
				this.material = this.currentMaterial;
				this.mainModule.scalingMode = ParticleSystemScalingMode.Hierarchy;
				this.particles = null;
			}
			if (this.particles == null)
			{
				this.particles = new ParticleSystem.Particle[this.pSystem.main.maxParticles];
			}
			this.imageUV = new Vector4(0f, 0f, 1f, 1f);
			this.textureSheetAnimation = this.pSystem.textureSheetAnimation;
			this.textureSheetAnimationFrames = 0;
			this.textureSheetAnimationFrameSize = Vector2.zero;
			if (this.textureSheetAnimation.enabled)
			{
				this.textureSheetAnimationFrames = this.textureSheetAnimation.numTilesX * this.textureSheetAnimation.numTilesY;
				this.textureSheetAnimationFrameSize = new Vector2(1f / (float)this.textureSheetAnimation.numTilesX, 1f / (float)this.textureSheetAnimation.numTilesY);
			}
			return true;
		}

		// Token: 0x0600030D RID: 781 RVA: 0x0001332D File Offset: 0x0001152D
		protected override void Awake()
		{
			base.Awake();
			if (!this.Initialize())
			{
				base.enabled = false;
			}
		}

		// Token: 0x0600030E RID: 782 RVA: 0x00013344 File Offset: 0x00011544
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			vh.Clear();
			if (!base.gameObject.activeInHierarchy)
			{
				return;
			}
			if (!this.isInitialised && !this.pSystem.main.playOnAwake)
			{
				this.pSystem.Stop(false, ParticleSystemStopBehavior.StopEmittingAndClear);
				this.isInitialised = true;
			}
			Vector2 zero = Vector2.zero;
			Vector2 zero2 = Vector2.zero;
			Vector2 zero3 = Vector2.zero;
			int num = this.pSystem.GetParticles(this.particles);
			for (int i = 0; i < num; i++)
			{
				ParticleSystem.Particle particle = this.particles[i];
				Vector2 vector = ((this.mainModule.simulationSpace == ParticleSystemSimulationSpace.Local) ? particle.position : this._transform.InverseTransformPoint(particle.position));
				float num2 = -particle.rotation * 0.017453292f;
				float num3 = num2 + 1.5707964f;
				Color32 currentColor = particle.GetCurrentColor(this.pSystem);
				float num4 = particle.GetCurrentSize(this.pSystem) * 0.5f;
				if (this.mainModule.scalingMode == ParticleSystemScalingMode.Shape)
				{
					vector /= base.canvas.scaleFactor;
				}
				Vector4 vector2 = this.imageUV;
				if (this.textureSheetAnimation.enabled)
				{
					float num5 = 1f - particle.remainingLifetime / particle.startLifetime;
					if (this.textureSheetAnimation.frameOverTime.curveMin != null)
					{
						num5 = this.textureSheetAnimation.frameOverTime.curveMin.Evaluate(1f - particle.remainingLifetime / particle.startLifetime);
					}
					else if (this.textureSheetAnimation.frameOverTime.curve != null)
					{
						num5 = this.textureSheetAnimation.frameOverTime.curve.Evaluate(1f - particle.remainingLifetime / particle.startLifetime);
					}
					else if (this.textureSheetAnimation.frameOverTime.constant > 0f)
					{
						num5 = this.textureSheetAnimation.frameOverTime.constant - particle.remainingLifetime / particle.startLifetime;
					}
					num5 = Mathf.Repeat(num5 * (float)this.textureSheetAnimation.cycleCount, 1f);
					int num6 = 0;
					ParticleSystemAnimationType animation = this.textureSheetAnimation.animation;
					if (animation != ParticleSystemAnimationType.WholeSheet)
					{
						if (animation == ParticleSystemAnimationType.SingleRow)
						{
							num6 = Mathf.FloorToInt(num5 * (float)this.textureSheetAnimation.numTilesX);
							int num7 = this.textureSheetAnimation.rowIndex;
							if (this.textureSheetAnimation.useRandomRow)
							{
								num7 = Mathf.Abs((int)(particle.randomSeed % (uint)this.textureSheetAnimation.numTilesY));
							}
							num6 += num7 * this.textureSheetAnimation.numTilesX;
						}
					}
					else
					{
						num6 = Mathf.FloorToInt(num5 * (float)this.textureSheetAnimationFrames);
					}
					num6 %= this.textureSheetAnimationFrames;
					vector2.x = (float)(num6 % this.textureSheetAnimation.numTilesX) * this.textureSheetAnimationFrameSize.x;
					vector2.y = 1f - (float)(num6 / this.textureSheetAnimation.numTilesX + 1) * this.textureSheetAnimationFrameSize.y;
					vector2.z = vector2.x + this.textureSheetAnimationFrameSize.x;
					vector2.w = vector2.y + this.textureSheetAnimationFrameSize.y;
				}
				zero.x = vector2.x;
				zero.y = vector2.y;
				this._quad[0] = UIVertex.simpleVert;
				this._quad[0].color = currentColor;
				this._quad[0].uv0 = zero;
				zero.x = vector2.x;
				zero.y = vector2.w;
				this._quad[1] = UIVertex.simpleVert;
				this._quad[1].color = currentColor;
				this._quad[1].uv0 = zero;
				zero.x = vector2.z;
				zero.y = vector2.w;
				this._quad[2] = UIVertex.simpleVert;
				this._quad[2].color = currentColor;
				this._quad[2].uv0 = zero;
				zero.x = vector2.z;
				zero.y = vector2.y;
				this._quad[3] = UIVertex.simpleVert;
				this._quad[3].color = currentColor;
				this._quad[3].uv0 = zero;
				if (num2 == 0f)
				{
					zero2.x = vector.x - num4;
					zero2.y = vector.y - num4;
					zero3.x = vector.x + num4;
					zero3.y = vector.y + num4;
					zero.x = zero2.x;
					zero.y = zero2.y;
					this._quad[0].position = zero;
					zero.x = zero2.x;
					zero.y = zero3.y;
					this._quad[1].position = zero;
					zero.x = zero3.x;
					zero.y = zero3.y;
					this._quad[2].position = zero;
					zero.x = zero3.x;
					zero.y = zero2.y;
					this._quad[3].position = zero;
				}
				else if (this.use3dRotation)
				{
					Vector3 vector3 = ((this.mainModule.simulationSpace == ParticleSystemSimulationSpace.Local) ? particle.position : this._transform.InverseTransformPoint(particle.position));
					if (this.mainModule.scalingMode == ParticleSystemScalingMode.Shape)
					{
						vector /= base.canvas.scaleFactor;
					}
					Vector3[] array = new Vector3[]
					{
						new Vector3(-num4, -num4, 0f),
						new Vector3(-num4, num4, 0f),
						new Vector3(num4, num4, 0f),
						new Vector3(num4, -num4, 0f)
					};
					Quaternion quaternion = Quaternion.Euler(particle.rotation3D);
					this._quad[0].position = vector3 + quaternion * array[0];
					this._quad[1].position = vector3 + quaternion * array[1];
					this._quad[2].position = vector3 + quaternion * array[2];
					this._quad[3].position = vector3 + quaternion * array[3];
				}
				else
				{
					Vector2 vector4 = new Vector2(Mathf.Cos(num2), Mathf.Sin(num2)) * num4;
					Vector2 vector5 = new Vector2(Mathf.Cos(num3), Mathf.Sin(num3)) * num4;
					this._quad[0].position = vector - vector4 - vector5;
					this._quad[1].position = vector - vector4 + vector5;
					this._quad[2].position = vector + vector4 + vector5;
					this._quad[3].position = vector + vector4 - vector5;
				}
				vh.AddUIVertexQuad(this._quad);
			}
		}

		// Token: 0x0600030F RID: 783 RVA: 0x00013B5C File Offset: 0x00011D5C
		private void Update()
		{
			if (!this.fixedTime && Application.isPlaying)
			{
				this.pSystem.Simulate(Time.unscaledDeltaTime, false, false, true);
				this.SetAllDirty();
				if ((this.currentMaterial != null && this.currentTexture != this.currentMaterial.mainTexture) || (this.material != null && this.currentMaterial != null && this.material.shader != this.currentMaterial.shader))
				{
					this.pSystem = null;
					this.Initialize();
				}
			}
		}

		// Token: 0x06000310 RID: 784 RVA: 0x00013C04 File Offset: 0x00011E04
		private void LateUpdate()
		{
			if (!Application.isPlaying)
			{
				this.SetAllDirty();
			}
			else if (this.fixedTime)
			{
				this.pSystem.Simulate(Time.unscaledDeltaTime, false, false, true);
				this.SetAllDirty();
				if ((this.currentMaterial != null && this.currentTexture != this.currentMaterial.mainTexture) || (this.material != null && this.currentMaterial != null && this.material.shader != this.currentMaterial.shader))
				{
					this.pSystem = null;
					this.Initialize();
				}
			}
			if (this.material == this.currentMaterial)
			{
				return;
			}
			this.pSystem = null;
			this.Initialize();
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00013CD6 File Offset: 0x00011ED6
		protected override void OnDestroy()
		{
			this.currentMaterial = null;
			this.currentTexture = null;
		}

		// Token: 0x06000312 RID: 786 RVA: 0x00013CE6 File Offset: 0x00011EE6
		public void StartParticleEmission()
		{
			this.pSystem.time = 0f;
			this.pSystem.Play();
		}

		// Token: 0x06000313 RID: 787 RVA: 0x00013D03 File Offset: 0x00011F03
		public void StopParticleEmission()
		{
			this.pSystem.Stop(false, ParticleSystemStopBehavior.StopEmittingAndClear);
		}

		// Token: 0x06000314 RID: 788 RVA: 0x00013D12 File Offset: 0x00011F12
		public void PauseParticleEmission()
		{
			this.pSystem.Stop(false, ParticleSystemStopBehavior.StopEmitting);
		}

		// Token: 0x0400025A RID: 602
		[Tooltip("Having this enabled run the system in LateUpdate rather than in Update making it faster but less precise (more clunky)")]
		public bool fixedTime = true;

		// Token: 0x0400025B RID: 603
		[Tooltip("Enables 3d rotation for the particles")]
		public bool use3dRotation;

		// Token: 0x0400025C RID: 604
		private Transform _transform;

		// Token: 0x0400025D RID: 605
		private ParticleSystem pSystem;

		// Token: 0x0400025E RID: 606
		private ParticleSystem.Particle[] particles;

		// Token: 0x0400025F RID: 607
		private UIVertex[] _quad = new UIVertex[4];

		// Token: 0x04000260 RID: 608
		private Vector4 imageUV = Vector4.zero;

		// Token: 0x04000261 RID: 609
		private ParticleSystem.TextureSheetAnimationModule textureSheetAnimation;

		// Token: 0x04000262 RID: 610
		private int textureSheetAnimationFrames;

		// Token: 0x04000263 RID: 611
		private Vector2 textureSheetAnimationFrameSize;

		// Token: 0x04000264 RID: 612
		private ParticleSystemRenderer pRenderer;

		// Token: 0x04000265 RID: 613
		private bool isInitialised;

		// Token: 0x04000266 RID: 614
		private Material currentMaterial;

		// Token: 0x04000267 RID: 615
		private Texture currentTexture;

		// Token: 0x04000268 RID: 616
		private ParticleSystem.MainModule mainModule;
	}
}
