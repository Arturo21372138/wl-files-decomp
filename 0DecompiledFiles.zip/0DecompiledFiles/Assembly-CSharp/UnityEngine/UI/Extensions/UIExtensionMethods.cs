﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C0 RID: 192
	public static class UIExtensionMethods
	{
		// Token: 0x0600063E RID: 1598 RVA: 0x00024BD4 File Offset: 0x00022DD4
		public static Canvas GetParentCanvas(this RectTransform rt)
		{
			RectTransform rectTransform = rt;
			Canvas canvas = rt.GetComponent<Canvas>();
			int num = 0;
			while (canvas == null || num > 50)
			{
				canvas = rt.GetComponentInParent<Canvas>();
				if (canvas == null)
				{
					rectTransform = rectTransform.parent.GetComponent<RectTransform>();
					num++;
				}
			}
			return canvas;
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x00024C1D File Offset: 0x00022E1D
		public static Vector2 TransformInputBasedOnCanvasType(this Vector2 input, Canvas canvas)
		{
			if (canvas.renderMode == RenderMode.ScreenSpaceOverlay)
			{
				return canvas.GetEventCamera().ScreenToWorldPoint(input);
			}
			return input;
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x00024C40 File Offset: 0x00022E40
		public static Vector3 TransformInputBasedOnCanvasType(this Vector2 input, RectTransform rt)
		{
			Canvas parentCanvas = rt.GetParentCanvas();
			if (input == Vector2.zero || parentCanvas.renderMode == RenderMode.ScreenSpaceOverlay)
			{
				return input;
			}
			Vector2 vector;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(rt, input, parentCanvas.GetEventCamera(), out vector);
			return parentCanvas.transform.TransformPoint(vector);
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x00024C91 File Offset: 0x00022E91
		public static Camera GetEventCamera(this Canvas input)
		{
			if (!(input.worldCamera == null))
			{
				return input.worldCamera;
			}
			return Camera.main;
		}
	}
}
