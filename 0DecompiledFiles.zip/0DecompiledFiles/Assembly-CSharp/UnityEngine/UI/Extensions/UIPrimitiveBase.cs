﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A2 RID: 162
	[RequireComponent(typeof(CanvasRenderer))]
	public class UIPrimitiveBase : MaskableGraphic, ILayoutElement, ICanvasRaycastFilter
	{
		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x00020646 File Offset: 0x0001E846
		// (set) Token: 0x0600055D RID: 1373 RVA: 0x0002064E File Offset: 0x0001E84E
		public Sprite sprite
		{
			get
			{
				return this.m_Sprite;
			}
			set
			{
				if (SetPropertyUtility.SetClass<Sprite>(ref this.m_Sprite, value))
				{
					this.GeneratedUVs();
				}
				this.SetAllDirty();
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x0002066A File Offset: 0x0001E86A
		// (set) Token: 0x0600055F RID: 1375 RVA: 0x00020672 File Offset: 0x0001E872
		public Sprite overrideSprite
		{
			get
			{
				return this.activeSprite;
			}
			set
			{
				if (SetPropertyUtility.SetClass<Sprite>(ref this.m_OverrideSprite, value))
				{
					this.GeneratedUVs();
				}
				this.SetAllDirty();
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000560 RID: 1376 RVA: 0x0002068E File Offset: 0x0001E88E
		protected Sprite activeSprite
		{
			get
			{
				if (!(this.m_OverrideSprite != null))
				{
					return this.sprite;
				}
				return this.m_OverrideSprite;
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000561 RID: 1377 RVA: 0x000206AB File Offset: 0x0001E8AB
		// (set) Token: 0x06000562 RID: 1378 RVA: 0x000206B3 File Offset: 0x0001E8B3
		public float eventAlphaThreshold
		{
			get
			{
				return this.m_EventAlphaThreshold;
			}
			set
			{
				this.m_EventAlphaThreshold = value;
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000563 RID: 1379 RVA: 0x000206BC File Offset: 0x0001E8BC
		// (set) Token: 0x06000564 RID: 1380 RVA: 0x000206C4 File Offset: 0x0001E8C4
		public ResolutionMode ImproveResolution
		{
			get
			{
				return this.m_improveResolution;
			}
			set
			{
				this.m_improveResolution = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000565 RID: 1381 RVA: 0x000206D3 File Offset: 0x0001E8D3
		// (set) Token: 0x06000566 RID: 1382 RVA: 0x000206DB File Offset: 0x0001E8DB
		public float Resolution
		{
			get
			{
				return this.m_Resolution;
			}
			set
			{
				this.m_Resolution = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000567 RID: 1383 RVA: 0x000206EA File Offset: 0x0001E8EA
		// (set) Token: 0x06000568 RID: 1384 RVA: 0x000206F2 File Offset: 0x0001E8F2
		public bool UseNativeSize
		{
			get
			{
				return this.m_useNativeSize;
			}
			set
			{
				this.m_useNativeSize = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x00020701 File Offset: 0x0001E901
		protected UIPrimitiveBase()
		{
			base.useLegacyMeshGeneration = false;
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600056A RID: 1386 RVA: 0x00020726 File Offset: 0x0001E926
		public static Material defaultETC1GraphicMaterial
		{
			get
			{
				if (UIPrimitiveBase.s_ETC1DefaultUI == null)
				{
					UIPrimitiveBase.s_ETC1DefaultUI = Canvas.GetETC1SupportedCanvasMaterial();
				}
				return UIPrimitiveBase.s_ETC1DefaultUI;
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600056B RID: 1387 RVA: 0x00020744 File Offset: 0x0001E944
		public override Texture mainTexture
		{
			get
			{
				if (!(this.activeSprite == null))
				{
					return this.activeSprite.texture;
				}
				if (this.material != null && this.material.mainTexture != null)
				{
					return this.material.mainTexture;
				}
				return Graphic.s_WhiteTexture;
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600056C RID: 1388 RVA: 0x000207A0 File Offset: 0x0001E9A0
		public bool hasBorder
		{
			get
			{
				return this.activeSprite != null && this.activeSprite.border.sqrMagnitude > 0f;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x0600056D RID: 1389 RVA: 0x000207D8 File Offset: 0x0001E9D8
		public float pixelsPerUnit
		{
			get
			{
				float num = 100f;
				if (this.activeSprite)
				{
					num = this.activeSprite.pixelsPerUnit;
				}
				float num2 = 100f;
				if (base.canvas)
				{
					num2 = base.canvas.referencePixelsPerUnit;
				}
				return num / num2;
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x00020828 File Offset: 0x0001EA28
		// (set) Token: 0x0600056F RID: 1391 RVA: 0x00020876 File Offset: 0x0001EA76
		public override Material material
		{
			get
			{
				if (this.m_Material != null)
				{
					return this.m_Material;
				}
				if (this.activeSprite && this.activeSprite.associatedAlphaSplitTexture != null)
				{
					return UIPrimitiveBase.defaultETC1GraphicMaterial;
				}
				return this.defaultMaterial;
			}
			set
			{
				base.material = value;
			}
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x00020880 File Offset: 0x0001EA80
		protected UIVertex[] SetVbo(Vector2[] vertices, Vector2[] uvs)
		{
			UIVertex[] array = new UIVertex[4];
			for (int i = 0; i < vertices.Length; i++)
			{
				UIVertex simpleVert = UIVertex.simpleVert;
				simpleVert.color = this.color;
				simpleVert.position = vertices[i];
				simpleVert.uv0 = uvs[i];
				array[i] = simpleVert;
			}
			return array;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x000208E9 File Offset: 0x0001EAE9
		protected Vector2[] IncreaseResolution(Vector2[] input)
		{
			return this.IncreaseResolution(new List<Vector2>(input)).ToArray();
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x000208FC File Offset: 0x0001EAFC
		protected List<Vector2> IncreaseResolution(List<Vector2> input)
		{
			this.outputList.Clear();
			ResolutionMode improveResolution = this.ImproveResolution;
			if (improveResolution != ResolutionMode.PerSegment)
			{
				if (improveResolution == ResolutionMode.PerLine)
				{
					float num = 0f;
					for (int i = 0; i < input.Count - 1; i++)
					{
						num += Vector2.Distance(input[i], input[i + 1]);
					}
					this.ResolutionToNativeSize(num);
					float num2 = num / this.m_Resolution;
					int num3 = 0;
					for (int j = 0; j < input.Count - 1; j++)
					{
						Vector2 vector = input[j];
						this.outputList.Add(vector);
						Vector2 vector2 = input[j + 1];
						float num4 = Vector2.Distance(vector, vector2) / num2;
						float num5 = 1f / num4;
						int num6 = 0;
						while ((float)num6 < num4)
						{
							this.outputList.Add(Vector2.Lerp(vector, vector2, (float)num6 * num5));
							num3++;
							num6++;
						}
						this.outputList.Add(vector2);
					}
				}
			}
			else
			{
				for (int k = 0; k < input.Count - 1; k++)
				{
					Vector2 vector3 = input[k];
					this.outputList.Add(vector3);
					Vector2 vector4 = input[k + 1];
					this.ResolutionToNativeSize(Vector2.Distance(vector3, vector4));
					float num2 = 1f / this.m_Resolution;
					for (float num7 = 1f; num7 < this.m_Resolution; num7 += 1f)
					{
						this.outputList.Add(Vector2.Lerp(vector3, vector4, num2 * num7));
					}
					this.outputList.Add(vector4);
				}
			}
			return this.outputList;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x00020AB2 File Offset: 0x0001ECB2
		protected virtual void GeneratedUVs()
		{
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x00020AB4 File Offset: 0x0001ECB4
		protected virtual void ResolutionToNativeSize(float distance)
		{
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x00020AB6 File Offset: 0x0001ECB6
		public virtual void CalculateLayoutInputHorizontal()
		{
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x00020AB8 File Offset: 0x0001ECB8
		public virtual void CalculateLayoutInputVertical()
		{
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000577 RID: 1399 RVA: 0x00020ABA File Offset: 0x0001ECBA
		public virtual float minWidth
		{
			get
			{
				return 0f;
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000578 RID: 1400 RVA: 0x00020AC4 File Offset: 0x0001ECC4
		public virtual float preferredWidth
		{
			get
			{
				if (this.overrideSprite == null)
				{
					return 0f;
				}
				return this.overrideSprite.rect.size.x / this.pixelsPerUnit;
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000579 RID: 1401 RVA: 0x00020B04 File Offset: 0x0001ED04
		public virtual float flexibleWidth
		{
			get
			{
				return -1f;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600057A RID: 1402 RVA: 0x00020B0B File Offset: 0x0001ED0B
		public virtual float minHeight
		{
			get
			{
				return 0f;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600057B RID: 1403 RVA: 0x00020B14 File Offset: 0x0001ED14
		public virtual float preferredHeight
		{
			get
			{
				if (this.overrideSprite == null)
				{
					return 0f;
				}
				return this.overrideSprite.rect.size.y / this.pixelsPerUnit;
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600057C RID: 1404 RVA: 0x00020B54 File Offset: 0x0001ED54
		public virtual float flexibleHeight
		{
			get
			{
				return -1f;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x0600057D RID: 1405 RVA: 0x00020B5B File Offset: 0x0001ED5B
		public virtual int layoutPriority
		{
			get
			{
				return 0;
			}
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x00020B60 File Offset: 0x0001ED60
		public virtual bool IsRaycastLocationValid(Vector2 screenPoint, Camera eventCamera)
		{
			if (this.m_EventAlphaThreshold >= 1f)
			{
				return true;
			}
			Sprite overrideSprite = this.overrideSprite;
			if (overrideSprite == null)
			{
				return true;
			}
			Vector2 vector;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(base.rectTransform, screenPoint, eventCamera, out vector);
			Rect pixelAdjustedRect = base.GetPixelAdjustedRect();
			vector.x += base.rectTransform.pivot.x * pixelAdjustedRect.width;
			vector.y += base.rectTransform.pivot.y * pixelAdjustedRect.height;
			vector = this.MapCoordinate(vector, pixelAdjustedRect);
			Rect textureRect = overrideSprite.textureRect;
			Vector2 vector2 = new Vector2(vector.x / textureRect.width, vector.y / textureRect.height);
			float num = Mathf.Lerp(textureRect.x, textureRect.xMax, vector2.x) / (float)overrideSprite.texture.width;
			float num2 = Mathf.Lerp(textureRect.y, textureRect.yMax, vector2.y) / (float)overrideSprite.texture.height;
			bool flag;
			try
			{
				flag = overrideSprite.texture.GetPixelBilinear(num, num2).a >= this.m_EventAlphaThreshold;
			}
			catch (UnityException ex)
			{
				Debug.LogError("Using clickAlphaThreshold lower than 1 on Image whose sprite texture cannot be read. " + ex.Message + " Also make sure to disable sprite packing for this sprite.", this);
				flag = true;
			}
			return flag;
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x00020CC8 File Offset: 0x0001EEC8
		private Vector2 MapCoordinate(Vector2 local, Rect rect)
		{
			Rect rect2 = this.sprite.rect;
			return new Vector2(local.x * rect.width, local.y * rect.height);
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x00020CF8 File Offset: 0x0001EEF8
		private Vector4 GetAdjustedBorders(Vector4 border, Rect rect)
		{
			for (int i = 0; i <= 1; i++)
			{
				float num = border[i] + border[i + 2];
				if (rect.size[i] < num && num != 0f)
				{
					float num2 = rect.size[i] / num;
					ref Vector4 ptr = ref border;
					int num3 = i;
					ptr[num3] *= num2;
					ptr = ref border;
					num3 = i + 2;
					ptr[num3] *= num2;
				}
			}
			return border;
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x00020D8F File Offset: 0x0001EF8F
		protected override void OnEnable()
		{
			base.OnEnable();
			this.SetAllDirty();
		}

		// Token: 0x040003FC RID: 1020
		protected static Material s_ETC1DefaultUI;

		// Token: 0x040003FD RID: 1021
		private List<Vector2> outputList = new List<Vector2>();

		// Token: 0x040003FE RID: 1022
		[SerializeField]
		private Sprite m_Sprite;

		// Token: 0x040003FF RID: 1023
		[NonSerialized]
		private Sprite m_OverrideSprite;

		// Token: 0x04000400 RID: 1024
		internal float m_EventAlphaThreshold = 1f;

		// Token: 0x04000401 RID: 1025
		[SerializeField]
		private ResolutionMode m_improveResolution;

		// Token: 0x04000402 RID: 1026
		[SerializeField]
		protected float m_Resolution;

		// Token: 0x04000403 RID: 1027
		[SerializeField]
		private bool m_useNativeSize;
	}
}
