﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007DD RID: 2013
	public struct AddNotifyAchievementsUnlockedOptions
	{
	}
}
