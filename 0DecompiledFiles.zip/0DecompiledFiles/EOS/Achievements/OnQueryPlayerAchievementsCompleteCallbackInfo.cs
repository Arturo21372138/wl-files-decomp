﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200080D RID: 2061
	public struct OnQueryPlayerAchievementsCompleteCallbackInfo : ICallbackInfo
	{
		// Token: 0x1700086D RID: 2157
		// (get) Token: 0x060021E0 RID: 8672 RVA: 0x000284DD File Offset: 0x000266DD
		// (set) Token: 0x060021E1 RID: 8673 RVA: 0x000284E5 File Offset: 0x000266E5
		public Result ResultCode { readonly get; set; }

		// Token: 0x1700086E RID: 2158
		// (get) Token: 0x060021E2 RID: 8674 RVA: 0x000284EE File Offset: 0x000266EE
		// (set) Token: 0x060021E3 RID: 8675 RVA: 0x000284F6 File Offset: 0x000266F6
		public object ClientData { readonly get; set; }

		// Token: 0x1700086F RID: 2159
		// (get) Token: 0x060021E4 RID: 8676 RVA: 0x000284FF File Offset: 0x000266FF
		// (set) Token: 0x060021E5 RID: 8677 RVA: 0x00028507 File Offset: 0x00026707
		public ProductUserId TargetUserId { readonly get; set; }

		// Token: 0x17000870 RID: 2160
		// (get) Token: 0x060021E6 RID: 8678 RVA: 0x00028510 File Offset: 0x00026710
		// (set) Token: 0x060021E7 RID: 8679 RVA: 0x00028518 File Offset: 0x00026718
		public ProductUserId LocalUserId { readonly get; set; }

		// Token: 0x060021E8 RID: 8680 RVA: 0x00028521 File Offset: 0x00026721
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060021E9 RID: 8681 RVA: 0x00028529 File Offset: 0x00026729
		public Result? GetResultCode()
		{
			return new Result?(this.ResultCode);
		}
	}
}
