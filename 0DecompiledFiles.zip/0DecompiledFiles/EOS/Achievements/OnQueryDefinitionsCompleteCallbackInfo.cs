﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000808 RID: 2056
	public struct OnQueryDefinitionsCompleteCallbackInfo : ICallbackInfo
	{
		// Token: 0x17000869 RID: 2153
		// (get) Token: 0x060021CE RID: 8654 RVA: 0x00028429 File Offset: 0x00026629
		// (set) Token: 0x060021CF RID: 8655 RVA: 0x00028431 File Offset: 0x00026631
		public Result ResultCode { readonly get; set; }

		// Token: 0x1700086A RID: 2154
		// (get) Token: 0x060021D0 RID: 8656 RVA: 0x0002843A File Offset: 0x0002663A
		// (set) Token: 0x060021D1 RID: 8657 RVA: 0x00028442 File Offset: 0x00026642
		public object ClientData { readonly get; set; }

		// Token: 0x060021D2 RID: 8658 RVA: 0x0002844B File Offset: 0x0002664B
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060021D3 RID: 8659 RVA: 0x00028453 File Offset: 0x00026653
		public Result? GetResultCode()
		{
			return new Result?(this.ResultCode);
		}
	}
}
