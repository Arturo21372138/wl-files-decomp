﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000070 RID: 112
	[AddComponentMenu("Layout/Extensions/Curved Layout")]
	public class CurvedLayout : LayoutGroup
	{
		// Token: 0x0600035D RID: 861 RVA: 0x00016699 File Offset: 0x00014899
		protected override void OnEnable()
		{
			base.OnEnable();
			this.CalculateRadial();
		}

		// Token: 0x0600035E RID: 862 RVA: 0x000166A7 File Offset: 0x000148A7
		public override void SetLayoutHorizontal()
		{
		}

		// Token: 0x0600035F RID: 863 RVA: 0x000166A9 File Offset: 0x000148A9
		public override void SetLayoutVertical()
		{
		}

		// Token: 0x06000360 RID: 864 RVA: 0x000166AB File Offset: 0x000148AB
		public override void CalculateLayoutInputVertical()
		{
			this.CalculateRadial();
		}

		// Token: 0x06000361 RID: 865 RVA: 0x000166B3 File Offset: 0x000148B3
		public override void CalculateLayoutInputHorizontal()
		{
			this.CalculateRadial();
		}

		// Token: 0x06000362 RID: 866 RVA: 0x000166BC File Offset: 0x000148BC
		private void CalculateRadial()
		{
			this.m_Tracker.Clear();
			if (base.transform.childCount == 0)
			{
				return;
			}
			Vector2 vector = new Vector2((float)(base.childAlignment % TextAnchor.MiddleLeft) * 0.5f, (float)(base.childAlignment / TextAnchor.MiddleLeft) * 0.5f);
			Vector3 vector2 = new Vector3(base.GetStartOffset(0, base.GetTotalPreferredSize(0)), base.GetStartOffset(1, base.GetTotalPreferredSize(1)), 0f);
			float num = 0f;
			float num2 = 1f / (float)base.transform.childCount;
			Vector3 vector3 = this.itemAxis.normalized * this.itemSize;
			for (int i = 0; i < base.transform.childCount; i++)
			{
				RectTransform rectTransform = (RectTransform)base.transform.GetChild(i);
				if (rectTransform != null)
				{
					this.m_Tracker.Add(this, rectTransform, DrivenTransformProperties.AnchoredPositionX | DrivenTransformProperties.AnchoredPositionY | DrivenTransformProperties.AnchorMinX | DrivenTransformProperties.AnchorMinY | DrivenTransformProperties.AnchorMaxX | DrivenTransformProperties.AnchorMaxY | DrivenTransformProperties.PivotX | DrivenTransformProperties.PivotY);
					Vector3 vector4 = vector2 + vector3;
					vector2 = (rectTransform.localPosition = vector4 + (num - this.centerpoint) * this.CurveOffset);
					rectTransform.pivot = vector;
					RectTransform rectTransform2 = rectTransform;
					RectTransform rectTransform3 = rectTransform;
					Vector2 vector5 = new Vector2(0.5f, 0.5f);
					rectTransform3.anchorMax = vector5;
					rectTransform2.anchorMin = vector5;
					num += num2;
				}
			}
		}

		// Token: 0x040002C4 RID: 708
		public Vector3 CurveOffset;

		// Token: 0x040002C5 RID: 709
		[Tooltip("axis along which to place the items, Normalized before use")]
		public Vector3 itemAxis;

		// Token: 0x040002C6 RID: 710
		[Tooltip("size of each item along the Normalized axis")]
		public float itemSize;

		// Token: 0x040002C7 RID: 711
		public float centerpoint = 0.5f;
	}
}
