﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F2 RID: 2034
	internal struct DefinitionInternal : IGettable<Definition>
	{
		// Token: 0x0600217A RID: 8570 RVA: 0x00027EC0 File Offset: 0x000260C0
		public void Get(out Definition other)
		{
			other = default(Definition);
			Utf8String utf8String;
			Helper.Get(this.m_AchievementId, out utf8String);
			other.AchievementId = utf8String;
			Utf8String utf8String2;
			Helper.Get(this.m_DisplayName, out utf8String2);
			other.DisplayName = utf8String2;
			Utf8String utf8String3;
			Helper.Get(this.m_Description, out utf8String3);
			other.Description = utf8String3;
			Utf8String utf8String4;
			Helper.Get(this.m_LockedDisplayName, out utf8String4);
			other.LockedDisplayName = utf8String4;
			Utf8String utf8String5;
			Helper.Get(this.m_LockedDescription, out utf8String5);
			other.LockedDescription = utf8String5;
			Utf8String utf8String6;
			Helper.Get(this.m_HiddenDescription, out utf8String6);
			other.HiddenDescription = utf8String6;
			Utf8String utf8String7;
			Helper.Get(this.m_CompletionDescription, out utf8String7);
			other.CompletionDescription = utf8String7;
			Utf8String utf8String8;
			Helper.Get(this.m_UnlockedIconId, out utf8String8);
			other.UnlockedIconId = utf8String8;
			Utf8String utf8String9;
			Helper.Get(this.m_LockedIconId, out utf8String9);
			other.LockedIconId = utf8String9;
			bool flag;
			Helper.Get(this.m_IsHidden, out flag);
			other.IsHidden = flag;
			StatThresholds[] array;
			Helper.Get<StatThresholdsInternal, StatThresholds>(this.m_StatThresholds, out array, this.m_StatThresholdsCount, false);
			other.StatThresholds = array;
		}

		// Token: 0x04001659 RID: 5721
		private int m_ApiVersion;

		// Token: 0x0400165A RID: 5722
		private IntPtr m_AchievementId;

		// Token: 0x0400165B RID: 5723
		private IntPtr m_DisplayName;

		// Token: 0x0400165C RID: 5724
		private IntPtr m_Description;

		// Token: 0x0400165D RID: 5725
		private IntPtr m_LockedDisplayName;

		// Token: 0x0400165E RID: 5726
		private IntPtr m_LockedDescription;

		// Token: 0x0400165F RID: 5727
		private IntPtr m_HiddenDescription;

		// Token: 0x04001660 RID: 5728
		private IntPtr m_CompletionDescription;

		// Token: 0x04001661 RID: 5729
		private IntPtr m_UnlockedIconId;

		// Token: 0x04001662 RID: 5730
		private IntPtr m_LockedIconId;

		// Token: 0x04001663 RID: 5731
		private int m_IsHidden;

		// Token: 0x04001664 RID: 5732
		private int m_StatThresholdsCount;

		// Token: 0x04001665 RID: 5733
		private IntPtr m_StatThresholds;
	}
}
