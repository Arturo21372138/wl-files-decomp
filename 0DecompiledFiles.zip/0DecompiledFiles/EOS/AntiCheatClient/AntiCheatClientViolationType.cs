﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B2 RID: 1970
	public enum AntiCheatClientViolationType
	{
		// Token: 0x040015B9 RID: 5561
		Invalid,
		// Token: 0x040015BA RID: 5562
		IntegrityCatalogNotFound,
		// Token: 0x040015BB RID: 5563
		IntegrityCatalogError,
		// Token: 0x040015BC RID: 5564
		IntegrityCatalogCertificateRevoked,
		// Token: 0x040015BD RID: 5565
		IntegrityCatalogMissingMainExecutable,
		// Token: 0x040015BE RID: 5566
		GameFileMismatch,
		// Token: 0x040015BF RID: 5567
		RequiredGameFileNotFound,
		// Token: 0x040015C0 RID: 5568
		UnknownGameFileForbidden,
		// Token: 0x040015C1 RID: 5569
		SystemFileUntrusted,
		// Token: 0x040015C2 RID: 5570
		ForbiddenModuleLoaded,
		// Token: 0x040015C3 RID: 5571
		CorruptedMemory,
		// Token: 0x040015C4 RID: 5572
		ForbiddenToolDetected,
		// Token: 0x040015C5 RID: 5573
		InternalAntiCheatViolation,
		// Token: 0x040015C6 RID: 5574
		CorruptedNetworkMessageFlow,
		// Token: 0x040015C7 RID: 5575
		VirtualMachineNotAllowed,
		// Token: 0x040015C8 RID: 5576
		ForbiddenSystemConfiguration
	}
}
