﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B8 RID: 1976
	internal struct GetProtectMessageOutputLengthOptionsInternal : ISettable<GetProtectMessageOutputLengthOptions>, IDisposable
	{
		// Token: 0x060020AB RID: 8363 RVA: 0x00027047 File Offset: 0x00025247
		public void Set(ref GetProtectMessageOutputLengthOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			this.m_DataLengthBytes = other.DataLengthBytes;
		}

		// Token: 0x060020AC RID: 8364 RVA: 0x00027062 File Offset: 0x00025262
		public void Dispose()
		{
		}

		// Token: 0x040015D0 RID: 5584
		private int m_ApiVersion;

		// Token: 0x040015D1 RID: 5585
		private uint m_DataLengthBytes;
	}
}
