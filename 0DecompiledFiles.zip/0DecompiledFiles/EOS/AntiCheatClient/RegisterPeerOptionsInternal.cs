﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D5 RID: 2005
	internal struct RegisterPeerOptionsInternal : ISettable<RegisterPeerOptions>, IDisposable
	{
		// Token: 0x06002113 RID: 8467 RVA: 0x00027484 File Offset: 0x00025684
		public void Set(ref RegisterPeerOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 3;
			this.m_PeerHandle = other.PeerHandle;
			this.m_ClientType = other.ClientType;
			this.m_ClientPlatform = other.ClientPlatform;
			this.m_AuthenticationTimeout = other.AuthenticationTimeout;
			Helper.Set(other.AccountId_DEPRECATED, ref this.m_AccountId_DEPRECATED);
			Helper.Set(other.IpAddress, ref this.m_IpAddress);
			Helper.Set(other.PeerProductUserId, ref this.m_PeerProductUserId);
		}

		// Token: 0x06002114 RID: 8468 RVA: 0x00027501 File Offset: 0x00025701
		public void Dispose()
		{
			Helper.Dispose(ref this.m_AccountId_DEPRECATED);
			Helper.Dispose(ref this.m_IpAddress);
			Helper.Dispose(ref this.m_PeerProductUserId);
		}

		// Token: 0x040015FC RID: 5628
		private int m_ApiVersion;

		// Token: 0x040015FD RID: 5629
		private IntPtr m_PeerHandle;

		// Token: 0x040015FE RID: 5630
		private AntiCheatCommonClientType m_ClientType;

		// Token: 0x040015FF RID: 5631
		private AntiCheatCommonClientPlatform m_ClientPlatform;

		// Token: 0x04001600 RID: 5632
		private uint m_AuthenticationTimeout;

		// Token: 0x04001601 RID: 5633
		private IntPtr m_AccountId_DEPRECATED;

		// Token: 0x04001602 RID: 5634
		private IntPtr m_IpAddress;

		// Token: 0x04001603 RID: 5635
		private IntPtr m_PeerProductUserId;
	}
}
