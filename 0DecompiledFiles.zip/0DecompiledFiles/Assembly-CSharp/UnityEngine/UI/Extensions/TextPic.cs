﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200004A RID: 74
	[AddComponentMenu("UI/Extensions/TextPic")]
	[ExecuteInEditMode]
	public class TextPic : Text, IPointerClickHandler, IEventSystemHandler, IPointerExitHandler, IPointerEnterHandler, ISelectHandler
	{
		// Token: 0x1700005F RID: 95
		// (get) Token: 0x0600023A RID: 570 RVA: 0x0000C4B4 File Offset: 0x0000A6B4
		// (set) Token: 0x0600023B RID: 571 RVA: 0x0000C4BC File Offset: 0x0000A6BC
		public TextPic.HrefClickEvent onHrefClick
		{
			get
			{
				return this.m_OnHrefClick;
			}
			set
			{
				this.m_OnHrefClick = value;
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x0600023C RID: 572 RVA: 0x0000C4C5 File Offset: 0x0000A6C5
		// (set) Token: 0x0600023D RID: 573 RVA: 0x0000C4CD File Offset: 0x0000A6CD
		public bool Selected
		{
			get
			{
				return this.selected;
			}
			set
			{
				this.selected = value;
			}
		}

		// Token: 0x0600023E RID: 574 RVA: 0x0000C4D6 File Offset: 0x0000A6D6
		public void ResetIconList()
		{
			this.Reset_m_HrefInfos();
			base.Start();
		}

		// Token: 0x0600023F RID: 575 RVA: 0x0000C4E4 File Offset: 0x0000A6E4
		protected void UpdateQuadImage()
		{
			this.m_OutputText = this.GetOutputText();
			this.matches = TextPic.s_Regex.Matches(this.m_OutputText);
			if (this.matches != null && this.matches.Count > 0)
			{
				for (int i = 0; i < this.matches.Count; i++)
				{
					this.m_ImagesPool.RemoveAll((Image image) => image == null);
					if (this.m_ImagesPool.Count == 0)
					{
						base.GetComponentsInChildren<Image>(true, this.m_ImagesPool);
					}
					if (this.matches.Count > this.m_ImagesPool.Count)
					{
						GameObject gameObject = DefaultControls.CreateImage(default(DefaultControls.Resources));
						gameObject.layer = base.gameObject.layer;
						RectTransform rectTransform = gameObject.transform as RectTransform;
						if (rectTransform)
						{
							rectTransform.SetParent(base.rectTransform);
							rectTransform.anchoredPosition3D = Vector3.zero;
							rectTransform.localRotation = Quaternion.identity;
							rectTransform.localScale = Vector3.one;
						}
						this.m_ImagesPool.Add(gameObject.GetComponent<Image>());
					}
					string value = this.matches[i].Groups[1].Value;
					Image image2 = this.m_ImagesPool[i];
					Vector2 vector = Vector2.zero;
					if ((image2.sprite == null || image2.sprite.name != value) && this.inspectorIconList != null && this.inspectorIconList.Length != 0)
					{
						for (int j = 0; j < this.inspectorIconList.Length; j++)
						{
							if (this.inspectorIconList[j].name == value)
							{
								image2.sprite = this.inspectorIconList[j].sprite;
								image2.preserveAspect = true;
								image2.rectTransform.sizeDelta = new Vector2((float)base.fontSize * this.ImageScalingFactor * this.inspectorIconList[j].scale.x, (float)base.fontSize * this.ImageScalingFactor * this.inspectorIconList[j].scale.y);
								vector = this.inspectorIconList[j].offset;
								break;
							}
						}
					}
					image2.enabled = true;
					if (this.positions.Count > 0 && i < this.positions.Count)
					{
						RectTransform rectTransform2 = image2.rectTransform;
						List<Vector2> list = this.positions;
						int num = i;
						rectTransform2.anchoredPosition = (list[num] += vector);
					}
				}
			}
			else
			{
				for (int k = this.m_ImagesPool.Count - 1; k > 0; k--)
				{
					if (this.m_ImagesPool[k] && !this.culled_ImagesPool.Contains(this.m_ImagesPool[k].gameObject))
					{
						this.culled_ImagesPool.Add(this.m_ImagesPool[k].gameObject);
						this.m_ImagesPool.Remove(this.m_ImagesPool[k]);
					}
				}
			}
			for (int l = this.m_ImagesPool.Count - 1; l >= this.matches.Count; l--)
			{
				if (l >= 0 && this.m_ImagesPool.Count > 0 && this.m_ImagesPool[l] && !this.culled_ImagesPool.Contains(this.m_ImagesPool[l].gameObject))
				{
					this.culled_ImagesPool.Add(this.m_ImagesPool[l].gameObject);
					this.m_ImagesPool.Remove(this.m_ImagesPool[l]);
				}
			}
			if (this.culled_ImagesPool.Count > 0)
			{
				this.clearImages = true;
			}
		}

		// Token: 0x06000240 RID: 576 RVA: 0x0000C8F7 File Offset: 0x0000AAF7
		private void Reset_m_HrefInfos()
		{
			this.previousText = this.text;
			this.m_HrefInfos.Clear();
			this.isCreating_m_HrefInfos = true;
		}

		// Token: 0x06000241 RID: 577 RVA: 0x0000C918 File Offset: 0x0000AB18
		protected string GetOutputText()
		{
			TextPic.s_TextBuilder.Length = 0;
			this.indexText = 0;
			this.fixedString = this.text;
			if (this.inspectorIconList != null && this.inspectorIconList.Length != 0)
			{
				for (int i = 0; i < this.inspectorIconList.Length; i++)
				{
					if (!string.IsNullOrEmpty(this.inspectorIconList[i].name))
					{
						this.fixedString = this.fixedString.Replace(this.inspectorIconList[i].name, string.Concat(new string[]
						{
							"<quad name=",
							this.inspectorIconList[i].name,
							" size=",
							base.fontSize.ToString(),
							" width=1 />"
						}));
					}
				}
			}
			this.count = 0;
			this.href_matches = TextPic.s_HrefRegex.Matches(this.fixedString);
			if (this.href_matches != null && this.href_matches.Count > 0)
			{
				for (int j = 0; j < this.href_matches.Count; j++)
				{
					TextPic.s_TextBuilder.Append(this.fixedString.Substring(this.indexText, this.href_matches[j].Index - this.indexText));
					TextPic.s_TextBuilder.Append("<color=" + this.hyperlinkColor + ">");
					Group group = this.href_matches[j].Groups[1];
					if (this.isCreating_m_HrefInfos)
					{
						TextPic.HrefInfo hrefInfo = new TextPic.HrefInfo
						{
							startIndex = (this.usesNewRendering ? TextPic.s_TextBuilder.Length : (TextPic.s_TextBuilder.Length * 4)),
							endIndex = (this.usesNewRendering ? (TextPic.s_TextBuilder.Length + this.href_matches[j].Groups[2].Length - 1) : ((TextPic.s_TextBuilder.Length + this.href_matches[j].Groups[2].Length - 1) * 4 + 3)),
							name = group.Value
						};
						this.m_HrefInfos.Add(hrefInfo);
					}
					else if (this.count <= this.m_HrefInfos.Count - 1)
					{
						this.m_HrefInfos[this.count].startIndex = (this.usesNewRendering ? TextPic.s_TextBuilder.Length : (TextPic.s_TextBuilder.Length * 4));
						this.m_HrefInfos[this.count].endIndex = (this.usesNewRendering ? (TextPic.s_TextBuilder.Length + this.href_matches[j].Groups[2].Length - 1) : ((TextPic.s_TextBuilder.Length + this.href_matches[j].Groups[2].Length - 1) * 4 + 3));
						this.count++;
					}
					TextPic.s_TextBuilder.Append(this.href_matches[j].Groups[2].Value);
					TextPic.s_TextBuilder.Append("</color>");
					this.indexText = this.href_matches[j].Index + this.href_matches[j].Length;
				}
			}
			if (this.isCreating_m_HrefInfos)
			{
				this.isCreating_m_HrefInfos = false;
			}
			TextPic.s_TextBuilder.Append(this.fixedString.Substring(this.indexText, this.fixedString.Length - this.indexText));
			this.m_OutputText = TextPic.s_TextBuilder.ToString();
			this.m_ImagesVertexIndex.Clear();
			this.matches = TextPic.s_Regex.Matches(this.m_OutputText);
			this.href_matches = TextPic.s_HrefRegex.Matches(this.m_OutputText);
			this.indexes.Clear();
			for (int k = 0; k < this.matches.Count; k++)
			{
				this.indexes.Add(this.matches[k].Index);
			}
			if (this.matches != null && this.matches.Count > 0)
			{
				for (int l = 0; l < this.matches.Count; l++)
				{
					this.picIndex = this.matches[l].Index;
					if (this.usesNewRendering)
					{
						this.charactersRemoved = 0;
						this.removeCharacters = TextPic.remove_Regex.Matches(this.m_OutputText);
						for (int m = 0; m < this.removeCharacters.Count; m++)
						{
							if (this.removeCharacters[m].Index < this.picIndex && !this.indexes.Contains(this.removeCharacters[m].Index))
							{
								this.charactersRemoved += this.removeCharacters[m].Length;
							}
						}
						for (int n = 0; n < l; n++)
						{
							this.charactersRemoved += this.matches[n].Length - 1;
						}
						this.picIndex -= this.charactersRemoved;
					}
					this.vertIndex = this.picIndex * 4 + 3;
					this.m_ImagesVertexIndex.Add(this.vertIndex);
				}
			}
			if (this.usesNewRendering && this.m_HrefInfos != null && this.m_HrefInfos.Count > 0)
			{
				for (int num = 0; num < this.m_HrefInfos.Count; num++)
				{
					this.startCharactersRemoved = 0;
					this.endCharactersRemoved = 0;
					this.removeCharacters = TextPic.remove_Regex.Matches(this.m_OutputText);
					for (int num2 = 0; num2 < this.removeCharacters.Count; num2++)
					{
						if (this.removeCharacters[num2].Index < this.m_HrefInfos[num].startIndex && !this.indexes.Contains(this.removeCharacters[num2].Index))
						{
							this.startCharactersRemoved += this.removeCharacters[num2].Length;
						}
						else if (this.removeCharacters[num2].Index < this.m_HrefInfos[num].startIndex && this.indexes.Contains(this.removeCharacters[num2].Index))
						{
							this.startCharactersRemoved += this.removeCharacters[num2].Length - 1;
						}
						if (this.removeCharacters[num2].Index < this.m_HrefInfos[num].endIndex && !this.indexes.Contains(this.removeCharacters[num2].Index))
						{
							this.endCharactersRemoved += this.removeCharacters[num2].Length;
						}
						else if (this.removeCharacters[num2].Index < this.m_HrefInfos[num].endIndex && this.indexes.Contains(this.removeCharacters[num2].Index))
						{
							this.endCharactersRemoved += this.removeCharacters[num2].Length - 1;
						}
					}
					this.m_HrefInfos[num].startIndex -= this.startCharactersRemoved;
					this.m_HrefInfos[num].startIndex = this.m_HrefInfos[num].startIndex * 4;
					this.m_HrefInfos[num].endIndex -= this.endCharactersRemoved;
					this.m_HrefInfos[num].endIndex = this.m_HrefInfos[num].endIndex * 4 + 3;
				}
			}
			return this.m_OutputText;
		}

		// Token: 0x06000242 RID: 578 RVA: 0x0000D173 File Offset: 0x0000B373
		public virtual void OnHrefClick(string hrefName)
		{
			Application.OpenURL(hrefName);
		}

		// Token: 0x06000243 RID: 579 RVA: 0x0000D17C File Offset: 0x0000B37C
		protected override void OnPopulateMesh(VertexHelper toFill)
		{
			this.originalText = this.m_Text;
			this.m_Text = this.GetOutputText();
			base.OnPopulateMesh(toFill);
			this.m_DisableFontTextureRebuiltCallback = true;
			this.m_Text = this.originalText;
			this.positions.Clear();
			this.vert = default(UIVertex);
			for (int i = 0; i < this.m_ImagesVertexIndex.Count; i++)
			{
				int num = this.m_ImagesVertexIndex[i];
				if (num < toFill.currentVertCount)
				{
					toFill.PopulateUIVertex(ref this.vert, num);
					this.positions.Add(new Vector2(this.vert.position.x + (float)(base.fontSize / 2), this.vert.position.y + (float)(base.fontSize / 2)) + this.imageOffset);
					toFill.PopulateUIVertex(ref this.vert, num - 3);
					Vector3 position = this.vert.position;
					int j = num;
					int num2 = num - 3;
					while (j > num2)
					{
						toFill.PopulateUIVertex(ref this.vert, num);
						this.vert.position = position;
						toFill.SetUIVertex(this.vert, j);
						j--;
					}
				}
			}
			for (int k = 0; k < this.m_HrefInfos.Count; k++)
			{
				this.m_HrefInfos[k].boxes.Clear();
				if (this.m_HrefInfos[k].startIndex < toFill.currentVertCount)
				{
					toFill.PopulateUIVertex(ref this.vert, this.m_HrefInfos[k].startIndex);
					Vector3 vector = this.vert.position;
					Bounds bounds = new Bounds(vector, Vector3.zero);
					int num3 = this.m_HrefInfos[k].startIndex;
					int endIndex = this.m_HrefInfos[k].endIndex;
					while (num3 < endIndex && num3 < toFill.currentVertCount)
					{
						toFill.PopulateUIVertex(ref this.vert, num3);
						vector = this.vert.position;
						if (vector.x < bounds.min.x)
						{
							this.m_HrefInfos[k].boxes.Add(new Rect(bounds.min, bounds.size));
							bounds = new Bounds(vector, Vector3.zero);
						}
						else
						{
							bounds.Encapsulate(vector);
						}
						num3++;
					}
					this.m_HrefInfos[k].boxes.Add(new Rect(bounds.min, bounds.size));
				}
			}
			this.updateQuad = true;
			this.m_DisableFontTextureRebuiltCallback = false;
		}

		// Token: 0x06000244 RID: 580 RVA: 0x0000D44C File Offset: 0x0000B64C
		public void OnPointerClick(PointerEventData eventData)
		{
			RectTransformUtility.ScreenPointToLocalPointInRectangle(base.rectTransform, eventData.position, eventData.pressEventCamera, out this.lp);
			for (int i = 0; i < this.m_HrefInfos.Count; i++)
			{
				for (int j = 0; j < this.m_HrefInfos[i].boxes.Count; j++)
				{
					if (this.m_HrefInfos[i].boxes[j].Contains(this.lp))
					{
						this.m_OnHrefClick.Invoke(this.m_HrefInfos[i].name);
						return;
					}
				}
			}
		}

		// Token: 0x06000245 RID: 581 RVA: 0x0000D4F4 File Offset: 0x0000B6F4
		public void OnPointerEnter(PointerEventData eventData)
		{
			this.selected = true;
			if (this.m_ImagesPool.Count >= 1)
			{
				for (int i = 0; i < this.m_ImagesPool.Count; i++)
				{
					if (this.button != null && this.button.isActiveAndEnabled)
					{
						this.m_ImagesPool[i].color = this.button.colors.highlightedColor;
					}
				}
			}
		}

		// Token: 0x06000246 RID: 582 RVA: 0x0000D56C File Offset: 0x0000B76C
		public void OnPointerExit(PointerEventData eventData)
		{
			this.selected = false;
			if (this.m_ImagesPool.Count >= 1)
			{
				for (int i = 0; i < this.m_ImagesPool.Count; i++)
				{
					if (this.button != null && this.button.isActiveAndEnabled)
					{
						this.m_ImagesPool[i].color = this.button.colors.normalColor;
					}
					else
					{
						this.m_ImagesPool[i].color = this.color;
					}
				}
			}
		}

		// Token: 0x06000247 RID: 583 RVA: 0x0000D5FC File Offset: 0x0000B7FC
		public void OnSelect(BaseEventData eventData)
		{
			this.selected = true;
			if (this.m_ImagesPool.Count >= 1)
			{
				for (int i = 0; i < this.m_ImagesPool.Count; i++)
				{
					if (this.button != null && this.button.isActiveAndEnabled)
					{
						this.m_ImagesPool[i].color = this.button.colors.highlightedColor;
					}
				}
			}
		}

		// Token: 0x06000248 RID: 584 RVA: 0x0000D674 File Offset: 0x0000B874
		public void OnDeselect(BaseEventData eventData)
		{
			this.selected = false;
			if (this.m_ImagesPool.Count >= 1)
			{
				for (int i = 0; i < this.m_ImagesPool.Count; i++)
				{
					if (this.button != null && this.button.isActiveAndEnabled)
					{
						this.m_ImagesPool[i].color = this.button.colors.normalColor;
					}
				}
			}
		}

		// Token: 0x06000249 RID: 585 RVA: 0x0000D6EB File Offset: 0x0000B8EB
		public override void SetVerticesDirty()
		{
			base.SetVerticesDirty();
			this.updateQuad = true;
		}

		// Token: 0x0600024A RID: 586 RVA: 0x0000D6FC File Offset: 0x0000B8FC
		protected override void OnEnable()
		{
			this.usesNewRendering = false;
			if (Application.unityVersion.StartsWith("2019.1."))
			{
				if (!char.IsDigit(Application.unityVersion[8]))
				{
					if (Convert.ToInt32(Application.unityVersion[7].ToString()) > 4)
					{
						this.usesNewRendering = true;
					}
				}
				else
				{
					this.usesNewRendering = true;
				}
			}
			else
			{
				this.usesNewRendering = true;
			}
			base.OnEnable();
			base.supportRichText = true;
			base.alignByGeometry = true;
			if (this.m_ImagesPool.Count >= 1)
			{
				for (int i = 0; i < this.m_ImagesPool.Count; i++)
				{
					if (this.m_ImagesPool[i] != null)
					{
						this.m_ImagesPool[i].enabled = true;
					}
				}
			}
			this.updateQuad = true;
			this.onHrefClick.AddListener(new UnityAction<string>(this.OnHrefClick));
		}

		// Token: 0x0600024B RID: 587 RVA: 0x0000D7E4 File Offset: 0x0000B9E4
		protected override void OnDisable()
		{
			base.OnDisable();
			if (this.m_ImagesPool.Count >= 1)
			{
				for (int i = 0; i < this.m_ImagesPool.Count; i++)
				{
					if (this.m_ImagesPool[i] != null)
					{
						this.m_ImagesPool[i].enabled = false;
					}
				}
			}
			this.onHrefClick.RemoveListener(new UnityAction<string>(this.OnHrefClick));
		}

		// Token: 0x0600024C RID: 588 RVA: 0x0000D859 File Offset: 0x0000BA59
		private new void Start()
		{
			this.button = base.GetComponent<Button>();
			this.ResetIconList();
		}

		// Token: 0x0600024D RID: 589 RVA: 0x0000D870 File Offset: 0x0000BA70
		private void LateUpdate()
		{
			if (this.previousText != this.text)
			{
				this.Reset_m_HrefInfos();
				this.updateQuad = true;
			}
			Object @object = this.thisLock;
			lock (@object)
			{
				if (this.updateQuad)
				{
					this.UpdateQuadImage();
					this.updateQuad = false;
				}
				if (this.clearImages)
				{
					for (int i = 0; i < this.culled_ImagesPool.Count; i++)
					{
						Object.DestroyImmediate(this.culled_ImagesPool[i]);
					}
					this.culled_ImagesPool.Clear();
					this.clearImages = false;
				}
			}
		}

		// Token: 0x040001CA RID: 458
		public TextPic.IconName[] inspectorIconList;

		// Token: 0x040001CB RID: 459
		[Tooltip("Global scaling factor for all images")]
		public float ImageScalingFactor = 1f;

		// Token: 0x040001CC RID: 460
		public string hyperlinkColor = "blue";

		// Token: 0x040001CD RID: 461
		public Vector2 imageOffset = Vector2.zero;

		// Token: 0x040001CE RID: 462
		public bool isCreating_m_HrefInfos = true;

		// Token: 0x040001CF RID: 463
		[SerializeField]
		private TextPic.HrefClickEvent m_OnHrefClick = new TextPic.HrefClickEvent();

		// Token: 0x040001D0 RID: 464
		private readonly List<Image> m_ImagesPool = new List<Image>();

		// Token: 0x040001D1 RID: 465
		private readonly List<GameObject> culled_ImagesPool = new List<GameObject>();

		// Token: 0x040001D2 RID: 466
		private bool clearImages;

		// Token: 0x040001D3 RID: 467
		private Object thisLock = new Object();

		// Token: 0x040001D4 RID: 468
		private readonly List<int> m_ImagesVertexIndex = new List<int>();

		// Token: 0x040001D5 RID: 469
		private static readonly Regex s_Regex = new Regex("<quad name=(.+?) size=(\\d*\\.?\\d+%?) width=(\\d*\\.?\\d+%?) />", RegexOptions.Singleline);

		// Token: 0x040001D6 RID: 470
		private static readonly Regex s_HrefRegex = new Regex("<a href=([^>\\n\\s]+)>(.*?)(</a>)", RegexOptions.Singleline);

		// Token: 0x040001D7 RID: 471
		private string fixedString;

		// Token: 0x040001D8 RID: 472
		private bool updateQuad;

		// Token: 0x040001D9 RID: 473
		private string m_OutputText;

		// Token: 0x040001DA RID: 474
		private Button button;

		// Token: 0x040001DB RID: 475
		private bool selected;

		// Token: 0x040001DC RID: 476
		private List<Vector2> positions = new List<Vector2>();

		// Token: 0x040001DD RID: 477
		private string previousText = "";

		// Token: 0x040001DE RID: 478
		private readonly List<TextPic.HrefInfo> m_HrefInfos = new List<TextPic.HrefInfo>();

		// Token: 0x040001DF RID: 479
		private static readonly StringBuilder s_TextBuilder = new StringBuilder();

		// Token: 0x040001E0 RID: 480
		private MatchCollection matches;

		// Token: 0x040001E1 RID: 481
		private MatchCollection href_matches;

		// Token: 0x040001E2 RID: 482
		private MatchCollection removeCharacters;

		// Token: 0x040001E3 RID: 483
		private int picIndex;

		// Token: 0x040001E4 RID: 484
		private int vertIndex;

		// Token: 0x040001E5 RID: 485
		private bool usesNewRendering;

		// Token: 0x040001E6 RID: 486
		private static readonly Regex remove_Regex = new Regex("<b>|</b>|<i>|</i>|<size=.*?>|</size>|<color=.*?>|</color>|<material=.*?>|</material>|<quad name=(.+?) size=(\\d*\\.?\\d+%?) width=(\\d*\\.?\\d+%?) />|<a href=([^>\\n\\s]+)>|</a>|\\s", RegexOptions.Singleline);

		// Token: 0x040001E7 RID: 487
		private List<int> indexes = new List<int>();

		// Token: 0x040001E8 RID: 488
		private int charactersRemoved;

		// Token: 0x040001E9 RID: 489
		private int startCharactersRemoved;

		// Token: 0x040001EA RID: 490
		private int endCharactersRemoved;

		// Token: 0x040001EB RID: 491
		private int count;

		// Token: 0x040001EC RID: 492
		private int indexText;

		// Token: 0x040001ED RID: 493
		private string originalText;

		// Token: 0x040001EE RID: 494
		private UIVertex vert;

		// Token: 0x040001EF RID: 495
		private Vector2 lp;

		// Token: 0x0200011F RID: 287
		[Serializable]
		public struct IconName
		{
			// Token: 0x0400063B RID: 1595
			public string name;

			// Token: 0x0400063C RID: 1596
			public Sprite sprite;

			// Token: 0x0400063D RID: 1597
			public Vector2 offset;

			// Token: 0x0400063E RID: 1598
			public Vector2 scale;
		}

		// Token: 0x02000120 RID: 288
		[Serializable]
		public class HrefClickEvent : UnityEvent<string>
		{
		}

		// Token: 0x02000121 RID: 289
		[Serializable]
		public class HrefInfo
		{
			// Token: 0x0400063F RID: 1599
			public int startIndex;

			// Token: 0x04000640 RID: 1600
			public int endIndex;

			// Token: 0x04000641 RID: 1601
			public string name;

			// Token: 0x04000642 RID: 1602
			public readonly List<Rect> boxes = new List<Rect>();
		}
	}
}
