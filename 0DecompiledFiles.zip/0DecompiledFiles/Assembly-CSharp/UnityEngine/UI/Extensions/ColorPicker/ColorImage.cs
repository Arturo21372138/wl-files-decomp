﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000CE RID: 206
	[RequireComponent(typeof(Image))]
	public class ColorImage : MonoBehaviour
	{
		// Token: 0x060006C8 RID: 1736 RVA: 0x00027045 File Offset: 0x00025245
		private void Awake()
		{
			this.image = base.GetComponent<Image>();
			this.picker.onValueChanged.AddListener(new UnityAction<Color>(this.ColorChanged));
		}

		// Token: 0x060006C9 RID: 1737 RVA: 0x0002706F File Offset: 0x0002526F
		private void OnDestroy()
		{
			this.picker.onValueChanged.RemoveListener(new UnityAction<Color>(this.ColorChanged));
		}

		// Token: 0x060006CA RID: 1738 RVA: 0x0002708D File Offset: 0x0002528D
		private void ColorChanged(Color newColor)
		{
			this.image.color = newColor;
		}

		// Token: 0x04000504 RID: 1284
		public ColorPickerControl picker;

		// Token: 0x04000505 RID: 1285
		private Image image;
	}
}
