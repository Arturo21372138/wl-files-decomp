﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E9 RID: 233
	public enum TextureCompression
	{
		// Token: 0x040005B2 RID: 1458
		None,
		// Token: 0x040005B3 RID: 1459
		Normal,
		// Token: 0x040005B4 RID: 1460
		High,
		// Token: 0x040005B5 RID: 1461
		Low
	}
}
