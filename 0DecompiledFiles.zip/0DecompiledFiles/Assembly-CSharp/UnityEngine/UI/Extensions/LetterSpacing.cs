﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000059 RID: 89
	[AddComponentMenu("UI/Effects/Extensions/Letter Spacing")]
	public class LetterSpacing : BaseMeshEffect
	{
		// Token: 0x060002C2 RID: 706 RVA: 0x00011349 File Offset: 0x0000F549
		protected LetterSpacing()
		{
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060002C3 RID: 707 RVA: 0x00011351 File Offset: 0x0000F551
		// (set) Token: 0x060002C4 RID: 708 RVA: 0x00011359 File Offset: 0x0000F559
		public float spacing
		{
			get
			{
				return this.m_spacing;
			}
			set
			{
				if (this.m_spacing == value)
				{
					return;
				}
				this.m_spacing = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00011388 File Offset: 0x0000F588
		public override void ModifyMesh(VertexHelper vh)
		{
			if (!this.IsActive())
			{
				return;
			}
			List<UIVertex> list = new List<UIVertex>();
			vh.GetUIVertexStream(list);
			Text component = base.GetComponent<Text>();
			if (component == null)
			{
				Debug.LogWarning("LetterSpacing: Missing Text component");
				return;
			}
			string[] array = component.text.Split('\n', StringSplitOptions.None);
			float num = this.spacing * (float)component.fontSize / 100f;
			float num2 = 0f;
			int num3 = 0;
			switch (component.alignment)
			{
			case TextAnchor.UpperLeft:
			case TextAnchor.MiddleLeft:
			case TextAnchor.LowerLeft:
				num2 = 0f;
				break;
			case TextAnchor.UpperCenter:
			case TextAnchor.MiddleCenter:
			case TextAnchor.LowerCenter:
				num2 = 0.5f;
				break;
			case TextAnchor.UpperRight:
			case TextAnchor.MiddleRight:
			case TextAnchor.LowerRight:
				num2 = 1f;
				break;
			}
			foreach (string text in array)
			{
				float num4 = (float)(text.Length - 1) * num * num2;
				for (int j = 0; j < text.Length; j++)
				{
					int num5 = num3 * 6;
					int num6 = num3 * 6 + 1;
					int num7 = num3 * 6 + 2;
					int num8 = num3 * 6 + 3;
					int num9 = num3 * 6 + 4;
					int num10 = num3 * 6 + 5;
					if (num10 > list.Count - 1)
					{
						return;
					}
					UIVertex uivertex = list[num5];
					UIVertex uivertex2 = list[num6];
					UIVertex uivertex3 = list[num7];
					UIVertex uivertex4 = list[num8];
					UIVertex uivertex5 = list[num9];
					UIVertex uivertex6 = list[num10];
					Vector3 vector = Vector3.right * (num * (float)j - num4);
					uivertex.position += vector;
					uivertex2.position += vector;
					uivertex3.position += vector;
					uivertex4.position += vector;
					uivertex5.position += vector;
					uivertex6.position += vector;
					list[num5] = uivertex;
					list[num6] = uivertex2;
					list[num7] = uivertex3;
					list[num8] = uivertex4;
					list[num9] = uivertex5;
					list[num10] = uivertex6;
					num3++;
				}
				num3++;
			}
			vh.Clear();
			vh.AddUIVertexTriangleStream(list);
		}

		// Token: 0x0400022D RID: 557
		[SerializeField]
		private float m_spacing;
	}
}
