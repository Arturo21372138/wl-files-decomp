﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B1 RID: 1969
	public enum AntiCheatClientMode
	{
		// Token: 0x040015B5 RID: 5557
		Invalid,
		// Token: 0x040015B6 RID: 5558
		ClientServer,
		// Token: 0x040015B7 RID: 5559
		PeerToPeer
	}
}
