﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000054 RID: 84
	[RequireComponent(typeof(Text), typeof(RectTransform))]
	[AddComponentMenu("UI/Effects/Extensions/Cylinder Text")]
	public class CylinderText : BaseMeshEffect
	{
		// Token: 0x0600029C RID: 668 RVA: 0x0000FD35 File Offset: 0x0000DF35
		protected override void Awake()
		{
			base.Awake();
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0000FD43 File Offset: 0x0000DF43
		protected override void OnEnable()
		{
			base.OnEnable();
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x0600029E RID: 670 RVA: 0x0000FD54 File Offset: 0x0000DF54
		public override void ModifyMesh(VertexHelper vh)
		{
			if (!this.IsActive())
			{
				return;
			}
			int currentVertCount = vh.currentVertCount;
			if (!this.IsActive() || currentVertCount == 0)
			{
				return;
			}
			for (int i = 0; i < vh.currentVertCount; i++)
			{
				UIVertex uivertex = default(UIVertex);
				vh.PopulateUIVertex(ref uivertex, i);
				float x = uivertex.position.x;
				uivertex.position.z = -this.radius * Mathf.Cos(x / this.radius);
				uivertex.position.x = this.radius * Mathf.Sin(x / this.radius);
				vh.SetUIVertex(uivertex, i);
			}
		}

		// Token: 0x04000218 RID: 536
		public float radius;
	}
}
