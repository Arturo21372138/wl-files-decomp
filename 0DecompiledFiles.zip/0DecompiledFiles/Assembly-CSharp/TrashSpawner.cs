﻿using System;
using HawkNetworking;
using UnityEngine;

// Token: 0x02000005 RID: 5
public class TrashSpawner : MonoBehaviour
{
	// Token: 0x06000009 RID: 9 RVA: 0x00002108 File Offset: 0x00000308
	private void Update()
	{
		if (!HawkNetworkManager.DefaultInstance.IsServer())
		{
			return;
		}
		if (Time.time - this.spawnTimer >= 0.1f)
		{
			this.spawnTimer = Time.time;
			this.SpawnRndPrefab();
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x0000213B File Offset: 0x0000033B
	private void SpawnRndPrefab()
	{
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00002140 File Offset: 0x00000340
	private Transform GetRndSpawnTransform()
	{
		if (!this.spawnsParent || this.spawnsParent.childCount == 0)
		{
			return null;
		}
		int num = Random.Range(0, this.spawnsParent.childCount);
		return this.spawnsParent.GetChild(num);
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002188 File Offset: 0x00000388
	private GameObject GetRndPrefab()
	{
		if (this.prefabsToSpawn == null || this.prefabsToSpawn.Length == 0)
		{
			return null;
		}
		int num = Random.Range(0, this.prefabsToSpawn.Length);
		return this.prefabsToSpawn[num];
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000021C0 File Offset: 0x000003C0
	private void OnDrawGizmos()
	{
		Gizmos.color = Color.red;
		if (this.spawnsParent)
		{
			foreach (object obj in this.spawnsParent)
			{
				Gizmos.DrawWireCube(((Transform)obj).position, Vector3.one);
			}
		}
	}

	// Token: 0x04000007 RID: 7
	private const float SPAWN_RATE = 0.1f;

	// Token: 0x04000008 RID: 8
	[SerializeField]
	private Transform spawnsParent;

	// Token: 0x04000009 RID: 9
	[SerializeField]
	private GameObject[] prefabsToSpawn;

	// Token: 0x0400000A RID: 10
	private float spawnTimer;
}
