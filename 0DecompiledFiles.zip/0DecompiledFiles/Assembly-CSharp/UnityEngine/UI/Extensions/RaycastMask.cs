﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200005C RID: 92
	[RequireComponent(typeof(RectTransform))]
	[RequireComponent(typeof(Image))]
	[AddComponentMenu("UI/Extensions/Raycast Mask")]
	public class RaycastMask : MonoBehaviour, ICanvasRaycastFilter
	{
		// Token: 0x060002D5 RID: 725 RVA: 0x00011EDD File Offset: 0x000100DD
		private void Start()
		{
			this._image = base.GetComponent<Image>();
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00011EEC File Offset: 0x000100EC
		public bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera)
		{
			this._sprite = this._image.sprite;
			RectTransform rectTransform = (RectTransform)base.transform;
			Vector2 vector;
			RectTransformUtility.ScreenPointToLocalPointInRectangle((RectTransform)base.transform, sp, eventCamera, out vector);
			Vector2 vector2 = new Vector2(vector.x + rectTransform.pivot.x * rectTransform.rect.width, vector.y + rectTransform.pivot.y * rectTransform.rect.height);
			Rect textureRect = this._sprite.textureRect;
			Rect rect = rectTransform.rect;
			Image.Type type = this._image.type;
			int num;
			int num2;
			if (type != Image.Type.Simple && type == Image.Type.Sliced)
			{
				Vector4 border = this._sprite.border;
				if (vector2.x < border.x)
				{
					num = Mathf.FloorToInt(textureRect.x + vector2.x);
				}
				else if (vector2.x > rect.width - border.z)
				{
					num = Mathf.FloorToInt(textureRect.x + textureRect.width - (rect.width - vector2.x));
				}
				else
				{
					num = Mathf.FloorToInt(textureRect.x + border.x + (vector2.x - border.x) / (rect.width - border.x - border.z) * (textureRect.width - border.x - border.z));
				}
				if (vector2.y < border.y)
				{
					num2 = Mathf.FloorToInt(textureRect.y + vector2.y);
				}
				else if (vector2.y > rect.height - border.w)
				{
					num2 = Mathf.FloorToInt(textureRect.y + textureRect.height - (rect.height - vector2.y));
				}
				else
				{
					num2 = Mathf.FloorToInt(textureRect.y + border.y + (vector2.y - border.y) / (rect.height - border.y - border.w) * (textureRect.height - border.y - border.w));
				}
			}
			else
			{
				num = Mathf.FloorToInt(textureRect.x + textureRect.width * vector2.x / rect.width);
				num2 = Mathf.FloorToInt(textureRect.y + textureRect.height * vector2.y / rect.height);
			}
			bool flag;
			try
			{
				flag = this._sprite.texture.GetPixel(num, num2).a > 0f;
			}
			catch (UnityException)
			{
				Debug.LogWarning("Mask texture not readable, set your sprite to Texture Type 'Advanced' and check 'Read/Write Enabled'");
				Object.Destroy(this);
				flag = false;
			}
			return flag;
		}

		// Token: 0x04000237 RID: 567
		private Image _image;

		// Token: 0x04000238 RID: 568
		private Sprite _sprite;
	}
}
