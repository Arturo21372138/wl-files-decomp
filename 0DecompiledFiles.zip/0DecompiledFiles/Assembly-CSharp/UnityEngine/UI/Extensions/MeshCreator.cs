﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200006C RID: 108
	[ExecuteInEditMode]
	public class MeshCreator : MonoBehaviour
	{
		// Token: 0x06000328 RID: 808 RVA: 0x000153C0 File Offset: 0x000135C0
		public void CreateMesh(List<Vector2> points)
		{
			Vector2[] array = points.ToArray();
			int[] array2 = new Triangulator(array).Triangulate();
			Vector3[] array3 = new Vector3[array.Length];
			for (int i = 0; i < array3.Length; i++)
			{
				array3[i] = new Vector3(array[i].x, array[i].y, 0f);
			}
			Mesh mesh = new Mesh();
			mesh.vertices = array3;
			mesh.triangles = array2;
			mesh.RecalculateNormals();
			mesh.RecalculateBounds();
			base.GetComponent<MeshFilter>().mesh = mesh;
		}
	}
}
