﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B7 RID: 183
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("UI/Extensions/Scrollrect Conflict Manager")]
	public class ScrollConflictManager : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IEndDragHandler, IDragHandler
	{
		// Token: 0x0600060A RID: 1546 RVA: 0x00024031 File Offset: 0x00022231
		private void Awake()
		{
			if (this.ParentScrollRect)
			{
				this.InitialiseConflictManager();
			}
		}

		// Token: 0x0600060B RID: 1547 RVA: 0x00024048 File Offset: 0x00022248
		private void InitialiseConflictManager()
		{
			this._myScrollRect = base.GetComponent<ScrollRect>();
			this.scrollOtherHorizontally = this._myScrollRect.vertical;
			if (this.scrollOtherHorizontally)
			{
				if (this._myScrollRect.horizontal)
				{
					Debug.LogError("You have added the SecondScrollRect to a scroll view that already has both directions selected");
				}
				if (!this.ParentScrollRect.horizontal)
				{
					Debug.LogError("The other scroll rect does not support scrolling horizontally");
				}
			}
			else if (!this.ParentScrollRect.vertical)
			{
				Debug.LogError("The other scroll rect does not support scrolling vertically");
			}
			if (this.ParentScrollRect && !this.ParentScrollSnap)
			{
				this.ParentScrollSnap = this.ParentScrollRect.GetComponent<ScrollSnapBase>();
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x000240EC File Offset: 0x000222EC
		private void Start()
		{
			if (this.ParentScrollRect)
			{
				this.AssignScrollRectHandlers();
			}
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x00024101 File Offset: 0x00022301
		private void AssignScrollRectHandlers()
		{
			this._beginDragHandlers = this.ParentScrollRect.GetComponents<IBeginDragHandler>();
			this._dragHandlers = this.ParentScrollRect.GetComponents<IDragHandler>();
			this._endDragHandlers = this.ParentScrollRect.GetComponents<IEndDragHandler>();
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x00024136 File Offset: 0x00022336
		public void SetParentScrollRect(ScrollRect parentScrollRect)
		{
			this.ParentScrollRect = parentScrollRect;
			this.InitialiseConflictManager();
			this.AssignScrollRectHandlers();
		}

		// Token: 0x0600060F RID: 1551 RVA: 0x0002414C File Offset: 0x0002234C
		public void OnBeginDrag(PointerEventData eventData)
		{
			float num = Mathf.Abs(eventData.position.x - eventData.pressPosition.x);
			float num2 = Mathf.Abs(eventData.position.y - eventData.pressPosition.y);
			if (this.scrollOtherHorizontally)
			{
				if (num > num2)
				{
					this.scrollOther = true;
					this._myScrollRect.enabled = false;
					int i = 0;
					int num3 = this._beginDragHandlers.Length;
					while (i < num3)
					{
						this._beginDragHandlers[i].OnBeginDrag(eventData);
						if (this.ParentScrollSnap)
						{
							this.ParentScrollSnap.OnBeginDrag(eventData);
						}
						i++;
					}
					return;
				}
			}
			else if (num2 > num)
			{
				this.scrollOther = true;
				this._myScrollRect.enabled = false;
				int j = 0;
				int num4 = this._beginDragHandlers.Length;
				while (j < num4)
				{
					this._beginDragHandlers[j].OnBeginDrag(eventData);
					if (this.ParentScrollSnap)
					{
						this.ParentScrollSnap.OnBeginDrag(eventData);
					}
					j++;
				}
			}
		}

		// Token: 0x06000610 RID: 1552 RVA: 0x0002424C File Offset: 0x0002244C
		public void OnEndDrag(PointerEventData eventData)
		{
			if (this.scrollOther)
			{
				this._myScrollRect.enabled = true;
				this.scrollOther = false;
				int i = 0;
				int num = this._endDragHandlers.Length;
				while (i < num)
				{
					this._endDragHandlers[i].OnEndDrag(eventData);
					if (this.ParentScrollSnap)
					{
						this.ParentScrollSnap.OnEndDrag(eventData);
					}
					i++;
				}
			}
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x000242B0 File Offset: 0x000224B0
		public void OnDrag(PointerEventData eventData)
		{
			if (this.scrollOther)
			{
				int i = 0;
				int num = this._endDragHandlers.Length;
				while (i < num)
				{
					this._dragHandlers[i].OnDrag(eventData);
					if (this.ParentScrollSnap)
					{
						this.ParentScrollSnap.OnDrag(eventData);
					}
					i++;
				}
			}
		}

		// Token: 0x04000470 RID: 1136
		[Tooltip("The parent ScrollRect control hosting this ScrollSnap")]
		public ScrollRect ParentScrollRect;

		// Token: 0x04000471 RID: 1137
		[Tooltip("The parent ScrollSnap control hosting this Scroll Snap.\nIf left empty, it will use the ScrollSnap of the ParentScrollRect")]
		private ScrollSnapBase ParentScrollSnap;

		// Token: 0x04000472 RID: 1138
		private ScrollRect _myScrollRect;

		// Token: 0x04000473 RID: 1139
		private IBeginDragHandler[] _beginDragHandlers;

		// Token: 0x04000474 RID: 1140
		private IEndDragHandler[] _endDragHandlers;

		// Token: 0x04000475 RID: 1141
		private IDragHandler[] _dragHandlers;

		// Token: 0x04000476 RID: 1142
		private bool scrollOther;

		// Token: 0x04000477 RID: 1143
		private bool scrollOtherHorizontally;
	}
}
