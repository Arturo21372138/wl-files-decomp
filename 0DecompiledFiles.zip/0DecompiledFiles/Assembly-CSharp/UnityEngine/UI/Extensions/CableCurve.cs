﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000AD RID: 173
	[Serializable]
	public class CableCurve
	{
		// Token: 0x17000108 RID: 264
		// (get) Token: 0x060005CF RID: 1487 RVA: 0x00023124 File Offset: 0x00021324
		// (set) Token: 0x060005D0 RID: 1488 RVA: 0x0002312C File Offset: 0x0002132C
		public bool regenPoints
		{
			get
			{
				return this.m_regen;
			}
			set
			{
				this.m_regen = value;
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x060005D1 RID: 1489 RVA: 0x00023135 File Offset: 0x00021335
		// (set) Token: 0x060005D2 RID: 1490 RVA: 0x0002313D File Offset: 0x0002133D
		public Vector2 start
		{
			get
			{
				return this.m_start;
			}
			set
			{
				if (value != this.m_start)
				{
					this.m_regen = true;
				}
				this.m_start = value;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x060005D3 RID: 1491 RVA: 0x0002315B File Offset: 0x0002135B
		// (set) Token: 0x060005D4 RID: 1492 RVA: 0x00023163 File Offset: 0x00021363
		public Vector2 end
		{
			get
			{
				return this.m_end;
			}
			set
			{
				if (value != this.m_end)
				{
					this.m_regen = true;
				}
				this.m_end = value;
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x060005D5 RID: 1493 RVA: 0x00023181 File Offset: 0x00021381
		// (set) Token: 0x060005D6 RID: 1494 RVA: 0x00023189 File Offset: 0x00021389
		public float slack
		{
			get
			{
				return this.m_slack;
			}
			set
			{
				if (value != this.m_slack)
				{
					this.m_regen = true;
				}
				this.m_slack = Mathf.Max(0f, value);
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x060005D7 RID: 1495 RVA: 0x000231AC File Offset: 0x000213AC
		// (set) Token: 0x060005D8 RID: 1496 RVA: 0x000231B4 File Offset: 0x000213B4
		public int steps
		{
			get
			{
				return this.m_steps;
			}
			set
			{
				if (value != this.m_steps)
				{
					this.m_regen = true;
				}
				this.m_steps = Mathf.Max(2, value);
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x060005D9 RID: 1497 RVA: 0x000231D4 File Offset: 0x000213D4
		public Vector2 midPoint
		{
			get
			{
				Vector2 vector = Vector2.zero;
				if (this.m_steps == 2)
				{
					return (this.points[0] + this.points[1]) * 0.5f;
				}
				if (this.m_steps > 2)
				{
					int num = this.m_steps / 2;
					if (this.m_steps % 2 == 0)
					{
						vector = (this.points[num] + this.points[num + 1]) * 0.5f;
					}
					else
					{
						vector = this.points[num];
					}
				}
				return vector;
			}
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x00023270 File Offset: 0x00021470
		public CableCurve()
		{
			this.points = CableCurve.emptyCurve;
			this.m_start = Vector2.up;
			this.m_end = Vector2.up + Vector2.right;
			this.m_slack = 0.5f;
			this.m_steps = 20;
			this.m_regen = true;
		}

		// Token: 0x060005DB RID: 1499 RVA: 0x000232C8 File Offset: 0x000214C8
		public CableCurve(Vector2[] inputPoints)
		{
			this.points = inputPoints;
			this.m_start = inputPoints[0];
			this.m_end = inputPoints[1];
			this.m_slack = 0.5f;
			this.m_steps = 20;
			this.m_regen = true;
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x00023318 File Offset: 0x00021518
		public CableCurve(List<Vector2> inputPoints)
		{
			this.points = inputPoints.ToArray();
			this.m_start = inputPoints[0];
			this.m_end = inputPoints[1];
			this.m_slack = 0.5f;
			this.m_steps = 20;
			this.m_regen = true;
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0002336C File Offset: 0x0002156C
		public CableCurve(CableCurve v)
		{
			this.points = v.Points();
			this.m_start = v.start;
			this.m_end = v.end;
			this.m_slack = v.slack;
			this.m_steps = v.steps;
			this.m_regen = v.regenPoints;
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x000233C8 File Offset: 0x000215C8
		public Vector2[] Points()
		{
			if (!this.m_regen)
			{
				return this.points;
			}
			if (this.m_steps < 2)
			{
				return CableCurve.emptyCurve;
			}
			float num = Vector2.Distance(this.m_end, this.m_start);
			float num2 = Vector2.Distance(new Vector2(this.m_end.x, this.m_start.y), this.m_start);
			float num3 = num + Mathf.Max(0.0001f, this.m_slack);
			float num4 = 0f;
			float y = this.m_start.y;
			float num5 = num2;
			float y2 = this.end.y;
			if (num5 - num4 == 0f)
			{
				return CableCurve.emptyCurve;
			}
			float num6 = Mathf.Sqrt(Mathf.Pow(num3, 2f) - Mathf.Pow(y2 - y, 2f)) / (num5 - num4);
			int num7 = 30;
			int num8 = 0;
			int num9 = num7 * 10;
			bool flag = false;
			float num10 = 0f;
			float num11 = 100f;
			for (int i = 0; i < num7; i++)
			{
				for (int j = 0; j < 10; j++)
				{
					num8++;
					float num12 = num10 + num11;
					float num13 = (float)Math.Sinh((double)num12) / num12;
					if (!float.IsInfinity(num13))
					{
						if (num13 == num6)
						{
							flag = true;
							num10 = num12;
							break;
						}
						if (num13 > num6)
						{
							break;
						}
						num10 = num12;
						if (num8 > num9)
						{
							flag = true;
							break;
						}
					}
				}
				if (flag)
				{
					break;
				}
				num11 *= 0.1f;
			}
			float num14 = (num5 - num4) / 2f / num10;
			float num15 = (num4 + num5 - num14 * Mathf.Log((num3 + y2 - y) / (num3 - y2 + y))) / 2f;
			float num16 = (y2 + y - num3 * (float)Math.Cosh((double)num10) / (float)Math.Sinh((double)num10)) / 2f;
			this.points = new Vector2[this.m_steps];
			float num17 = (float)(this.m_steps - 1);
			for (int k = 0; k < this.m_steps; k++)
			{
				float num18 = (float)k / num17;
				Vector2 zero = Vector2.zero;
				zero.x = Mathf.Lerp(this.start.x, this.end.x, num18);
				zero.y = num14 * (float)Math.Cosh((double)((num18 * num2 - num15) / num14)) + num16;
				this.points[k] = zero;
			}
			this.m_regen = false;
			return this.points;
		}

		// Token: 0x04000456 RID: 1110
		[SerializeField]
		private Vector2 m_start;

		// Token: 0x04000457 RID: 1111
		[SerializeField]
		private Vector2 m_end;

		// Token: 0x04000458 RID: 1112
		[SerializeField]
		private float m_slack;

		// Token: 0x04000459 RID: 1113
		[SerializeField]
		private int m_steps;

		// Token: 0x0400045A RID: 1114
		[SerializeField]
		private bool m_regen;

		// Token: 0x0400045B RID: 1115
		private static Vector2[] emptyCurve = new Vector2[]
		{
			new Vector2(0f, 0f),
			new Vector2(0f, 0f)
		};

		// Token: 0x0400045C RID: 1116
		[SerializeField]
		private Vector2[] points;
	}
}
