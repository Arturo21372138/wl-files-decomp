﻿using System;

namespace UnityEngine.UI.Extensions.EasingCore
{
	// Token: 0x020000CB RID: 203
	public enum Ease
	{
		// Token: 0x040004E5 RID: 1253
		Linear,
		// Token: 0x040004E6 RID: 1254
		InBack,
		// Token: 0x040004E7 RID: 1255
		InBounce,
		// Token: 0x040004E8 RID: 1256
		InCirc,
		// Token: 0x040004E9 RID: 1257
		InCubic,
		// Token: 0x040004EA RID: 1258
		InElastic,
		// Token: 0x040004EB RID: 1259
		InExpo,
		// Token: 0x040004EC RID: 1260
		InQuad,
		// Token: 0x040004ED RID: 1261
		InQuart,
		// Token: 0x040004EE RID: 1262
		InQuint,
		// Token: 0x040004EF RID: 1263
		InSine,
		// Token: 0x040004F0 RID: 1264
		OutBack,
		// Token: 0x040004F1 RID: 1265
		OutBounce,
		// Token: 0x040004F2 RID: 1266
		OutCirc,
		// Token: 0x040004F3 RID: 1267
		OutCubic,
		// Token: 0x040004F4 RID: 1268
		OutElastic,
		// Token: 0x040004F5 RID: 1269
		OutExpo,
		// Token: 0x040004F6 RID: 1270
		OutQuad,
		// Token: 0x040004F7 RID: 1271
		OutQuart,
		// Token: 0x040004F8 RID: 1272
		OutQuint,
		// Token: 0x040004F9 RID: 1273
		OutSine,
		// Token: 0x040004FA RID: 1274
		InOutBack,
		// Token: 0x040004FB RID: 1275
		InOutBounce,
		// Token: 0x040004FC RID: 1276
		InOutCirc,
		// Token: 0x040004FD RID: 1277
		InOutCubic,
		// Token: 0x040004FE RID: 1278
		InOutElastic,
		// Token: 0x040004FF RID: 1279
		InOutExpo,
		// Token: 0x04000500 RID: 1280
		InOutQuad,
		// Token: 0x04000501 RID: 1281
		InOutQuart,
		// Token: 0x04000502 RID: 1282
		InOutQuint,
		// Token: 0x04000503 RID: 1283
		InOutSine
	}
}
