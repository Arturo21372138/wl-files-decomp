﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C5 RID: 1989
	internal struct OnMessageToServerCallbackInfoInternal : ICallbackInfoInternal, IGettable<OnMessageToServerCallbackInfo>
	{
		// Token: 0x17000825 RID: 2085
		// (get) Token: 0x060020DB RID: 8411 RVA: 0x0002720A File Offset: 0x0002540A
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x060020DC RID: 8412 RVA: 0x00027214 File Offset: 0x00025414
		public void Get(out OnMessageToServerCallbackInfo other)
		{
			other = default(OnMessageToServerCallbackInfo);
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
			ArraySegment<byte> arraySegment;
			Helper.Get(this.m_MessageData, out arraySegment, this.m_MessageDataSizeBytes);
			other.MessageData = arraySegment;
		}

		// Token: 0x040015DD RID: 5597
		private IntPtr m_ClientData;

		// Token: 0x040015DE RID: 5598
		private IntPtr m_MessageData;

		// Token: 0x040015DF RID: 5599
		private uint m_MessageDataSizeBytes;
	}
}
