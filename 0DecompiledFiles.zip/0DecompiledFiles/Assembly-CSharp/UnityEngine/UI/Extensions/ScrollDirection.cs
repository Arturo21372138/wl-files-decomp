﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000080 RID: 128
	public enum ScrollDirection
	{
		// Token: 0x040002E9 RID: 745
		Vertical,
		// Token: 0x040002EA RID: 746
		Horizontal
	}
}
