﻿using System;
using System.Reflection;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x020000F2 RID: 242
	public static class SpriteUtilityEx
	{
		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000768 RID: 1896 RVA: 0x0002A86D File Offset: 0x00028A6D
		public static Type Type
		{
			get
			{
				if (!(SpriteUtilityEx.type == null))
				{
					return SpriteUtilityEx.type;
				}
				return SpriteUtilityEx.type = Type.GetType("UnityEditor.Sprites.SpriteUtility, UnityEditor");
			}
		}

		// Token: 0x06000769 RID: 1897 RVA: 0x0002A894 File Offset: 0x00028A94
		public static void GenerateOutline(Texture2D texture, Rect rect, float detail, byte alphaTolerance, bool holeDetection, out Vector2[][] paths)
		{
			Vector2[][] array = new Vector2[0][];
			object[] array2 = new object[] { texture, rect, detail, alphaTolerance, holeDetection, array };
			SpriteUtilityEx.Type.GetMethod("GenerateOutline", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, array2);
			paths = (Vector2[][])array2[5];
		}

		// Token: 0x040005D5 RID: 1493
		private static Type type;
	}
}
