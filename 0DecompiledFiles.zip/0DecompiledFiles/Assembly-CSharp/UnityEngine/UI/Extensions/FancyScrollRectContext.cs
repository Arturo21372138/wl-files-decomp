﻿using System;
using System.Runtime.CompilerServices;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000086 RID: 134
	public class FancyScrollRectContext : IFancyScrollRectContext
	{
		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x060003FF RID: 1023 RVA: 0x000181DB File Offset: 0x000163DB
		// (set) Token: 0x06000400 RID: 1024 RVA: 0x000181E3 File Offset: 0x000163E3
		ScrollDirection IFancyScrollRectContext.ScrollDirection { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000401 RID: 1025 RVA: 0x000181EC File Offset: 0x000163EC
		// (set) Token: 0x06000402 RID: 1026 RVA: 0x000181F4 File Offset: 0x000163F4
		[TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
		Func<ValueTuple<float, float>> IFancyScrollRectContext.CalculateScrollSize
		{
			[return: TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
			get;
			[param: TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
			set;
		}
	}
}
