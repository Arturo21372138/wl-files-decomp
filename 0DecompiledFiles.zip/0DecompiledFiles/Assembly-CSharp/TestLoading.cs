﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.AddressableAssets.ResourceLocators;
using UnityEngine.ResourceManagement.AsyncOperations;

// Token: 0x02000003 RID: 3
public class TestLoading : MonoBehaviour
{
	// Token: 0x06000004 RID: 4 RVA: 0x0000208C File Offset: 0x0000028C
	private void Awake()
	{
		base.StartCoroutine(this.Test());
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000209B File Offset: 0x0000029B
	private IEnumerator Test()
	{
		yield return new WaitForSeconds(10f);
		AsyncOperationHandle<IResourceLocator> asyncOperationHandle = Addressables.InitializeAsync();
		yield return asyncOperationHandle;
		Debug.LogError("Loading Screen Start: " + Time.time.ToString());
		Addressables.InstantiateAsync(this.prefab, this.parent, false, true).Completed += delegate(AsyncOperationHandle<GameObject> x)
		{
			Debug.LogError("Loading Screen Finished: " + Time.time.ToString());
		};
		yield break;
	}

	// Token: 0x04000004 RID: 4
	[SerializeField]
	private AssetReference prefab;

	// Token: 0x04000005 RID: 5
	[SerializeField]
	private Transform parent;
}
