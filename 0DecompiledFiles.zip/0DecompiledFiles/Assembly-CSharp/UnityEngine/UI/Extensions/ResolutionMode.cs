﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A1 RID: 161
	public enum ResolutionMode
	{
		// Token: 0x040003F9 RID: 1017
		None,
		// Token: 0x040003FA RID: 1018
		PerSegment,
		// Token: 0x040003FB RID: 1019
		PerLine
	}
}
