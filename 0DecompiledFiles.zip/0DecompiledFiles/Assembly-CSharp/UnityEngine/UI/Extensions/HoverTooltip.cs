﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A8 RID: 168
	[AddComponentMenu("UI/Extensions/HoverTooltip")]
	public class HoverTooltip : MonoBehaviour
	{
		// Token: 0x06000597 RID: 1431 RVA: 0x000216B8 File Offset: 0x0001F8B8
		private void Start()
		{
			this.GUICamera = GameObject.Find("GUICamera").GetComponent<Camera>();
			this.GUIMode = base.transform.parent.parent.GetComponent<Canvas>().renderMode;
			this.bgImageSource = this.bgImage.GetComponent<Image>();
			this.inside = false;
			this.HideTooltipVisibility();
			base.transform.parent.gameObject.SetActive(false);
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x0002172E File Offset: 0x0001F92E
		public void SetTooltip(string text)
		{
			this.NewTooltip();
			this.thisText.text = text;
			this.OnScreenSpaceCamera();
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00021748 File Offset: 0x0001F948
		public void SetTooltip(string[] texts)
		{
			this.NewTooltip();
			string text = "";
			int num = 0;
			foreach (string text2 in texts)
			{
				if (num == 0)
				{
					text += text2;
				}
				else
				{
					text = text + "\n" + text2;
				}
				num++;
			}
			this.thisText.text = text;
			this.OnScreenSpaceCamera();
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x000217AA File Offset: 0x0001F9AA
		public void SetTooltip(string text, bool test)
		{
			this.NewTooltip();
			this.thisText.text = text;
			this.OnScreenSpaceCamera();
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x000217C4 File Offset: 0x0001F9C4
		public void OnScreenSpaceCamera()
		{
			Vector3 vector = this.GUICamera.ScreenToViewportPoint(UIExtensionsInputManager.MousePosition);
			float num = this.GUICamera.ViewportToScreenPoint(vector).x + this.tooltipRealWidth * this.bgImage.pivot.x;
			if (num > this.upperRight.x)
			{
				float num2 = this.upperRight.x - num;
				float num3;
				if ((double)num2 > (double)this.defaultXOffset * 0.75)
				{
					num3 = num2;
				}
				else
				{
					num3 = this.defaultXOffset - this.tooltipRealWidth * 2f;
				}
				Vector3 vector2 = new Vector3(this.GUICamera.ViewportToScreenPoint(vector).x + num3, 0f, 0f);
				vector.x = this.GUICamera.ScreenToViewportPoint(vector2).x;
			}
			num = this.GUICamera.ViewportToScreenPoint(vector).x - this.tooltipRealWidth * this.bgImage.pivot.x;
			if (num < this.lowerLeft.x)
			{
				float num4 = this.lowerLeft.x - num;
				float num3;
				if ((double)num4 < (double)this.defaultXOffset * 0.75 - (double)this.tooltipRealWidth)
				{
					num3 = -num4;
				}
				else
				{
					num3 = this.tooltipRealWidth * 2f;
				}
				Vector3 vector3 = new Vector3(this.GUICamera.ViewportToScreenPoint(vector).x - num3, 0f, 0f);
				vector.x = this.GUICamera.ScreenToViewportPoint(vector3).x;
			}
			num = this.GUICamera.ViewportToScreenPoint(vector).y - (this.bgImage.sizeDelta.y * this.currentYScaleFactor * this.bgImage.pivot.y - this.tooltipRealHeight);
			if (num > this.upperRight.y)
			{
				float num5 = this.upperRight.y - num;
				float num6 = this.bgImage.sizeDelta.y * this.currentYScaleFactor * this.bgImage.pivot.y;
				if ((double)num5 > (double)this.defaultYOffset * 0.75)
				{
					num6 = num5;
				}
				else
				{
					num6 = this.defaultYOffset - this.tooltipRealHeight * 2f;
				}
				Vector3 vector4 = new Vector3(vector.x, this.GUICamera.ViewportToScreenPoint(vector).y + num6, 0f);
				vector.y = this.GUICamera.ScreenToViewportPoint(vector4).y;
			}
			num = this.GUICamera.ViewportToScreenPoint(vector).y - this.bgImage.sizeDelta.y * this.currentYScaleFactor * this.bgImage.pivot.y;
			if (num < this.lowerLeft.y)
			{
				float num7 = this.lowerLeft.y - num;
				float num6 = this.bgImage.sizeDelta.y * this.currentYScaleFactor * this.bgImage.pivot.y;
				if ((double)num7 < (double)this.defaultYOffset * 0.75 - (double)this.tooltipRealHeight)
				{
					num6 = num7;
				}
				else
				{
					num6 = this.tooltipRealHeight * 2f;
				}
				Vector3 vector5 = new Vector3(vector.x, this.GUICamera.ViewportToScreenPoint(vector).y + num6, 0f);
				vector.y = this.GUICamera.ScreenToViewportPoint(vector5).y;
			}
			base.transform.parent.transform.position = new Vector3(this.GUICamera.ViewportToWorldPoint(vector).x, this.GUICamera.ViewportToWorldPoint(vector).y, 0f);
			base.transform.parent.gameObject.SetActive(true);
			this.inside = true;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00021B9E File Offset: 0x0001FD9E
		public void HideTooltip()
		{
			if (this.GUIMode == RenderMode.ScreenSpaceCamera && this != null)
			{
				base.transform.parent.gameObject.SetActive(false);
				this.inside = false;
				this.HideTooltipVisibility();
			}
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00021BD5 File Offset: 0x0001FDD5
		private void Update()
		{
			this.LayoutInit();
			if (this.inside && this.GUIMode == RenderMode.ScreenSpaceCamera)
			{
				this.OnScreenSpaceCamera();
			}
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x00021BF4 File Offset: 0x0001FDF4
		private void LayoutInit()
		{
			if (this.firstUpdate)
			{
				this.firstUpdate = false;
				this.bgImage.sizeDelta = new Vector2(this.hlG.preferredWidth + (float)this.horizontalPadding, this.hlG.preferredHeight + (float)this.verticalPadding);
				this.defaultYOffset = this.bgImage.sizeDelta.y * this.currentYScaleFactor * this.bgImage.pivot.y;
				this.defaultXOffset = this.bgImage.sizeDelta.x * this.currentXScaleFactor * this.bgImage.pivot.x;
				this.tooltipRealHeight = this.bgImage.sizeDelta.y * this.currentYScaleFactor;
				this.tooltipRealWidth = this.bgImage.sizeDelta.x * this.currentXScaleFactor;
				this.ActivateTooltipVisibility();
			}
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00021CE8 File Offset: 0x0001FEE8
		private void NewTooltip()
		{
			this.firstUpdate = true;
			this.lowerLeft = this.GUICamera.ViewportToScreenPoint(new Vector3(0f, 0f, 0f));
			this.upperRight = this.GUICamera.ViewportToScreenPoint(new Vector3(1f, 1f, 0f));
			this.currentYScaleFactor = (float)Screen.height / base.transform.root.GetComponent<CanvasScaler>().referenceResolution.y;
			this.currentXScaleFactor = (float)Screen.width / base.transform.root.GetComponent<CanvasScaler>().referenceResolution.x;
		}

		// Token: 0x060005A0 RID: 1440 RVA: 0x00021D94 File Offset: 0x0001FF94
		public void ActivateTooltipVisibility()
		{
			Color color = this.thisText.color;
			this.thisText.color = new Color(color.r, color.g, color.b, 1f);
			this.bgImageSource.color = new Color(this.bgImageSource.color.r, this.bgImageSource.color.g, this.bgImageSource.color.b, 0.8f);
		}

		// Token: 0x060005A1 RID: 1441 RVA: 0x00021E1C File Offset: 0x0002001C
		public void HideTooltipVisibility()
		{
			Color color = this.thisText.color;
			this.thisText.color = new Color(color.r, color.g, color.b, 0f);
			this.bgImageSource.color = new Color(this.bgImageSource.color.r, this.bgImageSource.color.g, this.bgImageSource.color.b, 0f);
		}

		// Token: 0x0400041C RID: 1052
		public int horizontalPadding;

		// Token: 0x0400041D RID: 1053
		public int verticalPadding;

		// Token: 0x0400041E RID: 1054
		public Text thisText;

		// Token: 0x0400041F RID: 1055
		public HorizontalLayoutGroup hlG;

		// Token: 0x04000420 RID: 1056
		public RectTransform bgImage;

		// Token: 0x04000421 RID: 1057
		private Image bgImageSource;

		// Token: 0x04000422 RID: 1058
		private bool firstUpdate;

		// Token: 0x04000423 RID: 1059
		private bool inside;

		// Token: 0x04000424 RID: 1060
		private RenderMode GUIMode;

		// Token: 0x04000425 RID: 1061
		private Camera GUICamera;

		// Token: 0x04000426 RID: 1062
		private Vector3 lowerLeft;

		// Token: 0x04000427 RID: 1063
		private Vector3 upperRight;

		// Token: 0x04000428 RID: 1064
		private float currentYScaleFactor;

		// Token: 0x04000429 RID: 1065
		private float currentXScaleFactor;

		// Token: 0x0400042A RID: 1066
		private float defaultYOffset;

		// Token: 0x0400042B RID: 1067
		private float defaultXOffset;

		// Token: 0x0400042C RID: 1068
		private float tooltipRealHeight;

		// Token: 0x0400042D RID: 1069
		private float tooltipRealWidth;
	}
}
