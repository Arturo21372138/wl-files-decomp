﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200081F RID: 2079
	internal struct UnlockAchievementsOptionsInternal : ISettable<UnlockAchievementsOptions>, IDisposable
	{
		// Token: 0x06002231 RID: 8753 RVA: 0x000289D6 File Offset: 0x00026BD6
		public void Set(ref UnlockAchievementsOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.UserId, ref this.m_UserId);
			Helper.Set(other.AchievementIds, ref this.m_AchievementIds, out this.m_AchievementsCount, true);
		}

		// Token: 0x06002232 RID: 8754 RVA: 0x00028A0E File Offset: 0x00026C0E
		public void Dispose()
		{
			Helper.Dispose(ref this.m_UserId);
			Helper.Dispose(ref this.m_AchievementIds);
		}

		// Token: 0x040016D8 RID: 5848
		private int m_ApiVersion;

		// Token: 0x040016D9 RID: 5849
		private IntPtr m_UserId;

		// Token: 0x040016DA RID: 5850
		private IntPtr m_AchievementIds;

		// Token: 0x040016DB RID: 5851
		private uint m_AchievementsCount;
	}
}
