﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000051 RID: 81
	[Serializable]
	public struct Vector3_Array2D
	{
		// Token: 0x1700006B RID: 107
		public Vector3 this[int _idx]
		{
			get
			{
				return this.array[_idx];
			}
			set
			{
				this.array[_idx] = value;
			}
		}

		// Token: 0x04000214 RID: 532
		[SerializeField]
		public Vector3[] array;
	}
}
