﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B8 RID: 184
	[AddComponentMenu("UI/Extensions/ScrollRectEx")]
	public class ScrollRectEx : ScrollRect
	{
		// Token: 0x06000613 RID: 1555 RVA: 0x0002430C File Offset: 0x0002250C
		private void DoForParents<T>(Action<T> action) where T : IEventSystemHandler
		{
			Transform transform = base.transform.parent;
			while (transform != null)
			{
				foreach (Component component in transform.GetComponents<Component>())
				{
					if (component is T)
					{
						action((T)((object)((IEventSystemHandler)component)));
					}
				}
				transform = transform.parent;
			}
		}

		// Token: 0x06000614 RID: 1556 RVA: 0x0002436C File Offset: 0x0002256C
		public override void OnInitializePotentialDrag(PointerEventData eventData)
		{
			this.DoForParents<IInitializePotentialDragHandler>(delegate(IInitializePotentialDragHandler parent)
			{
				parent.OnInitializePotentialDrag(eventData);
			});
			base.OnInitializePotentialDrag(eventData);
		}

		// Token: 0x06000615 RID: 1557 RVA: 0x000243A4 File Offset: 0x000225A4
		public override void OnDrag(PointerEventData eventData)
		{
			if (this.routeToParent)
			{
				this.DoForParents<IDragHandler>(delegate(IDragHandler parent)
				{
					parent.OnDrag(eventData);
				});
				return;
			}
			base.OnDrag(eventData);
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x000243E8 File Offset: 0x000225E8
		public override void OnBeginDrag(PointerEventData eventData)
		{
			if (!base.horizontal && Math.Abs(eventData.delta.x) > Math.Abs(eventData.delta.y))
			{
				this.routeToParent = true;
			}
			else if (!base.vertical && Math.Abs(eventData.delta.x) < Math.Abs(eventData.delta.y))
			{
				this.routeToParent = true;
			}
			else
			{
				this.routeToParent = false;
			}
			if (this.routeToParent)
			{
				this.DoForParents<IBeginDragHandler>(delegate(IBeginDragHandler parent)
				{
					parent.OnBeginDrag(eventData);
				});
				return;
			}
			base.OnBeginDrag(eventData);
		}

		// Token: 0x06000617 RID: 1559 RVA: 0x000244AC File Offset: 0x000226AC
		public override void OnEndDrag(PointerEventData eventData)
		{
			if (this.routeToParent)
			{
				this.DoForParents<IEndDragHandler>(delegate(IEndDragHandler parent)
				{
					parent.OnEndDrag(eventData);
				});
			}
			else
			{
				base.OnEndDrag(eventData);
			}
			this.routeToParent = false;
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x000244F8 File Offset: 0x000226F8
		public override void OnScroll(PointerEventData eventData)
		{
			if (!base.horizontal && Math.Abs(eventData.scrollDelta.x) > Math.Abs(eventData.scrollDelta.y))
			{
				this.routeToParent = true;
			}
			else if (!base.vertical && Math.Abs(eventData.scrollDelta.x) < Math.Abs(eventData.scrollDelta.y))
			{
				this.routeToParent = true;
			}
			else
			{
				this.routeToParent = false;
			}
			if (this.routeToParent)
			{
				this.DoForParents<IScrollHandler>(delegate(IScrollHandler parent)
				{
					parent.OnScroll(eventData);
				});
				return;
			}
			base.OnScroll(eventData);
		}

		// Token: 0x04000478 RID: 1144
		private bool routeToParent;
	}
}
