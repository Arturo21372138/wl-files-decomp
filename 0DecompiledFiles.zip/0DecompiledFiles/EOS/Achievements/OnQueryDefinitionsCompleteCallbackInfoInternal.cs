﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000809 RID: 2057
	internal struct OnQueryDefinitionsCompleteCallbackInfoInternal : ICallbackInfoInternal, IGettable<OnQueryDefinitionsCompleteCallbackInfo>
	{
		// Token: 0x1700086B RID: 2155
		// (get) Token: 0x060021D4 RID: 8660 RVA: 0x00028460 File Offset: 0x00026660
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x060021D5 RID: 8661 RVA: 0x00028468 File Offset: 0x00026668
		public void Get(out OnQueryDefinitionsCompleteCallbackInfo other)
		{
			other = default(OnQueryDefinitionsCompleteCallbackInfo);
			other.ResultCode = this.m_ResultCode;
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
		}

		// Token: 0x04001697 RID: 5783
		private Result m_ResultCode;

		// Token: 0x04001698 RID: 5784
		private IntPtr m_ClientData;
	}
}
