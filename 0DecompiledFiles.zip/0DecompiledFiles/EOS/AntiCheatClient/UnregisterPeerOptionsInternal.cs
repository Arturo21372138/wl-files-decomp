﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007DB RID: 2011
	internal struct UnregisterPeerOptionsInternal : ISettable<UnregisterPeerOptions>, IDisposable
	{
		// Token: 0x0600211F RID: 8479 RVA: 0x000275A7 File Offset: 0x000257A7
		public void Set(ref UnregisterPeerOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			this.m_PeerHandle = other.PeerHandle;
		}

		// Token: 0x06002120 RID: 8480 RVA: 0x000275C2 File Offset: 0x000257C2
		public void Dispose()
		{
		}

		// Token: 0x0400160C RID: 5644
		private int m_ApiVersion;

		// Token: 0x0400160D RID: 5645
		private IntPtr m_PeerHandle;
	}
}
