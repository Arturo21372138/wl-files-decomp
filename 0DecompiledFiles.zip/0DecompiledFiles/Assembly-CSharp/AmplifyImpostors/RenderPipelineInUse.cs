﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E1 RID: 225
	public enum RenderPipelineInUse
	{
		// Token: 0x04000560 RID: 1376
		None,
		// Token: 0x04000561 RID: 1377
		LW,
		// Token: 0x04000562 RID: 1378
		HD,
		// Token: 0x04000563 RID: 1379
		URP,
		// Token: 0x04000564 RID: 1380
		Custom = 3
	}
}
