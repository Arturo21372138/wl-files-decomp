﻿using System;
using System.Collections;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200008D RID: 141
	[ExecuteInEditMode]
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("UI/Extensions/Scroll Snap")]
	public class ScrollSnap : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IEndDragHandler, IDragHandler, IScrollSnap
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000448 RID: 1096 RVA: 0x00019CE4 File Offset: 0x00017EE4
		// (remove) Token: 0x06000449 RID: 1097 RVA: 0x00019D1C File Offset: 0x00017F1C
		public event ScrollSnap.PageSnapChange onPageChange;

		// Token: 0x0600044A RID: 1098 RVA: 0x00019D54 File Offset: 0x00017F54
		private void Start()
		{
			this._lerp = false;
			this._scroll_rect = base.gameObject.GetComponent<ScrollRect>();
			this._scrollRectTransform = base.gameObject.GetComponent<RectTransform>();
			this._listContainerTransform = this._scroll_rect.content;
			this._listContainerRectTransform = this._listContainerTransform.GetComponent<RectTransform>();
			this.UpdateListItemsSize();
			this.UpdateListItemPositions();
			this.PageChanged(this.CurrentPage());
			if (this.NextButton)
			{
				this.NextButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.NextScreen();
				});
			}
			if (this.PrevButton)
			{
				this.PrevButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.PreviousScreen();
				});
			}
			if (this._scroll_rect.horizontalScrollbar != null && this._scroll_rect.horizontal)
			{
				this._scroll_rect.horizontalScrollbar.gameObject.GetOrAddComponent<ScrollSnapScrollbarHelper>().ss = this;
			}
			if (this._scroll_rect.verticalScrollbar != null && this._scroll_rect.vertical)
			{
				this._scroll_rect.verticalScrollbar.gameObject.GetOrAddComponent<ScrollSnapScrollbarHelper>().ss = this;
			}
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x00019E98 File Offset: 0x00018098
		public void UpdateListItemsSize()
		{
			float num;
			float num2;
			if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
			{
				num = this._scrollRectTransform.rect.width / (float)this.ItemsVisibleAtOnce;
				num2 = this._listContainerRectTransform.rect.width / (float)this._itemsCount;
			}
			else
			{
				num = this._scrollRectTransform.rect.height / (float)this.ItemsVisibleAtOnce;
				num2 = this._listContainerRectTransform.rect.height / (float)this._itemsCount;
			}
			this._itemSize = num;
			if (this.LinkScrolrectScrollSensitivity)
			{
				this._scroll_rect.scrollSensitivity = this._itemSize;
			}
			if (this.AutoLayoutItems && num2 != num && this._itemsCount > 0)
			{
				if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
				{
					using (IEnumerator enumerator = this._listContainerTransform.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							object obj = enumerator.Current;
							GameObject gameObject = ((Transform)obj).gameObject;
							if (gameObject.activeInHierarchy)
							{
								LayoutElement layoutElement = gameObject.GetComponent<LayoutElement>();
								if (layoutElement == null)
								{
									layoutElement = gameObject.AddComponent<LayoutElement>();
								}
								layoutElement.minWidth = this._itemSize;
							}
						}
						return;
					}
				}
				foreach (object obj2 in this._listContainerTransform)
				{
					GameObject gameObject2 = ((Transform)obj2).gameObject;
					if (gameObject2.activeInHierarchy)
					{
						LayoutElement layoutElement2 = gameObject2.GetComponent<LayoutElement>();
						if (layoutElement2 == null)
						{
							layoutElement2 = gameObject2.AddComponent<LayoutElement>();
						}
						layoutElement2.minHeight = this._itemSize;
					}
				}
			}
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x0001A070 File Offset: 0x00018270
		public void UpdateListItemPositions()
		{
			if (!this._listContainerRectTransform.rect.size.Equals(this._listContainerCachedSize))
			{
				int num = 0;
				using (IEnumerator enumerator = this._listContainerTransform.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (((Transform)enumerator.Current).gameObject.activeInHierarchy)
						{
							num++;
						}
					}
				}
				this._itemsCount = 0;
				Array.Resize<Vector3>(ref this._pageAnchorPositions, num);
				if (num > 0)
				{
					this._pages = Mathf.Max(num - this.ItemsVisibleAtOnce + 1, 1);
					if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
					{
						this._scroll_rect.horizontalNormalizedPosition = 0f;
						this._listContainerMaxPosition = this._listContainerTransform.localPosition.x;
						this._scroll_rect.horizontalNormalizedPosition = 1f;
						this._listContainerMinPosition = this._listContainerTransform.localPosition.x;
						this._listContainerSize = this._listContainerMaxPosition - this._listContainerMinPosition;
						for (int i = 0; i < this._pages; i++)
						{
							this._pageAnchorPositions[i] = new Vector3(this._listContainerMaxPosition - this._itemSize * (float)i, this._listContainerTransform.localPosition.y, this._listContainerTransform.localPosition.z);
						}
					}
					else
					{
						this._scroll_rect.verticalNormalizedPosition = 1f;
						this._listContainerMinPosition = this._listContainerTransform.localPosition.y;
						this._scroll_rect.verticalNormalizedPosition = 0f;
						this._listContainerMaxPosition = this._listContainerTransform.localPosition.y;
						this._listContainerSize = this._listContainerMaxPosition - this._listContainerMinPosition;
						for (int j = 0; j < this._pages; j++)
						{
							this._pageAnchorPositions[j] = new Vector3(this._listContainerTransform.localPosition.x, this._listContainerMinPosition + this._itemSize * (float)j, this._listContainerTransform.localPosition.z);
						}
					}
					this.UpdateScrollbar(this.LinkScrolbarSteps);
					this._startingPage = Mathf.Min(this._startingPage, this._pages);
					this.ResetPage();
				}
				if (this._itemsCount != num)
				{
					this.PageChanged(this.CurrentPage());
				}
				this._itemsCount = num;
				this._listContainerCachedSize.Set(this._listContainerRectTransform.rect.size.x, this._listContainerRectTransform.rect.size.y);
			}
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x0001A32C File Offset: 0x0001852C
		public void ResetPage()
		{
			if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
			{
				this._scroll_rect.horizontalNormalizedPosition = ((this._pages > 1) ? ((float)this._startingPage / (float)(this._pages - 1)) : 0f);
				return;
			}
			this._scroll_rect.verticalNormalizedPosition = ((this._pages > 1) ? ((float)(this._pages - this._startingPage - 1) / (float)(this._pages - 1)) : 0f);
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x0001A3A4 File Offset: 0x000185A4
		private void UpdateScrollbar(bool linkSteps)
		{
			if (linkSteps)
			{
				if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
				{
					if (this._scroll_rect.horizontalScrollbar != null)
					{
						this._scroll_rect.horizontalScrollbar.numberOfSteps = this._pages;
						return;
					}
				}
				else if (this._scroll_rect.verticalScrollbar != null)
				{
					this._scroll_rect.verticalScrollbar.numberOfSteps = this._pages;
					return;
				}
			}
			else if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
			{
				if (this._scroll_rect.horizontalScrollbar != null)
				{
					this._scroll_rect.horizontalScrollbar.numberOfSteps = 0;
					return;
				}
			}
			else if (this._scroll_rect.verticalScrollbar != null)
			{
				this._scroll_rect.verticalScrollbar.numberOfSteps = 0;
			}
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x0001A464 File Offset: 0x00018664
		private void LateUpdate()
		{
			this.UpdateListItemsSize();
			this.UpdateListItemPositions();
			if (this._lerp)
			{
				this.UpdateScrollbar(false);
				this._listContainerTransform.localPosition = Vector3.Lerp(this._listContainerTransform.localPosition, this._lerpTarget, 7.5f * Time.deltaTime);
				if (Vector3.Distance(this._listContainerTransform.localPosition, this._lerpTarget) < 0.001f)
				{
					this._listContainerTransform.localPosition = this._lerpTarget;
					this._lerp = false;
					this.UpdateScrollbar(this.LinkScrolbarSteps);
				}
				if (Vector3.Distance(this._listContainerTransform.localPosition, this._lerpTarget) < 10f)
				{
					this.PageChanged(this.CurrentPage());
				}
			}
			if (this._fastSwipeTimer)
			{
				this._fastSwipeCounter++;
			}
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x0001A53C File Offset: 0x0001873C
		public void NextScreen()
		{
			this.UpdateListItemPositions();
			if (this.CurrentPage() < this._pages - 1)
			{
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[this.CurrentPage() + 1];
				this.PageChanged(this.CurrentPage() + 1);
			}
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0001A58D File Offset: 0x0001878D
		public void PreviousScreen()
		{
			this.UpdateListItemPositions();
			if (this.CurrentPage() > 0)
			{
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[this.CurrentPage() - 1];
				this.PageChanged(this.CurrentPage() - 1);
			}
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x0001A5CC File Offset: 0x000187CC
		private void NextScreenCommand()
		{
			if (this._pageOnDragStart < this._pages - 1)
			{
				int num = Mathf.Min(this._pages - 1, this._pageOnDragStart + this.ItemsVisibleAtOnce);
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[num];
				this.PageChanged(num);
			}
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x0001A624 File Offset: 0x00018824
		private void PrevScreenCommand()
		{
			if (this._pageOnDragStart > 0)
			{
				int num = Mathf.Max(0, this._pageOnDragStart - this.ItemsVisibleAtOnce);
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[num];
				this.PageChanged(num);
			}
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0001A670 File Offset: 0x00018870
		public int CurrentPage()
		{
			float num;
			if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
			{
				num = this._listContainerMaxPosition - this._listContainerTransform.localPosition.x;
				num = Mathf.Clamp(num, 0f, this._listContainerSize);
			}
			else
			{
				num = this._listContainerTransform.localPosition.y - this._listContainerMinPosition;
				num = Mathf.Clamp(num, 0f, this._listContainerSize);
			}
			return Mathf.Clamp(Mathf.RoundToInt(num / this._itemSize), 0, this._pages);
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0001A6F4 File Offset: 0x000188F4
		public void SetLerp(bool value)
		{
			this._lerp = value;
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0001A6FD File Offset: 0x000188FD
		public void ChangePage(int page)
		{
			if (0 <= page && page < this._pages)
			{
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[page];
				this.PageChanged(page);
			}
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0001A72C File Offset: 0x0001892C
		private void PageChanged(int currentPage)
		{
			this._startingPage = currentPage;
			if (this.NextButton)
			{
				this.NextButton.interactable = currentPage < this._pages - 1;
			}
			if (this.PrevButton)
			{
				this.PrevButton.interactable = currentPage > 0;
			}
			if (this.onPageChange != null)
			{
				this.onPageChange(currentPage);
			}
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0001A793 File Offset: 0x00018993
		public void OnBeginDrag(PointerEventData eventData)
		{
			this.UpdateScrollbar(false);
			this._fastSwipeCounter = 0;
			this._fastSwipeTimer = true;
			this._positionOnDragStart = eventData.position;
			this._pageOnDragStart = this.CurrentPage();
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0001A7C8 File Offset: 0x000189C8
		public void OnEndDrag(PointerEventData eventData)
		{
			this._startDrag = true;
			float num;
			if (this.direction == ScrollSnap.ScrollDirection.Horizontal)
			{
				num = this._positionOnDragStart.x - eventData.position.x;
			}
			else
			{
				num = -this._positionOnDragStart.y + eventData.position.y;
			}
			if (!this.UseFastSwipe)
			{
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[this.CurrentPage()];
				return;
			}
			this.fastSwipe = false;
			this._fastSwipeTimer = false;
			if (this._fastSwipeCounter <= this._fastSwipeTarget && Math.Abs(num) > (float)this.FastSwipeThreshold)
			{
				this.fastSwipe = true;
			}
			if (!this.fastSwipe)
			{
				this._lerp = true;
				this._lerpTarget = this._pageAnchorPositions[this.CurrentPage()];
				return;
			}
			if (num > 0f)
			{
				this.NextScreenCommand();
				return;
			}
			this.PrevScreenCommand();
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0001A8B2 File Offset: 0x00018AB2
		public void OnDrag(PointerEventData eventData)
		{
			this._lerp = false;
			if (this._startDrag)
			{
				this.OnBeginDrag(eventData);
				this._startDrag = false;
			}
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0001A8D1 File Offset: 0x00018AD1
		public void StartScreenChange()
		{
		}

		// Token: 0x0400032B RID: 811
		private ScrollRect _scroll_rect;

		// Token: 0x0400032C RID: 812
		private RectTransform _scrollRectTransform;

		// Token: 0x0400032D RID: 813
		private Transform _listContainerTransform;

		// Token: 0x0400032E RID: 814
		private int _pages;

		// Token: 0x0400032F RID: 815
		private int _startingPage;

		// Token: 0x04000330 RID: 816
		private Vector3[] _pageAnchorPositions;

		// Token: 0x04000331 RID: 817
		private Vector3 _lerpTarget;

		// Token: 0x04000332 RID: 818
		private bool _lerp;

		// Token: 0x04000333 RID: 819
		private float _listContainerMinPosition;

		// Token: 0x04000334 RID: 820
		private float _listContainerMaxPosition;

		// Token: 0x04000335 RID: 821
		private float _listContainerSize;

		// Token: 0x04000336 RID: 822
		private RectTransform _listContainerRectTransform;

		// Token: 0x04000337 RID: 823
		private Vector2 _listContainerCachedSize;

		// Token: 0x04000338 RID: 824
		private float _itemSize;

		// Token: 0x04000339 RID: 825
		private int _itemsCount;

		// Token: 0x0400033A RID: 826
		private bool _startDrag = true;

		// Token: 0x0400033B RID: 827
		private Vector3 _positionOnDragStart;

		// Token: 0x0400033C RID: 828
		private int _pageOnDragStart;

		// Token: 0x0400033D RID: 829
		private bool _fastSwipeTimer;

		// Token: 0x0400033E RID: 830
		private int _fastSwipeCounter;

		// Token: 0x0400033F RID: 831
		private int _fastSwipeTarget = 10;

		// Token: 0x04000340 RID: 832
		[Tooltip("Button to go to the next page. (optional)")]
		public Button NextButton;

		// Token: 0x04000341 RID: 833
		[Tooltip("Button to go to the previous page. (optional)")]
		public Button PrevButton;

		// Token: 0x04000342 RID: 834
		[Tooltip("Number of items visible in one page of scroll frame.")]
		[Range(1f, 100f)]
		public int ItemsVisibleAtOnce = 1;

		// Token: 0x04000343 RID: 835
		[Tooltip("Sets minimum width of list items to 1/itemsVisibleAtOnce.")]
		public bool AutoLayoutItems = true;

		// Token: 0x04000344 RID: 836
		[Tooltip("If you wish to update scrollbar numberOfSteps to number of active children on list.")]
		public bool LinkScrolbarSteps;

		// Token: 0x04000345 RID: 837
		[Tooltip("If you wish to update scrollrect sensitivity to size of list element.")]
		public bool LinkScrolrectScrollSensitivity;

		// Token: 0x04000346 RID: 838
		public bool UseFastSwipe = true;

		// Token: 0x04000347 RID: 839
		public int FastSwipeThreshold = 100;

		// Token: 0x04000349 RID: 841
		public ScrollSnap.ScrollDirection direction;

		// Token: 0x0400034A RID: 842
		private bool fastSwipe;

		// Token: 0x02000139 RID: 313
		public enum ScrollDirection
		{
			// Token: 0x04000687 RID: 1671
			Horizontal,
			// Token: 0x04000688 RID: 1672
			Vertical
		}

		// Token: 0x0200013A RID: 314
		// (Invoke) Token: 0x06000804 RID: 2052
		public delegate void PageSnapChange(int page);
	}
}
