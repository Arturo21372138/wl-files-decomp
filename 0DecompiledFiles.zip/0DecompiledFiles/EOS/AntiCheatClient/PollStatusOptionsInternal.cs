﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007CD RID: 1997
	internal struct PollStatusOptionsInternal : ISettable<PollStatusOptions>, IDisposable
	{
		// Token: 0x060020F3 RID: 8435 RVA: 0x000272EA File Offset: 0x000254EA
		public void Set(ref PollStatusOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			this.m_OutMessageLength = other.OutMessageLength;
		}

		// Token: 0x060020F4 RID: 8436 RVA: 0x00027305 File Offset: 0x00025505
		public void Dispose()
		{
		}

		// Token: 0x040015E3 RID: 5603
		private int m_ApiVersion;

		// Token: 0x040015E4 RID: 5604
		private uint m_OutMessageLength;
	}
}
