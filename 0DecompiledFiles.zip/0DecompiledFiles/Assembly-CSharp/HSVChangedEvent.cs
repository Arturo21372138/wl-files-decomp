﻿using System;
using UnityEngine.Events;

// Token: 0x02000009 RID: 9
public class HSVChangedEvent : UnityEvent<float, float, float>
{
}
