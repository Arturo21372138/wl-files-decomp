﻿using System;

namespace ch.sycoforge.Decal.Wrapper
{
	// Token: 0x02000028 RID: 40
	public class EasyDecal : EasyDecal
	{
	}
}
