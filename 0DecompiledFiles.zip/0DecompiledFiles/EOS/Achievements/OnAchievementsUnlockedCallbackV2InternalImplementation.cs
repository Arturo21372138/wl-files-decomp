﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000802 RID: 2050
	internal static class OnAchievementsUnlockedCallbackV2InternalImplementation
	{
		// Token: 0x17000862 RID: 2146
		// (get) Token: 0x060021B6 RID: 8630 RVA: 0x000282D3 File Offset: 0x000264D3
		public static OnAchievementsUnlockedCallbackV2Internal Delegate
		{
			get
			{
				if (OnAchievementsUnlockedCallbackV2InternalImplementation.s_Delegate == null)
				{
					OnAchievementsUnlockedCallbackV2InternalImplementation.s_Delegate = new OnAchievementsUnlockedCallbackV2Internal(OnAchievementsUnlockedCallbackV2InternalImplementation.EntryPoint);
				}
				return OnAchievementsUnlockedCallbackV2InternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060021B7 RID: 8631 RVA: 0x000282F4 File Offset: 0x000264F4
		[MonoPInvokeCallback(typeof(OnAchievementsUnlockedCallbackV2Internal))]
		public static void EntryPoint(ref OnAchievementsUnlockedCallbackV2InfoInternal data)
		{
			OnAchievementsUnlockedCallbackV2 onAchievementsUnlockedCallbackV;
			OnAchievementsUnlockedCallbackV2Info onAchievementsUnlockedCallbackV2Info;
			if (Helper.TryGetCallback<OnAchievementsUnlockedCallbackV2InfoInternal, OnAchievementsUnlockedCallbackV2, OnAchievementsUnlockedCallbackV2Info>(ref data, out onAchievementsUnlockedCallbackV, out onAchievementsUnlockedCallbackV2Info))
			{
				onAchievementsUnlockedCallbackV(ref onAchievementsUnlockedCallbackV2Info);
			}
		}

		// Token: 0x0400168B RID: 5771
		private static OnAchievementsUnlockedCallbackV2Internal s_Delegate;
	}
}
