﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000094 RID: 148
	public abstract class Menu<T> : Menu where T : Menu<T>
	{
		// Token: 0x170000CE RID: 206
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x0001CDE4 File Offset: 0x0001AFE4
		// (set) Token: 0x060004CF RID: 1231 RVA: 0x0001CDEB File Offset: 0x0001AFEB
		public static T Instance { get; private set; }

		// Token: 0x060004D0 RID: 1232 RVA: 0x0001CDF3 File Offset: 0x0001AFF3
		protected virtual void Awake()
		{
			Menu<T>.Instance = (T)((object)this);
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x0001CE00 File Offset: 0x0001B000
		protected virtual void OnDestroy()
		{
			Menu<T>.Instance = default(T);
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x0001CE1C File Offset: 0x0001B01C
		protected static void Open()
		{
			GameObject gameObject = null;
			if (Menu<T>.Instance == null)
			{
				MenuManager.Instance.CreateInstance(typeof(T).Name, out gameObject);
				MenuManager.Instance.OpenMenu(gameObject.GetMenu());
				return;
			}
			Menu<T>.Instance.gameObject.SetActive(true);
			MenuManager.Instance.OpenMenu(Menu<T>.Instance);
		}

		// Token: 0x060004D3 RID: 1235 RVA: 0x0001CE94 File Offset: 0x0001B094
		protected static void Close()
		{
			if (Menu<T>.Instance == null)
			{
				Debug.LogErrorFormat("Trying to close menu {0} but Instance is null", new object[] { typeof(T) });
				return;
			}
			MenuManager.Instance.CloseMenu(Menu<T>.Instance);
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x0001CEE5 File Offset: 0x0001B0E5
		public override void OnBackPressed()
		{
			Menu<T>.Close();
		}
	}
}
