﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000041 RID: 65
	[AddComponentMenu("UI/Extensions/RescalePanels/RescalePanel")]
	public class RescalePanel : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IDragHandler
	{
		// Token: 0x060001BE RID: 446 RVA: 0x0000A8F0 File Offset: 0x00008AF0
		private void Awake()
		{
			this.rectTransform = base.transform.parent.GetComponent<RectTransform>();
			this.goTransform = base.transform.parent;
			this.thisRectTransform = base.GetComponent<RectTransform>();
			this.sizeDelta = this.thisRectTransform.sizeDelta;
		}

		// Token: 0x060001BF RID: 447 RVA: 0x0000A941 File Offset: 0x00008B41
		public void OnPointerDown(PointerEventData data)
		{
			this.rectTransform.SetAsLastSibling();
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.rectTransform, data.position, data.pressEventCamera, out this.previousPointerPosition);
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000A96C File Offset: 0x00008B6C
		public void OnDrag(PointerEventData data)
		{
			if (this.rectTransform == null)
			{
				return;
			}
			Vector3 vector = this.goTransform.localScale;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.rectTransform, data.position, data.pressEventCamera, out this.currentPointerPosition);
			Vector2 vector2 = this.currentPointerPosition - this.previousPointerPosition;
			vector += new Vector3(-vector2.y * 0.001f, -vector2.y * 0.001f, 0f);
			vector = new Vector3(Mathf.Clamp(vector.x, this.minSize.x, this.maxSize.x), Mathf.Clamp(vector.y, this.minSize.y, this.maxSize.y), 1f);
			this.goTransform.localScale = vector;
			this.previousPointerPosition = this.currentPointerPosition;
			float num = this.sizeDelta.x / this.goTransform.localScale.x;
			Vector2 vector3 = new Vector2(num, num);
			this.thisRectTransform.sizeDelta = vector3;
		}

		// Token: 0x04000199 RID: 409
		public Vector2 minSize;

		// Token: 0x0400019A RID: 410
		public Vector2 maxSize;

		// Token: 0x0400019B RID: 411
		private RectTransform rectTransform;

		// Token: 0x0400019C RID: 412
		private Transform goTransform;

		// Token: 0x0400019D RID: 413
		private Vector2 currentPointerPosition;

		// Token: 0x0400019E RID: 414
		private Vector2 previousPointerPosition;

		// Token: 0x0400019F RID: 415
		private RectTransform thisRectTransform;

		// Token: 0x040001A0 RID: 416
		private Vector2 sizeDelta;
	}
}
