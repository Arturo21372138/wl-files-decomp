﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B0 RID: 176
	[RequireComponent(typeof(EventSystem))]
	[AddComponentMenu("UI/Extensions/DragCorrector")]
	public class DragCorrector : MonoBehaviour
	{
		// Token: 0x060005F1 RID: 1521 RVA: 0x00023C5C File Offset: 0x00021E5C
		private void Start()
		{
			this.dragTH = this.baseTH * (int)Screen.dpi / this.basePPI;
			EventSystem component = base.GetComponent<EventSystem>();
			if (component)
			{
				component.pixelDragThreshold = this.dragTH;
			}
		}

		// Token: 0x04000466 RID: 1126
		public int baseTH = 6;

		// Token: 0x04000467 RID: 1127
		public int basePPI = 210;

		// Token: 0x04000468 RID: 1128
		public int dragTH;
	}
}
