﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Runtime.CompilerServices;

// Token: 0x02000005 RID: 5
[CompilerGenerated]
[EditorBrowsable(EditorBrowsableState.Never)]
[GeneratedCode("Unity.MonoScriptGenerator.MonoScriptInfoGenerator", null)]
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{
	// Token: 0x06000019 RID: 25 RVA: 0x000024D4 File Offset: 0x000006D4
	[MethodImpl(MethodImplOptions.AggressiveInlining)]
	private static UnitySourceGeneratedAssemblyMonoScriptTypes_v1.MonoScriptData Get()
	{
		UnitySourceGeneratedAssemblyMonoScriptTypes_v1.MonoScriptData monoScriptData = default(UnitySourceGeneratedAssemblyMonoScriptTypes_v1.MonoScriptData);
		monoScriptData.FilePathsData = new byte[]
		{
			0, 0, 0, 1, 0, 0, 0, 60, 92, 65,
			115, 115, 101, 116, 115, 92, 83, 99, 114, 105,
			112, 116, 115, 92, 65, 114, 99, 97, 100, 101,
			77, 97, 99, 104, 105, 110, 101, 92, 65, 114,
			99, 97, 100, 101, 77, 97, 99, 104, 105, 110,
			101, 92, 65, 114, 99, 97, 100, 101, 77, 97,
			99, 104, 105, 110, 101, 46, 99, 115, 0, 0,
			0, 1, 0, 0, 0, 64, 92, 65, 115, 115,
			101, 116, 115, 92, 83, 99, 114, 105, 112, 116,
			115, 92, 65, 114, 99, 97, 100, 101, 77, 97,
			99, 104, 105, 110, 101, 92, 65, 114, 99, 97,
			100, 101, 77, 97, 99, 104, 105, 110, 101, 92,
			65, 114, 99, 97, 100, 101, 77, 97, 99, 104,
			105, 110, 101, 71, 97, 109, 101, 46, 99, 115,
			0, 0, 0, 1, 0, 0, 0, 65, 92, 65,
			115, 115, 101, 116, 115, 92, 83, 99, 114, 105,
			112, 116, 115, 92, 65, 114, 99, 97, 100, 101,
			77, 97, 99, 104, 105, 110, 101, 92, 65, 114,
			99, 97, 100, 101, 77, 97, 99, 104, 105, 110,
			101, 92, 65, 114, 99, 97, 100, 101, 77, 97,
			99, 104, 105, 110, 101, 73, 110, 116, 114, 111,
			46, 99, 115
		};
		monoScriptData.TypesData = new byte[]
		{
			0, 0, 0, 0, 14, 124, 65, 114, 99, 97,
			100, 101, 77, 97, 99, 104, 105, 110, 101, 0,
			0, 0, 0, 18, 124, 65, 114, 99, 97, 100,
			101, 77, 97, 99, 104, 105, 110, 101, 71, 97,
			109, 101, 0, 0, 0, 0, 19, 124, 65, 114,
			99, 97, 100, 101, 77, 97, 99, 104, 105, 110,
			101, 73, 110, 116, 114, 111
		};
		monoScriptData.TotalFiles = 3;
		monoScriptData.TotalTypes = 3;
		monoScriptData.IsEditorOnly = false;
		return monoScriptData;
	}

	// Token: 0x0200000C RID: 12
	private struct MonoScriptData
	{
		// Token: 0x04000027 RID: 39
		public byte[] FilePathsData;

		// Token: 0x04000028 RID: 40
		public byte[] TypesData;

		// Token: 0x04000029 RID: 41
		public int TotalTypes;

		// Token: 0x0400002A RID: 42
		public int TotalFiles;

		// Token: 0x0400002B RID: 43
		public bool IsEditorOnly;
	}
}
