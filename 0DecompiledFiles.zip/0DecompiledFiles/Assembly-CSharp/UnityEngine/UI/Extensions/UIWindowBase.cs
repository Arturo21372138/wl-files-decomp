﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000AB RID: 171
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/UI Window Base")]
	public class UIWindowBase : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IDragHandler, IEndDragHandler
	{
		// Token: 0x060005BA RID: 1466 RVA: 0x00022808 File Offset: 0x00020A08
		private void Start()
		{
			if (this.RootTransform == null)
			{
				this.RootTransform = base.GetComponent<RectTransform>();
			}
			this.m_originalCoods = this.RootTransform.position;
			this.m_canvas = base.GetComponentInParent<Canvas>();
			this.m_canvasRectTransform = this.m_canvas.GetComponent<RectTransform>();
		}

		// Token: 0x060005BB RID: 1467 RVA: 0x0002285D File Offset: 0x00020A5D
		private void Update()
		{
			if (UIWindowBase.ResetCoords)
			{
				this.resetCoordinatePosition();
			}
		}

		// Token: 0x060005BC RID: 1468 RVA: 0x0002286C File Offset: 0x00020A6C
		public void OnDrag(PointerEventData eventData)
		{
			if (this._isDragging)
			{
				Vector3 vector = this.ScreenToCanvas(eventData.position) - this.ScreenToCanvas(eventData.position - eventData.delta);
				this.RootTransform.localPosition += vector;
			}
		}

		// Token: 0x060005BD RID: 1469 RVA: 0x000228CC File Offset: 0x00020ACC
		public void OnBeginDrag(PointerEventData eventData)
		{
			if (eventData.pointerCurrentRaycast.gameObject == null)
			{
				return;
			}
			if (eventData.pointerCurrentRaycast.gameObject.name == base.name)
			{
				this._isDragging = true;
			}
		}

		// Token: 0x060005BE RID: 1470 RVA: 0x00022917 File Offset: 0x00020B17
		public void OnEndDrag(PointerEventData eventData)
		{
			this._isDragging = false;
		}

		// Token: 0x060005BF RID: 1471 RVA: 0x00022920 File Offset: 0x00020B20
		private void resetCoordinatePosition()
		{
			this.RootTransform.position = this.m_originalCoods;
			UIWindowBase.ResetCoords = false;
		}

		// Token: 0x060005C0 RID: 1472 RVA: 0x0002293C File Offset: 0x00020B3C
		private Vector3 ScreenToCanvas(Vector3 screenPosition)
		{
			Vector2 sizeDelta = this.m_canvasRectTransform.sizeDelta;
			Vector3 vector;
			Vector2 vector2;
			Vector2 vector3;
			if (this.m_canvas.renderMode == RenderMode.ScreenSpaceOverlay || (this.m_canvas.renderMode == RenderMode.ScreenSpaceCamera && this.m_canvas.worldCamera == null))
			{
				vector = screenPosition;
				vector2 = Vector2.zero;
				vector3 = sizeDelta;
			}
			else
			{
				Ray ray = this.m_canvas.worldCamera.ScreenPointToRay(screenPosition);
				Plane plane = new Plane(this.m_canvasRectTransform.forward, this.m_canvasRectTransform.position);
				float num;
				if (!plane.Raycast(ray, out num))
				{
					throw new Exception("Is it practically possible?");
				}
				Vector3 vector4 = ray.origin + ray.direction * num;
				vector = this.m_canvasRectTransform.InverseTransformPoint(vector4);
				vector2 = -Vector2.Scale(sizeDelta, this.m_canvasRectTransform.pivot);
				vector3 = Vector2.Scale(sizeDelta, Vector2.one - this.m_canvasRectTransform.pivot);
			}
			vector.x = Mathf.Clamp(vector.x, vector2.x + (float)this.KeepWindowInCanvas, vector3.x - (float)this.KeepWindowInCanvas);
			vector.y = Mathf.Clamp(vector.y, vector2.y + (float)this.KeepWindowInCanvas, vector3.y - (float)this.KeepWindowInCanvas);
			return vector;
		}

		// Token: 0x0400044A RID: 1098
		private bool _isDragging;

		// Token: 0x0400044B RID: 1099
		public static bool ResetCoords;

		// Token: 0x0400044C RID: 1100
		private Vector3 m_originalCoods = Vector3.zero;

		// Token: 0x0400044D RID: 1101
		private Canvas m_canvas;

		// Token: 0x0400044E RID: 1102
		private RectTransform m_canvasRectTransform;

		// Token: 0x0400044F RID: 1103
		[Tooltip("Number of pixels of the window that must stay inside the canvas view.")]
		public int KeepWindowInCanvas = 5;

		// Token: 0x04000450 RID: 1104
		[Tooltip("The transform that is moved when dragging, can be left empty in which case its own transform is used.")]
		public RectTransform RootTransform;
	}
}
