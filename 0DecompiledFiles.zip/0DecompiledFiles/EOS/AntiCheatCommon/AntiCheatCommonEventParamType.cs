﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000770 RID: 1904
	public enum AntiCheatCommonEventParamType
	{
		// Token: 0x04001492 RID: 5266
		Invalid,
		// Token: 0x04001493 RID: 5267
		ClientHandle,
		// Token: 0x04001494 RID: 5268
		String,
		// Token: 0x04001495 RID: 5269
		UInt32,
		// Token: 0x04001496 RID: 5270
		Int32,
		// Token: 0x04001497 RID: 5271
		UInt64,
		// Token: 0x04001498 RID: 5272
		Int64,
		// Token: 0x04001499 RID: 5273
		Vector3f,
		// Token: 0x0400149A RID: 5274
		Quat,
		// Token: 0x0400149B RID: 5275
		Float
	}
}
