﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000073 RID: 115
	public abstract class FancyScrollView<TItemData, TContext> : MonoBehaviour where TContext : class, new()
	{
		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000371 RID: 881
		protected abstract GameObject CellPrefab { get; }

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000372 RID: 882 RVA: 0x00016888 File Offset: 0x00014A88
		// (set) Token: 0x06000373 RID: 883 RVA: 0x00016890 File Offset: 0x00014A90
		protected IList<TItemData> ItemsSource { get; set; } = new List<TItemData>();

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000374 RID: 884 RVA: 0x00016899 File Offset: 0x00014A99
		protected TContext Context { get; } = new TContext();

		// Token: 0x06000375 RID: 885 RVA: 0x000168A1 File Offset: 0x00014AA1
		protected virtual void Initialize()
		{
		}

		// Token: 0x06000376 RID: 886 RVA: 0x000168A3 File Offset: 0x00014AA3
		protected virtual void UpdateContents(IList<TItemData> itemsSource)
		{
			this.ItemsSource = itemsSource;
			this.Refresh();
		}

		// Token: 0x06000377 RID: 887 RVA: 0x000168B2 File Offset: 0x00014AB2
		protected virtual void Relayout()
		{
			this.UpdatePosition(this.currentPosition, false);
		}

		// Token: 0x06000378 RID: 888 RVA: 0x000168C1 File Offset: 0x00014AC1
		protected virtual void Refresh()
		{
			this.UpdatePosition(this.currentPosition, true);
		}

		// Token: 0x06000379 RID: 889 RVA: 0x000168D0 File Offset: 0x00014AD0
		protected virtual void UpdatePosition(float position)
		{
			this.UpdatePosition(position, false);
		}

		// Token: 0x0600037A RID: 890 RVA: 0x000168DC File Offset: 0x00014ADC
		private void UpdatePosition(float position, bool forceRefresh)
		{
			if (!this.initialized)
			{
				this.Initialize();
				this.initialized = true;
			}
			this.currentPosition = position;
			float num = position - this.scrollOffset / this.cellInterval;
			int num2 = Mathf.CeilToInt(num);
			float num3 = (Mathf.Ceil(num) - num) * this.cellInterval;
			if (num3 + (float)this.pool.Count * this.cellInterval < 1f)
			{
				this.ResizePool(num3);
			}
			this.UpdateCells(num3, num2, forceRefresh);
		}

		// Token: 0x0600037B RID: 891 RVA: 0x00016958 File Offset: 0x00014B58
		private void ResizePool(float firstPosition)
		{
			int num = Mathf.CeilToInt((1f - firstPosition) / this.cellInterval) - this.pool.Count;
			for (int i = 0; i < num; i++)
			{
				FancyCell<TItemData, TContext> component = Object.Instantiate<GameObject>(this.CellPrefab, this.cellContainer).GetComponent<FancyCell<TItemData, TContext>>();
				if (component == null)
				{
					throw new MissingComponentException(string.Format("FancyCell<{0}, {1}> component not found in {2}.", typeof(TItemData).FullName, typeof(TContext).FullName, this.CellPrefab.name));
				}
				component.SetContext(this.Context);
				component.Initialize();
				component.SetVisible(false);
				this.pool.Add(component);
			}
		}

		// Token: 0x0600037C RID: 892 RVA: 0x00016A18 File Offset: 0x00014C18
		private void UpdateCells(float firstPosition, int firstIndex, bool forceRefresh)
		{
			for (int i = 0; i < this.pool.Count; i++)
			{
				int num = firstIndex + i;
				float num2 = firstPosition + (float)i * this.cellInterval;
				FancyCell<TItemData, TContext> fancyCell = this.pool[this.CircularIndex(num, this.pool.Count)];
				if (this.loop)
				{
					num = this.CircularIndex(num, this.ItemsSource.Count);
				}
				if (num < 0 || num >= this.ItemsSource.Count || num2 > 1f)
				{
					fancyCell.SetVisible(false);
				}
				else
				{
					if (forceRefresh || fancyCell.Index != num || !fancyCell.IsVisible)
					{
						fancyCell.Index = num;
						fancyCell.SetVisible(true);
						fancyCell.UpdateContent(this.ItemsSource[num]);
					}
					fancyCell.UpdatePosition(num2);
				}
			}
		}

		// Token: 0x0600037D RID: 893 RVA: 0x00016AE8 File Offset: 0x00014CE8
		private int CircularIndex(int i, int size)
		{
			if (size < 1)
			{
				return 0;
			}
			if (i >= 0)
			{
				return i % size;
			}
			return size - 1 + (i + 1) % size;
		}

		// Token: 0x040002CA RID: 714
		[SerializeField]
		[Range(0.01f, 1f)]
		protected float cellInterval = 0.2f;

		// Token: 0x040002CB RID: 715
		[SerializeField]
		[Range(0f, 1f)]
		protected float scrollOffset = 0.5f;

		// Token: 0x040002CC RID: 716
		[SerializeField]
		protected bool loop;

		// Token: 0x040002CD RID: 717
		[SerializeField]
		protected Transform cellContainer;

		// Token: 0x040002CE RID: 718
		private readonly IList<FancyCell<TItemData, TContext>> pool = new List<FancyCell<TItemData, TContext>>();

		// Token: 0x040002CF RID: 719
		protected bool initialized;

		// Token: 0x040002D0 RID: 720
		protected float currentPosition;
	}
}
