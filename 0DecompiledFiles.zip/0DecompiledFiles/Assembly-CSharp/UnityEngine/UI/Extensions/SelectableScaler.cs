﻿using System;
using System.Collections;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000BC RID: 188
	[AddComponentMenu("UI/Extensions/Selectable Scalar")]
	[RequireComponent(typeof(Button))]
	public class SelectableScaler : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler
	{
		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000630 RID: 1584 RVA: 0x000248CB File Offset: 0x00022ACB
		public Selectable Target
		{
			get
			{
				if (this.selectable == null)
				{
					this.selectable = base.GetComponent<Selectable>();
				}
				return this.selectable;
			}
		}

		// Token: 0x06000631 RID: 1585 RVA: 0x000248ED File Offset: 0x00022AED
		private void Awake()
		{
			if (this.target == null)
			{
				this.target = base.transform;
			}
			this.initScale = this.target.localScale;
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0002491A File Offset: 0x00022B1A
		private void OnEnable()
		{
			this.target.localScale = this.initScale;
		}

		// Token: 0x06000633 RID: 1587 RVA: 0x0002492D File Offset: 0x00022B2D
		public void OnPointerDown(PointerEventData eventData)
		{
			if (this.Target != null && !this.Target.interactable)
			{
				return;
			}
			base.StopCoroutine("ScaleOUT");
			base.StartCoroutine("ScaleIN");
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x00024962 File Offset: 0x00022B62
		public void OnPointerUp(PointerEventData eventData)
		{
			if (this.Target != null && !this.Target.interactable)
			{
				return;
			}
			base.StopCoroutine("ScaleIN");
			base.StartCoroutine("ScaleOUT");
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x00024997 File Offset: 0x00022B97
		private IEnumerator ScaleIN()
		{
			if (this.animCurve.keys.Length != 0)
			{
				this.target.localScale = this.initScale;
				float t = 0f;
				float maxT = this.animCurve.keys[this.animCurve.length - 1].time;
				while (t < maxT)
				{
					t += this.speed * Time.unscaledDeltaTime;
					this.target.localScale = Vector3.one * this.animCurve.Evaluate(t);
					yield return null;
				}
			}
			yield break;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x000249A6 File Offset: 0x00022BA6
		private IEnumerator ScaleOUT()
		{
			if (this.animCurve.keys.Length != 0)
			{
				float t = 0f;
				float maxT = this.animCurve.keys[this.animCurve.length - 1].time;
				while (t < maxT)
				{
					t += this.speed * Time.unscaledDeltaTime;
					this.target.localScale = Vector3.one * this.animCurve.Evaluate(maxT - t);
					yield return null;
				}
				base.transform.localScale = this.initScale;
			}
			yield break;
		}

		// Token: 0x04000483 RID: 1155
		public AnimationCurve animCurve;

		// Token: 0x04000484 RID: 1156
		[Tooltip("Animation speed multiplier")]
		public float speed = 1f;

		// Token: 0x04000485 RID: 1157
		private Vector3 initScale;

		// Token: 0x04000486 RID: 1158
		public Transform target;

		// Token: 0x04000487 RID: 1159
		private Selectable selectable;
	}
}
