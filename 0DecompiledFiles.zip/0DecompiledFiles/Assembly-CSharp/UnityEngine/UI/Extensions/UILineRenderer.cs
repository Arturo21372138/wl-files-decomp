﻿using System;
using System.Collections.Generic;
using UnityEngine.Sprites;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200009D RID: 157
	[AddComponentMenu("UI/Extensions/Primitives/UILineRenderer")]
	[RequireComponent(typeof(RectTransform))]
	public class UILineRenderer : UIPrimitiveBase
	{
		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000520 RID: 1312 RVA: 0x0001E2CD File Offset: 0x0001C4CD
		// (set) Token: 0x06000521 RID: 1313 RVA: 0x0001E2D5 File Offset: 0x0001C4D5
		public float LineThickness
		{
			get
			{
				return this.lineThickness;
			}
			set
			{
				this.lineThickness = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000522 RID: 1314 RVA: 0x0001E2E4 File Offset: 0x0001C4E4
		// (set) Token: 0x06000523 RID: 1315 RVA: 0x0001E2EC File Offset: 0x0001C4EC
		public bool RelativeSize
		{
			get
			{
				return this.relativeSize;
			}
			set
			{
				this.relativeSize = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000524 RID: 1316 RVA: 0x0001E2FB File Offset: 0x0001C4FB
		// (set) Token: 0x06000525 RID: 1317 RVA: 0x0001E303 File Offset: 0x0001C503
		public bool LineList
		{
			get
			{
				return this.lineList;
			}
			set
			{
				this.lineList = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x06000526 RID: 1318 RVA: 0x0001E312 File Offset: 0x0001C512
		// (set) Token: 0x06000527 RID: 1319 RVA: 0x0001E31A File Offset: 0x0001C51A
		public bool LineCaps
		{
			get
			{
				return this.lineCaps;
			}
			set
			{
				this.lineCaps = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x06000528 RID: 1320 RVA: 0x0001E329 File Offset: 0x0001C529
		// (set) Token: 0x06000529 RID: 1321 RVA: 0x0001E331 File Offset: 0x0001C531
		public int BezierSegmentsPerCurve
		{
			get
			{
				return this.bezierSegmentsPerCurve;
			}
			set
			{
				this.bezierSegmentsPerCurve = value;
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x0600052A RID: 1322 RVA: 0x0001E33A File Offset: 0x0001C53A
		// (set) Token: 0x0600052B RID: 1323 RVA: 0x0001E342 File Offset: 0x0001C542
		public Vector2[] Points
		{
			get
			{
				return this.m_points;
			}
			set
			{
				if (this.m_points == value)
				{
					return;
				}
				this.m_points = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x0600052C RID: 1324 RVA: 0x0001E35B File Offset: 0x0001C55B
		// (set) Token: 0x0600052D RID: 1325 RVA: 0x0001E363 File Offset: 0x0001C563
		public List<Vector2[]> Segments
		{
			get
			{
				return this.m_segments;
			}
			set
			{
				this.m_segments = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x0001E374 File Offset: 0x0001C574
		private void PopulateMesh(VertexHelper vh, Vector2[] pointsToDraw)
		{
			if (this.BezierMode != UILineRenderer.BezierType.None && this.BezierMode != UILineRenderer.BezierType.Catenary && pointsToDraw.Length > 3)
			{
				BezierPath bezierPath = new BezierPath();
				bezierPath.SetControlPoints(pointsToDraw);
				bezierPath.SegmentsPerCurve = this.bezierSegmentsPerCurve;
				UILineRenderer.BezierType bezierMode = this.BezierMode;
				List<Vector2> list;
				if (bezierMode != UILineRenderer.BezierType.Basic)
				{
					if (bezierMode != UILineRenderer.BezierType.Improved)
					{
						list = bezierPath.GetDrawingPoints2();
					}
					else
					{
						list = bezierPath.GetDrawingPoints1();
					}
				}
				else
				{
					list = bezierPath.GetDrawingPoints0();
				}
				pointsToDraw = list.ToArray();
			}
			if (this.BezierMode == UILineRenderer.BezierType.Catenary && pointsToDraw.Length == 2)
			{
				pointsToDraw = new CableCurve(pointsToDraw)
				{
					slack = base.Resolution,
					steps = this.BezierSegmentsPerCurve
				}.Points();
			}
			if (base.ImproveResolution != ResolutionMode.None)
			{
				pointsToDraw = base.IncreaseResolution(pointsToDraw);
			}
			float num = ((!this.relativeSize) ? 1f : base.rectTransform.rect.width);
			float num2 = ((!this.relativeSize) ? 1f : base.rectTransform.rect.height);
			float num3 = -base.rectTransform.pivot.x * num;
			float num4 = -base.rectTransform.pivot.y * num2;
			List<UIVertex[]> list2 = new List<UIVertex[]>();
			if (this.lineList)
			{
				for (int i = 1; i < pointsToDraw.Length; i += 2)
				{
					Vector2 vector = pointsToDraw[i - 1];
					Vector2 vector2 = pointsToDraw[i];
					vector = new Vector2(vector.x * num + num3, vector.y * num2 + num4);
					vector2 = new Vector2(vector2.x * num + num3, vector2.y * num2 + num4);
					if (this.lineCaps)
					{
						list2.Add(this.CreateLineCap(vector, vector2, UILineRenderer.SegmentType.Start));
					}
					list2.Add(this.CreateLineSegment(vector, vector2, UILineRenderer.SegmentType.Middle, (list2.Count > 1) ? list2[list2.Count - 2] : null));
					if (this.lineCaps)
					{
						list2.Add(this.CreateLineCap(vector, vector2, UILineRenderer.SegmentType.End));
					}
				}
			}
			else
			{
				for (int j = 1; j < pointsToDraw.Length; j++)
				{
					Vector2 vector3 = pointsToDraw[j - 1];
					Vector2 vector4 = pointsToDraw[j];
					vector3 = new Vector2(vector3.x * num + num3, vector3.y * num2 + num4);
					vector4 = new Vector2(vector4.x * num + num3, vector4.y * num2 + num4);
					if (this.lineCaps && j == 1)
					{
						list2.Add(this.CreateLineCap(vector3, vector4, UILineRenderer.SegmentType.Start));
					}
					list2.Add(this.CreateLineSegment(vector3, vector4, UILineRenderer.SegmentType.Middle, null));
					if (this.lineCaps && j == pointsToDraw.Length - 1)
					{
						list2.Add(this.CreateLineCap(vector3, vector4, UILineRenderer.SegmentType.End));
					}
				}
			}
			for (int k = 0; k < list2.Count; k++)
			{
				if (!this.lineList && k < list2.Count - 1)
				{
					Vector3 vector5 = list2[k][1].position - list2[k][2].position;
					Vector3 vector6 = list2[k + 1][2].position - list2[k + 1][1].position;
					float num5 = Vector2.Angle(vector5, vector6) * 0.017453292f;
					float num6 = Mathf.Sign(Vector3.Cross(vector5.normalized, vector6.normalized).z);
					float num7 = this.lineThickness / (2f * Mathf.Tan(num5 / 2f));
					Vector3 vector7 = list2[k][2].position - vector5.normalized * num7 * num6;
					Vector3 vector8 = list2[k][3].position + vector5.normalized * num7 * num6;
					UILineRenderer.JoinType joinType = this.LineJoins;
					if (joinType == UILineRenderer.JoinType.Miter)
					{
						if (num7 < vector5.magnitude / 2f && num7 < vector6.magnitude / 2f && num5 > 0.2617994f)
						{
							list2[k][2].position = vector7;
							list2[k][3].position = vector8;
							list2[k + 1][0].position = vector8;
							list2[k + 1][1].position = vector7;
						}
						else
						{
							joinType = UILineRenderer.JoinType.Bevel;
						}
					}
					if (joinType == UILineRenderer.JoinType.Bevel)
					{
						if (num7 < vector5.magnitude / 2f && num7 < vector6.magnitude / 2f && num5 > 0.5235988f)
						{
							if (num6 < 0f)
							{
								list2[k][2].position = vector7;
								list2[k + 1][1].position = vector7;
							}
							else
							{
								list2[k][3].position = vector8;
								list2[k + 1][0].position = vector8;
							}
						}
						UIVertex[] array = new UIVertex[]
						{
							list2[k][2],
							list2[k][3],
							list2[k + 1][0],
							list2[k + 1][1]
						};
						vh.AddUIVertexQuad(array);
					}
				}
				vh.AddUIVertexQuad(list2[k]);
			}
			if (vh.currentVertCount > 64000)
			{
				Debug.LogError("Max Verticies size is 64000, current mesh verticies count is [" + vh.currentVertCount.ToString() + "] - Cannot Draw");
				vh.Clear();
				return;
			}
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x0001E980 File Offset: 0x0001CB80
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			if (this.m_points != null && this.m_points.Length != 0)
			{
				this.GeneratedUVs();
				vh.Clear();
				this.PopulateMesh(vh, this.m_points);
				return;
			}
			if (this.m_segments != null && this.m_segments.Count > 0)
			{
				this.GeneratedUVs();
				vh.Clear();
				for (int i = 0; i < this.m_segments.Count; i++)
				{
					Vector2[] array = this.m_segments[i];
					this.PopulateMesh(vh, array);
				}
			}
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x0001EA08 File Offset: 0x0001CC08
		private UIVertex[] CreateLineCap(Vector2 start, Vector2 end, UILineRenderer.SegmentType type)
		{
			if (type == UILineRenderer.SegmentType.Start)
			{
				Vector2 vector = start - (end - start).normalized * this.lineThickness / 2f;
				return this.CreateLineSegment(vector, start, UILineRenderer.SegmentType.Start, null);
			}
			if (type == UILineRenderer.SegmentType.End)
			{
				Vector2 vector2 = end + (end - start).normalized * this.lineThickness / 2f;
				return this.CreateLineSegment(end, vector2, UILineRenderer.SegmentType.End, null);
			}
			Debug.LogError("Bad SegmentType passed in to CreateLineCap. Must be SegmentType.Start or SegmentType.End");
			return null;
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x0001EA94 File Offset: 0x0001CC94
		private UIVertex[] CreateLineSegment(Vector2 start, Vector2 end, UILineRenderer.SegmentType type, UIVertex[] previousVert = null)
		{
			Vector2 vector = new Vector2(start.y - end.y, end.x - start.x).normalized * this.lineThickness / 2f;
			Vector2 vector2 = Vector2.zero;
			Vector2 vector3 = Vector2.zero;
			if (previousVert != null)
			{
				vector2 = new Vector2(previousVert[3].position.x, previousVert[3].position.y);
				vector3 = new Vector2(previousVert[2].position.x, previousVert[2].position.y);
			}
			else
			{
				vector2 = start - vector;
				vector3 = start + vector;
			}
			Vector2 vector4 = end + vector;
			Vector2 vector5 = end - vector;
			switch (type)
			{
			case UILineRenderer.SegmentType.Start:
				return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRenderer.startUvs);
			case UILineRenderer.SegmentType.End:
				return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRenderer.endUvs);
			case UILineRenderer.SegmentType.Full:
				return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRenderer.fullUvs);
			}
			return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRenderer.middleUvs);
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0001EC50 File Offset: 0x0001CE50
		protected override void GeneratedUVs()
		{
			if (base.activeSprite != null)
			{
				Vector4 outerUV = DataUtility.GetOuterUV(base.activeSprite);
				Vector4 innerUV = DataUtility.GetInnerUV(base.activeSprite);
				UILineRenderer.UV_TOP_LEFT = new Vector2(outerUV.x, outerUV.y);
				UILineRenderer.UV_BOTTOM_LEFT = new Vector2(outerUV.x, outerUV.w);
				UILineRenderer.UV_TOP_CENTER_LEFT = new Vector2(innerUV.x, innerUV.y);
				UILineRenderer.UV_TOP_CENTER_RIGHT = new Vector2(innerUV.z, innerUV.y);
				UILineRenderer.UV_BOTTOM_CENTER_LEFT = new Vector2(innerUV.x, innerUV.w);
				UILineRenderer.UV_BOTTOM_CENTER_RIGHT = new Vector2(innerUV.z, innerUV.w);
				UILineRenderer.UV_TOP_RIGHT = new Vector2(outerUV.z, outerUV.y);
				UILineRenderer.UV_BOTTOM_RIGHT = new Vector2(outerUV.z, outerUV.w);
			}
			else
			{
				UILineRenderer.UV_TOP_LEFT = Vector2.zero;
				UILineRenderer.UV_BOTTOM_LEFT = new Vector2(0f, 1f);
				UILineRenderer.UV_TOP_CENTER_LEFT = new Vector2(0.5f, 0f);
				UILineRenderer.UV_TOP_CENTER_RIGHT = new Vector2(0.5f, 0f);
				UILineRenderer.UV_BOTTOM_CENTER_LEFT = new Vector2(0.5f, 1f);
				UILineRenderer.UV_BOTTOM_CENTER_RIGHT = new Vector2(0.5f, 1f);
				UILineRenderer.UV_TOP_RIGHT = new Vector2(1f, 0f);
				UILineRenderer.UV_BOTTOM_RIGHT = Vector2.one;
			}
			UILineRenderer.startUvs = new Vector2[]
			{
				UILineRenderer.UV_TOP_LEFT,
				UILineRenderer.UV_BOTTOM_LEFT,
				UILineRenderer.UV_BOTTOM_CENTER_LEFT,
				UILineRenderer.UV_TOP_CENTER_LEFT
			};
			UILineRenderer.middleUvs = new Vector2[]
			{
				UILineRenderer.UV_TOP_CENTER_LEFT,
				UILineRenderer.UV_BOTTOM_CENTER_LEFT,
				UILineRenderer.UV_BOTTOM_CENTER_RIGHT,
				UILineRenderer.UV_TOP_CENTER_RIGHT
			};
			UILineRenderer.endUvs = new Vector2[]
			{
				UILineRenderer.UV_TOP_CENTER_RIGHT,
				UILineRenderer.UV_BOTTOM_CENTER_RIGHT,
				UILineRenderer.UV_BOTTOM_RIGHT,
				UILineRenderer.UV_TOP_RIGHT
			};
			UILineRenderer.fullUvs = new Vector2[]
			{
				UILineRenderer.UV_TOP_LEFT,
				UILineRenderer.UV_BOTTOM_LEFT,
				UILineRenderer.UV_BOTTOM_RIGHT,
				UILineRenderer.UV_TOP_RIGHT
			};
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0001EEB4 File Offset: 0x0001D0B4
		protected override void ResolutionToNativeSize(float distance)
		{
			if (base.UseNativeSize)
			{
				this.m_Resolution = distance / (base.activeSprite.rect.width / base.pixelsPerUnit);
				this.lineThickness = base.activeSprite.rect.height / base.pixelsPerUnit;
			}
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0001EF0C File Offset: 0x0001D10C
		private int GetSegmentPointCount()
		{
			List<Vector2[]> segments = this.Segments;
			if (segments != null && segments.Count > 0)
			{
				int num = 0;
				foreach (Vector2[] array in this.Segments)
				{
					num += array.Length;
				}
				return num;
			}
			return this.Points.Length;
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0001EF84 File Offset: 0x0001D184
		public Vector2 GetPosition(int index, int segmentIndex = 0)
		{
			if (segmentIndex > 0)
			{
				return this.Segments[segmentIndex - 1][index - 1];
			}
			if (this.Segments.Count > 0)
			{
				int num = 0;
				int num2 = index;
				foreach (Vector2[] array in this.Segments)
				{
					if (num2 - array.Length <= 0)
					{
						break;
					}
					num2 -= array.Length;
					num++;
				}
				return this.Segments[num][num2 - 1];
			}
			return this.Points[index - 1];
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x0001F034 File Offset: 0x0001D234
		public Vector2 GetPositionBySegment(int index, int segment)
		{
			return this.Segments[segment][index - 1];
		}

		// Token: 0x06000537 RID: 1335 RVA: 0x0001F04C File Offset: 0x0001D24C
		public Vector2 GetClosestPoint(Vector2 p1, Vector2 p2, Vector2 p3)
		{
			Vector2 vector = p3 - p1;
			Vector2 vector2 = p2 - p1;
			float num = Mathf.Clamp01(Vector2.Dot(vector, vector2.normalized) / vector2.magnitude);
			return p1 + vector2 * num;
		}

		// Token: 0x040003BD RID: 957
		private const float MIN_MITER_JOIN = 0.2617994f;

		// Token: 0x040003BE RID: 958
		private const float MIN_BEVEL_NICE_JOIN = 0.5235988f;

		// Token: 0x040003BF RID: 959
		private static Vector2 UV_TOP_LEFT;

		// Token: 0x040003C0 RID: 960
		private static Vector2 UV_BOTTOM_LEFT;

		// Token: 0x040003C1 RID: 961
		private static Vector2 UV_TOP_CENTER_LEFT;

		// Token: 0x040003C2 RID: 962
		private static Vector2 UV_TOP_CENTER_RIGHT;

		// Token: 0x040003C3 RID: 963
		private static Vector2 UV_BOTTOM_CENTER_LEFT;

		// Token: 0x040003C4 RID: 964
		private static Vector2 UV_BOTTOM_CENTER_RIGHT;

		// Token: 0x040003C5 RID: 965
		private static Vector2 UV_TOP_RIGHT;

		// Token: 0x040003C6 RID: 966
		private static Vector2 UV_BOTTOM_RIGHT;

		// Token: 0x040003C7 RID: 967
		private static Vector2[] startUvs;

		// Token: 0x040003C8 RID: 968
		private static Vector2[] middleUvs;

		// Token: 0x040003C9 RID: 969
		private static Vector2[] endUvs;

		// Token: 0x040003CA RID: 970
		private static Vector2[] fullUvs;

		// Token: 0x040003CB RID: 971
		[SerializeField]
		[Tooltip("Points to draw lines between\n Can be improved using the Resolution Option")]
		internal Vector2[] m_points;

		// Token: 0x040003CC RID: 972
		[SerializeField]
		[Tooltip("Segments to be drawn\n This is a list of arrays of points")]
		internal List<Vector2[]> m_segments;

		// Token: 0x040003CD RID: 973
		[SerializeField]
		[Tooltip("Thickness of the line")]
		internal float lineThickness = 2f;

		// Token: 0x040003CE RID: 974
		[SerializeField]
		[Tooltip("Use the relative bounds of the Rect Transform (0,0 -> 0,1) or screen space coordinates")]
		internal bool relativeSize;

		// Token: 0x040003CF RID: 975
		[SerializeField]
		[Tooltip("Do the points identify a single line or split pairs of lines")]
		internal bool lineList;

		// Token: 0x040003D0 RID: 976
		[SerializeField]
		[Tooltip("Add end caps to each line\nMultiple caps when used with Line List")]
		internal bool lineCaps;

		// Token: 0x040003D1 RID: 977
		[SerializeField]
		[Tooltip("Resolution of the Bezier curve, different to line Resolution")]
		internal int bezierSegmentsPerCurve = 10;

		// Token: 0x040003D2 RID: 978
		[Tooltip("The type of Join used between lines, Square/Mitre or Curved/Bevel")]
		public UILineRenderer.JoinType LineJoins;

		// Token: 0x040003D3 RID: 979
		[Tooltip("Bezier method to apply to line, see docs for options\nCan't be used in conjunction with Resolution as Bezier already changes the resolution")]
		public UILineRenderer.BezierType BezierMode;

		// Token: 0x040003D4 RID: 980
		[HideInInspector]
		public bool drivenExternally;

		// Token: 0x02000141 RID: 321
		private enum SegmentType
		{
			// Token: 0x04000691 RID: 1681
			Start,
			// Token: 0x04000692 RID: 1682
			Middle,
			// Token: 0x04000693 RID: 1683
			End,
			// Token: 0x04000694 RID: 1684
			Full
		}

		// Token: 0x02000142 RID: 322
		public enum JoinType
		{
			// Token: 0x04000696 RID: 1686
			Bevel,
			// Token: 0x04000697 RID: 1687
			Miter
		}

		// Token: 0x02000143 RID: 323
		public enum BezierType
		{
			// Token: 0x04000699 RID: 1689
			None,
			// Token: 0x0400069A RID: 1690
			Quick,
			// Token: 0x0400069B RID: 1691
			Basic,
			// Token: 0x0400069C RID: 1692
			Improved,
			// Token: 0x0400069D RID: 1693
			Catenary
		}
	}
}
