﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000058 RID: 88
	[AddComponentMenu("UI/Effects/Extensions/Gradient2")]
	public class Gradient2 : BaseMeshEffect
	{
		// Token: 0x17000073 RID: 115
		// (get) Token: 0x060002AE RID: 686 RVA: 0x0001023E File Offset: 0x0000E43E
		// (set) Token: 0x060002AF RID: 687 RVA: 0x00010246 File Offset: 0x0000E446
		public Gradient2.Blend BlendMode
		{
			get
			{
				return this._blendMode;
			}
			set
			{
				this._blendMode = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x060002B0 RID: 688 RVA: 0x0001025A File Offset: 0x0000E45A
		// (set) Token: 0x060002B1 RID: 689 RVA: 0x00010262 File Offset: 0x0000E462
		public Gradient EffectGradient
		{
			get
			{
				return this._effectGradient;
			}
			set
			{
				this._effectGradient = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060002B2 RID: 690 RVA: 0x00010276 File Offset: 0x0000E476
		// (set) Token: 0x060002B3 RID: 691 RVA: 0x0001027E File Offset: 0x0000E47E
		public Gradient2.Type GradientType
		{
			get
			{
				return this._gradientType;
			}
			set
			{
				this._gradientType = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060002B4 RID: 692 RVA: 0x00010292 File Offset: 0x0000E492
		// (set) Token: 0x060002B5 RID: 693 RVA: 0x0001029A File Offset: 0x0000E49A
		public bool ModifyVertices
		{
			get
			{
				return this._modifyVertices;
			}
			set
			{
				this._modifyVertices = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x000102AE File Offset: 0x0000E4AE
		// (set) Token: 0x060002B7 RID: 695 RVA: 0x000102B6 File Offset: 0x0000E4B6
		public float Offset
		{
			get
			{
				return this._offset;
			}
			set
			{
				this._offset = Mathf.Clamp(value, -1f, 1f);
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x000102D9 File Offset: 0x0000E4D9
		// (set) Token: 0x060002B9 RID: 697 RVA: 0x000102E1 File Offset: 0x0000E4E1
		public float Zoom
		{
			get
			{
				return this._zoom;
			}
			set
			{
				this._zoom = Mathf.Clamp(value, 0.1f, 10f);
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x060002BA RID: 698 RVA: 0x00010304 File Offset: 0x0000E504
		public override void ModifyMesh(VertexHelper helper)
		{
			if (!this.IsActive() || helper.currentVertCount == 0)
			{
				return;
			}
			List<UIVertex> list = new List<UIVertex>();
			helper.GetUIVertexStream(list);
			int count = list.Count;
			switch (this.GradientType)
			{
			case Gradient2.Type.Horizontal:
			case Gradient2.Type.Vertical:
			{
				Rect bounds = this.GetBounds(list);
				float num = bounds.xMin;
				float num2 = bounds.width;
				Func<UIVertex, float> func = (UIVertex v) => v.position.x;
				if (this.GradientType == Gradient2.Type.Vertical)
				{
					num = bounds.yMin;
					num2 = bounds.height;
					func = (UIVertex v) => v.position.y;
				}
				float num3 = ((num2 == 0f) ? 0f : (1f / num2 / this.Zoom));
				float num4 = (1f - 1f / this.Zoom) * 0.5f;
				float num5 = this.Offset * (1f - num4) - num4;
				if (this.ModifyVertices)
				{
					this.SplitTrianglesAtGradientStops(list, bounds, num4, helper);
				}
				UIVertex uivertex = default(UIVertex);
				for (int i = 0; i < helper.currentVertCount; i++)
				{
					helper.PopulateUIVertex(ref uivertex, i);
					uivertex.color = this.BlendColor(uivertex.color, this.EffectGradient.Evaluate((func(uivertex) - num) * num3 - num5));
					helper.SetUIVertex(uivertex, i);
				}
				return;
			}
			case Gradient2.Type.Radial:
			{
				Rect bounds2 = this.GetBounds(list);
				float num6 = ((bounds2.width == 0f) ? 0f : (1f / bounds2.width / this.Zoom));
				float num7 = ((bounds2.height == 0f) ? 0f : (1f / bounds2.height / this.Zoom));
				if (this.ModifyVertices)
				{
					helper.Clear();
					float num8 = bounds2.width / 2f;
					float num9 = bounds2.height / 2f;
					UIVertex uivertex2 = default(UIVertex);
					uivertex2.position = Vector3.right * bounds2.center.x + Vector3.up * bounds2.center.y + Vector3.forward * list[0].position.z;
					uivertex2.normal = list[0].normal;
					uivertex2.uv0 = new Vector2(0.5f, 0.5f);
					uivertex2.color = Color.white;
					int num10 = 64;
					for (int j = 0; j < num10; j++)
					{
						UIVertex uivertex3 = default(UIVertex);
						float num11 = (float)j * 360f / (float)num10;
						float num12 = Mathf.Cos(0.017453292f * num11);
						float num13 = Mathf.Sin(0.017453292f * num11);
						uivertex3.position = Vector3.right * num12 * num8 + Vector3.up * num13 * num9 + Vector3.forward * list[0].position.z;
						uivertex3.normal = list[0].normal;
						uivertex3.uv0 = new Vector2((num12 + 1f) * 0.5f, (num13 + 1f) * 0.5f);
						uivertex3.color = Color.white;
						helper.AddVert(uivertex3);
					}
					helper.AddVert(uivertex2);
					for (int k = 1; k < num10; k++)
					{
						helper.AddTriangle(k - 1, k, num10);
					}
					helper.AddTriangle(0, num10 - 1, num10);
				}
				UIVertex uivertex4 = default(UIVertex);
				for (int l = 0; l < helper.currentVertCount; l++)
				{
					helper.PopulateUIVertex(ref uivertex4, l);
					uivertex4.color = this.BlendColor(uivertex4.color, this.EffectGradient.Evaluate(Mathf.Sqrt(Mathf.Pow(Mathf.Abs(uivertex4.position.x - bounds2.center.x) * num6, 2f) + Mathf.Pow(Mathf.Abs(uivertex4.position.y - bounds2.center.y) * num7, 2f)) * 2f - this.Offset));
					helper.SetUIVertex(uivertex4, l);
				}
				return;
			}
			case Gradient2.Type.Diamond:
			{
				Rect bounds3 = this.GetBounds(list);
				float num14 = ((bounds3.height == 0f) ? 0f : (1f / bounds3.height / this.Zoom));
				float num15 = bounds3.center.y / 2f;
				Vector3 vector = (Vector3.right + Vector3.up) * num15 + Vector3.forward * list[0].position.z;
				if (this.ModifyVertices)
				{
					helper.Clear();
					for (int m = 0; m < count; m++)
					{
						helper.AddVert(list[m]);
					}
					helper.AddVert(new UIVertex
					{
						position = vector,
						normal = list[0].normal,
						uv0 = new Vector2(0.5f, 0.5f),
						color = Color.white
					});
					for (int n = 1; n < count; n++)
					{
						helper.AddTriangle(n - 1, n, count);
					}
					helper.AddTriangle(0, count - 1, count);
				}
				UIVertex uivertex5 = default(UIVertex);
				for (int num16 = 0; num16 < helper.currentVertCount; num16++)
				{
					helper.PopulateUIVertex(ref uivertex5, num16);
					uivertex5.color = this.BlendColor(uivertex5.color, this.EffectGradient.Evaluate(Vector3.Distance(uivertex5.position, vector) * num14 - this.Offset));
					helper.SetUIVertex(uivertex5, num16);
				}
				return;
			}
			default:
				return;
			}
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00010964 File Offset: 0x0000EB64
		private Rect GetBounds(List<UIVertex> vertices)
		{
			float num = vertices[0].position.x;
			float num2 = num;
			float num3 = vertices[0].position.y;
			float num4 = num3;
			for (int i = vertices.Count - 1; i >= 1; i--)
			{
				float x = vertices[i].position.x;
				float y = vertices[i].position.y;
				if (x > num2)
				{
					num2 = x;
				}
				else if (x < num)
				{
					num = x;
				}
				if (y > num4)
				{
					num4 = y;
				}
				else if (y < num3)
				{
					num3 = y;
				}
			}
			return new Rect(num, num3, num2 - num, num4 - num3);
		}

		// Token: 0x060002BC RID: 700 RVA: 0x00010A0C File Offset: 0x0000EC0C
		private void SplitTrianglesAtGradientStops(List<UIVertex> _vertexList, Rect bounds, float zoomOffset, VertexHelper helper)
		{
			List<float> list = this.FindStops(zoomOffset, bounds);
			if (list.Count > 0)
			{
				helper.Clear();
				int count = _vertexList.Count;
				for (int i = 0; i < count; i += 3)
				{
					float[] positions = this.GetPositions(_vertexList, i);
					List<int> list2 = new List<int>(3);
					List<UIVertex> list3 = new List<UIVertex>(3);
					List<UIVertex> list4 = new List<UIVertex>(2);
					for (int j = 0; j < list.Count; j++)
					{
						int currentVertCount = helper.currentVertCount;
						bool flag = list4.Count > 0;
						bool flag2 = false;
						for (int k = 0; k < 3; k++)
						{
							if (!list2.Contains(k) && positions[k] < list[j])
							{
								int num = (k + 1) % 3;
								UIVertex uivertex = _vertexList[k + i];
								if (positions[num] > list[j])
								{
									list2.Insert(0, k);
									list3.Insert(0, uivertex);
									flag2 = true;
								}
								else
								{
									list2.Add(k);
									list3.Add(uivertex);
								}
							}
						}
						if (list2.Count != 0)
						{
							if (list2.Count == 3)
							{
								break;
							}
							foreach (UIVertex uivertex2 in list3)
							{
								helper.AddVert(uivertex2);
							}
							list4.Clear();
							foreach (int num2 in list2)
							{
								int num3 = (num2 + 1) % 3;
								if (positions[num3] < list[j])
								{
									num3 = (num3 + 1) % 3;
								}
								list4.Add(this.CreateSplitVertex(_vertexList[num2 + i], _vertexList[num3 + i], list[j]));
							}
							if (list4.Count == 1)
							{
								int num4 = (list2[0] + 2) % 3;
								list4.Add(this.CreateSplitVertex(_vertexList[list2[0] + i], _vertexList[num4 + i], list[j]));
							}
							foreach (UIVertex uivertex3 in list4)
							{
								helper.AddVert(uivertex3);
							}
							if (flag)
							{
								helper.AddTriangle(currentVertCount - 2, currentVertCount, currentVertCount + 1);
								helper.AddTriangle(currentVertCount - 2, currentVertCount + 1, currentVertCount - 1);
								if (list3.Count > 0)
								{
									if (flag2)
									{
										helper.AddTriangle(currentVertCount - 2, currentVertCount + 3, currentVertCount);
									}
									else
									{
										helper.AddTriangle(currentVertCount + 1, currentVertCount + 3, currentVertCount - 1);
									}
								}
							}
							else
							{
								int currentVertCount2 = helper.currentVertCount;
								helper.AddTriangle(currentVertCount, currentVertCount2 - 2, currentVertCount2 - 1);
								if (list3.Count > 1)
								{
									helper.AddTriangle(currentVertCount, currentVertCount2 - 1, currentVertCount + 1);
								}
							}
							list3.Clear();
						}
					}
					if (list4.Count > 0)
					{
						if (list3.Count == 0)
						{
							for (int l = 0; l < 3; l++)
							{
								if (!list2.Contains(l) && positions[l] > list[list.Count - 1])
								{
									int num5 = (l + 1) % 3;
									UIVertex uivertex4 = _vertexList[l + i];
									if (positions[num5] > list[list.Count - 1])
									{
										list3.Insert(0, uivertex4);
									}
									else
									{
										list3.Add(uivertex4);
									}
								}
							}
						}
						foreach (UIVertex uivertex5 in list3)
						{
							helper.AddVert(uivertex5);
						}
						int currentVertCount3 = helper.currentVertCount;
						if (list3.Count > 1)
						{
							helper.AddTriangle(currentVertCount3 - 4, currentVertCount3 - 2, currentVertCount3 - 1);
							helper.AddTriangle(currentVertCount3 - 4, currentVertCount3 - 1, currentVertCount3 - 3);
						}
						else if (list3.Count > 0)
						{
							helper.AddTriangle(currentVertCount3 - 3, currentVertCount3 - 1, currentVertCount3 - 2);
						}
					}
					else
					{
						helper.AddVert(_vertexList[i]);
						helper.AddVert(_vertexList[i + 1]);
						helper.AddVert(_vertexList[i + 2]);
						int currentVertCount4 = helper.currentVertCount;
						helper.AddTriangle(currentVertCount4 - 3, currentVertCount4 - 2, currentVertCount4 - 1);
					}
				}
			}
		}

		// Token: 0x060002BD RID: 701 RVA: 0x00010E8C File Offset: 0x0000F08C
		private float[] GetPositions(List<UIVertex> _vertexList, int index)
		{
			float[] array = new float[3];
			if (this.GradientType == Gradient2.Type.Horizontal)
			{
				array[0] = _vertexList[index].position.x;
				array[1] = _vertexList[index + 1].position.x;
				array[2] = _vertexList[index + 2].position.x;
			}
			else
			{
				array[0] = _vertexList[index].position.y;
				array[1] = _vertexList[index + 1].position.y;
				array[2] = _vertexList[index + 2].position.y;
			}
			return array;
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00010F2C File Offset: 0x0000F12C
		private List<float> FindStops(float zoomOffset, Rect bounds)
		{
			List<float> list = new List<float>();
			float num = this.Offset * (1f - zoomOffset);
			float num2 = zoomOffset - num;
			float num3 = 1f - zoomOffset - num;
			foreach (GradientColorKey gradientColorKey in this.EffectGradient.colorKeys)
			{
				if (gradientColorKey.time >= num3)
				{
					break;
				}
				if (gradientColorKey.time > num2)
				{
					list.Add((gradientColorKey.time - num2) * this.Zoom);
				}
			}
			foreach (GradientAlphaKey gradientAlphaKey in this.EffectGradient.alphaKeys)
			{
				if (gradientAlphaKey.time >= num3)
				{
					break;
				}
				if (gradientAlphaKey.time > num2)
				{
					list.Add((gradientAlphaKey.time - num2) * this.Zoom);
				}
			}
			float num4 = bounds.xMin;
			float num5 = bounds.width;
			if (this.GradientType == Gradient2.Type.Vertical)
			{
				num4 = bounds.yMin;
				num5 = bounds.height;
			}
			list.Sort();
			for (int j = 0; j < list.Count; j++)
			{
				list[j] = list[j] * num5 + num4;
				if (j > 0 && Math.Abs(list[j] - list[j - 1]) < 2f)
				{
					list.RemoveAt(j);
					j--;
				}
			}
			return list;
		}

		// Token: 0x060002BF RID: 703 RVA: 0x00011098 File Offset: 0x0000F298
		private UIVertex CreateSplitVertex(UIVertex vertex1, UIVertex vertex2, float stop)
		{
			if (this.GradientType == Gradient2.Type.Horizontal)
			{
				float num = vertex1.position.x - stop;
				float num2 = vertex1.position.x - vertex2.position.x;
				float num3 = vertex1.position.y - vertex2.position.y;
				float num4 = vertex1.uv0.x - vertex2.uv0.x;
				float num5 = vertex1.uv0.y - vertex2.uv0.y;
				float num6 = num / num2;
				float num7 = vertex1.position.y - num3 * num6;
				return new UIVertex
				{
					position = new Vector3(stop, num7, vertex1.position.z),
					normal = vertex1.normal,
					uv0 = new Vector2(vertex1.uv0.x - num4 * num6, vertex1.uv0.y - num5 * num6),
					color = Color.white
				};
			}
			float num8 = vertex1.position.y - stop;
			float num9 = vertex1.position.y - vertex2.position.y;
			float num10 = vertex1.position.x - vertex2.position.x;
			float num11 = vertex1.uv0.x - vertex2.uv0.x;
			float num12 = vertex1.uv0.y - vertex2.uv0.y;
			float num13 = num8 / num9;
			float num14 = vertex1.position.x - num10 * num13;
			return new UIVertex
			{
				position = new Vector3(num14, stop, vertex1.position.z),
				normal = vertex1.normal,
				uv0 = new Vector2(vertex1.uv0.x - num11 * num13, vertex1.uv0.y - num12 * num13),
				color = Color.white
			};
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x000112A8 File Offset: 0x0000F4A8
		private Color BlendColor(Color colorA, Color colorB)
		{
			Gradient2.Blend blendMode = this.BlendMode;
			if (blendMode == Gradient2.Blend.Add)
			{
				return colorA + colorB;
			}
			if (blendMode != Gradient2.Blend.Multiply)
			{
				return colorB;
			}
			return colorA * colorB;
		}

		// Token: 0x04000227 RID: 551
		[SerializeField]
		private Gradient2.Type _gradientType;

		// Token: 0x04000228 RID: 552
		[SerializeField]
		private Gradient2.Blend _blendMode = Gradient2.Blend.Multiply;

		// Token: 0x04000229 RID: 553
		[SerializeField]
		[Tooltip("Add vertices to display complex gradients. Turn off if your shape is already very complex, like text.")]
		private bool _modifyVertices = true;

		// Token: 0x0400022A RID: 554
		[SerializeField]
		[Range(-1f, 1f)]
		private float _offset;

		// Token: 0x0400022B RID: 555
		[SerializeField]
		[Range(0.1f, 10f)]
		private float _zoom = 1f;

		// Token: 0x0400022C RID: 556
		[SerializeField]
		private Gradient _effectGradient = new Gradient
		{
			colorKeys = new GradientColorKey[]
			{
				new GradientColorKey(Color.black, 0f),
				new GradientColorKey(Color.white, 1f)
			}
		};

		// Token: 0x02000124 RID: 292
		public enum Type
		{
			// Token: 0x04000649 RID: 1609
			Horizontal,
			// Token: 0x0400064A RID: 1610
			Vertical,
			// Token: 0x0400064B RID: 1611
			Radial,
			// Token: 0x0400064C RID: 1612
			Diamond
		}

		// Token: 0x02000125 RID: 293
		public enum Blend
		{
			// Token: 0x0400064E RID: 1614
			Override,
			// Token: 0x0400064F RID: 1615
			Add,
			// Token: 0x04000650 RID: 1616
			Multiply
		}
	}
}
