﻿using System;
using UnityEngine;
using VisualDesignCafe.Rendering.Instancing;

namespace NatureRendererDemo
{
	// Token: 0x0200001A RID: 26
	[ExecuteAlways]
	public class UseReferenceCamera : MonoBehaviour
	{
		// Token: 0x06000043 RID: 67 RVA: 0x000039B2 File Offset: 0x00001BB2
		private void Start()
		{
			this._camera = base.GetComponent<Camera>();
		}

		// Token: 0x06000044 RID: 68 RVA: 0x000039C0 File Offset: 0x00001BC0
		private void Update()
		{
			this._delay--;
			if (this._delay <= 0)
			{
				CameraRenderer camera = RendererPool.GetCamera(CameraId.GetId(this._camera));
				if (camera != null && camera.ReferenceCamera != this._referenceCamera)
				{
					camera.SetReferenceCamera(this._referenceCamera);
				}
			}
		}

		// Token: 0x04000050 RID: 80
		[SerializeField]
		private Camera _referenceCamera;

		// Token: 0x04000051 RID: 81
		private Camera _camera;

		// Token: 0x04000052 RID: 82
		private int _delay = 1;
	}
}
