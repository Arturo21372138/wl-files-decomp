﻿using System;
using System.Collections;
using HawkNetworking;
using Rewired;
using UnityEngine;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;

// Token: 0x02000003 RID: 3
[DisallowMultipleComponent]
public abstract class ArcadeMachineGame : MonoBehaviour
{
	// Token: 0x06000007 RID: 7 RVA: 0x00002270 File Offset: 0x00000470
	private void Awake()
	{
		if (this.camera && this.intro)
		{
			Canvas component = this.intro.GetComponent<Canvas>();
			if (component)
			{
				component.worldCamera = this.camera;
			}
		}
		if (!HawkNetworkManager.DefaultInstance.IsConnected())
		{
			this.player = ReInput.players.GetPlayer(0);
			this.PreStartIntro(LocalPhysicsMode.None);
		}
		this.ArcadeAwake();
	}

	// Token: 0x06000008 RID: 8 RVA: 0x000022E1 File Offset: 0x000004E1
	protected virtual void ArcadeAwake()
	{
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000022E4 File Offset: 0x000004E4
	public void StartGame(ArcadeMachine arcadeMachine, global::PlayerController playerController, UIPlayerBasedArcadeMachineCanvas ui, SceneInstance sceneInstance, LocalPhysicsMode physicsMode)
	{
		this.arcadeMachine = arcadeMachine;
		this.playerController = playerController;
		this.sceneInstance = sceneInstance;
		if (playerController)
		{
			this.player = playerController.GetPlayerControllerInputManager().GetRewiredPlayer();
		}
		if (this.camera)
		{
			this.camera.cullingMask = LayerMask.GetMask(new string[] { "2DGames" });
		}
		if (this.renderTexture == null && this.camera)
		{
			this.renderTexture = new RenderTexture(this.pixelWidth, this.pixelHeight, 4);
			this.renderTexture.filterMode = FilterMode.Point;
			this.camera.targetTexture = this.renderTexture;
			if (ui)
			{
				ui.SetTextureDisplay(this.renderTexture);
			}
		}
		this.PreStartIntro(physicsMode);
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000023B8 File Offset: 0x000005B8
	private void PreStartIntro(LocalPhysicsMode physicsMode)
	{
		ArcadeMachineGame.<>c__DisplayClass12_0 CS$<>8__locals1 = new ArcadeMachineGame.<>c__DisplayClass12_0();
		CS$<>8__locals1.<>4__this = this;
		CS$<>8__locals1.physicsMode = physicsMode;
		base.StartCoroutine(CS$<>8__locals1.<PreStartIntro>g__Intro|0());
	}

	// Token: 0x0600000B RID: 11
	protected abstract void OnStartGame();

	// Token: 0x0600000C RID: 12 RVA: 0x000023E6 File Offset: 0x000005E6
	private IEnumerator UpdatePhysics(SceneInstance sceneInstance, LocalPhysicsMode physicsMode)
	{
		WaitForFixedUpdate forFixedUpdate = new WaitForFixedUpdate();
		if (physicsMode != LocalPhysicsMode.Physics2D)
		{
			if (physicsMode != LocalPhysicsMode.Physics3D)
			{
				if (sceneInstance.Scene.IsValid())
				{
					yield break;
				}
				for (;;)
				{
					yield return forFixedUpdate;
					Physics.Simulate(Time.fixedDeltaTime);
					Physics2D.Simulate(Time.fixedDeltaTime);
				}
			}
			else
			{
				for (;;)
				{
					yield return forFixedUpdate;
					sceneInstance.Scene.GetPhysicsScene().Simulate(Time.fixedDeltaTime);
				}
			}
		}
		else
		{
			for (;;)
			{
				yield return forFixedUpdate;
				sceneInstance.Scene.GetPhysicsScene2D().Simulate(Time.fixedDeltaTime);
			}
		}
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000023FC File Offset: 0x000005FC
	private void OnDestroy()
	{
		if (this.renderTexture)
		{
			this.renderTexture.Release();
			Object.Destroy(this.renderTexture);
			this.renderTexture = null;
		}
		this.OnDestroyGame();
	}

	// Token: 0x0600000E RID: 14
	protected abstract void OnDestroyGame();

	// Token: 0x0600000F RID: 15 RVA: 0x0000242E File Offset: 0x0000062E
	public global::PlayerController GetPlayerController()
	{
		return this.playerController;
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00002436 File Offset: 0x00000636
	public ArcadeMachine GetArcadeMachine()
	{
		return this.arcadeMachine;
	}

	// Token: 0x06000011 RID: 17 RVA: 0x0000243E File Offset: 0x0000063E
	public SceneInstance GetSceneInstance()
	{
		return this.sceneInstance;
	}

	// Token: 0x06000012 RID: 18 RVA: 0x00002446 File Offset: 0x00000646
	public Player GetPlayer()
	{
		return this.player;
	}

	// Token: 0x04000007 RID: 7
	[SerializeField]
	private Camera camera;

	// Token: 0x04000008 RID: 8
	[SerializeField]
	private int pixelWidth = 400;

	// Token: 0x04000009 RID: 9
	[SerializeField]
	private int pixelHeight = 400;

	// Token: 0x0400000A RID: 10
	[SerializeField]
	private ArcadeMachineIntro intro;

	// Token: 0x0400000B RID: 11
	private ArcadeMachine arcadeMachine;

	// Token: 0x0400000C RID: 12
	private global::PlayerController playerController;

	// Token: 0x0400000D RID: 13
	private RenderTexture renderTexture;

	// Token: 0x0400000E RID: 14
	private SceneInstance sceneInstance;

	// Token: 0x0400000F RID: 15
	private Player player;
}
