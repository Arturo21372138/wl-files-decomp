﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007ED RID: 2029
	public struct CopyUnlockedAchievementByAchievementIdOptions
	{
		// Token: 0x17000842 RID: 2114
		// (get) Token: 0x06002158 RID: 8536 RVA: 0x00027D3C File Offset: 0x00025F3C
		// (set) Token: 0x06002159 RID: 8537 RVA: 0x00027D44 File Offset: 0x00025F44
		public ProductUserId UserId { readonly get; set; }

		// Token: 0x17000843 RID: 2115
		// (get) Token: 0x0600215A RID: 8538 RVA: 0x00027D4D File Offset: 0x00025F4D
		// (set) Token: 0x0600215B RID: 8539 RVA: 0x00027D55 File Offset: 0x00025F55
		public Utf8String AchievementId { readonly get; set; }
	}
}
