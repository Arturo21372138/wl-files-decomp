﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E5 RID: 2021
	public struct CopyAchievementDefinitionV2ByAchievementIdOptions
	{
		// Token: 0x1700083A RID: 2106
		// (get) Token: 0x06002140 RID: 8512 RVA: 0x00027BA3 File Offset: 0x00025DA3
		// (set) Token: 0x06002141 RID: 8513 RVA: 0x00027BAB File Offset: 0x00025DAB
		public Utf8String AchievementId { readonly get; set; }
	}
}
