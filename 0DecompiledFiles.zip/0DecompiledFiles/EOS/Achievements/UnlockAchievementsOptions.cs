﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200081E RID: 2078
	public struct UnlockAchievementsOptions
	{
		// Token: 0x1700088A RID: 2186
		// (get) Token: 0x0600222D RID: 8749 RVA: 0x000289B4 File Offset: 0x00026BB4
		// (set) Token: 0x0600222E RID: 8750 RVA: 0x000289BC File Offset: 0x00026BBC
		public ProductUserId UserId { readonly get; set; }

		// Token: 0x1700088B RID: 2187
		// (get) Token: 0x0600222F RID: 8751 RVA: 0x000289C5 File Offset: 0x00026BC5
		// (set) Token: 0x06002230 RID: 8752 RVA: 0x000289CD File Offset: 0x00026BCD
		public Utf8String[] AchievementIds { readonly get; set; }
	}
}
