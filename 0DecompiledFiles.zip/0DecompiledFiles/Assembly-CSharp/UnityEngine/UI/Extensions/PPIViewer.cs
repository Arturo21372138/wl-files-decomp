﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B5 RID: 181
	[RequireComponent(typeof(Text))]
	[AddComponentMenu("UI/Extensions/PPIViewer")]
	public class PPIViewer : MonoBehaviour
	{
		// Token: 0x06000606 RID: 1542 RVA: 0x00023FD3 File Offset: 0x000221D3
		private void Awake()
		{
			this.label = base.GetComponent<Text>();
		}

		// Token: 0x06000607 RID: 1543 RVA: 0x00023FE4 File Offset: 0x000221E4
		private void Start()
		{
			if (this.label != null)
			{
				this.label.text = "PPI: " + Screen.dpi.ToString();
			}
		}

		// Token: 0x0400046F RID: 1135
		private Text label;
	}
}
