﻿using System;
using UnityEngine;

// Token: 0x02000002 RID: 2
public class AnimationKeyInputTestTrigger : MonoBehaviour
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	private void Start()
	{
		this.animator = base.GetComponent<Animator>();
	}

	// Token: 0x06000002 RID: 2 RVA: 0x0000205E File Offset: 0x0000025E
	private void Update()
	{
		if (Input.GetKeyDown(this.triggerKey))
		{
			this.animator.Play(this.animationString, -1, 0f);
		}
	}

	// Token: 0x04000001 RID: 1
	private Animator animator;

	// Token: 0x04000002 RID: 2
	[SerializeField]
	private string animationString;

	// Token: 0x04000003 RID: 3
	[SerializeField]
	private string triggerKey;
}
