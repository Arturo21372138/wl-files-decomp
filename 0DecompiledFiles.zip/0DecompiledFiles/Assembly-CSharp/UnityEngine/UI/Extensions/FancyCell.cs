﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000071 RID: 113
	public abstract class FancyCell<TItemData, TContext> : MonoBehaviour where TContext : class, new()
	{
		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000364 RID: 868 RVA: 0x00016820 File Offset: 0x00014A20
		// (set) Token: 0x06000365 RID: 869 RVA: 0x00016828 File Offset: 0x00014A28
		public int Index { get; set; } = -1;

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000366 RID: 870 RVA: 0x00016831 File Offset: 0x00014A31
		public virtual bool IsVisible
		{
			get
			{
				return base.gameObject.activeSelf;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000367 RID: 871 RVA: 0x0001683E File Offset: 0x00014A3E
		// (set) Token: 0x06000368 RID: 872 RVA: 0x00016846 File Offset: 0x00014A46
		private protected TContext Context { protected get; private set; }

		// Token: 0x06000369 RID: 873 RVA: 0x0001684F File Offset: 0x00014A4F
		public virtual void SetContext(TContext context)
		{
			this.Context = context;
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00016858 File Offset: 0x00014A58
		public virtual void Initialize()
		{
		}

		// Token: 0x0600036B RID: 875 RVA: 0x0001685A File Offset: 0x00014A5A
		public virtual void SetVisible(bool visible)
		{
			base.gameObject.SetActive(visible);
		}

		// Token: 0x0600036C RID: 876
		public abstract void UpdateContent(TItemData itemData);

		// Token: 0x0600036D RID: 877
		public abstract void UpdatePosition(float position);
	}
}
