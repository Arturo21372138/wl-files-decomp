﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000800 RID: 2048
	// (Invoke) Token: 0x060021AF RID: 8623
	public delegate void OnAchievementsUnlockedCallbackV2(ref OnAchievementsUnlockedCallbackV2Info data);
}
