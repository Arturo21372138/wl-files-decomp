﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200006B RID: 107
	[ExecuteInEditMode]
	public class CardExpanding3D : MonoBehaviour
	{
		// Token: 0x06000324 RID: 804 RVA: 0x000148D8 File Offset: 0x00012AD8
		private void Start()
		{
			if (this.cardAutoSize)
			{
				this.cardSize = new Vector2(this.cardCorners[0].localScale.x * 2f + this.cardEdges[0].localScale.x, this.cardCorners[0].localScale.y * 2f + this.cardEdges[0].localScale.y);
				this.cardPosition = this.cardCenter.localPosition;
			}
			if (this.pageAutoSize)
			{
				this.pageSize = new Vector2((float)Screen.width, (float)(Screen.height / 3));
				this.pagePosition = new Vector2(0f, (float)(Screen.height / 2) - this.pageSize.y / 2f);
			}
			this.rect = base.GetComponent<RectTransform>();
		}

		// Token: 0x06000325 RID: 805 RVA: 0x000149BC File Offset: 0x00012BBC
		private void Update()
		{
			if (this.animationActive == 1 || this.animationActive == -1)
			{
				for (int i = 0; i < this.cardCorners.Length; i++)
				{
					this.cardCorners[i].localPosition = Vector3.Lerp(this.cardCorners[i].localPosition, this.nextCornerPos[i], Time.deltaTime * this.lerpSpeed);
					this.cardCorners[i].GetComponent<SuperellipsePoints>().superness = Mathf.Lerp(this.cardCorners[i].GetComponent<SuperellipsePoints>().superness, (float)this.nextSuperness, Time.deltaTime * this.lerpSpeed);
					if (Mathf.Abs(this.cardCorners[i].GetComponent<SuperellipsePoints>().superness - (float)this.nextSuperness) <= 1f)
					{
						this.cardCorners[i].localPosition = this.nextCornerPos[i];
						this.cardEdges[i].localPosition = this.nextEdgePos[i];
						this.cardEdges[i].localScale = new Vector3(this.nextEdgeScale[i].x, this.nextEdgeScale[i].y, 1f);
						base.transform.localPosition = this.nextPos;
						this.cardCenter.localScale = new Vector3(this.nextCenterScale.x, this.nextCenterScale.y, 1f);
						this.cardCorners[i].GetComponent<SuperellipsePoints>().superness = (float)this.nextSuperness;
						this.rect.offsetMin = this.nextMin;
						this.rect.offsetMax = this.nextMax;
					}
				}
				for (int j = 0; j < this.cardEdges.Length; j++)
				{
					this.cardEdges[j].localPosition = Vector3.Lerp(this.cardEdges[j].localPosition, this.nextEdgePos[j], Time.deltaTime * this.lerpSpeed);
					this.cardEdges[j].localScale = Vector3.Lerp(this.cardEdges[j].localScale, new Vector3(this.nextEdgeScale[j].x, this.nextEdgeScale[j].y, 1f), Time.deltaTime * this.lerpSpeed);
				}
				base.transform.localPosition = Vector3.Lerp(base.transform.localPosition, this.nextPos, Time.deltaTime * this.lerpSpeed);
				this.cardCenter.localScale = Vector3.Lerp(this.cardCenter.localScale, new Vector3(this.nextCenterScale.x, this.nextCenterScale.y, 1f), Time.deltaTime * this.lerpSpeed);
				this.rect.offsetMin = Vector3.Lerp(this.rect.offsetMin, this.nextMin, Time.deltaTime * this.lerpSpeed);
				this.rect.offsetMax = Vector3.Lerp(this.rect.offsetMax, this.nextMax, Time.deltaTime * this.lerpSpeed);
			}
		}

		// Token: 0x06000326 RID: 806 RVA: 0x00014D28 File Offset: 0x00012F28
		public void ToggleCard()
		{
			if (this.animationActive != 1 || this.animationActive == 0)
			{
				this.animationActive = 1;
				for (int i = 0; i < this.cardCorners.Length; i++)
				{
					float num = this.pageSize.x / 2f * Mathf.Sign(this.cardCorners[i].localScale.x) - this.cardCorners[i].localScale.x;
					float num2 = this.pageSize.y / 2f * Mathf.Sign(this.cardCorners[i].localScale.y) - this.cardCorners[i].localScale.y;
					this.nextCornerPos[i] = new Vector2(num, num2);
				}
				for (int j = 0; j < this.cardEdges.Length; j++)
				{
					float num3 = 0f;
					float num4 = 0f;
					float num5 = 0f;
					float num6 = 0f;
					if (this.cardEdges[j].localPosition.x != 0f)
					{
						num3 = Mathf.Sign(this.cardEdges[j].localPosition.x) * (this.pageSize.x / 2f - this.cardEdges[j].localScale.x / 2f);
						num4 = 0f;
						num5 = this.cornerSize;
						num6 = this.pageSize.y - this.cornerSize * 2f;
					}
					else if (this.cardEdges[j].localPosition.y != 0f)
					{
						num3 = 0f;
						num4 = Mathf.Sign(this.cardEdges[j].localPosition.y) * (this.pageSize.y / 2f - this.cardEdges[j].localScale.y / 2f);
						num5 = this.pageSize.x - this.cornerSize * 2f;
						num6 = this.cornerSize;
					}
					this.nextEdgePos[j] = new Vector2(num3, num4);
					this.nextEdgeScale[j] = new Vector2(num5, num6);
				}
				this.nextCenterScale = this.pageSize - new Vector2(this.cornerSize * 2f, this.cornerSize * 2f);
				this.nextPos = this.pagePosition;
				this.nextSuperness = this.pageSuperness;
				this.nextMin = new Vector2(-this.pageSize.x / 2f, -this.pageSize.y / 2f) + this.nextPos;
				this.nextMax = new Vector2(this.pageSize.x / 2f, this.pageSize.y / 2f) + this.nextPos;
				return;
			}
			if (this.animationActive != -1)
			{
				this.animationActive = -1;
				for (int k = 0; k < this.cardCorners.Length; k++)
				{
					float num7 = Mathf.Sign(this.cardCorners[k].localScale.x) * (this.cardSize.x / 2f) - this.cardCorners[k].localScale.x;
					float num8 = Mathf.Sign(this.cardCorners[k].localScale.y) * (this.cardSize.y / 2f) - this.cardCorners[k].localScale.y;
					this.nextCornerPos[k] = new Vector2(num7, num8);
				}
				for (int l = 0; l < this.cardEdges.Length; l++)
				{
					float num9 = 0f;
					float num10 = 0f;
					float num11 = 0f;
					float num12 = 0f;
					if (this.cardEdges[l].localPosition.x != 0f)
					{
						num9 = Mathf.Sign(this.cardEdges[l].localPosition.x) * (this.cardSize.x / 2f) - Mathf.Sign(this.cardEdges[l].localPosition.x) * (this.cardEdges[l].localScale.x / 2f);
						num10 = 0f;
						num11 = this.cornerSize;
						num12 = this.cardSize.y - this.cornerSize * 2f;
					}
					else if (this.cardEdges[l].localPosition.y != 0f)
					{
						num9 = 0f;
						num10 = Mathf.Sign(this.cardEdges[l].localPosition.y) * (this.cardSize.y / 2f) - Mathf.Sign(this.cardEdges[l].localPosition.y) * (this.cardEdges[l].localScale.y / 2f);
						num11 = this.cardSize.x - this.cornerSize * 2f;
						num12 = this.cornerSize;
					}
					this.nextEdgePos[l] = new Vector2(num9, num10);
					this.nextEdgeScale[l] = new Vector2(num11, num12);
				}
				this.nextCenterScale = this.cardSize - new Vector2(this.cornerSize * 2f, this.cornerSize * 2f);
				this.nextPos = this.cardPosition;
				this.nextSuperness = this.cardSuperness;
				this.nextMin = new Vector2(-this.cardSize.x / 2f, -this.cardSize.y / 2f) + this.nextPos;
				this.nextMax = new Vector2(this.cardSize.x / 2f, this.cardSize.y / 2f) + this.nextPos;
			}
		}

		// Token: 0x0400028B RID: 651
		[SerializeField]
		private float lerpSpeed = 12f;

		// Token: 0x0400028C RID: 652
		[SerializeField]
		private float cornerSize = 64f;

		// Token: 0x0400028D RID: 653
		[Header("Parts")]
		public RectTransform[] cardCorners;

		// Token: 0x0400028E RID: 654
		public RectTransform[] cardEdges;

		// Token: 0x0400028F RID: 655
		public RectTransform cardCenter;

		// Token: 0x04000290 RID: 656
		[Header("Card Info")]
		[Tooltip("Positions and sizes card to its current transform.")]
		public bool cardAutoSize = true;

		// Token: 0x04000291 RID: 657
		public Vector2 cardSize;

		// Token: 0x04000292 RID: 658
		public Vector2 cardPosition;

		// Token: 0x04000293 RID: 659
		[Range(1f, 96f)]
		public int cardSuperness = 4;

		// Token: 0x04000294 RID: 660
		[Header("Page Info")]
		[Tooltip("Positions and sizes the page to the top third of the screen.")]
		public bool pageAutoSize = true;

		// Token: 0x04000295 RID: 661
		public Vector2 pageSize;

		// Token: 0x04000296 RID: 662
		public Vector2 pagePosition;

		// Token: 0x04000297 RID: 663
		[Range(1f, 96f)]
		public int pageSuperness = 96;

		// Token: 0x04000298 RID: 664
		private int animationActive;

		// Token: 0x04000299 RID: 665
		private Vector2[] nextCornerPos = new Vector2[4];

		// Token: 0x0400029A RID: 666
		private Vector2[] nextEdgePos = new Vector2[4];

		// Token: 0x0400029B RID: 667
		private Vector2[] nextEdgeScale = new Vector2[4];

		// Token: 0x0400029C RID: 668
		private Vector2 nextCenterScale;

		// Token: 0x0400029D RID: 669
		private Vector2 nextPos;

		// Token: 0x0400029E RID: 670
		private int nextSuperness;

		// Token: 0x0400029F RID: 671
		private RectTransform rect;

		// Token: 0x040002A0 RID: 672
		private Vector2 nextMin;

		// Token: 0x040002A1 RID: 673
		private Vector2 nextMax;
	}
}
