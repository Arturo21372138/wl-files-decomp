﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000814 RID: 2068
	public struct PlayerAchievement
	{
		// Token: 0x17000878 RID: 2168
		// (get) Token: 0x06002202 RID: 8706 RVA: 0x00028694 File Offset: 0x00026894
		// (set) Token: 0x06002203 RID: 8707 RVA: 0x0002869C File Offset: 0x0002689C
		public Utf8String AchievementId { readonly get; set; }

		// Token: 0x17000879 RID: 2169
		// (get) Token: 0x06002204 RID: 8708 RVA: 0x000286A5 File Offset: 0x000268A5
		// (set) Token: 0x06002205 RID: 8709 RVA: 0x000286AD File Offset: 0x000268AD
		public double Progress { readonly get; set; }

		// Token: 0x1700087A RID: 2170
		// (get) Token: 0x06002206 RID: 8710 RVA: 0x000286B6 File Offset: 0x000268B6
		// (set) Token: 0x06002207 RID: 8711 RVA: 0x000286BE File Offset: 0x000268BE
		public DateTimeOffset? UnlockTime { readonly get; set; }

		// Token: 0x1700087B RID: 2171
		// (get) Token: 0x06002208 RID: 8712 RVA: 0x000286C7 File Offset: 0x000268C7
		// (set) Token: 0x06002209 RID: 8713 RVA: 0x000286CF File Offset: 0x000268CF
		public PlayerStatInfo[] StatInfo { readonly get; set; }

		// Token: 0x1700087C RID: 2172
		// (get) Token: 0x0600220A RID: 8714 RVA: 0x000286D8 File Offset: 0x000268D8
		// (set) Token: 0x0600220B RID: 8715 RVA: 0x000286E0 File Offset: 0x000268E0
		public Utf8String DisplayName { readonly get; set; }

		// Token: 0x1700087D RID: 2173
		// (get) Token: 0x0600220C RID: 8716 RVA: 0x000286E9 File Offset: 0x000268E9
		// (set) Token: 0x0600220D RID: 8717 RVA: 0x000286F1 File Offset: 0x000268F1
		public Utf8String Description { readonly get; set; }

		// Token: 0x1700087E RID: 2174
		// (get) Token: 0x0600220E RID: 8718 RVA: 0x000286FA File Offset: 0x000268FA
		// (set) Token: 0x0600220F RID: 8719 RVA: 0x00028702 File Offset: 0x00026902
		public Utf8String IconURL { readonly get; set; }

		// Token: 0x1700087F RID: 2175
		// (get) Token: 0x06002210 RID: 8720 RVA: 0x0002870B File Offset: 0x0002690B
		// (set) Token: 0x06002211 RID: 8721 RVA: 0x00028713 File Offset: 0x00026913
		public Utf8String FlavorText { readonly get; set; }
	}
}
