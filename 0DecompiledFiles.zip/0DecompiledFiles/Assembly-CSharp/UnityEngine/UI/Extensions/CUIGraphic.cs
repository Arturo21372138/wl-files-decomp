﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200004F RID: 79
	[RequireComponent(typeof(RectTransform))]
	[RequireComponent(typeof(Graphic))]
	[DisallowMultipleComponent]
	[AddComponentMenu("UI/Effects/Extensions/Curly UI Graphic")]
	public class CUIGraphic : BaseMeshEffect
	{
		// Token: 0x17000062 RID: 98
		// (get) Token: 0x0600026D RID: 621 RVA: 0x0000E4F1 File Offset: 0x0000C6F1
		public bool IsCurved
		{
			get
			{
				return this.isCurved;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x0600026E RID: 622 RVA: 0x0000E4F9 File Offset: 0x0000C6F9
		public bool IsLockWithRatio
		{
			get
			{
				return this.isLockWithRatio;
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600026F RID: 623 RVA: 0x0000E501 File Offset: 0x0000C701
		public RectTransform RectTrans
		{
			get
			{
				return this.rectTrans;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000270 RID: 624 RVA: 0x0000E509 File Offset: 0x0000C709
		public Graphic UIGraphic
		{
			get
			{
				return this.uiGraphic;
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000271 RID: 625 RVA: 0x0000E511 File Offset: 0x0000C711
		public CUIGraphic RefCUIGraphic
		{
			get
			{
				return this.refCUIGraphic;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000272 RID: 626 RVA: 0x0000E519 File Offset: 0x0000C719
		public CUIBezierCurve[] RefCurves
		{
			get
			{
				return this.refCurves;
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000273 RID: 627 RVA: 0x0000E521 File Offset: 0x0000C721
		public Vector3_Array2D[] RefCurvesControlRatioPoints
		{
			get
			{
				return this.refCurvesControlRatioPoints;
			}
		}

		// Token: 0x06000274 RID: 628 RVA: 0x0000E52C File Offset: 0x0000C72C
		protected void solveDoubleEquationWithVector(float _x_1, float _y_1, float _x_2, float _y_2, Vector3 _constant_1, Vector3 _contant_2, out Vector3 _x, out Vector3 _y)
		{
			if (Mathf.Abs(_x_1) > Mathf.Abs(_x_2))
			{
				Vector3 vector = _constant_1 * _x_2 / _x_1;
				float num = _y_1 * _x_2 / _x_1;
				_y = (_contant_2 - vector) / (_y_2 - num);
				if (_x_2 != 0f)
				{
					_x = (vector - num * _y) / _x_2;
					return;
				}
				_x = (_constant_1 - _y_1 * _y) / _x_1;
				return;
			}
			else
			{
				Vector3 vector = _contant_2 * _x_1 / _x_2;
				float num = _y_2 * _x_1 / _x_2;
				_x = (_constant_1 - vector) / (_y_1 - num);
				if (_x_1 != 0f)
				{
					_y = (vector - num * _x) / _x_1;
					return;
				}
				_y = (_contant_2 - _y_2 * _x) / _x_2;
				return;
			}
		}

		// Token: 0x06000275 RID: 629 RVA: 0x0000E638 File Offset: 0x0000C838
		protected UIVertex uiVertexLerp(UIVertex _a, UIVertex _b, float _time)
		{
			return new UIVertex
			{
				position = Vector3.Lerp(_a.position, _b.position, _time),
				normal = Vector3.Lerp(_a.normal, _b.normal, _time),
				tangent = Vector3.Lerp(_a.tangent, _b.tangent, _time),
				uv0 = Vector2.Lerp(_a.uv0, _b.uv0, _time),
				uv1 = Vector2.Lerp(_a.uv1, _b.uv1, _time),
				color = Color.Lerp(_a.color, _b.color, _time)
			};
		}

		// Token: 0x06000276 RID: 630 RVA: 0x0000E720 File Offset: 0x0000C920
		protected UIVertex uiVertexBerp(UIVertex v_bottomLeft, UIVertex v_topLeft, UIVertex v_topRight, UIVertex v_bottomRight, float _xTime, float _yTime)
		{
			UIVertex uivertex = this.uiVertexLerp(v_topLeft, v_topRight, _xTime);
			UIVertex uivertex2 = this.uiVertexLerp(v_bottomLeft, v_bottomRight, _xTime);
			return this.uiVertexLerp(uivertex2, uivertex, _yTime);
		}

		// Token: 0x06000277 RID: 631 RVA: 0x0000E750 File Offset: 0x0000C950
		protected void tessellateQuad(List<UIVertex> _quads, int _thisQuadIdx)
		{
			UIVertex uivertex = _quads[_thisQuadIdx];
			UIVertex uivertex2 = _quads[_thisQuadIdx + 1];
			UIVertex uivertex3 = _quads[_thisQuadIdx + 2];
			UIVertex uivertex4 = _quads[_thisQuadIdx + 3];
			float num = 100f / this.resolution;
			int num2 = Mathf.Max(1, Mathf.CeilToInt((uivertex2.position - uivertex.position).magnitude / num));
			int num3 = Mathf.Max(1, Mathf.CeilToInt((uivertex3.position - uivertex2.position).magnitude / num));
			int num4 = 0;
			for (int i = 0; i < num3; i++)
			{
				int j = 0;
				while (j < num2)
				{
					_quads.Add(default(UIVertex));
					_quads.Add(default(UIVertex));
					_quads.Add(default(UIVertex));
					_quads.Add(default(UIVertex));
					float num5 = (float)i / (float)num3;
					float num6 = (float)j / (float)num2;
					float num7 = (float)(i + 1) / (float)num3;
					float num8 = (float)(j + 1) / (float)num2;
					_quads[_quads.Count - 4] = this.uiVertexBerp(uivertex, uivertex2, uivertex3, uivertex4, num5, num6);
					_quads[_quads.Count - 3] = this.uiVertexBerp(uivertex, uivertex2, uivertex3, uivertex4, num5, num8);
					_quads[_quads.Count - 2] = this.uiVertexBerp(uivertex, uivertex2, uivertex3, uivertex4, num7, num8);
					_quads[_quads.Count - 1] = this.uiVertexBerp(uivertex, uivertex2, uivertex3, uivertex4, num7, num6);
					j++;
					num4++;
				}
			}
		}

		// Token: 0x06000278 RID: 632 RVA: 0x0000E8F4 File Offset: 0x0000CAF4
		protected void tessellateGraphic(List<UIVertex> _verts)
		{
			for (int i = 0; i < _verts.Count; i += 6)
			{
				this.reuse_quads.Add(_verts[i]);
				this.reuse_quads.Add(_verts[i + 1]);
				this.reuse_quads.Add(_verts[i + 2]);
				this.reuse_quads.Add(_verts[i + 4]);
			}
			int num = this.reuse_quads.Count / 4;
			for (int j = 0; j < num; j++)
			{
				this.tessellateQuad(this.reuse_quads, j * 4);
			}
			this.reuse_quads.RemoveRange(0, num * 4);
			_verts.Clear();
			for (int k = 0; k < this.reuse_quads.Count; k += 4)
			{
				_verts.Add(this.reuse_quads[k]);
				_verts.Add(this.reuse_quads[k + 1]);
				_verts.Add(this.reuse_quads[k + 2]);
				_verts.Add(this.reuse_quads[k + 2]);
				_verts.Add(this.reuse_quads[k + 3]);
				_verts.Add(this.reuse_quads[k]);
			}
			this.reuse_quads.Clear();
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0000EA36 File Offset: 0x0000CC36
		protected override void OnRectTransformDimensionsChange()
		{
			if (this.isLockWithRatio)
			{
				this.UpdateCurveControlPointPositions();
			}
		}

		// Token: 0x0600027A RID: 634 RVA: 0x0000EA48 File Offset: 0x0000CC48
		public void Refresh()
		{
			this.ReportSet();
			for (int i = 0; i < this.refCurves.Length; i++)
			{
				CUIBezierCurve cuibezierCurve = this.refCurves[i];
				if (cuibezierCurve.ControlPoints != null)
				{
					Vector3[] controlPoints = cuibezierCurve.ControlPoints;
					for (int j = 0; j < CUIBezierCurve.CubicBezierCurvePtNum; j++)
					{
						Vector3 vector = controlPoints[j];
						vector.x = (vector.x + this.rectTrans.rect.width * this.rectTrans.pivot.x) / this.rectTrans.rect.width;
						vector.y = (vector.y + this.rectTrans.rect.height * this.rectTrans.pivot.y) / this.rectTrans.rect.height;
						this.refCurvesControlRatioPoints[i][j] = vector;
					}
				}
			}
			if (this.uiGraphic != null)
			{
				this.uiGraphic.enabled = false;
				this.uiGraphic.enabled = true;
			}
		}

		// Token: 0x0600027B RID: 635 RVA: 0x0000EB7A File Offset: 0x0000CD7A
		protected override void Awake()
		{
			base.Awake();
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x0600027C RID: 636 RVA: 0x0000EB88 File Offset: 0x0000CD88
		protected override void OnEnable()
		{
			base.OnEnable();
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0000EB98 File Offset: 0x0000CD98
		public virtual void ReportSet()
		{
			if (this.rectTrans == null)
			{
				this.rectTrans = base.GetComponent<RectTransform>();
			}
			if (this.refCurves == null)
			{
				this.refCurves = new CUIBezierCurve[2];
			}
			bool flag = true;
			for (int i = 0; i < 2; i++)
			{
				flag &= this.refCurves[i] != null;
			}
			if (!(flag & (this.refCurves.Length == 2)))
			{
				CUIBezierCurve[] array = this.refCurves;
				for (int j = 0; j < 2; j++)
				{
					if (this.refCurves[j] == null)
					{
						GameObject gameObject = new GameObject();
						gameObject.transform.SetParent(base.transform);
						gameObject.transform.localPosition = Vector3.zero;
						gameObject.transform.localEulerAngles = Vector3.zero;
						if (j == 0)
						{
							gameObject.name = "BottomRefCurve";
						}
						else
						{
							gameObject.name = "TopRefCurve";
						}
						array[j] = gameObject.AddComponent<CUIBezierCurve>();
					}
					else
					{
						array[j] = this.refCurves[j];
					}
					array[j].ReportSet();
				}
				this.refCurves = array;
			}
			if (this.refCurvesControlRatioPoints == null)
			{
				this.refCurvesControlRatioPoints = new Vector3_Array2D[this.refCurves.Length];
				for (int k = 0; k < this.refCurves.Length; k++)
				{
					this.refCurvesControlRatioPoints[k].array = new Vector3[this.refCurves[k].ControlPoints.Length];
				}
				this.FixTextToRectTrans();
				this.Refresh();
			}
			for (int l = 0; l < 2; l++)
			{
				this.refCurves[l].OnRefresh = new Action(this.Refresh);
			}
		}

		// Token: 0x0600027E RID: 638 RVA: 0x0000ED3C File Offset: 0x0000CF3C
		public void FixTextToRectTrans()
		{
			for (int i = 0; i < this.refCurves.Length; i++)
			{
				CUIBezierCurve cuibezierCurve = this.refCurves[i];
				for (int j = 0; j < CUIBezierCurve.CubicBezierCurvePtNum; j++)
				{
					if (cuibezierCurve.ControlPoints != null)
					{
						Vector3[] controlPoints = cuibezierCurve.ControlPoints;
						if (i == 0)
						{
							controlPoints[j].y = -this.rectTrans.rect.height * this.rectTrans.pivot.y;
						}
						else
						{
							controlPoints[j].y = this.rectTrans.rect.height - this.rectTrans.rect.height * this.rectTrans.pivot.y;
						}
						controlPoints[j].x = this.rectTrans.rect.width * (float)j / (float)(CUIBezierCurve.CubicBezierCurvePtNum - 1);
						Vector3[] array = controlPoints;
						int num = j;
						array[num].x = array[num].x - this.rectTrans.rect.width * this.rectTrans.pivot.x;
						controlPoints[j].z = 0f;
					}
				}
			}
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0000EE84 File Offset: 0x0000D084
		public void ReferenceCUIForBCurves()
		{
			Vector3 localPosition = this.rectTrans.localPosition;
			localPosition.x += -this.rectTrans.rect.width * this.rectTrans.pivot.x + this.refCUIGraphic.rectTrans.rect.width * this.refCUIGraphic.rectTrans.pivot.x;
			localPosition.y += -this.rectTrans.rect.height * this.rectTrans.pivot.y + this.refCUIGraphic.rectTrans.rect.height * this.refCUIGraphic.rectTrans.pivot.y;
			Vector3 vector = new Vector3(localPosition.x / this.refCUIGraphic.RectTrans.rect.width, localPosition.y / this.refCUIGraphic.RectTrans.rect.height, localPosition.z);
			Vector3 vector2 = new Vector3((localPosition.x + this.rectTrans.rect.width) / this.refCUIGraphic.RectTrans.rect.width, (localPosition.y + this.rectTrans.rect.height) / this.refCUIGraphic.RectTrans.rect.height, localPosition.z);
			this.refCurves[0].ControlPoints[0] = this.refCUIGraphic.GetBCurveSandwichSpacePoint(vector.x, vector.y) - this.rectTrans.localPosition;
			this.refCurves[0].ControlPoints[3] = this.refCUIGraphic.GetBCurveSandwichSpacePoint(vector2.x, vector.y) - this.rectTrans.localPosition;
			this.refCurves[1].ControlPoints[0] = this.refCUIGraphic.GetBCurveSandwichSpacePoint(vector.x, vector2.y) - this.rectTrans.localPosition;
			this.refCurves[1].ControlPoints[3] = this.refCUIGraphic.GetBCurveSandwichSpacePoint(vector2.x, vector2.y) - this.rectTrans.localPosition;
			for (int i = 0; i < this.refCurves.Length; i++)
			{
				CUIBezierCurve cuibezierCurve = this.refCurves[i];
				float num = ((i == 0) ? vector.y : vector2.y);
				Vector3 bcurveSandwichSpacePoint = this.refCUIGraphic.GetBCurveSandwichSpacePoint(vector.x, num);
				Vector3 bcurveSandwichSpacePoint2 = this.refCUIGraphic.GetBCurveSandwichSpacePoint(vector2.x, num);
				float num2 = 0.25f;
				float num3 = 0.75f;
				Vector3 bcurveSandwichSpacePoint3 = this.refCUIGraphic.GetBCurveSandwichSpacePoint((vector.x * 0.75f + vector2.x * 0.25f) / 1f, num);
				Vector3 bcurveSandwichSpacePoint4 = this.refCUIGraphic.GetBCurveSandwichSpacePoint((vector.x * 0.25f + vector2.x * 0.75f) / 1f, num);
				float num4 = 3f * num3 * num3 * num2;
				float num5 = 3f * num3 * num2 * num2;
				float num6 = 3f * num2 * num2 * num3;
				float num7 = 3f * num2 * num3 * num3;
				Vector3 vector3 = bcurveSandwichSpacePoint3 - Mathf.Pow(num3, 3f) * bcurveSandwichSpacePoint - Mathf.Pow(num2, 3f) * bcurveSandwichSpacePoint2;
				Vector3 vector4 = bcurveSandwichSpacePoint4 - Mathf.Pow(num2, 3f) * bcurveSandwichSpacePoint - Mathf.Pow(num3, 3f) * bcurveSandwichSpacePoint2;
				Vector3 vector5;
				Vector3 vector6;
				this.solveDoubleEquationWithVector(num4, num5, num6, num7, vector3, vector4, out vector5, out vector6);
				cuibezierCurve.ControlPoints[1] = vector5 - this.rectTrans.localPosition;
				cuibezierCurve.ControlPoints[2] = vector6 - this.rectTrans.localPosition;
			}
		}

		// Token: 0x06000280 RID: 640 RVA: 0x0000F2C4 File Offset: 0x0000D4C4
		public override void ModifyMesh(Mesh _mesh)
		{
			if (!this.IsActive())
			{
				return;
			}
			using (VertexHelper vertexHelper = new VertexHelper(_mesh))
			{
				this.ModifyMesh(vertexHelper);
				vertexHelper.FillMesh(_mesh);
			}
		}

		// Token: 0x06000281 RID: 641 RVA: 0x0000F30C File Offset: 0x0000D50C
		public override void ModifyMesh(VertexHelper _vh)
		{
			if (!this.IsActive())
			{
				return;
			}
			List<UIVertex> list = new List<UIVertex>();
			_vh.GetUIVertexStream(list);
			this.modifyVertices(list);
			_vh.Clear();
			_vh.AddUIVertexTriangleStream(list);
		}

		// Token: 0x06000282 RID: 642 RVA: 0x0000F344 File Offset: 0x0000D544
		protected virtual void modifyVertices(List<UIVertex> _verts)
		{
			if (!this.IsActive())
			{
				return;
			}
			this.tessellateGraphic(_verts);
			if (!this.isCurved)
			{
				return;
			}
			for (int i = 0; i < _verts.Count; i++)
			{
				UIVertex uivertex = _verts[i];
				float num = (uivertex.position.x + this.rectTrans.rect.width * this.rectTrans.pivot.x) / this.rectTrans.rect.width;
				float num2 = (uivertex.position.y + this.rectTrans.rect.height * this.rectTrans.pivot.y) / this.rectTrans.rect.height;
				Vector3 bcurveSandwichSpacePoint = this.GetBCurveSandwichSpacePoint(num, num2);
				uivertex.position.x = bcurveSandwichSpacePoint.x;
				uivertex.position.y = bcurveSandwichSpacePoint.y;
				uivertex.position.z = bcurveSandwichSpacePoint.z;
				_verts[i] = uivertex;
			}
		}

		// Token: 0x06000283 RID: 643 RVA: 0x0000F464 File Offset: 0x0000D664
		public void UpdateCurveControlPointPositions()
		{
			this.ReportSet();
			for (int i = 0; i < this.refCurves.Length; i++)
			{
				CUIBezierCurve cuibezierCurve = this.refCurves[i];
				for (int j = 0; j < this.refCurves[i].ControlPoints.Length; j++)
				{
					Vector3 vector = this.refCurvesControlRatioPoints[i][j];
					vector.x = vector.x * this.rectTrans.rect.width - this.rectTrans.rect.width * this.rectTrans.pivot.x;
					vector.y = vector.y * this.rectTrans.rect.height - this.rectTrans.rect.height * this.rectTrans.pivot.y;
					cuibezierCurve.ControlPoints[j] = vector;
				}
			}
		}

		// Token: 0x06000284 RID: 644 RVA: 0x0000F569 File Offset: 0x0000D769
		public Vector3 GetBCurveSandwichSpacePoint(float _xTime, float _yTime)
		{
			return this.refCurves[0].GetPoint(_xTime) * (1f - _yTime) + this.refCurves[1].GetPoint(_xTime) * _yTime;
		}

		// Token: 0x06000285 RID: 645 RVA: 0x0000F59E File Offset: 0x0000D79E
		public Vector3 GetBCurveSandwichSpaceTangent(float _xTime, float _yTime)
		{
			return this.refCurves[0].GetTangent(_xTime) * (1f - _yTime) + this.refCurves[1].GetTangent(_xTime) * _yTime;
		}

		// Token: 0x04000205 RID: 517
		public static readonly int bottomCurveIdx = 0;

		// Token: 0x04000206 RID: 518
		public static readonly int topCurveIdx = 1;

		// Token: 0x04000207 RID: 519
		[Tooltip("Set true to make the curve/morph to work. Set false to quickly see the original UI.")]
		[SerializeField]
		protected bool isCurved = true;

		// Token: 0x04000208 RID: 520
		[Tooltip("Set true to dynamically change the curve according to the dynamic change of the UI layout")]
		[SerializeField]
		protected bool isLockWithRatio = true;

		// Token: 0x04000209 RID: 521
		[Tooltip("Pick a higher resolution to improve the quality of the curved graphic.")]
		[SerializeField]
		[Range(0.01f, 30f)]
		protected float resolution = 5f;

		// Token: 0x0400020A RID: 522
		protected RectTransform rectTrans;

		// Token: 0x0400020B RID: 523
		[Tooltip("Put in the Graphic you want to curve/morph here.")]
		[SerializeField]
		protected Graphic uiGraphic;

		// Token: 0x0400020C RID: 524
		[Tooltip("Put in the reference Graphic that will be used to tune the bezier curves. Think button image and text.")]
		[SerializeField]
		protected CUIGraphic refCUIGraphic;

		// Token: 0x0400020D RID: 525
		[Tooltip("Do not touch this unless you are sure what you are doing. The curves are (re)generated automatically.")]
		[SerializeField]
		protected CUIBezierCurve[] refCurves;

		// Token: 0x0400020E RID: 526
		[HideInInspector]
		[SerializeField]
		protected Vector3_Array2D[] refCurvesControlRatioPoints;

		// Token: 0x0400020F RID: 527
		protected List<UIVertex> reuse_quads = new List<UIVertex>();
	}
}
