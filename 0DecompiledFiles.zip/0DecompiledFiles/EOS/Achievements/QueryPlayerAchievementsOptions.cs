﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200081A RID: 2074
	public struct QueryPlayerAchievementsOptions
	{
		// Token: 0x17000886 RID: 2182
		// (get) Token: 0x06002222 RID: 8738 RVA: 0x000288F3 File Offset: 0x00026AF3
		// (set) Token: 0x06002223 RID: 8739 RVA: 0x000288FB File Offset: 0x00026AFB
		public ProductUserId TargetUserId { readonly get; set; }

		// Token: 0x17000887 RID: 2183
		// (get) Token: 0x06002224 RID: 8740 RVA: 0x00028904 File Offset: 0x00026B04
		// (set) Token: 0x06002225 RID: 8741 RVA: 0x0002890C File Offset: 0x00026B0C
		public ProductUserId LocalUserId { readonly get; set; }
	}
}
