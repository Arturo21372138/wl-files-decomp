﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007AE RID: 1966
	public struct AddNotifyPeerAuthStatusChangedOptions
	{
	}
}
