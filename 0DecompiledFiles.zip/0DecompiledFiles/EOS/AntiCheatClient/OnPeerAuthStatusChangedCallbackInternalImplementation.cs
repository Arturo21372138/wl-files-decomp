﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007CB RID: 1995
	internal static class OnPeerAuthStatusChangedCallbackInternalImplementation
	{
		// Token: 0x17000827 RID: 2087
		// (get) Token: 0x060020EF RID: 8431 RVA: 0x00027299 File Offset: 0x00025499
		public static OnPeerAuthStatusChangedCallbackInternal Delegate
		{
			get
			{
				if (OnPeerAuthStatusChangedCallbackInternalImplementation.s_Delegate == null)
				{
					OnPeerAuthStatusChangedCallbackInternalImplementation.s_Delegate = new OnPeerAuthStatusChangedCallbackInternal(OnPeerAuthStatusChangedCallbackInternalImplementation.EntryPoint);
				}
				return OnPeerAuthStatusChangedCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060020F0 RID: 8432 RVA: 0x000272B8 File Offset: 0x000254B8
		[MonoPInvokeCallback(typeof(OnPeerAuthStatusChangedCallbackInternal))]
		public static void EntryPoint(ref OnClientAuthStatusChangedCallbackInfoInternal data)
		{
			OnPeerAuthStatusChangedCallback onPeerAuthStatusChangedCallback;
			OnClientAuthStatusChangedCallbackInfo onClientAuthStatusChangedCallbackInfo;
			if (Helper.TryGetCallback<OnClientAuthStatusChangedCallbackInfoInternal, OnPeerAuthStatusChangedCallback, OnClientAuthStatusChangedCallbackInfo>(ref data, out onPeerAuthStatusChangedCallback, out onClientAuthStatusChangedCallbackInfo))
			{
				onPeerAuthStatusChangedCallback(ref onClientAuthStatusChangedCallbackInfo);
			}
		}

		// Token: 0x040015E1 RID: 5601
		private static OnPeerAuthStatusChangedCallbackInternal s_Delegate;
	}
}
