﻿using System;
using System.Collections.Generic;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C9 RID: 201
	[AddComponentMenu("UI/Extensions/UI Scrollrect Occlusion")]
	public class UI_ScrollRectOcclusion : MonoBehaviour
	{
		// Token: 0x0600069A RID: 1690 RVA: 0x0002639B File Offset: 0x0002459B
		private void Awake()
		{
			if (this.InitByUser)
			{
				return;
			}
			this.Init();
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x000263AC File Offset: 0x000245AC
		public void Init()
		{
			if (base.GetComponent<ScrollRect>() != null)
			{
				this._scrollRect = base.GetComponent<ScrollRect>();
				this._scrollRect.onValueChanged.AddListener(new UnityAction<Vector2>(this.OnScroll));
				this._isHorizontal = this._scrollRect.horizontal;
				this._isVertical = this._scrollRect.vertical;
				for (int i = 0; i < this._scrollRect.content.childCount; i++)
				{
					this.items.Add(this._scrollRect.content.GetChild(i).GetComponent<RectTransform>());
				}
				if (this._scrollRect.content.GetComponent<VerticalLayoutGroup>() != null)
				{
					this._verticalLayoutGroup = this._scrollRect.content.GetComponent<VerticalLayoutGroup>();
				}
				if (this._scrollRect.content.GetComponent<HorizontalLayoutGroup>() != null)
				{
					this._horizontalLayoutGroup = this._scrollRect.content.GetComponent<HorizontalLayoutGroup>();
				}
				if (this._scrollRect.content.GetComponent<GridLayoutGroup>() != null)
				{
					this._gridLayoutGroup = this._scrollRect.content.GetComponent<GridLayoutGroup>();
				}
				if (this._scrollRect.content.GetComponent<ContentSizeFitter>() != null)
				{
					this._contentSizeFitter = this._scrollRect.content.GetComponent<ContentSizeFitter>();
					return;
				}
			}
			else
			{
				Debug.LogError("UI_ScrollRectOcclusion => No ScrollRect component found");
			}
		}

		// Token: 0x0600069C RID: 1692 RVA: 0x00026514 File Offset: 0x00024714
		private void DisableGridComponents()
		{
			if (this._isVertical)
			{
				this._disableMarginY = this._scrollRect.GetComponent<RectTransform>().rect.height / 2f + this.items[0].sizeDelta.y;
			}
			if (this._isHorizontal)
			{
				this._disableMarginX = this._scrollRect.GetComponent<RectTransform>().rect.width / 2f + this.items[0].sizeDelta.x;
			}
			if (this._verticalLayoutGroup)
			{
				this._verticalLayoutGroup.enabled = false;
			}
			if (this._horizontalLayoutGroup)
			{
				this._horizontalLayoutGroup.enabled = false;
			}
			if (this._contentSizeFitter)
			{
				this._contentSizeFitter.enabled = false;
			}
			if (this._gridLayoutGroup)
			{
				this._gridLayoutGroup.enabled = false;
			}
			this.hasDisabledGridComponents = true;
		}

		// Token: 0x0600069D RID: 1693 RVA: 0x00026614 File Offset: 0x00024814
		public void OnScroll(Vector2 pos)
		{
			if (!this.hasDisabledGridComponents)
			{
				this.DisableGridComponents();
			}
			for (int i = 0; i < this.items.Count; i++)
			{
				if (this._isVertical && this._isHorizontal)
				{
					if (this._scrollRect.transform.InverseTransformPoint(this.items[i].position).y < -this._disableMarginY || this._scrollRect.transform.InverseTransformPoint(this.items[i].position).y > this._disableMarginY || this._scrollRect.transform.InverseTransformPoint(this.items[i].position).x < -this._disableMarginX || this._scrollRect.transform.InverseTransformPoint(this.items[i].position).x > this._disableMarginX)
					{
						this.items[i].gameObject.SetActive(false);
					}
					else
					{
						this.items[i].gameObject.SetActive(true);
					}
				}
				else
				{
					if (this._isVertical)
					{
						if (this._scrollRect.transform.InverseTransformPoint(this.items[i].position).y < -this._disableMarginY || this._scrollRect.transform.InverseTransformPoint(this.items[i].position).y > this._disableMarginY)
						{
							this.items[i].gameObject.SetActive(false);
						}
						else
						{
							this.items[i].gameObject.SetActive(true);
						}
					}
					if (this._isHorizontal)
					{
						if (this._scrollRect.transform.InverseTransformPoint(this.items[i].position).x < -this._disableMarginX || this._scrollRect.transform.InverseTransformPoint(this.items[i].position).x > this._disableMarginX)
						{
							this.items[i].gameObject.SetActive(false);
						}
						else
						{
							this.items[i].gameObject.SetActive(true);
						}
					}
				}
			}
		}

		// Token: 0x040004CF RID: 1231
		public bool InitByUser;

		// Token: 0x040004D0 RID: 1232
		private ScrollRect _scrollRect;

		// Token: 0x040004D1 RID: 1233
		private ContentSizeFitter _contentSizeFitter;

		// Token: 0x040004D2 RID: 1234
		private VerticalLayoutGroup _verticalLayoutGroup;

		// Token: 0x040004D3 RID: 1235
		private HorizontalLayoutGroup _horizontalLayoutGroup;

		// Token: 0x040004D4 RID: 1236
		private GridLayoutGroup _gridLayoutGroup;

		// Token: 0x040004D5 RID: 1237
		private bool _isVertical;

		// Token: 0x040004D6 RID: 1238
		private bool _isHorizontal;

		// Token: 0x040004D7 RID: 1239
		private float _disableMarginX;

		// Token: 0x040004D8 RID: 1240
		private float _disableMarginY;

		// Token: 0x040004D9 RID: 1241
		private bool hasDisabledGridComponents;

		// Token: 0x040004DA RID: 1242
		private List<RectTransform> items = new List<RectTransform>();
	}
}
