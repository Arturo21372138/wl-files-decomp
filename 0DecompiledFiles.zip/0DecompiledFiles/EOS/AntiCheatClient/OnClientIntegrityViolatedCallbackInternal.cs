﻿using System;
using System.Runtime.InteropServices;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007BA RID: 1978
	// (Invoke) Token: 0x060020B2 RID: 8370
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	internal delegate void OnClientIntegrityViolatedCallbackInternal(ref OnClientIntegrityViolatedCallbackInfoInternal data);
}
