﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E0 RID: 2016
	internal struct AddNotifyAchievementsUnlockedV2OptionsInternal : ISettable<AddNotifyAchievementsUnlockedV2Options>, IDisposable
	{
		// Token: 0x06002136 RID: 8502 RVA: 0x00027B26 File Offset: 0x00025D26
		public void Set(ref AddNotifyAchievementsUnlockedV2Options other)
		{
			this.Dispose();
			this.m_ApiVersion = 2;
		}

		// Token: 0x06002137 RID: 8503 RVA: 0x00027B35 File Offset: 0x00025D35
		public void Dispose()
		{
		}

		// Token: 0x04001629 RID: 5673
		private int m_ApiVersion;
	}
}
