﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007DF RID: 2015
	public struct AddNotifyAchievementsUnlockedV2Options
	{
	}
}
