﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E8 RID: 2024
	internal struct CopyAchievementDefinitionV2ByIndexOptionsInternal : ISettable<CopyAchievementDefinitionV2ByIndexOptions>, IDisposable
	{
		// Token: 0x06002146 RID: 8518 RVA: 0x00027BF2 File Offset: 0x00025DF2
		public void Set(ref CopyAchievementDefinitionV2ByIndexOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 2;
			this.m_AchievementIndex = other.AchievementIndex;
		}

		// Token: 0x06002147 RID: 8519 RVA: 0x00027C0D File Offset: 0x00025E0D
		public void Dispose()
		{
		}

		// Token: 0x04001634 RID: 5684
		private int m_ApiVersion;

		// Token: 0x04001635 RID: 5685
		private uint m_AchievementIndex;
	}
}
