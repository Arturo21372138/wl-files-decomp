﻿using System;
using System.Runtime.CompilerServices;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000087 RID: 135
	public interface IFancyScrollRectContext
	{
		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000404 RID: 1028
		// (set) Token: 0x06000405 RID: 1029
		ScrollDirection ScrollDirection { get; set; }

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000406 RID: 1030
		// (set) Token: 0x06000407 RID: 1031
		[TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
		Func<ValueTuple<float, float>> CalculateScrollSize
		{
			[return: TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
			get;
			[param: TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
			set;
		}
	}
}
