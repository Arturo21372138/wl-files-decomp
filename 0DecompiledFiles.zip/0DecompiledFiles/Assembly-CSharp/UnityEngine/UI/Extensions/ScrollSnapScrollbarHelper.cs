﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200008F RID: 143
	[DisallowMultipleComponent]
	public class ScrollSnapScrollbarHelper : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler, IBeginDragHandler, IEndDragHandler, IDragHandler
	{
		// Token: 0x06000486 RID: 1158 RVA: 0x0001B748 File Offset: 0x00019948
		public void OnBeginDrag(PointerEventData eventData)
		{
			this.OnScrollBarDown();
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x0001B750 File Offset: 0x00019950
		public void OnDrag(PointerEventData eventData)
		{
			this.ss.CurrentPage();
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x0001B75E File Offset: 0x0001995E
		public void OnEndDrag(PointerEventData eventData)
		{
			this.OnScrollBarUp();
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x0001B766 File Offset: 0x00019966
		public void OnPointerDown(PointerEventData eventData)
		{
			this.OnScrollBarDown();
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x0001B76E File Offset: 0x0001996E
		public void OnPointerUp(PointerEventData eventData)
		{
			this.OnScrollBarUp();
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x0001B776 File Offset: 0x00019976
		private void OnScrollBarDown()
		{
			if (this.ss != null)
			{
				this.ss.SetLerp(false);
				this.ss.StartScreenChange();
			}
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0001B797 File Offset: 0x00019997
		private void OnScrollBarUp()
		{
			this.ss.SetLerp(true);
			this.ss.ChangePage(this.ss.CurrentPage());
		}

		// Token: 0x0400037B RID: 891
		internal IScrollSnap ss;
	}
}
