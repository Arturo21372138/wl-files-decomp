﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007CE RID: 1998
	public struct ProtectMessageOptions
	{
		// Token: 0x17000829 RID: 2089
		// (get) Token: 0x060020F5 RID: 8437 RVA: 0x00027307 File Offset: 0x00025507
		// (set) Token: 0x060020F6 RID: 8438 RVA: 0x0002730F File Offset: 0x0002550F
		public ArraySegment<byte> Data { readonly get; set; }

		// Token: 0x1700082A RID: 2090
		// (get) Token: 0x060020F7 RID: 8439 RVA: 0x00027318 File Offset: 0x00025518
		// (set) Token: 0x060020F8 RID: 8440 RVA: 0x00027320 File Offset: 0x00025520
		public uint OutBufferSizeBytes { readonly get; set; }
	}
}
