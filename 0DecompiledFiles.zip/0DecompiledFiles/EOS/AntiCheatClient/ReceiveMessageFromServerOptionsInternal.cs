﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D3 RID: 2003
	internal struct ReceiveMessageFromServerOptionsInternal : ISettable<ReceiveMessageFromServerOptions>, IDisposable
	{
		// Token: 0x06002103 RID: 8451 RVA: 0x000273DA File Offset: 0x000255DA
		public void Set(ref ReceiveMessageFromServerOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.Data, ref this.m_Data, out this.m_DataLengthBytes);
		}

		// Token: 0x06002104 RID: 8452 RVA: 0x00027400 File Offset: 0x00025600
		public void Dispose()
		{
			Helper.Dispose(ref this.m_Data);
		}

		// Token: 0x040015F2 RID: 5618
		private int m_ApiVersion;

		// Token: 0x040015F3 RID: 5619
		private uint m_DataLengthBytes;

		// Token: 0x040015F4 RID: 5620
		private IntPtr m_Data;
	}
}
