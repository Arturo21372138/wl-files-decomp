﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B9 RID: 1977
	// (Invoke) Token: 0x060020AE RID: 8366
	public delegate void OnClientIntegrityViolatedCallback(ref OnClientIntegrityViolatedCallbackInfo data);
}
