﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007FE RID: 2046
	public struct OnAchievementsUnlockedCallbackInfo : ICallbackInfo
	{
		// Token: 0x1700085E RID: 2142
		// (get) Token: 0x060021A4 RID: 8612 RVA: 0x00028221 File Offset: 0x00026421
		// (set) Token: 0x060021A5 RID: 8613 RVA: 0x00028229 File Offset: 0x00026429
		public object ClientData { readonly get; set; }

		// Token: 0x1700085F RID: 2143
		// (get) Token: 0x060021A6 RID: 8614 RVA: 0x00028232 File Offset: 0x00026432
		// (set) Token: 0x060021A7 RID: 8615 RVA: 0x0002823A File Offset: 0x0002643A
		public ProductUserId UserId { readonly get; set; }

		// Token: 0x17000860 RID: 2144
		// (get) Token: 0x060021A8 RID: 8616 RVA: 0x00028243 File Offset: 0x00026443
		// (set) Token: 0x060021A9 RID: 8617 RVA: 0x0002824B File Offset: 0x0002644B
		public Utf8String[] AchievementIds { readonly get; set; }

		// Token: 0x060021AA RID: 8618 RVA: 0x00028254 File Offset: 0x00026454
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060021AB RID: 8619 RVA: 0x0002825C File Offset: 0x0002645C
		public Result? GetResultCode()
		{
			return null;
		}
	}
}
