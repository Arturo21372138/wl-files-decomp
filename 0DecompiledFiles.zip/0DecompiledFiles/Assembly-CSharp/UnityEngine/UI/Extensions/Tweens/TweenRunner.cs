﻿using System;
using System.Collections;

namespace UnityEngine.UI.Extensions.Tweens
{
	// Token: 0x020000DD RID: 221
	internal class TweenRunner<T> where T : struct, ITweenValue
	{
		// Token: 0x06000745 RID: 1861 RVA: 0x00028E89 File Offset: 0x00027089
		private static IEnumerator Start(T tweenInfo)
		{
			if (!tweenInfo.ValidTarget())
			{
				yield break;
			}
			float elapsedTime = 0f;
			while (elapsedTime < tweenInfo.duration)
			{
				elapsedTime += (tweenInfo.ignoreTimeScale ? Time.unscaledDeltaTime : Time.deltaTime);
				float num = Mathf.Clamp01(elapsedTime / tweenInfo.duration);
				tweenInfo.TweenValue(num);
				yield return null;
			}
			tweenInfo.TweenValue(1f);
			tweenInfo.Finished();
			yield break;
		}

		// Token: 0x06000746 RID: 1862 RVA: 0x00028E98 File Offset: 0x00027098
		public void Init(MonoBehaviour coroutineContainer)
		{
			this.m_CoroutineContainer = coroutineContainer;
		}

		// Token: 0x06000747 RID: 1863 RVA: 0x00028EA4 File Offset: 0x000270A4
		public void StartTween(T info)
		{
			if (this.m_CoroutineContainer == null)
			{
				Debug.LogWarning("Coroutine container not configured... did you forget to call Init?");
				return;
			}
			if (this.m_Tween != null)
			{
				this.m_CoroutineContainer.StopCoroutine(this.m_Tween);
				this.m_Tween = null;
			}
			if (!this.m_CoroutineContainer.gameObject.activeInHierarchy)
			{
				info.TweenValue(1f);
				return;
			}
			this.m_Tween = TweenRunner<T>.Start(info);
			this.m_CoroutineContainer.StartCoroutine(this.m_Tween);
		}

		// Token: 0x0400054F RID: 1359
		protected MonoBehaviour m_CoroutineContainer;

		// Token: 0x04000550 RID: 1360
		protected IEnumerator m_Tween;
	}
}
