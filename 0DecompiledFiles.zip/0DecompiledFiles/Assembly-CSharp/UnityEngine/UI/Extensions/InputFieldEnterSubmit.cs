﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B2 RID: 178
	[RequireComponent(typeof(InputField))]
	[AddComponentMenu("UI/Extensions/Input Field Submit")]
	public class InputFieldEnterSubmit : MonoBehaviour
	{
		// Token: 0x060005F5 RID: 1525 RVA: 0x00023D49 File Offset: 0x00021F49
		private void Awake()
		{
			this._input = base.GetComponent<InputField>();
			this._input.onEndEdit.AddListener(new UnityAction<string>(this.OnEndEdit));
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x00023D73 File Offset: 0x00021F73
		public void OnEndEdit(string txt)
		{
			if (!UIExtensionsInputManager.GetKeyDown(KeyCode.Return) && !UIExtensionsInputManager.GetKeyDown(KeyCode.KeypadEnter))
			{
				return;
			}
			this.EnterSubmit.Invoke(txt);
			if (this.defocusInput)
			{
				EventSystem.current.SetSelectedGameObject(null);
			}
		}

		// Token: 0x04000469 RID: 1129
		public InputFieldEnterSubmit.EnterSubmitEvent EnterSubmit;

		// Token: 0x0400046A RID: 1130
		public bool defocusInput = true;

		// Token: 0x0400046B RID: 1131
		private InputField _input;

		// Token: 0x0200014B RID: 331
		[Serializable]
		public class EnterSubmitEvent : UnityEvent<string>
		{
		}
	}
}
