﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200007C RID: 124
	public interface IFancyCellGroupContext
	{
		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060003AB RID: 939
		// (set) Token: 0x060003AC RID: 940
		GameObject CellTemplate { get; set; }

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060003AD RID: 941
		// (set) Token: 0x060003AE RID: 942
		Func<int> GetGroupCount { get; set; }
	}
}
