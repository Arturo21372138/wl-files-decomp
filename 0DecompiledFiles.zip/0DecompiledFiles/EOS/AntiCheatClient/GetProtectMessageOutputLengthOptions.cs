﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B7 RID: 1975
	public struct GetProtectMessageOutputLengthOptions
	{
		// Token: 0x1700081B RID: 2075
		// (get) Token: 0x060020A9 RID: 8361 RVA: 0x00027036 File Offset: 0x00025236
		// (set) Token: 0x060020AA RID: 8362 RVA: 0x0002703E File Offset: 0x0002523E
		public uint DataLengthBytes { readonly get; set; }
	}
}
