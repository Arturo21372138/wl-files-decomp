﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000031 RID: 49
	public enum AutoCompleteSearchType
	{
		// Token: 0x040000D1 RID: 209
		ArraySort,
		// Token: 0x040000D2 RID: 210
		Linq
	}
}
