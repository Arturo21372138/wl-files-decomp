﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200005D RID: 93
	[AddComponentMenu("UI/Effects/Extensions/UIAdditiveEffect")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class UIAdditiveEffect : MonoBehaviour
	{
		// Token: 0x060002D8 RID: 728 RVA: 0x000121D8 File Offset: 0x000103D8
		private void Start()
		{
			this.SetMaterial();
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x000121E0 File Offset: 0x000103E0
		public void SetMaterial()
		{
			this.mGraphic = base.GetComponent<MaskableGraphic>();
			if (this.mGraphic != null)
			{
				if (this.mGraphic.material == null || this.mGraphic.material.name == "Default UI Material")
				{
					this.mGraphic.material = new Material(ShaderLibrary.GetShaderInstance("UI Extensions/UIAdditive"));
					return;
				}
			}
			else
			{
				Debug.LogError("Please attach component to a Graphical UI component");
			}
		}

		// Token: 0x060002DA RID: 730 RVA: 0x0001225B File Offset: 0x0001045B
		public void OnValidate()
		{
			this.SetMaterial();
		}

		// Token: 0x04000239 RID: 569
		private MaskableGraphic mGraphic;
	}
}
