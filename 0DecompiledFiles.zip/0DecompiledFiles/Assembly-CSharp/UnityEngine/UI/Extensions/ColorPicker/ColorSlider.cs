﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D4 RID: 212
	[RequireComponent(typeof(Slider))]
	public class ColorSlider : MonoBehaviour
	{
		// Token: 0x06000707 RID: 1799 RVA: 0x00027C68 File Offset: 0x00025E68
		private void Awake()
		{
			this.slider = base.GetComponent<Slider>();
			this.ColorPicker.onValueChanged.AddListener(new UnityAction<Color>(this.ColorChanged));
			this.ColorPicker.onHSVChanged.AddListener(new UnityAction<float, float, float>(this.HSVChanged));
			this.slider.onValueChanged.AddListener(new UnityAction<float>(this.SliderChanged));
		}

		// Token: 0x06000708 RID: 1800 RVA: 0x00027CD8 File Offset: 0x00025ED8
		private void OnDestroy()
		{
			this.ColorPicker.onValueChanged.RemoveListener(new UnityAction<Color>(this.ColorChanged));
			this.ColorPicker.onHSVChanged.RemoveListener(new UnityAction<float, float, float>(this.HSVChanged));
			this.slider.onValueChanged.RemoveListener(new UnityAction<float>(this.SliderChanged));
		}

		// Token: 0x06000709 RID: 1801 RVA: 0x00027D3C File Offset: 0x00025F3C
		private void ColorChanged(Color newColor)
		{
			this.listen = false;
			switch (this.type)
			{
			case ColorValues.R:
				this.slider.normalizedValue = newColor.r;
				return;
			case ColorValues.G:
				this.slider.normalizedValue = newColor.g;
				return;
			case ColorValues.B:
				this.slider.normalizedValue = newColor.b;
				return;
			case ColorValues.A:
				this.slider.normalizedValue = newColor.a;
				return;
			default:
				return;
			}
		}

		// Token: 0x0600070A RID: 1802 RVA: 0x00027DB8 File Offset: 0x00025FB8
		private void HSVChanged(float hue, float saturation, float value)
		{
			this.listen = false;
			switch (this.type)
			{
			case ColorValues.Hue:
				this.slider.normalizedValue = hue;
				return;
			case ColorValues.Saturation:
				this.slider.normalizedValue = saturation;
				return;
			case ColorValues.Value:
				this.slider.normalizedValue = value;
				return;
			default:
				return;
			}
		}

		// Token: 0x0600070B RID: 1803 RVA: 0x00027E0E File Offset: 0x0002600E
		private void SliderChanged(float newValue)
		{
			if (this.listen)
			{
				newValue = this.slider.normalizedValue;
				this.ColorPicker.AssignColor(this.type, newValue);
			}
			this.listen = true;
		}

		// Token: 0x0400052D RID: 1325
		public ColorPickerControl ColorPicker;

		// Token: 0x0400052E RID: 1326
		public ColorValues type;

		// Token: 0x0400052F RID: 1327
		private Slider slider;

		// Token: 0x04000530 RID: 1328
		private bool listen = true;
	}
}
