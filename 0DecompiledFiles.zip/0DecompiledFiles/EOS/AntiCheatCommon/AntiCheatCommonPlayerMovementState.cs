﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000774 RID: 1908
	public enum AntiCheatCommonPlayerMovementState
	{
		// Token: 0x040014B7 RID: 5303
		None,
		// Token: 0x040014B8 RID: 5304
		Crouching,
		// Token: 0x040014B9 RID: 5305
		Prone,
		// Token: 0x040014BA RID: 5306
		Mounted,
		// Token: 0x040014BB RID: 5307
		Swimming,
		// Token: 0x040014BC RID: 5308
		Falling,
		// Token: 0x040014BD RID: 5309
		Flying,
		// Token: 0x040014BE RID: 5310
		OnLadder
	}
}
