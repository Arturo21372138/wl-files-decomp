﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C1 RID: 193
	public static class UIExtensionsInputManager
	{
		// Token: 0x06000642 RID: 1602 RVA: 0x00024CAD File Offset: 0x00022EAD
		public static bool GetMouseButton(int button)
		{
			return Input.GetMouseButton(button);
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x00024CB5 File Offset: 0x00022EB5
		public static bool GetMouseButtonDown(int button)
		{
			return Input.GetMouseButtonDown(button);
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x00024CBD File Offset: 0x00022EBD
		public static bool GetMouseButtonUp(int button)
		{
			return Input.GetMouseButtonUp(button);
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x00024CC5 File Offset: 0x00022EC5
		public static bool GetButton(string input)
		{
			return Input.GetButton(input);
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x00024CCD File Offset: 0x00022ECD
		public static bool GetButtonDown(string input)
		{
			return Input.GetButtonDown(input);
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x00024CD5 File Offset: 0x00022ED5
		public static bool GetButtonUp(string input)
		{
			return Input.GetButtonUp(input);
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x00024CDD File Offset: 0x00022EDD
		public static bool GetKey(KeyCode key)
		{
			return Input.GetKey(key);
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00024CE5 File Offset: 0x00022EE5
		public static bool GetKeyDown(KeyCode key)
		{
			return Input.GetKeyDown(key);
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x00024CED File Offset: 0x00022EED
		public static bool GetKeyUp(KeyCode key)
		{
			return Input.GetKeyUp(key);
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00024CF5 File Offset: 0x00022EF5
		public static float GetAxisRaw(string axis)
		{
			return Input.GetAxisRaw(axis);
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x0600064C RID: 1612 RVA: 0x00024CFD File Offset: 0x00022EFD
		public static Vector3 MousePosition
		{
			get
			{
				return Input.mousePosition;
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x0600064D RID: 1613 RVA: 0x00024D04 File Offset: 0x00022F04
		public static Vector3 MouseScrollDelta
		{
			get
			{
				return Input.mouseScrollDelta;
			}
		}
	}
}
