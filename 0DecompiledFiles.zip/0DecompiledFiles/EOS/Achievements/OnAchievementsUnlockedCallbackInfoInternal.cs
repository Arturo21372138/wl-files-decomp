﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007FF RID: 2047
	internal struct OnAchievementsUnlockedCallbackInfoInternal : ICallbackInfoInternal, IGettable<OnAchievementsUnlockedCallbackInfo>
	{
		// Token: 0x17000861 RID: 2145
		// (get) Token: 0x060021AC RID: 8620 RVA: 0x00028272 File Offset: 0x00026472
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x060021AD RID: 8621 RVA: 0x0002827C File Offset: 0x0002647C
		public void Get(out OnAchievementsUnlockedCallbackInfo other)
		{
			other = default(OnAchievementsUnlockedCallbackInfo);
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
			ProductUserId productUserId;
			Helper.Get<ProductUserId>(this.m_UserId, out productUserId);
			other.UserId = productUserId;
			Utf8String[] array;
			Helper.Get(this.m_AchievementIds, out array, this.m_AchievementsCount, true);
			other.AchievementIds = array;
		}

		// Token: 0x04001687 RID: 5767
		private IntPtr m_ClientData;

		// Token: 0x04001688 RID: 5768
		private IntPtr m_UserId;

		// Token: 0x04001689 RID: 5769
		private uint m_AchievementsCount;

		// Token: 0x0400168A RID: 5770
		private IntPtr m_AchievementIds;
	}
}
