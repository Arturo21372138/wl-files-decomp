﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace Cinemachine
{
	// Token: 0x02000036 RID: 54
	[DocumentationSorting(DocumentationSortingAttribute.Level.API)]
	public abstract class CinemachineExtension : MonoBehaviour
	{
		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000292 RID: 658 RVA: 0x00012332 File Offset: 0x00010532
		public CinemachineVirtualCameraBase VirtualCamera
		{
			get
			{
				if (this.m_vcamOwner == null)
				{
					this.m_vcamOwner = base.GetComponent<CinemachineVirtualCameraBase>();
				}
				return this.m_vcamOwner;
			}
		}

		// Token: 0x06000293 RID: 659 RVA: 0x00012354 File Offset: 0x00010554
		protected virtual void Awake()
		{
			this.ConnectToVcam(true);
		}

		// Token: 0x06000294 RID: 660 RVA: 0x0001235D File Offset: 0x0001055D
		protected virtual void OnEnable()
		{
		}

		// Token: 0x06000295 RID: 661 RVA: 0x0001235F File Offset: 0x0001055F
		protected virtual void OnDestroy()
		{
			this.ConnectToVcam(false);
		}

		// Token: 0x06000296 RID: 662 RVA: 0x00012368 File Offset: 0x00010568
		internal void EnsureStarted()
		{
			this.ConnectToVcam(true);
		}

		// Token: 0x06000297 RID: 663 RVA: 0x00012374 File Offset: 0x00010574
		protected virtual void ConnectToVcam(bool connect)
		{
			if (connect && this.VirtualCamera == null)
			{
				Debug.LogError("CinemachineExtension requires a Cinemachine Virtual Camera component");
			}
			if (this.VirtualCamera != null)
			{
				if (connect)
				{
					this.VirtualCamera.AddExtension(this);
				}
				else
				{
					this.VirtualCamera.RemoveExtension(this);
				}
			}
			this.mExtraState = null;
		}

		// Token: 0x06000298 RID: 664 RVA: 0x000123CE File Offset: 0x000105CE
		public virtual void PrePipelineMutateCameraStateCallback(CinemachineVirtualCameraBase vcam, ref CameraState curState, float deltaTime)
		{
		}

		// Token: 0x06000299 RID: 665 RVA: 0x000123D0 File Offset: 0x000105D0
		public void InvokePostPipelineStageCallback(CinemachineVirtualCameraBase vcam, CinemachineCore.Stage stage, ref CameraState state, float deltaTime)
		{
			this.PostPipelineStageCallback(vcam, stage, ref state, deltaTime);
		}

		// Token: 0x0600029A RID: 666
		protected abstract void PostPipelineStageCallback(CinemachineVirtualCameraBase vcam, CinemachineCore.Stage stage, ref CameraState state, float deltaTime);

		// Token: 0x0600029B RID: 667 RVA: 0x000123DD File Offset: 0x000105DD
		public virtual void OnTargetObjectWarped(Transform target, Vector3 positionDelta)
		{
		}

		// Token: 0x0600029C RID: 668 RVA: 0x000123DF File Offset: 0x000105DF
		public virtual void ForceCameraPosition(Vector3 pos, Quaternion rot)
		{
		}

		// Token: 0x0600029D RID: 669 RVA: 0x000123E1 File Offset: 0x000105E1
		public virtual bool OnTransitionFromCamera(ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime)
		{
			return false;
		}

		// Token: 0x0600029E RID: 670 RVA: 0x000123E4 File Offset: 0x000105E4
		public virtual float GetMaxDampTime()
		{
			return 0f;
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x0600029F RID: 671 RVA: 0x000123EB File Offset: 0x000105EB
		public virtual bool RequiresUserInput
		{
			get
			{
				return false;
			}
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x000123F0 File Offset: 0x000105F0
		protected T GetExtraState<T>(ICinemachineCamera vcam) where T : class, new()
		{
			if (this.mExtraState == null)
			{
				this.mExtraState = new Dictionary<ICinemachineCamera, object>();
			}
			object obj = null;
			if (!this.mExtraState.TryGetValue(vcam, out obj))
			{
				obj = (this.mExtraState[vcam] = new T());
			}
			return obj as T;
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00012448 File Offset: 0x00010648
		protected List<T> GetAllExtraStates<T>() where T : class, new()
		{
			List<T> list = new List<T>();
			if (this.mExtraState != null)
			{
				foreach (KeyValuePair<ICinemachineCamera, object> keyValuePair in this.mExtraState)
				{
					list.Add(keyValuePair.Value as T);
				}
			}
			return list;
		}

		// Token: 0x040001DE RID: 478
		protected const float Epsilon = 0.0001f;

		// Token: 0x040001DF RID: 479
		private CinemachineVirtualCameraBase m_vcamOwner;

		// Token: 0x040001E0 RID: 480
		private Dictionary<ICinemachineCamera, object> mExtraState;
	}
}
