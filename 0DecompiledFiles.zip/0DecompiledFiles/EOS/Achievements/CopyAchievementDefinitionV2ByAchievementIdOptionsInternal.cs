﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E6 RID: 2022
	internal struct CopyAchievementDefinitionV2ByAchievementIdOptionsInternal : ISettable<CopyAchievementDefinitionV2ByAchievementIdOptions>, IDisposable
	{
		// Token: 0x06002142 RID: 8514 RVA: 0x00027BB4 File Offset: 0x00025DB4
		public void Set(ref CopyAchievementDefinitionV2ByAchievementIdOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 2;
			Helper.Set(other.AchievementId, ref this.m_AchievementId);
		}

		// Token: 0x06002143 RID: 8515 RVA: 0x00027BD4 File Offset: 0x00025DD4
		public void Dispose()
		{
			Helper.Dispose(ref this.m_AchievementId);
		}

		// Token: 0x04001631 RID: 5681
		private int m_ApiVersion;

		// Token: 0x04001632 RID: 5682
		private IntPtr m_AchievementId;
	}
}
