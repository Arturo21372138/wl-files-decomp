﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D7 RID: 2007
	internal struct Reserved01OptionsInternal : ISettable<Reserved01Options>, IDisposable
	{
		// Token: 0x06002115 RID: 8469 RVA: 0x00027524 File Offset: 0x00025724
		public void Set(ref Reserved01Options other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002116 RID: 8470 RVA: 0x00027533 File Offset: 0x00025733
		public void Dispose()
		{
		}

		// Token: 0x04001604 RID: 5636
		private int m_ApiVersion;
	}
}
