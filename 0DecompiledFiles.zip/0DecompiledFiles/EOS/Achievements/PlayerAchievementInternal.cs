﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000815 RID: 2069
	internal struct PlayerAchievementInternal : IGettable<PlayerAchievement>
	{
		// Token: 0x06002212 RID: 8722 RVA: 0x0002871C File Offset: 0x0002691C
		public void Get(out PlayerAchievement other)
		{
			other = default(PlayerAchievement);
			Utf8String utf8String;
			Helper.Get(this.m_AchievementId, out utf8String);
			other.AchievementId = utf8String;
			other.Progress = this.m_Progress;
			DateTimeOffset? dateTimeOffset;
			Helper.Get(this.m_UnlockTime, out dateTimeOffset);
			other.UnlockTime = dateTimeOffset;
			PlayerStatInfo[] array;
			Helper.Get<PlayerStatInfoInternal, PlayerStatInfo>(this.m_StatInfo, out array, this.m_StatInfoCount, false);
			other.StatInfo = array;
			Utf8String utf8String2;
			Helper.Get(this.m_DisplayName, out utf8String2);
			other.DisplayName = utf8String2;
			Utf8String utf8String3;
			Helper.Get(this.m_Description, out utf8String3);
			other.Description = utf8String3;
			Utf8String utf8String4;
			Helper.Get(this.m_IconURL, out utf8String4);
			other.IconURL = utf8String4;
			Utf8String utf8String5;
			Helper.Get(this.m_FlavorText, out utf8String5);
			other.FlavorText = utf8String5;
		}

		// Token: 0x040016B3 RID: 5811
		private int m_ApiVersion;

		// Token: 0x040016B4 RID: 5812
		private IntPtr m_AchievementId;

		// Token: 0x040016B5 RID: 5813
		private double m_Progress;

		// Token: 0x040016B6 RID: 5814
		private long m_UnlockTime;

		// Token: 0x040016B7 RID: 5815
		private int m_StatInfoCount;

		// Token: 0x040016B8 RID: 5816
		private IntPtr m_StatInfo;

		// Token: 0x040016B9 RID: 5817
		private IntPtr m_DisplayName;

		// Token: 0x040016BA RID: 5818
		private IntPtr m_Description;

		// Token: 0x040016BB RID: 5819
		private IntPtr m_IconURL;

		// Token: 0x040016BC RID: 5820
		private IntPtr m_FlavorText;
	}
}
