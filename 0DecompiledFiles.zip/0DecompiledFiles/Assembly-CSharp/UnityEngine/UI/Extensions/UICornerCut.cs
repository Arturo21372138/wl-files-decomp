﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200009B RID: 155
	[AddComponentMenu("UI/Extensions/Primitives/Cut Corners")]
	public class UICornerCut : UIPrimitiveBase
	{
		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x06000503 RID: 1283 RVA: 0x0001D9D5 File Offset: 0x0001BBD5
		// (set) Token: 0x06000504 RID: 1284 RVA: 0x0001D9DD File Offset: 0x0001BBDD
		public bool CutUL
		{
			get
			{
				return this.m_cutUL;
			}
			set
			{
				this.m_cutUL = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x06000505 RID: 1285 RVA: 0x0001D9EC File Offset: 0x0001BBEC
		// (set) Token: 0x06000506 RID: 1286 RVA: 0x0001D9F4 File Offset: 0x0001BBF4
		public bool CutUR
		{
			get
			{
				return this.m_cutUR;
			}
			set
			{
				this.m_cutUR = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x06000507 RID: 1287 RVA: 0x0001DA03 File Offset: 0x0001BC03
		// (set) Token: 0x06000508 RID: 1288 RVA: 0x0001DA0B File Offset: 0x0001BC0B
		public bool CutLL
		{
			get
			{
				return this.m_cutLL;
			}
			set
			{
				this.m_cutLL = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x06000509 RID: 1289 RVA: 0x0001DA1A File Offset: 0x0001BC1A
		// (set) Token: 0x0600050A RID: 1290 RVA: 0x0001DA22 File Offset: 0x0001BC22
		public bool CutLR
		{
			get
			{
				return this.m_cutLR;
			}
			set
			{
				this.m_cutLR = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x0600050B RID: 1291 RVA: 0x0001DA31 File Offset: 0x0001BC31
		// (set) Token: 0x0600050C RID: 1292 RVA: 0x0001DA39 File Offset: 0x0001BC39
		public bool MakeColumns
		{
			get
			{
				return this.m_makeColumns;
			}
			set
			{
				this.m_makeColumns = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x0600050D RID: 1293 RVA: 0x0001DA48 File Offset: 0x0001BC48
		// (set) Token: 0x0600050E RID: 1294 RVA: 0x0001DA50 File Offset: 0x0001BC50
		public bool UseColorUp
		{
			get
			{
				return this.m_useColorUp;
			}
			set
			{
				this.m_useColorUp = value;
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x0600050F RID: 1295 RVA: 0x0001DA59 File Offset: 0x0001BC59
		// (set) Token: 0x06000510 RID: 1296 RVA: 0x0001DA61 File Offset: 0x0001BC61
		public Color32 ColorUp
		{
			get
			{
				return this.m_colorUp;
			}
			set
			{
				this.m_colorUp = value;
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x06000511 RID: 1297 RVA: 0x0001DA6A File Offset: 0x0001BC6A
		// (set) Token: 0x06000512 RID: 1298 RVA: 0x0001DA72 File Offset: 0x0001BC72
		public bool UseColorDown
		{
			get
			{
				return this.m_useColorDown;
			}
			set
			{
				this.m_useColorDown = value;
			}
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x06000513 RID: 1299 RVA: 0x0001DA7B File Offset: 0x0001BC7B
		// (set) Token: 0x06000514 RID: 1300 RVA: 0x0001DA83 File Offset: 0x0001BC83
		public Color32 ColorDown
		{
			get
			{
				return this.m_colorDown;
			}
			set
			{
				this.m_colorDown = value;
			}
		}

		// Token: 0x06000515 RID: 1301 RVA: 0x0001DA8C File Offset: 0x0001BC8C
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			Rect rect = base.rectTransform.rect;
			Rect rect2 = rect;
			Color32 color = this.color;
			bool flag = this.m_cutUL | this.m_cutUR;
			bool flag2 = this.m_cutLL | this.m_cutLR;
			bool flag3 = this.m_cutLL | this.m_cutUL;
			bool flag4 = this.m_cutLR | this.m_cutUR;
			if ((flag || flag2) && this.cornerSize.sqrMagnitude > 0f)
			{
				vh.Clear();
				if (flag3)
				{
					rect2.xMin += this.cornerSize.x;
				}
				if (flag2)
				{
					rect2.yMin += this.cornerSize.y;
				}
				if (flag)
				{
					rect2.yMax -= this.cornerSize.y;
				}
				if (flag4)
				{
					rect2.xMax -= this.cornerSize.x;
				}
				if (this.m_makeColumns)
				{
					Vector2 vector = new Vector2(rect.xMin, this.m_cutUL ? rect2.yMax : rect.yMax);
					Vector2 vector2 = new Vector2(rect.xMax, this.m_cutUR ? rect2.yMax : rect.yMax);
					Vector2 vector3 = new Vector2(rect.xMin, this.m_cutLL ? rect2.yMin : rect.yMin);
					Vector2 vector4 = new Vector2(rect.xMax, this.m_cutLR ? rect2.yMin : rect.yMin);
					if (flag3)
					{
						UICornerCut.AddSquare(vector3, vector, new Vector2(rect2.xMin, rect.yMax), new Vector2(rect2.xMin, rect.yMin), rect, this.m_useColorUp ? this.m_colorUp : color, vh);
					}
					if (flag4)
					{
						UICornerCut.AddSquare(vector2, vector4, new Vector2(rect2.xMax, rect.yMin), new Vector2(rect2.xMax, rect.yMax), rect, this.m_useColorDown ? this.m_colorDown : color, vh);
					}
				}
				else
				{
					Vector2 vector = new Vector2(this.m_cutUL ? rect2.xMin : rect.xMin, rect.yMax);
					Vector2 vector2 = new Vector2(this.m_cutUR ? rect2.xMax : rect.xMax, rect.yMax);
					Vector2 vector3 = new Vector2(this.m_cutLL ? rect2.xMin : rect.xMin, rect.yMin);
					Vector2 vector4 = new Vector2(this.m_cutLR ? rect2.xMax : rect.xMax, rect.yMin);
					if (flag2)
					{
						UICornerCut.AddSquare(vector4, vector3, new Vector2(rect.xMin, rect2.yMin), new Vector2(rect.xMax, rect2.yMin), rect, this.m_useColorDown ? this.m_colorDown : color, vh);
					}
					if (flag)
					{
						UICornerCut.AddSquare(vector, vector2, new Vector2(rect.xMax, rect2.yMax), new Vector2(rect.xMin, rect2.yMax), rect, this.m_useColorUp ? this.m_colorUp : color, vh);
					}
				}
				if (this.m_makeColumns)
				{
					UICornerCut.AddSquare(new Rect(rect2.xMin, rect.yMin, rect2.width, rect.height), rect, color, vh);
					return;
				}
				UICornerCut.AddSquare(new Rect(rect.xMin, rect2.yMin, rect.width, rect2.height), rect, color, vh);
			}
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x0001DE3C File Offset: 0x0001C03C
		private static void AddSquare(Rect rect, Rect rectUV, Color32 color32, VertexHelper vh)
		{
			int num = UICornerCut.AddVert(rect.xMin, rect.yMin, rectUV, color32, vh);
			int num2 = UICornerCut.AddVert(rect.xMin, rect.yMax, rectUV, color32, vh);
			int num3 = UICornerCut.AddVert(rect.xMax, rect.yMax, rectUV, color32, vh);
			int num4 = UICornerCut.AddVert(rect.xMax, rect.yMin, rectUV, color32, vh);
			vh.AddTriangle(num, num2, num3);
			vh.AddTriangle(num3, num4, num);
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0001DEB8 File Offset: 0x0001C0B8
		private static void AddSquare(Vector2 a, Vector2 b, Vector2 c, Vector2 d, Rect rectUV, Color32 color32, VertexHelper vh)
		{
			int num = UICornerCut.AddVert(a.x, a.y, rectUV, color32, vh);
			int num2 = UICornerCut.AddVert(b.x, b.y, rectUV, color32, vh);
			int num3 = UICornerCut.AddVert(c.x, c.y, rectUV, color32, vh);
			int num4 = UICornerCut.AddVert(d.x, d.y, rectUV, color32, vh);
			vh.AddTriangle(num, num2, num3);
			vh.AddTriangle(num3, num4, num);
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x0001DF3C File Offset: 0x0001C13C
		private static int AddVert(float x, float y, Rect area, Color32 color32, VertexHelper vh)
		{
			Vector2 vector = new Vector2(Mathf.InverseLerp(area.xMin, area.xMax, x), Mathf.InverseLerp(area.yMin, area.yMax, y));
			vh.AddVert(new Vector3(x, y), color32, vector);
			return vh.currentVertCount - 1;
		}

		// Token: 0x040003B1 RID: 945
		public Vector2 cornerSize = new Vector2(16f, 16f);

		// Token: 0x040003B2 RID: 946
		[Header("Corners to cut")]
		[SerializeField]
		private bool m_cutUL = true;

		// Token: 0x040003B3 RID: 947
		[SerializeField]
		private bool m_cutUR;

		// Token: 0x040003B4 RID: 948
		[SerializeField]
		private bool m_cutLL;

		// Token: 0x040003B5 RID: 949
		[SerializeField]
		private bool m_cutLR;

		// Token: 0x040003B6 RID: 950
		[Tooltip("Up-Down colors become Left-Right colors")]
		[SerializeField]
		private bool m_makeColumns;

		// Token: 0x040003B7 RID: 951
		[Header("Color the cut bars differently")]
		[SerializeField]
		private bool m_useColorUp;

		// Token: 0x040003B8 RID: 952
		[SerializeField]
		private Color32 m_colorUp;

		// Token: 0x040003B9 RID: 953
		[SerializeField]
		private bool m_useColorDown;

		// Token: 0x040003BA RID: 954
		[SerializeField]
		private Color32 m_colorDown;
	}
}
