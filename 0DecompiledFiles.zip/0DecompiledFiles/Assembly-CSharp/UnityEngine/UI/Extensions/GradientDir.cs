﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000057 RID: 87
	public enum GradientDir
	{
		// Token: 0x04000223 RID: 547
		Vertical,
		// Token: 0x04000224 RID: 548
		Horizontal,
		// Token: 0x04000225 RID: 549
		DiagonalLeftToRight,
		// Token: 0x04000226 RID: 550
		DiagonalRightToLeft
	}
}
