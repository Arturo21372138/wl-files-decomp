﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007A5 RID: 1957
	internal struct AddExternalIntegrityCatalogOptionsInternal : ISettable<AddExternalIntegrityCatalogOptions>, IDisposable
	{
		// Token: 0x0600207C RID: 8316 RVA: 0x00026A13 File Offset: 0x00024C13
		public void Set(ref AddExternalIntegrityCatalogOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.PathToBinFile, ref this.m_PathToBinFile);
		}

		// Token: 0x0600207D RID: 8317 RVA: 0x00026A33 File Offset: 0x00024C33
		public void Dispose()
		{
			Helper.Dispose(ref this.m_PathToBinFile);
		}

		// Token: 0x04001597 RID: 5527
		private int m_ApiVersion;

		// Token: 0x04001598 RID: 5528
		private IntPtr m_PathToBinFile;
	}
}
