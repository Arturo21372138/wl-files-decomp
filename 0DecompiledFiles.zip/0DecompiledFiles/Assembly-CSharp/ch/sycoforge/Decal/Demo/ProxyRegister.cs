﻿using System;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000026 RID: 38
	public class ProxyRegister : MonoBehaviour
	{
		// Token: 0x06000076 RID: 118 RVA: 0x00004F0C File Offset: 0x0000310C
		private void Start()
		{
			EasyDecal.SetStaticProxyCollection(this.ProxyCollection);
		}

		// Token: 0x040000A1 RID: 161
		public StaticProxyCollection ProxyCollection;
	}
}
