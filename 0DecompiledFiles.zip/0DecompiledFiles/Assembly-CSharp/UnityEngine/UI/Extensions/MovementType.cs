﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200007F RID: 127
	public enum MovementType
	{
		// Token: 0x040002E5 RID: 741
		Unrestricted,
		// Token: 0x040002E6 RID: 742
		Elastic,
		// Token: 0x040002E7 RID: 743
		Clamped
	}
}
