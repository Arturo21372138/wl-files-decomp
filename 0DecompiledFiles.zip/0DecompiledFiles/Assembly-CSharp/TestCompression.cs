﻿using System;
using UnityEngine;

// Token: 0x0200000A RID: 10
public class TestCompression : MonoBehaviour
{
	// Token: 0x06000016 RID: 22 RVA: 0x00002896 File Offset: 0x00000A96
	private void Start()
	{
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00002898 File Offset: 0x00000A98
	private void Update()
	{
	}
}
