﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000817 RID: 2071
	internal struct PlayerStatInfoInternal : IGettable<PlayerStatInfo>
	{
		// Token: 0x06002219 RID: 8729 RVA: 0x00028808 File Offset: 0x00026A08
		public void Get(out PlayerStatInfo other)
		{
			other = default(PlayerStatInfo);
			Utf8String utf8String;
			Helper.Get(this.m_Name, out utf8String);
			other.Name = utf8String;
			other.CurrentValue = this.m_CurrentValue;
			other.ThresholdValue = this.m_ThresholdValue;
		}

		// Token: 0x040016C0 RID: 5824
		private int m_ApiVersion;

		// Token: 0x040016C1 RID: 5825
		private IntPtr m_Name;

		// Token: 0x040016C2 RID: 5826
		private int m_CurrentValue;

		// Token: 0x040016C3 RID: 5827
		private int m_ThresholdValue;
	}
}
