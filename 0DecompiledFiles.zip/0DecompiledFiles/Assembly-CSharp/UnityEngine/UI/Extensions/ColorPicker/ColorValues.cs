﻿using System;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D6 RID: 214
	public enum ColorValues
	{
		// Token: 0x04000536 RID: 1334
		R,
		// Token: 0x04000537 RID: 1335
		G,
		// Token: 0x04000538 RID: 1336
		B,
		// Token: 0x04000539 RID: 1337
		A,
		// Token: 0x0400053A RID: 1338
		Hue,
		// Token: 0x0400053B RID: 1339
		Saturation,
		// Token: 0x0400053C RID: 1340
		Value
	}
}
