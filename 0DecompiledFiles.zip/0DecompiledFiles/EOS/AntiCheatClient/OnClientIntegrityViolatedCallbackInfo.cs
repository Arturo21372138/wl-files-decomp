﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007BC RID: 1980
	public struct OnClientIntegrityViolatedCallbackInfo : ICallbackInfo
	{
		// Token: 0x1700081D RID: 2077
		// (get) Token: 0x060020B7 RID: 8375 RVA: 0x000270A5 File Offset: 0x000252A5
		// (set) Token: 0x060020B8 RID: 8376 RVA: 0x000270AD File Offset: 0x000252AD
		public object ClientData { readonly get; set; }

		// Token: 0x1700081E RID: 2078
		// (get) Token: 0x060020B9 RID: 8377 RVA: 0x000270B6 File Offset: 0x000252B6
		// (set) Token: 0x060020BA RID: 8378 RVA: 0x000270BE File Offset: 0x000252BE
		public AntiCheatClientViolationType ViolationType { readonly get; set; }

		// Token: 0x1700081F RID: 2079
		// (get) Token: 0x060020BB RID: 8379 RVA: 0x000270C7 File Offset: 0x000252C7
		// (set) Token: 0x060020BC RID: 8380 RVA: 0x000270CF File Offset: 0x000252CF
		public Utf8String ViolationMessage { readonly get; set; }

		// Token: 0x060020BD RID: 8381 RVA: 0x000270D8 File Offset: 0x000252D8
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060020BE RID: 8382 RVA: 0x000270E0 File Offset: 0x000252E0
		public Result? GetResultCode()
		{
			return null;
		}
	}
}
