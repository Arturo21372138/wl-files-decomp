﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000053 RID: 83
	[RequireComponent(typeof(Text), typeof(RectTransform))]
	[AddComponentMenu("UI/Effects/Extensions/Curved Text")]
	public class CurvedText : BaseMeshEffect
	{
		// Token: 0x1700006C RID: 108
		// (get) Token: 0x06000293 RID: 659 RVA: 0x0000FB92 File Offset: 0x0000DD92
		// (set) Token: 0x06000294 RID: 660 RVA: 0x0000FB9A File Offset: 0x0000DD9A
		public AnimationCurve CurveForText
		{
			get
			{
				return this._curveForText;
			}
			set
			{
				this._curveForText = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000295 RID: 661 RVA: 0x0000FBAE File Offset: 0x0000DDAE
		// (set) Token: 0x06000296 RID: 662 RVA: 0x0000FBB6 File Offset: 0x0000DDB6
		public float CurveMultiplier
		{
			get
			{
				return this._curveMultiplier;
			}
			set
			{
				this._curveMultiplier = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x06000297 RID: 663 RVA: 0x0000FBCA File Offset: 0x0000DDCA
		protected override void Awake()
		{
			base.Awake();
			this.rectTrans = base.GetComponent<RectTransform>();
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x06000298 RID: 664 RVA: 0x0000FBE4 File Offset: 0x0000DDE4
		protected override void OnEnable()
		{
			base.OnEnable();
			this.rectTrans = base.GetComponent<RectTransform>();
			this.OnRectTransformDimensionsChange();
		}

		// Token: 0x06000299 RID: 665 RVA: 0x0000FC00 File Offset: 0x0000DE00
		public override void ModifyMesh(VertexHelper vh)
		{
			int currentVertCount = vh.currentVertCount;
			if (!this.IsActive() || currentVertCount == 0)
			{
				return;
			}
			for (int i = 0; i < vh.currentVertCount; i++)
			{
				UIVertex uivertex = default(UIVertex);
				vh.PopulateUIVertex(ref uivertex, i);
				uivertex.position.y = uivertex.position.y + this._curveForText.Evaluate(this.rectTrans.rect.width * this.rectTrans.pivot.x + uivertex.position.x) * this._curveMultiplier;
				vh.SetUIVertex(uivertex, i);
			}
		}

		// Token: 0x0600029A RID: 666 RVA: 0x0000FC9C File Offset: 0x0000DE9C
		protected override void OnRectTransformDimensionsChange()
		{
			if (this.rectTrans)
			{
				Keyframe keyframe = this._curveForText[this._curveForText.length - 1];
				keyframe.time = this.rectTrans.rect.width;
				this._curveForText.MoveKey(this._curveForText.length - 1, keyframe);
			}
		}

		// Token: 0x04000215 RID: 533
		[SerializeField]
		private AnimationCurve _curveForText = AnimationCurve.Linear(0f, 0f, 1f, 10f);

		// Token: 0x04000216 RID: 534
		[SerializeField]
		private float _curveMultiplier = 1f;

		// Token: 0x04000217 RID: 535
		private RectTransform rectTrans;
	}
}
