﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000804 RID: 2052
	internal struct OnAchievementsUnlockedCallbackV2InfoInternal : ICallbackInfoInternal, IGettable<OnAchievementsUnlockedCallbackV2Info>
	{
		// Token: 0x17000867 RID: 2151
		// (get) Token: 0x060021C2 RID: 8642 RVA: 0x0002837A File Offset: 0x0002657A
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x060021C3 RID: 8643 RVA: 0x00028384 File Offset: 0x00026584
		public void Get(out OnAchievementsUnlockedCallbackV2Info other)
		{
			other = default(OnAchievementsUnlockedCallbackV2Info);
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
			ProductUserId productUserId;
			Helper.Get<ProductUserId>(this.m_UserId, out productUserId);
			other.UserId = productUserId;
			Utf8String utf8String;
			Helper.Get(this.m_AchievementId, out utf8String);
			other.AchievementId = utf8String;
			DateTimeOffset? dateTimeOffset;
			Helper.Get(this.m_UnlockTime, out dateTimeOffset);
			other.UnlockTime = dateTimeOffset;
		}

		// Token: 0x04001690 RID: 5776
		private IntPtr m_ClientData;

		// Token: 0x04001691 RID: 5777
		private IntPtr m_UserId;

		// Token: 0x04001692 RID: 5778
		private IntPtr m_AchievementId;

		// Token: 0x04001693 RID: 5779
		private long m_UnlockTime;
	}
}
