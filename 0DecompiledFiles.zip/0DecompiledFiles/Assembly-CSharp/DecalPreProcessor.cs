﻿using System;
using ch.sycoforge.Decal;
using UnityEngine;

// Token: 0x0200000D RID: 13
[RequireComponent(typeof(EasyDecal))]
public class DecalPreProcessor : MonoBehaviour
{
	// Token: 0x0600001E RID: 30 RVA: 0x00002AD8 File Offset: 0x00000CD8
	private void Awake()
	{
		base.GetComponent<EasyDecal>().Distance = Random.Range(0.0001f, 0.001f);
	}
}
