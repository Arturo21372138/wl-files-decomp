﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B6 RID: 182
	public class ReadOnlyAttribute : PropertyAttribute
	{
	}
}
