﻿using System;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000027 RID: 39
	public class Sinoid : MonoBehaviour
	{
		// Token: 0x06000078 RID: 120 RVA: 0x00004F21 File Offset: 0x00003121
		private void Start()
		{
			this.startPos = base.transform.position;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00004F34 File Offset: 0x00003134
		private void Update()
		{
			this.accuTime += Time.deltaTime;
			base.transform.position = this.startPos + Vector3.up * this.Amplitude * Mathf.Sin(this.accuTime * 2f * 3.1415927f * this.SineFreq);
			base.transform.Rotate((Vector3.up + Vector3.forward) * this.AngularVelocity * Time.deltaTime);
		}

		// Token: 0x040000A2 RID: 162
		public float AngularVelocity = 2f;

		// Token: 0x040000A3 RID: 163
		public float SineFreq = 0.2f;

		// Token: 0x040000A4 RID: 164
		public float Amplitude = 0.25f;

		// Token: 0x040000A5 RID: 165
		private float accuTime;

		// Token: 0x040000A6 RID: 166
		private Vector3 startPos;
	}
}
