﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200009C RID: 156
	[AddComponentMenu("UI/Extensions/Primitives/UIGridRenderer")]
	public class UIGridRenderer : UILineRenderer
	{
		// Token: 0x170000DF RID: 223
		// (get) Token: 0x0600051A RID: 1306 RVA: 0x0001DFBA File Offset: 0x0001C1BA
		// (set) Token: 0x0600051B RID: 1307 RVA: 0x0001DFC2 File Offset: 0x0001C1C2
		public int GridColumns
		{
			get
			{
				return this.m_GridColumns;
			}
			set
			{
				if (this.m_GridColumns == value)
				{
					return;
				}
				this.m_GridColumns = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x0600051C RID: 1308 RVA: 0x0001DFDB File Offset: 0x0001C1DB
		// (set) Token: 0x0600051D RID: 1309 RVA: 0x0001DFE3 File Offset: 0x0001C1E3
		public int GridRows
		{
			get
			{
				return this.m_GridRows;
			}
			set
			{
				if (this.m_GridRows == value)
				{
					return;
				}
				this.m_GridRows = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x0001DFFC File Offset: 0x0001C1FC
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			this.relativeSize = true;
			int num = this.GridRows * 3 + 1;
			if (this.GridRows % 2 == 0)
			{
				num++;
			}
			num += this.GridColumns * 3 + 1;
			this.m_points = new Vector2[num];
			int num2 = 0;
			for (int i = 0; i < this.GridRows; i++)
			{
				float num3 = 1f;
				float num4 = 0f;
				if (i % 2 == 0)
				{
					num3 = 0f;
					num4 = 1f;
				}
				float num5 = (float)i / (float)this.GridRows;
				this.m_points[num2].x = num3;
				this.m_points[num2].y = num5;
				num2++;
				this.m_points[num2].x = num4;
				this.m_points[num2].y = num5;
				num2++;
				this.m_points[num2].x = num4;
				this.m_points[num2].y = (float)(i + 1) / (float)this.GridRows;
				num2++;
			}
			if (this.GridRows % 2 == 0)
			{
				this.m_points[num2].x = 1f;
				this.m_points[num2].y = 1f;
				num2++;
			}
			this.m_points[num2].x = 0f;
			this.m_points[num2].y = 1f;
			num2++;
			for (int j = 0; j < this.GridColumns; j++)
			{
				float num6 = 1f;
				float num7 = 0f;
				if (j % 2 == 0)
				{
					num6 = 0f;
					num7 = 1f;
				}
				float num8 = (float)j / (float)this.GridColumns;
				this.m_points[num2].x = num8;
				this.m_points[num2].y = num6;
				num2++;
				this.m_points[num2].x = num8;
				this.m_points[num2].y = num7;
				num2++;
				this.m_points[num2].x = (float)(j + 1) / (float)this.GridColumns;
				this.m_points[num2].y = num7;
				num2++;
			}
			if (this.GridColumns % 2 == 0)
			{
				this.m_points[num2].x = 1f;
				this.m_points[num2].y = 1f;
			}
			else
			{
				this.m_points[num2].x = 1f;
				this.m_points[num2].y = 0f;
			}
			base.OnPopulateMesh(vh);
		}

		// Token: 0x040003BB RID: 955
		[SerializeField]
		private int m_GridColumns = 10;

		// Token: 0x040003BC RID: 956
		[SerializeField]
		private int m_GridRows = 10;
	}
}
