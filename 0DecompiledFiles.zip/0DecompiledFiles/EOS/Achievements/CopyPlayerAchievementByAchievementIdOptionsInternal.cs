﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007EA RID: 2026
	internal struct CopyPlayerAchievementByAchievementIdOptionsInternal : ISettable<CopyPlayerAchievementByAchievementIdOptions>, IDisposable
	{
		// Token: 0x0600214E RID: 8526 RVA: 0x00027C44 File Offset: 0x00025E44
		public void Set(ref CopyPlayerAchievementByAchievementIdOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 2;
			Helper.Set(other.TargetUserId, ref this.m_TargetUserId);
			Helper.Set(other.AchievementId, ref this.m_AchievementId);
			Helper.Set(other.LocalUserId, ref this.m_LocalUserId);
		}

		// Token: 0x0600214F RID: 8527 RVA: 0x00027C91 File Offset: 0x00025E91
		public void Dispose()
		{
			Helper.Dispose(ref this.m_TargetUserId);
			Helper.Dispose(ref this.m_AchievementId);
			Helper.Dispose(ref this.m_LocalUserId);
		}

		// Token: 0x04001639 RID: 5689
		private int m_ApiVersion;

		// Token: 0x0400163A RID: 5690
		private IntPtr m_TargetUserId;

		// Token: 0x0400163B RID: 5691
		private IntPtr m_AchievementId;

		// Token: 0x0400163C RID: 5692
		private IntPtr m_LocalUserId;
	}
}
