﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007A9 RID: 1961
	internal struct AddNotifyMessageToPeerOptionsInternal : ISettable<AddNotifyMessageToPeerOptions>, IDisposable
	{
		// Token: 0x06002080 RID: 8320 RVA: 0x00026A51 File Offset: 0x00024C51
		public void Set(ref AddNotifyMessageToPeerOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002081 RID: 8321 RVA: 0x00026A60 File Offset: 0x00024C60
		public void Dispose()
		{
		}

		// Token: 0x0400159A RID: 5530
		private int m_ApiVersion;
	}
}
