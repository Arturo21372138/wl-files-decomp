﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000032 RID: 50
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/AutoComplete ComboBox")]
	public class AutoCompleteComboBox : MonoBehaviour
	{
		// Token: 0x17000014 RID: 20
		// (get) Token: 0x060000E1 RID: 225 RVA: 0x000060ED File Offset: 0x000042ED
		// (set) Token: 0x060000E2 RID: 226 RVA: 0x000060F5 File Offset: 0x000042F5
		public DropDownListItem SelectedItem { get; private set; }

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x060000E3 RID: 227 RVA: 0x000060FE File Offset: 0x000042FE
		// (set) Token: 0x060000E4 RID: 228 RVA: 0x00006106 File Offset: 0x00004306
		public string Text { get; private set; }

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x060000E5 RID: 229 RVA: 0x0000610F File Offset: 0x0000430F
		// (set) Token: 0x060000E6 RID: 230 RVA: 0x00006117 File Offset: 0x00004317
		public float ScrollBarWidth
		{
			get
			{
				return this._scrollBarWidth;
			}
			set
			{
				this._scrollBarWidth = value;
				this.RedrawPanel();
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000E7 RID: 231 RVA: 0x00006126 File Offset: 0x00004326
		// (set) Token: 0x060000E8 RID: 232 RVA: 0x0000612E File Offset: 0x0000432E
		public int ItemsToDisplay
		{
			get
			{
				return this._itemsToDisplay;
			}
			set
			{
				this._itemsToDisplay = value;
				this.RedrawPanel();
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000E9 RID: 233 RVA: 0x0000613D File Offset: 0x0000433D
		// (set) Token: 0x060000EA RID: 234 RVA: 0x00006145 File Offset: 0x00004345
		public bool InputColorMatching
		{
			get
			{
				return this._ChangeInputTextColorBasedOnMatchingItems;
			}
			set
			{
				this._ChangeInputTextColorBasedOnMatchingItems = value;
				if (this._ChangeInputTextColorBasedOnMatchingItems)
				{
					this.SetInputTextColor();
				}
			}
		}

		// Token: 0x060000EB RID: 235 RVA: 0x0000615C File Offset: 0x0000435C
		public void Awake()
		{
			this.Initialize();
		}

		// Token: 0x060000EC RID: 236 RVA: 0x00006165 File Offset: 0x00004365
		public void Start()
		{
			if (this.SelectFirstItemOnStart && this.AvailableOptions.Count > 0)
			{
				this.ToggleDropdownPanel(false);
				this.OnItemClicked(this.AvailableOptions[0]);
			}
		}

		// Token: 0x060000ED RID: 237 RVA: 0x00006198 File Offset: 0x00004398
		private bool Initialize()
		{
			bool flag = true;
			try
			{
				this._rectTransform = base.GetComponent<RectTransform>();
				this._inputRT = this._rectTransform.Find("InputField").GetComponent<RectTransform>();
				this._mainInput = this._inputRT.GetComponent<InputField>();
				this._overlayRT = this._rectTransform.Find("Overlay").GetComponent<RectTransform>();
				this._overlayRT.gameObject.SetActive(false);
				this._scrollPanelRT = this._overlayRT.Find("ScrollPanel").GetComponent<RectTransform>();
				this._scrollBarRT = this._scrollPanelRT.Find("Scrollbar").GetComponent<RectTransform>();
				this._slidingAreaRT = this._scrollBarRT.Find("SlidingArea").GetComponent<RectTransform>();
				this._itemsPanelRT = this._scrollPanelRT.Find("Items").GetComponent<RectTransform>();
				this._canvas = base.GetComponentInParent<Canvas>();
				this._canvasRT = this._canvas.GetComponent<RectTransform>();
				this._scrollRect = this._scrollPanelRT.GetComponent<ScrollRect>();
				this._scrollRect.scrollSensitivity = this._rectTransform.sizeDelta.y / 2f;
				this._scrollRect.movementType = ScrollRect.MovementType.Clamped;
				this._scrollRect.content = this._itemsPanelRT;
				this.itemTemplate = this._rectTransform.Find("ItemTemplate").gameObject;
				this.itemTemplate.SetActive(false);
			}
			catch (NullReferenceException ex)
			{
				Debug.LogException(ex);
				Debug.LogError("Something is setup incorrectly with the dropdownlist component causing a Null Reference Exception");
				flag = false;
			}
			this.panelObjects = new Dictionary<string, GameObject>();
			this._prunedPanelItems = new List<string>();
			this._panelItems = new List<string>();
			this.RebuildPanel();
			return flag;
		}

		// Token: 0x060000EE RID: 238 RVA: 0x00006364 File Offset: 0x00004564
		public void AddItem(string item)
		{
			this.AvailableOptions.Add(item);
			this.RebuildPanel();
		}

		// Token: 0x060000EF RID: 239 RVA: 0x00006378 File Offset: 0x00004578
		public void RemoveItem(string item)
		{
			this.AvailableOptions.Remove(item);
			this.RebuildPanel();
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x0000638D File Offset: 0x0000458D
		public void SetAvailableOptions(List<string> newOptions)
		{
			this.AvailableOptions.Clear();
			this.AvailableOptions = newOptions;
			this.RebuildPanel();
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x000063A8 File Offset: 0x000045A8
		public void SetAvailableOptions(string[] newOptions)
		{
			this.AvailableOptions.Clear();
			for (int i = 0; i < newOptions.Length; i++)
			{
				this.AvailableOptions.Add(newOptions[i]);
			}
			this.RebuildPanel();
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x000063E2 File Offset: 0x000045E2
		public void ResetItems()
		{
			this.AvailableOptions.Clear();
			this.RebuildPanel();
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x000063F8 File Offset: 0x000045F8
		private void RebuildPanel()
		{
			if (this._isPanelActive)
			{
				this.ToggleDropdownPanel(false);
			}
			this._panelItems.Clear();
			this._prunedPanelItems.Clear();
			this.panelObjects.Clear();
			foreach (object obj in this._itemsPanelRT.transform)
			{
				Object.Destroy(((Transform)obj).gameObject);
			}
			foreach (string text in this.AvailableOptions)
			{
				this._panelItems.Add(text.ToLower());
			}
			List<GameObject> list = new List<GameObject>(this.panelObjects.Values);
			int num = 0;
			while (list.Count < this.AvailableOptions.Count)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.itemTemplate);
				gameObject.name = "Item " + num.ToString();
				gameObject.transform.SetParent(this._itemsPanelRT, false);
				list.Add(gameObject);
				num++;
			}
			for (int i = 0; i < list.Count; i++)
			{
				list[i].SetActive(i <= this.AvailableOptions.Count);
				if (i < this.AvailableOptions.Count)
				{
					list[i].name = "Item " + i.ToString() + " " + this._panelItems[i];
					list[i].transform.Find("Text").GetComponent<Text>().text = this._panelItems[i];
					Button component = list[i].GetComponent<Button>();
					component.onClick.RemoveAllListeners();
					string textOfItem = this._panelItems[i];
					component.onClick.AddListener(delegate
					{
						this.OnItemClicked(textOfItem);
					});
					this.panelObjects[this._panelItems[i]] = list[i];
				}
			}
			this.SetInputTextColor();
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00006668 File Offset: 0x00004868
		private void OnItemClicked(string item)
		{
			this.Text = item;
			this._mainInput.text = this.Text;
			this.ToggleDropdownPanel(true);
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x0000668C File Offset: 0x0000488C
		private void RedrawPanel()
		{
			float num = ((this._panelItems.Count > this.ItemsToDisplay) ? this._scrollBarWidth : 0f);
			this._scrollBarRT.gameObject.SetActive(this._panelItems.Count > this.ItemsToDisplay);
			if (!this._hasDrawnOnce || this._rectTransform.sizeDelta != this._inputRT.sizeDelta)
			{
				this._hasDrawnOnce = true;
				this._inputRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._rectTransform.sizeDelta.x);
				this._inputRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this._rectTransform.sizeDelta.y);
				this._scrollPanelRT.SetParent(base.transform, true);
				this._scrollPanelRT.anchoredPosition = new Vector2(0f, -this._rectTransform.sizeDelta.y);
				this._overlayRT.SetParent(this._canvas.transform, false);
				this._overlayRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._canvasRT.sizeDelta.x);
				this._overlayRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this._canvasRT.sizeDelta.y);
				this._overlayRT.SetParent(base.transform, true);
				this._scrollPanelRT.SetParent(this._overlayRT, true);
			}
			if (this._panelItems.Count < 1)
			{
				return;
			}
			float num2 = this._rectTransform.sizeDelta.y * (float)Mathf.Min(this._itemsToDisplay, this._panelItems.Count) + this.DropdownOffset;
			this._scrollPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2);
			this._scrollPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._rectTransform.sizeDelta.x);
			this._itemsPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._scrollPanelRT.sizeDelta.x - num - 5f);
			this._itemsPanelRT.anchoredPosition = new Vector2(5f, 0f);
			this._scrollBarRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, num);
			this._scrollBarRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2);
			this._slidingAreaRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, 0f);
			this._slidingAreaRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2 - this._scrollBarRT.sizeDelta.x);
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x000068E0 File Offset: 0x00004AE0
		public void OnValueChanged(string currText)
		{
			this.Text = currText;
			this.PruneItems(currText);
			this.RedrawPanel();
			if (this._panelItems.Count == 0)
			{
				this._isPanelActive = true;
				this.ToggleDropdownPanel(false);
			}
			else if (!this._isPanelActive)
			{
				this.ToggleDropdownPanel(false);
			}
			bool flag = this._panelItems.Contains(this.Text) != this._selectionIsValid;
			this._selectionIsValid = this._panelItems.Contains(this.Text);
			this.OnSelectionChanged.Invoke(this.Text, this._selectionIsValid);
			this.OnSelectionTextChanged.Invoke(this.Text);
			if (flag)
			{
				this.OnSelectionValidityChanged.Invoke(this._selectionIsValid);
			}
			this.SetInputTextColor();
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x000069A4 File Offset: 0x00004BA4
		private void SetInputTextColor()
		{
			if (this.InputColorMatching)
			{
				if (this._selectionIsValid)
				{
					this._mainInput.textComponent.color = this.ValidSelectionTextColor;
					return;
				}
				if (this._panelItems.Count > 0)
				{
					this._mainInput.textComponent.color = this.MatchingItemsRemainingTextColor;
					return;
				}
				this._mainInput.textComponent.color = this.NoItemsRemainingTextColor;
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x00006A13 File Offset: 0x00004C13
		public void ToggleDropdownPanel(bool directClick = false)
		{
			this._isPanelActive = !this._isPanelActive;
			this._overlayRT.gameObject.SetActive(this._isPanelActive);
			if (this._isPanelActive)
			{
				base.transform.SetAsLastSibling();
				return;
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00006A50 File Offset: 0x00004C50
		private void PruneItems(string currText)
		{
			if (this.autocompleteSearchType == AutoCompleteSearchType.Linq)
			{
				this.PruneItemsLinq(currText);
				return;
			}
			this.PruneItemsArray(currText);
		}

		// Token: 0x060000FA RID: 250 RVA: 0x00006A6C File Offset: 0x00004C6C
		private void PruneItemsLinq(string currText)
		{
			currText = currText.ToLower();
			foreach (string text in this._panelItems.Where((string x) => !x.Contains(currText)).ToArray<string>())
			{
				this.panelObjects[text].SetActive(false);
				this._panelItems.Remove(text);
				this._prunedPanelItems.Add(text);
			}
			foreach (string text2 in this._prunedPanelItems.Where((string x) => x.Contains(currText)).ToArray<string>())
			{
				this.panelObjects[text2].SetActive(true);
				this._panelItems.Add(text2);
				this._prunedPanelItems.Remove(text2);
			}
		}

		// Token: 0x060000FB RID: 251 RVA: 0x00006B50 File Offset: 0x00004D50
		private void PruneItemsArray(string currText)
		{
			string text = currText.ToLower();
			for (int i = this._panelItems.Count - 1; i >= 0; i--)
			{
				string text2 = this._panelItems[i];
				if (!text2.Contains(text))
				{
					this.panelObjects[this._panelItems[i]].SetActive(false);
					this._panelItems.RemoveAt(i);
					this._prunedPanelItems.Add(text2);
				}
			}
			for (int j = this._prunedPanelItems.Count - 1; j >= 0; j--)
			{
				string text3 = this._prunedPanelItems[j];
				if (text3.Contains(text))
				{
					this.panelObjects[this._prunedPanelItems[j]].SetActive(true);
					this._prunedPanelItems.RemoveAt(j);
					this._panelItems.Add(text3);
				}
			}
		}

		// Token: 0x040000D3 RID: 211
		public Color disabledTextColor;

		// Token: 0x040000D5 RID: 213
		public List<string> AvailableOptions;

		// Token: 0x040000D6 RID: 214
		private bool _isPanelActive;

		// Token: 0x040000D7 RID: 215
		private bool _hasDrawnOnce;

		// Token: 0x040000D8 RID: 216
		private InputField _mainInput;

		// Token: 0x040000D9 RID: 217
		private RectTransform _inputRT;

		// Token: 0x040000DA RID: 218
		private RectTransform _rectTransform;

		// Token: 0x040000DB RID: 219
		private RectTransform _overlayRT;

		// Token: 0x040000DC RID: 220
		private RectTransform _scrollPanelRT;

		// Token: 0x040000DD RID: 221
		private RectTransform _scrollBarRT;

		// Token: 0x040000DE RID: 222
		private RectTransform _slidingAreaRT;

		// Token: 0x040000DF RID: 223
		private RectTransform _itemsPanelRT;

		// Token: 0x040000E0 RID: 224
		private Canvas _canvas;

		// Token: 0x040000E1 RID: 225
		private RectTransform _canvasRT;

		// Token: 0x040000E2 RID: 226
		private ScrollRect _scrollRect;

		// Token: 0x040000E3 RID: 227
		private List<string> _panelItems;

		// Token: 0x040000E4 RID: 228
		private List<string> _prunedPanelItems;

		// Token: 0x040000E5 RID: 229
		private Dictionary<string, GameObject> panelObjects;

		// Token: 0x040000E6 RID: 230
		private GameObject itemTemplate;

		// Token: 0x040000E8 RID: 232
		[SerializeField]
		private float _scrollBarWidth = 20f;

		// Token: 0x040000E9 RID: 233
		[SerializeField]
		private int _itemsToDisplay;

		// Token: 0x040000EA RID: 234
		public bool SelectFirstItemOnStart;

		// Token: 0x040000EB RID: 235
		[SerializeField]
		[Tooltip("Change input text color based on matching items")]
		private bool _ChangeInputTextColorBasedOnMatchingItems;

		// Token: 0x040000EC RID: 236
		public float DropdownOffset = 10f;

		// Token: 0x040000ED RID: 237
		public Color ValidSelectionTextColor = Color.green;

		// Token: 0x040000EE RID: 238
		public Color MatchingItemsRemainingTextColor = Color.black;

		// Token: 0x040000EF RID: 239
		public Color NoItemsRemainingTextColor = Color.red;

		// Token: 0x040000F0 RID: 240
		public AutoCompleteSearchType autocompleteSearchType = AutoCompleteSearchType.Linq;

		// Token: 0x040000F1 RID: 241
		private bool _selectionIsValid;

		// Token: 0x040000F2 RID: 242
		public AutoCompleteComboBox.SelectionTextChangedEvent OnSelectionTextChanged;

		// Token: 0x040000F3 RID: 243
		public AutoCompleteComboBox.SelectionValidityChangedEvent OnSelectionValidityChanged;

		// Token: 0x040000F4 RID: 244
		public AutoCompleteComboBox.SelectionChangedEvent OnSelectionChanged;

		// Token: 0x02000108 RID: 264
		[Serializable]
		public class SelectionChangedEvent : UnityEvent<string, bool>
		{
		}

		// Token: 0x02000109 RID: 265
		[Serializable]
		public class SelectionTextChangedEvent : UnityEvent<string>
		{
		}

		// Token: 0x0200010A RID: 266
		[Serializable]
		public class SelectionValidityChangedEvent : UnityEvent<bool>
		{
		}
	}
}
