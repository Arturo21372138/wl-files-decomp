﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200007A RID: 122
	public abstract class FancyGridViewCell<TItemData> : FancyGridViewCell<TItemData, FancyGridViewContext>
	{
		// Token: 0x0600039C RID: 924 RVA: 0x0001703D File Offset: 0x0001523D
		public sealed override void SetContext(FancyGridViewContext context)
		{
			base.SetContext(context);
		}
	}
}
