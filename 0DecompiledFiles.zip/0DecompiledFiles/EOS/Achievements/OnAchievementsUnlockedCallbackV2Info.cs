﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000803 RID: 2051
	public struct OnAchievementsUnlockedCallbackV2Info : ICallbackInfo
	{
		// Token: 0x17000863 RID: 2147
		// (get) Token: 0x060021B8 RID: 8632 RVA: 0x00028315 File Offset: 0x00026515
		// (set) Token: 0x060021B9 RID: 8633 RVA: 0x0002831D File Offset: 0x0002651D
		public object ClientData { readonly get; set; }

		// Token: 0x17000864 RID: 2148
		// (get) Token: 0x060021BA RID: 8634 RVA: 0x00028326 File Offset: 0x00026526
		// (set) Token: 0x060021BB RID: 8635 RVA: 0x0002832E File Offset: 0x0002652E
		public ProductUserId UserId { readonly get; set; }

		// Token: 0x17000865 RID: 2149
		// (get) Token: 0x060021BC RID: 8636 RVA: 0x00028337 File Offset: 0x00026537
		// (set) Token: 0x060021BD RID: 8637 RVA: 0x0002833F File Offset: 0x0002653F
		public Utf8String AchievementId { readonly get; set; }

		// Token: 0x17000866 RID: 2150
		// (get) Token: 0x060021BE RID: 8638 RVA: 0x00028348 File Offset: 0x00026548
		// (set) Token: 0x060021BF RID: 8639 RVA: 0x00028350 File Offset: 0x00026550
		public DateTimeOffset? UnlockTime { readonly get; set; }

		// Token: 0x060021C0 RID: 8640 RVA: 0x00028359 File Offset: 0x00026559
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060021C1 RID: 8641 RVA: 0x00028364 File Offset: 0x00026564
		public Result? GetResultCode()
		{
			return null;
		}
	}
}
