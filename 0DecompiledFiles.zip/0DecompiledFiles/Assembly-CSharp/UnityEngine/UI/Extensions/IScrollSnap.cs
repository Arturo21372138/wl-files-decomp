﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200008A RID: 138
	internal interface IScrollSnap
	{
		// Token: 0x0600042A RID: 1066
		void ChangePage(int page);

		// Token: 0x0600042B RID: 1067
		void SetLerp(bool value);

		// Token: 0x0600042C RID: 1068
		int CurrentPage();

		// Token: 0x0600042D RID: 1069
		void StartScreenChange();
	}
}
