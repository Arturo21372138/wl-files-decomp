﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200006F RID: 111
	[ExecuteInEditMode]
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("UI/Extensions/ContentSnapScrollHorizontal")]
	public class ContentScrollSnapHorizontal : MonoBehaviour, IBeginDragHandler, IEventSystemHandler, IEndDragHandler
	{
		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000334 RID: 820 RVA: 0x000159CA File Offset: 0x00013BCA
		// (set) Token: 0x06000335 RID: 821 RVA: 0x000159D2 File Offset: 0x00013BD2
		public ContentScrollSnapHorizontal.StartMovementEvent MovementStarted
		{
			get
			{
				return this.m_StartMovementEvent;
			}
			set
			{
				this.m_StartMovementEvent = value;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000336 RID: 822 RVA: 0x000159DB File Offset: 0x00013BDB
		// (set) Token: 0x06000337 RID: 823 RVA: 0x000159E3 File Offset: 0x00013BE3
		public ContentScrollSnapHorizontal.CurrentItemChangeEvent CurrentItemChanged
		{
			get
			{
				return this.m_CurrentItemChangeEvent;
			}
			set
			{
				this.m_CurrentItemChangeEvent = value;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06000338 RID: 824 RVA: 0x000159EC File Offset: 0x00013BEC
		// (set) Token: 0x06000339 RID: 825 RVA: 0x000159F4 File Offset: 0x00013BF4
		public ContentScrollSnapHorizontal.FoundItemToSnapToEvent ItemFoundToSnap
		{
			get
			{
				return this.m_FoundItemToSnapToEvent;
			}
			set
			{
				this.m_FoundItemToSnapToEvent = value;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x0600033A RID: 826 RVA: 0x000159FD File Offset: 0x00013BFD
		// (set) Token: 0x0600033B RID: 827 RVA: 0x00015A05 File Offset: 0x00013C05
		public ContentScrollSnapHorizontal.SnappedToItemEvent ItemSnappedTo
		{
			get
			{
				return this.m_SnappedToItemEvent;
			}
			set
			{
				this.m_SnappedToItemEvent = value;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x0600033C RID: 828 RVA: 0x00015A0E File Offset: 0x00013C0E
		private bool ContentIsHorizonalLayoutGroup
		{
			get
			{
				return this.contentTransform.GetComponent<HorizontalLayoutGroup>() != null;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600033D RID: 829 RVA: 0x00015A21 File Offset: 0x00013C21
		public bool Moving
		{
			get
			{
				return this.Sliding || this.Lerping;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x0600033E RID: 830 RVA: 0x00015A33 File Offset: 0x00013C33
		public bool Sliding
		{
			get
			{
				return this.mSliding;
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x0600033F RID: 831 RVA: 0x00015A3B File Offset: 0x00013C3B
		public bool Lerping
		{
			get
			{
				return this.mLerping;
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000340 RID: 832 RVA: 0x00015A43 File Offset: 0x00013C43
		public int ClosestItemIndex
		{
			get
			{
				return this.contentPositions.IndexOf(this.FindClosestFrom(this.contentTransform.localPosition));
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000341 RID: 833 RVA: 0x00015A61 File Offset: 0x00013C61
		public int LerpTargetIndex
		{
			get
			{
				return this.contentPositions.IndexOf(this.lerpTarget);
			}
		}

		// Token: 0x06000342 RID: 834 RVA: 0x00015A74 File Offset: 0x00013C74
		private void Awake()
		{
			this.scrollRect = base.GetComponent<ScrollRect>();
			this.scrollRectTransform = (RectTransform)this.scrollRect.transform;
			this.contentTransform = this.scrollRect.content;
			if (this.nextButton)
			{
				this.nextButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.NextItem();
				});
			}
			if (this.prevButton)
			{
				this.prevButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.PreviousItem();
				});
			}
			if (this.IsScrollRectAvailable)
			{
				this.SetupDrivenTransforms();
				this.SetupSnapScroll();
				this.scrollRect.horizontalNormalizedPosition = 0f;
				this._closestItem = 0;
				this.GoTo(this.startInfo);
			}
		}

		// Token: 0x06000343 RID: 835 RVA: 0x00015B48 File Offset: 0x00013D48
		public void SetNewItems(ref List<Transform> newItems)
		{
			if (this.scrollRect && this.contentTransform)
			{
				for (int i = this.scrollRect.content.childCount - 1; i >= 0; i--)
				{
					Transform child = this.contentTransform.GetChild(i);
					child.SetParent(null);
					Object.DestroyImmediate(child.gameObject);
				}
				foreach (Transform transform in newItems)
				{
					GameObject gameObject = transform.gameObject;
					if (gameObject.IsPrefab())
					{
						gameObject = Object.Instantiate<GameObject>(transform.gameObject, this.contentTransform);
					}
					else
					{
						gameObject.transform.SetParent(this.contentTransform);
					}
				}
				this.SetupDrivenTransforms();
				this.SetupSnapScroll();
				this.scrollRect.horizontalNormalizedPosition = 0f;
				this._closestItem = 0;
				this.GoTo(this.startInfo);
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000344 RID: 836 RVA: 0x00015C50 File Offset: 0x00013E50
		private bool IsScrollRectAvailable
		{
			get
			{
				return this.scrollRect && this.contentTransform && this.contentTransform.childCount > 0;
			}
		}

		// Token: 0x06000345 RID: 837 RVA: 0x00015C7D File Offset: 0x00013E7D
		private void OnDisable()
		{
			this.tracker.Clear();
		}

		// Token: 0x06000346 RID: 838 RVA: 0x00015C8C File Offset: 0x00013E8C
		private void SetupDrivenTransforms()
		{
			this.tracker = default(DrivenRectTransformTracker);
			this.tracker.Clear();
			foreach (object obj in this.contentTransform)
			{
				RectTransform rectTransform = (RectTransform)obj;
				this.tracker.Add(this, rectTransform, DrivenTransformProperties.Anchors);
				rectTransform.anchorMax = new Vector2(0f, 1f);
				rectTransform.anchorMin = new Vector2(0f, 1f);
			}
		}

		// Token: 0x06000347 RID: 839 RVA: 0x00015D34 File Offset: 0x00013F34
		private void SetupSnapScroll()
		{
			if (this.ContentIsHorizonalLayoutGroup)
			{
				this.SetupWithHorizontalLayoutGroup();
				return;
			}
			this.SetupWithCalculatedSpacing();
		}

		// Token: 0x06000348 RID: 840 RVA: 0x00015D4C File Offset: 0x00013F4C
		private void SetupWithHorizontalLayoutGroup()
		{
			HorizontalLayoutGroup component = this.contentTransform.GetComponent<HorizontalLayoutGroup>();
			float num = 0f;
			int num2 = 0;
			for (int i = 0; i < this.contentTransform.childCount; i++)
			{
				if (!this.ignoreInactiveItems || this.contentTransform.GetChild(i).gameObject.activeInHierarchy)
				{
					num += ((RectTransform)this.contentTransform.GetChild(i)).sizeDelta.x;
					num2++;
				}
			}
			float num3 = (float)(num2 - 1) * component.spacing;
			float num4 = num + num3 + (float)component.padding.left + (float)component.padding.right;
			this.contentTransform.sizeDelta = new Vector2(num4, this.contentTransform.sizeDelta.y);
			float num5 = Mathf.Min(((RectTransform)this.contentTransform.GetChild(0)).sizeDelta.x, ((RectTransform)this.contentTransform.GetChild(this.contentTransform.childCount - 1)).sizeDelta.x);
			this.scrollRectTransform.sizeDelta = new Vector2(num5, this.scrollRectTransform.sizeDelta.y);
			this.contentPositions = new List<Vector3>();
			float x = this.scrollRectTransform.sizeDelta.x;
			this.totalScrollableWidth = num4 - x;
			float num6 = (float)component.padding.left;
			int num7 = 0;
			for (int j = 0; j < this.contentTransform.childCount; j++)
			{
				if (!this.ignoreInactiveItems || this.contentTransform.GetChild(j).gameObject.activeInHierarchy)
				{
					float x2 = ((RectTransform)this.contentTransform.GetChild(j)).sizeDelta.x;
					float num8 = num6 + component.spacing * (float)num7 + (x2 - x) / 2f;
					this.scrollRect.horizontalNormalizedPosition = num8 / this.totalScrollableWidth;
					this.contentPositions.Add(this.contentTransform.localPosition);
					num6 += x2;
					num7++;
				}
			}
		}

		// Token: 0x06000349 RID: 841 RVA: 0x00015F70 File Offset: 0x00014170
		private void SetupWithCalculatedSpacing()
		{
			List<RectTransform> list = new List<RectTransform>();
			for (int i = 0; i < this.contentTransform.childCount; i++)
			{
				if (!this.ignoreInactiveItems || this.contentTransform.GetChild(i).gameObject.activeInHierarchy)
				{
					RectTransform rectTransform = (RectTransform)this.contentTransform.GetChild(i);
					int num = list.Count;
					for (int j = 0; j < list.Count; j++)
					{
						if (this.DstFromTopLeftOfTransformToTopLeftOfParent(rectTransform).x < this.DstFromTopLeftOfTransformToTopLeftOfParent(list[j]).x)
						{
							num = j;
							break;
						}
					}
					list.Insert(num, rectTransform);
				}
			}
			RectTransform rectTransform2 = list[list.Count - 1];
			float num2 = this.DstFromTopLeftOfTransformToTopLeftOfParent(rectTransform2).x + rectTransform2.sizeDelta.x;
			this.contentTransform.sizeDelta = new Vector2(num2, this.contentTransform.sizeDelta.y);
			float num3 = Mathf.Min(list[0].sizeDelta.x, list[list.Count - 1].sizeDelta.x);
			this.scrollRectTransform.sizeDelta = new Vector2(num3, this.scrollRectTransform.sizeDelta.y);
			this.contentPositions = new List<Vector3>();
			float x = this.scrollRectTransform.sizeDelta.x;
			this.totalScrollableWidth = num2 - x;
			for (int k = 0; k < list.Count; k++)
			{
				float num4 = this.DstFromTopLeftOfTransformToTopLeftOfParent(list[k]).x + (list[k].sizeDelta.x - x) / 2f;
				this.scrollRect.horizontalNormalizedPosition = num4 / this.totalScrollableWidth;
				this.contentPositions.Add(this.contentTransform.localPosition);
			}
		}

		// Token: 0x0600034A RID: 842 RVA: 0x00016158 File Offset: 0x00014358
		public void GoTo(ContentScrollSnapHorizontal.MoveInfo info)
		{
			if (!this.Moving && info.index != this.ClosestItemIndex)
			{
				this.MovementStarted.Invoke();
			}
			if (info.indexType == ContentScrollSnapHorizontal.MoveInfo.IndexType.childIndex)
			{
				this.mLerpTime = info.duration;
				this.GoToChild(info.index, info.jump);
				return;
			}
			if (info.indexType == ContentScrollSnapHorizontal.MoveInfo.IndexType.positionIndex)
			{
				this.mLerpTime = info.duration;
				this.GoToContentPos(info.index, info.jump);
			}
		}

		// Token: 0x0600034B RID: 843 RVA: 0x000161D4 File Offset: 0x000143D4
		private void GoToChild(int index, bool jump)
		{
			int num = Mathf.Clamp(index, 0, this.contentPositions.Count - 1);
			if (!this.ContentIsHorizonalLayoutGroup)
			{
				int num2 = 0;
				Vector3 localPosition = this.contentTransform.localPosition;
				for (int i = 0; i < this.contentTransform.childCount; i++)
				{
					if (!this.ignoreInactiveItems || this.contentTransform.GetChild(i).gameObject.activeInHierarchy)
					{
						if (num2 == num)
						{
							RectTransform rectTransform = (RectTransform)this.contentTransform.GetChild(i);
							float num3 = this.DstFromTopLeftOfTransformToTopLeftOfParent(rectTransform).x + (rectTransform.sizeDelta.x - this.scrollRectTransform.sizeDelta.x) / 2f;
							this.scrollRect.horizontalNormalizedPosition = num3 / this.totalScrollableWidth;
							this.lerpTarget = this.contentTransform.localPosition;
							if (!jump)
							{
								this.contentTransform.localPosition = localPosition;
								this.StopMovement();
								base.StartCoroutine("LerpToContent");
							}
							return;
						}
						num2++;
					}
				}
				return;
			}
			this.lerpTarget = this.contentPositions[num];
			if (jump)
			{
				this.contentTransform.localPosition = this.lerpTarget;
				return;
			}
			this.StopMovement();
			base.StartCoroutine("LerpToContent");
		}

		// Token: 0x0600034C RID: 844 RVA: 0x00016320 File Offset: 0x00014520
		private void GoToContentPos(int index, bool jump)
		{
			int num = Mathf.Clamp(index, 0, this.contentPositions.Count - 1);
			this.lerpTarget = this.contentPositions[num];
			if (jump)
			{
				this.contentTransform.localPosition = this.lerpTarget;
				return;
			}
			this.StopMovement();
			base.StartCoroutine("LerpToContent");
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0001637C File Offset: 0x0001457C
		public void NextItem()
		{
			int num;
			if (this.Sliding)
			{
				num = this.ClosestItemIndex + 1;
			}
			else
			{
				num = this.LerpTargetIndex + 1;
			}
			ContentScrollSnapHorizontal.MoveInfo moveInfo = new ContentScrollSnapHorizontal.MoveInfo(ContentScrollSnapHorizontal.MoveInfo.IndexType.positionIndex, num, this.jumpToItem, this.lerpTime);
			this.GoTo(moveInfo);
		}

		// Token: 0x0600034E RID: 846 RVA: 0x000163C4 File Offset: 0x000145C4
		public void PreviousItem()
		{
			int num;
			if (this.Sliding)
			{
				num = this.ClosestItemIndex - 1;
			}
			else
			{
				num = this.LerpTargetIndex - 1;
			}
			ContentScrollSnapHorizontal.MoveInfo moveInfo = new ContentScrollSnapHorizontal.MoveInfo(ContentScrollSnapHorizontal.MoveInfo.IndexType.positionIndex, num, this.jumpToItem, this.lerpTime);
			this.GoTo(moveInfo);
		}

		// Token: 0x0600034F RID: 847 RVA: 0x00016409 File Offset: 0x00014609
		public void UpdateLayout()
		{
			this.SetupDrivenTransforms();
			this.SetupSnapScroll();
		}

		// Token: 0x06000350 RID: 848 RVA: 0x00016417 File Offset: 0x00014617
		public void UpdateLayoutAndMoveTo(ContentScrollSnapHorizontal.MoveInfo info)
		{
			this.SetupDrivenTransforms();
			this.SetupSnapScroll();
			this.GoTo(info);
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0001642C File Offset: 0x0001462C
		public void OnBeginDrag(PointerEventData ped)
		{
			this.StopMovement();
			if (!this.Moving)
			{
				this.MovementStarted.Invoke();
			}
		}

		// Token: 0x06000352 RID: 850 RVA: 0x00016447 File Offset: 0x00014647
		public void OnEndDrag(PointerEventData ped)
		{
			if (this.IsScrollRectAvailable)
			{
				base.StartCoroutine("SlideAndLerp");
			}
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00016460 File Offset: 0x00014660
		private void Update()
		{
			if (this.IsScrollRectAvailable && this._closestItem != this.ClosestItemIndex)
			{
				this.CurrentItemChanged.Invoke(this.ClosestItemIndex);
				this.ChangePaginationInfo(this.ClosestItemIndex);
				this._closestItem = this.ClosestItemIndex;
			}
		}

		// Token: 0x06000354 RID: 852 RVA: 0x000164AC File Offset: 0x000146AC
		private IEnumerator SlideAndLerp()
		{
			this.mSliding = true;
			while (Mathf.Abs(this.scrollRect.velocity.x) > (float)this.snappingVelocityThreshold)
			{
				yield return null;
			}
			this.lerpTarget = this.FindClosestFrom(this.contentTransform.localPosition);
			this.ItemFoundToSnap.Invoke(this.LerpTargetIndex);
			while (Vector3.Distance(this.contentTransform.localPosition, this.lerpTarget) > 1f)
			{
				this.contentTransform.localPosition = Vector3.Lerp(this.scrollRect.content.localPosition, this.lerpTarget, 7.5f * Time.deltaTime);
				yield return null;
			}
			this.mSliding = false;
			this.scrollRect.velocity = Vector2.zero;
			this.contentTransform.localPosition = this.lerpTarget;
			this.ItemSnappedTo.Invoke(this.LerpTargetIndex);
			yield break;
		}

		// Token: 0x06000355 RID: 853 RVA: 0x000164BB File Offset: 0x000146BB
		private IEnumerator LerpToContent()
		{
			this.ItemFoundToSnap.Invoke(this.LerpTargetIndex);
			this.mLerping = true;
			Vector3 originalContentPos = this.contentTransform.localPosition;
			float elapsedTime = 0f;
			while (elapsedTime < this.mLerpTime)
			{
				elapsedTime += Time.deltaTime;
				this.contentTransform.localPosition = Vector3.Lerp(originalContentPos, this.lerpTarget, elapsedTime / this.mLerpTime);
				yield return null;
			}
			this.ItemSnappedTo.Invoke(this.LerpTargetIndex);
			this.mLerping = false;
			yield break;
		}

		// Token: 0x06000356 RID: 854 RVA: 0x000164CA File Offset: 0x000146CA
		private void StopMovement()
		{
			this.scrollRect.velocity = Vector2.zero;
			base.StopCoroutine("SlideAndLerp");
			base.StopCoroutine("LerpToContent");
		}

		// Token: 0x06000357 RID: 855 RVA: 0x000164F4 File Offset: 0x000146F4
		private void ChangePaginationInfo(int targetScreen)
		{
			if (this.pagination)
			{
				for (int i = 0; i < this.pagination.transform.childCount; i++)
				{
					this.pagination.transform.GetChild(i).GetComponent<Toggle>().isOn = targetScreen == i;
				}
			}
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00016548 File Offset: 0x00014748
		private Vector2 DstFromTopLeftOfTransformToTopLeftOfParent(RectTransform rt)
		{
			return new Vector2(rt.anchoredPosition.x - rt.sizeDelta.x * rt.pivot.x, rt.anchoredPosition.y + rt.sizeDelta.y * (1f - rt.pivot.y));
		}

		// Token: 0x06000359 RID: 857 RVA: 0x000165A8 File Offset: 0x000147A8
		private Vector3 FindClosestFrom(Vector3 start)
		{
			Vector3 vector = Vector3.zero;
			float num = float.PositiveInfinity;
			foreach (Vector3 vector2 in this.contentPositions)
			{
				if (Vector3.Distance(start, vector2) < num)
				{
					num = Vector3.Distance(start, vector2);
					vector = vector2;
				}
			}
			return vector;
		}

		// Token: 0x040002AD RID: 685
		public bool ignoreInactiveItems = true;

		// Token: 0x040002AE RID: 686
		public ContentScrollSnapHorizontal.MoveInfo startInfo = new ContentScrollSnapHorizontal.MoveInfo(ContentScrollSnapHorizontal.MoveInfo.IndexType.positionIndex, 0);

		// Token: 0x040002AF RID: 687
		public GameObject prevButton;

		// Token: 0x040002B0 RID: 688
		public GameObject nextButton;

		// Token: 0x040002B1 RID: 689
		public GameObject pagination;

		// Token: 0x040002B2 RID: 690
		[Tooltip("The velocity below which the scroll rect will start to snap")]
		public int snappingVelocityThreshold = 50;

		// Token: 0x040002B3 RID: 691
		[Header("Paging Info")]
		[Tooltip("Should the pagination & buttons jump or lerp to the items")]
		public bool jumpToItem;

		// Token: 0x040002B4 RID: 692
		[Tooltip("The time it will take for the pagination or buttons to move between items")]
		public float lerpTime = 0.3f;

		// Token: 0x040002B5 RID: 693
		[Header("Events")]
		[SerializeField]
		[Tooltip("Event is triggered whenever the scroll rect starts to move, even when triggered programmatically")]
		private ContentScrollSnapHorizontal.StartMovementEvent m_StartMovementEvent = new ContentScrollSnapHorizontal.StartMovementEvent();

		// Token: 0x040002B6 RID: 694
		[SerializeField]
		[Tooltip("Event is triggered whenever the closest item to the center of the scrollrect changes")]
		private ContentScrollSnapHorizontal.CurrentItemChangeEvent m_CurrentItemChangeEvent = new ContentScrollSnapHorizontal.CurrentItemChangeEvent();

		// Token: 0x040002B7 RID: 695
		[SerializeField]
		[Tooltip("Event is triggered when the ContentSnapScroll decides which item it is going to snap to. Returns the index of the closest position.")]
		private ContentScrollSnapHorizontal.FoundItemToSnapToEvent m_FoundItemToSnapToEvent = new ContentScrollSnapHorizontal.FoundItemToSnapToEvent();

		// Token: 0x040002B8 RID: 696
		[SerializeField]
		[Tooltip("Event is triggered when we finally settle on an element. Returns the index of the item's position.")]
		private ContentScrollSnapHorizontal.SnappedToItemEvent m_SnappedToItemEvent = new ContentScrollSnapHorizontal.SnappedToItemEvent();

		// Token: 0x040002B9 RID: 697
		private ScrollRect scrollRect;

		// Token: 0x040002BA RID: 698
		private RectTransform scrollRectTransform;

		// Token: 0x040002BB RID: 699
		private RectTransform contentTransform;

		// Token: 0x040002BC RID: 700
		private List<Vector3> contentPositions;

		// Token: 0x040002BD RID: 701
		private Vector3 lerpTarget = Vector3.zero;

		// Token: 0x040002BE RID: 702
		private float totalScrollableWidth;

		// Token: 0x040002BF RID: 703
		private DrivenRectTransformTracker tracker;

		// Token: 0x040002C0 RID: 704
		private float mLerpTime;

		// Token: 0x040002C1 RID: 705
		private int _closestItem;

		// Token: 0x040002C2 RID: 706
		private bool mSliding;

		// Token: 0x040002C3 RID: 707
		private bool mLerping;

		// Token: 0x02000128 RID: 296
		[Serializable]
		public class StartMovementEvent : UnityEvent
		{
		}

		// Token: 0x02000129 RID: 297
		[Serializable]
		public class CurrentItemChangeEvent : UnityEvent<int>
		{
		}

		// Token: 0x0200012A RID: 298
		[Serializable]
		public class FoundItemToSnapToEvent : UnityEvent<int>
		{
		}

		// Token: 0x0200012B RID: 299
		[Serializable]
		public class SnappedToItemEvent : UnityEvent<int>
		{
		}

		// Token: 0x0200012C RID: 300
		[Serializable]
		public struct MoveInfo
		{
			// Token: 0x060007E6 RID: 2022 RVA: 0x0002BEE4 File Offset: 0x0002A0E4
			public MoveInfo(ContentScrollSnapHorizontal.MoveInfo.IndexType _indexType, int _index)
			{
				this.indexType = _indexType;
				this.index = _index;
				this.jump = true;
				this.duration = 0f;
			}

			// Token: 0x060007E7 RID: 2023 RVA: 0x0002BF06 File Offset: 0x0002A106
			public MoveInfo(ContentScrollSnapHorizontal.MoveInfo.IndexType _indexType, int _index, bool _jump, float _duration)
			{
				this.indexType = _indexType;
				this.index = _index;
				this.jump = _jump;
				this.duration = _duration;
			}

			// Token: 0x04000657 RID: 1623
			[Tooltip("Child Index means the Index corresponds to the content item at that index in the hierarchy.\nPosition Index means the Index corresponds to the content item in that snap position.\nA higher Position Index in a Horizontal Scroll Snap means it would be further to the right.")]
			public ContentScrollSnapHorizontal.MoveInfo.IndexType indexType;

			// Token: 0x04000658 RID: 1624
			[Tooltip("Zero based")]
			public int index;

			// Token: 0x04000659 RID: 1625
			[Tooltip("If this is true the snap scroll will jump to the index, otherwise it will lerp there.")]
			public bool jump;

			// Token: 0x0400065A RID: 1626
			[Tooltip("If jump is false this is the time it will take to lerp to the index")]
			public float duration;

			// Token: 0x02000164 RID: 356
			public enum IndexType
			{
				// Token: 0x040006EB RID: 1771
				childIndex,
				// Token: 0x040006EC RID: 1772
				positionIndex
			}
		}
	}
}
