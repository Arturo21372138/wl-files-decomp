﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007CF RID: 1999
	internal struct ProtectMessageOptionsInternal : ISettable<ProtectMessageOptions>, IDisposable
	{
		// Token: 0x060020F9 RID: 8441 RVA: 0x00027329 File Offset: 0x00025529
		public void Set(ref ProtectMessageOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.Data, ref this.m_Data, out this.m_DataLengthBytes);
			this.m_OutBufferSizeBytes = other.OutBufferSizeBytes;
		}

		// Token: 0x060020FA RID: 8442 RVA: 0x0002735B File Offset: 0x0002555B
		public void Dispose()
		{
			Helper.Dispose(ref this.m_Data);
		}

		// Token: 0x040015E7 RID: 5607
		private int m_ApiVersion;

		// Token: 0x040015E8 RID: 5608
		private uint m_DataLengthBytes;

		// Token: 0x040015E9 RID: 5609
		private IntPtr m_Data;

		// Token: 0x040015EA RID: 5610
		private uint m_OutBufferSizeBytes;
	}
}
