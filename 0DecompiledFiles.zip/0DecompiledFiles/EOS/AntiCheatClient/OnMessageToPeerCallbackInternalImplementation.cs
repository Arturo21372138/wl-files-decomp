﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C0 RID: 1984
	internal static class OnMessageToPeerCallbackInternalImplementation
	{
		// Token: 0x17000821 RID: 2081
		// (get) Token: 0x060020C9 RID: 8393 RVA: 0x00027148 File Offset: 0x00025348
		public static OnMessageToPeerCallbackInternal Delegate
		{
			get
			{
				if (OnMessageToPeerCallbackInternalImplementation.s_Delegate == null)
				{
					OnMessageToPeerCallbackInternalImplementation.s_Delegate = new OnMessageToPeerCallbackInternal(OnMessageToPeerCallbackInternalImplementation.EntryPoint);
				}
				return OnMessageToPeerCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060020CA RID: 8394 RVA: 0x00027168 File Offset: 0x00025368
		[MonoPInvokeCallback(typeof(OnMessageToPeerCallbackInternal))]
		public static void EntryPoint(ref OnMessageToClientCallbackInfoInternal data)
		{
			OnMessageToPeerCallback onMessageToPeerCallback;
			OnMessageToClientCallbackInfo onMessageToClientCallbackInfo;
			if (Helper.TryGetCallback<OnMessageToClientCallbackInfoInternal, OnMessageToPeerCallback, OnMessageToClientCallbackInfo>(ref data, out onMessageToPeerCallback, out onMessageToClientCallbackInfo))
			{
				onMessageToPeerCallback(ref onMessageToClientCallbackInfo);
			}
		}

		// Token: 0x040015D9 RID: 5593
		private static OnMessageToPeerCallbackInternal s_Delegate;
	}
}
