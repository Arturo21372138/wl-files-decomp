﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000820 RID: 2080
	public struct UnlockedAchievement
	{
		// Token: 0x1700088C RID: 2188
		// (get) Token: 0x06002233 RID: 8755 RVA: 0x00028A26 File Offset: 0x00026C26
		// (set) Token: 0x06002234 RID: 8756 RVA: 0x00028A2E File Offset: 0x00026C2E
		public Utf8String AchievementId { readonly get; set; }

		// Token: 0x1700088D RID: 2189
		// (get) Token: 0x06002235 RID: 8757 RVA: 0x00028A37 File Offset: 0x00026C37
		// (set) Token: 0x06002236 RID: 8758 RVA: 0x00028A3F File Offset: 0x00026C3F
		public DateTimeOffset? UnlockTime { readonly get; set; }
	}
}
