﻿using System;
using System.Collections;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200006A RID: 106
	public class CardStack2D : MonoBehaviour
	{
		// Token: 0x0600031F RID: 799 RVA: 0x00014574 File Offset: 0x00012774
		private void Start()
		{
			this.xPowerDifference = 9 - this.cards.Length;
			if (this.useDefaultUsedXPos)
			{
				int num = (int)this.cards[0].GetComponent<RectTransform>().rect.width;
				this.usedCardXPos = (int)((float)Screen.width * 0.5f + (float)num);
			}
			this.cardPositions = new Vector3[this.cards.Length * 2 - 1];
			for (int i = this.cards.Length; i > -1; i--)
			{
				if (i < this.cards.Length - 1)
				{
					this.cardPositions[i] = new Vector3(-Mathf.Pow(2f, (float)(i + this.xPowerDifference)) + this.cardPositions[i + 1].x, 0f, (float)(this.cardZMultiplier * Mathf.Abs(i + 1 - this.cards.Length)));
				}
				else
				{
					this.cardPositions[i] = Vector3.zero;
				}
			}
			for (int j = this.cards.Length; j < this.cardPositions.Length; j++)
			{
				this.cardPositions[j] = new Vector3((float)(this.usedCardXPos + 4 * (j - this.cards.Length)), 0f, (float)(-2 + -2 * (j - this.cards.Length)));
			}
		}

		// Token: 0x06000320 RID: 800 RVA: 0x000146C4 File Offset: 0x000128C4
		private void Update()
		{
			if (CardStack2D.canUseHorizontalAxis)
			{
				if ((UIExtensionsInputManager.GetAxisRaw("Horizontal") < 0f || UIExtensionsInputManager.GetKey(this.leftButton)) && this.cardArrayOffset > 0)
				{
					this.cardArrayOffset--;
					base.StartCoroutine(this.ButtonCooldown());
				}
				else if ((UIExtensionsInputManager.GetAxisRaw("Horizontal") > 0f || UIExtensionsInputManager.GetKey(this.rightButton)) && this.cardArrayOffset < this.cards.Length - 1)
				{
					this.cardArrayOffset++;
					base.StartCoroutine(this.ButtonCooldown());
				}
			}
			for (int i = 0; i < this.cards.Length; i++)
			{
				this.cards[i].localPosition = Vector3.Lerp(this.cards[i].localPosition, this.cardPositions[i + this.cardArrayOffset], Time.deltaTime * this.cardMoveSpeed);
				if (Mathf.Abs(this.cards[i].localPosition.x - this.cardPositions[i + this.cardArrayOffset].x) < 0.01f)
				{
					this.cards[i].localPosition = this.cardPositions[i + this.cardArrayOffset];
					if (this.cards[i].localPosition.x == 0f)
					{
						this.cards[i].gameObject.GetComponent<CanvasGroup>().interactable = true;
					}
					else
					{
						this.cards[i].gameObject.GetComponent<CanvasGroup>().interactable = false;
					}
				}
			}
		}

		// Token: 0x06000321 RID: 801 RVA: 0x00014863 File Offset: 0x00012A63
		private IEnumerator ButtonCooldown()
		{
			CardStack2D.canUseHorizontalAxis = false;
			yield return new WaitForSeconds(this.buttonCooldownTime);
			CardStack2D.canUseHorizontalAxis = true;
			yield break;
		}

		// Token: 0x0400027F RID: 639
		[SerializeField]
		private float cardMoveSpeed = 8f;

		// Token: 0x04000280 RID: 640
		[SerializeField]
		private float buttonCooldownTime = 0.125f;

		// Token: 0x04000281 RID: 641
		[SerializeField]
		private int cardZMultiplier = 32;

		// Token: 0x04000282 RID: 642
		[SerializeField]
		private bool useDefaultUsedXPos = true;

		// Token: 0x04000283 RID: 643
		[SerializeField]
		private int usedCardXPos = 1280;

		// Token: 0x04000284 RID: 644
		[SerializeField]
		private KeyCode leftButton = KeyCode.LeftArrow;

		// Token: 0x04000285 RID: 645
		[SerializeField]
		private KeyCode rightButton = KeyCode.RightArrow;

		// Token: 0x04000286 RID: 646
		[SerializeField]
		private Transform[] cards;

		// Token: 0x04000287 RID: 647
		private int cardArrayOffset;

		// Token: 0x04000288 RID: 648
		private Vector3[] cardPositions;

		// Token: 0x04000289 RID: 649
		private int xPowerDifference;

		// Token: 0x0400028A RID: 650
		public static bool canUseHorizontalAxis = true;
	}
}
