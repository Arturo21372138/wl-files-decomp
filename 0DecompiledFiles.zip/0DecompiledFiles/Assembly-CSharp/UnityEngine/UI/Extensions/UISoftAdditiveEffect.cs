﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000062 RID: 98
	[AddComponentMenu("UI/Effects/Extensions/UISoftAdditiveEffect")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class UISoftAdditiveEffect : MonoBehaviour
	{
		// Token: 0x060002EE RID: 750 RVA: 0x0001254F File Offset: 0x0001074F
		private void Start()
		{
			this.SetMaterial();
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00012558 File Offset: 0x00010758
		public void SetMaterial()
		{
			this.mGraphic = base.GetComponent<MaskableGraphic>();
			if (this.mGraphic != null)
			{
				if (this.mGraphic.material == null || this.mGraphic.material.name == "Default UI Material")
				{
					this.mGraphic.material = new Material(ShaderLibrary.GetShaderInstance("UI Extensions/UISoftAdditive"));
					return;
				}
			}
			else
			{
				Debug.LogError("Please attach component to a Graphical UI component");
			}
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x000125D3 File Offset: 0x000107D3
		public void OnValidate()
		{
			this.SetMaterial();
		}

		// Token: 0x04000243 RID: 579
		private MaskableGraphic mGraphic;
	}
}
