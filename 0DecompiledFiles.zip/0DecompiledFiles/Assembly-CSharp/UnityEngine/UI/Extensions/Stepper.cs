﻿using System;
using System.Collections;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000048 RID: 72
	[AddComponentMenu("UI/Extensions/Stepper")]
	[RequireComponent(typeof(RectTransform))]
	public class Stepper : UIBehaviour
	{
		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000210 RID: 528 RVA: 0x0000BE4C File Offset: 0x0000A04C
		private float separatorWidth
		{
			get
			{
				if (this._separatorWidth == 0f && this.separator)
				{
					this._separatorWidth = this.separator.rectTransform.rect.width;
					Image component = this.separator.GetComponent<Image>();
					if (component)
					{
						this._separatorWidth /= component.pixelsPerUnit;
					}
				}
				return this._separatorWidth;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x06000211 RID: 529 RVA: 0x0000BEBE File Offset: 0x0000A0BE
		public Selectable[] sides
		{
			get
			{
				if (this._sides == null || this._sides.Length == 0)
				{
					this._sides = this.GetSides();
				}
				return this._sides;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x06000212 RID: 530 RVA: 0x0000BEE3 File Offset: 0x0000A0E3
		// (set) Token: 0x06000213 RID: 531 RVA: 0x0000BEEB File Offset: 0x0000A0EB
		public int value
		{
			get
			{
				return this._value;
			}
			set
			{
				this._value = value;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000214 RID: 532 RVA: 0x0000BEF4 File Offset: 0x0000A0F4
		// (set) Token: 0x06000215 RID: 533 RVA: 0x0000BEFC File Offset: 0x0000A0FC
		public int minimum
		{
			get
			{
				return this._minimum;
			}
			set
			{
				this._minimum = value;
			}
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000216 RID: 534 RVA: 0x0000BF05 File Offset: 0x0000A105
		// (set) Token: 0x06000217 RID: 535 RVA: 0x0000BF0D File Offset: 0x0000A10D
		public int maximum
		{
			get
			{
				return this._maximum;
			}
			set
			{
				this._maximum = value;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000218 RID: 536 RVA: 0x0000BF16 File Offset: 0x0000A116
		// (set) Token: 0x06000219 RID: 537 RVA: 0x0000BF1E File Offset: 0x0000A11E
		public int step
		{
			get
			{
				return this._step;
			}
			set
			{
				this._step = value;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x0600021A RID: 538 RVA: 0x0000BF27 File Offset: 0x0000A127
		// (set) Token: 0x0600021B RID: 539 RVA: 0x0000BF2F File Offset: 0x0000A12F
		public bool wrap
		{
			get
			{
				return this._wrap;
			}
			set
			{
				this._wrap = value;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x0600021C RID: 540 RVA: 0x0000BF38 File Offset: 0x0000A138
		// (set) Token: 0x0600021D RID: 541 RVA: 0x0000BF40 File Offset: 0x0000A140
		public Graphic separator
		{
			get
			{
				return this._separator;
			}
			set
			{
				this._separator = value;
				this._separatorWidth = 0f;
				this.LayoutSides(this.sides);
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x0600021E RID: 542 RVA: 0x0000BF60 File Offset: 0x0000A160
		// (set) Token: 0x0600021F RID: 543 RVA: 0x0000BF68 File Offset: 0x0000A168
		public Stepper.StepperValueChangedEvent onValueChanged
		{
			get
			{
				return this._onValueChanged;
			}
			set
			{
				this._onValueChanged = value;
			}
		}

		// Token: 0x06000220 RID: 544 RVA: 0x0000BF71 File Offset: 0x0000A171
		protected Stepper()
		{
		}

		// Token: 0x06000221 RID: 545 RVA: 0x0000BF93 File Offset: 0x0000A193
		protected override void Start()
		{
			if (base.isActiveAndEnabled)
			{
				base.StartCoroutine(this.DelayedInit());
			}
		}

		// Token: 0x06000222 RID: 546 RVA: 0x0000BFAA File Offset: 0x0000A1AA
		protected override void OnEnable()
		{
			base.StartCoroutine(this.DelayedInit());
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000BFB9 File Offset: 0x0000A1B9
		private IEnumerator DelayedInit()
		{
			yield return null;
			this.RecreateSprites(this.sides);
			yield break;
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000BFC8 File Offset: 0x0000A1C8
		private Selectable[] GetSides()
		{
			Selectable[] componentsInChildren = base.GetComponentsInChildren<Selectable>();
			if (componentsInChildren.Length != 2)
			{
				throw new InvalidOperationException("A stepper must have two Button children");
			}
			if (!this.wrap)
			{
				this.DisableAtExtremes(componentsInChildren);
			}
			this.LayoutSides(componentsInChildren);
			return componentsInChildren;
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000C004 File Offset: 0x0000A204
		public void StepUp()
		{
			this.Step(this.step);
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000C012 File Offset: 0x0000A212
		public void StepDown()
		{
			this.Step(-this.step);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000C024 File Offset: 0x0000A224
		private void Step(int amount)
		{
			this.value += amount;
			if (this.wrap)
			{
				if (this.value > this.maximum)
				{
					this.value = this.minimum;
				}
				if (this.value < this.minimum)
				{
					this.value = this.maximum;
				}
			}
			else
			{
				this.value = Math.Max(this.minimum, this.value);
				this.value = Math.Min(this.maximum, this.value);
				this.DisableAtExtremes(this.sides);
			}
			this._onValueChanged.Invoke(this.value);
		}

		// Token: 0x06000228 RID: 552 RVA: 0x0000C0C8 File Offset: 0x0000A2C8
		private void DisableAtExtremes(Selectable[] sides)
		{
			sides[0].interactable = this.wrap || this.value > this.minimum;
			sides[1].interactable = this.wrap || this.value < this.maximum;
		}

		// Token: 0x06000229 RID: 553 RVA: 0x0000C118 File Offset: 0x0000A318
		private void RecreateSprites(Selectable[] sides)
		{
			for (int i = 0; i < 2; i++)
			{
				if (!(sides[i].image == null))
				{
					Sprite sprite = Stepper.CutSprite(sides[i].image.sprite, i == 0);
					StepperSide component = sides[i].GetComponent<StepperSide>();
					if (component)
					{
						component.cutSprite = sprite;
					}
					sides[i].image.overrideSprite = sprite;
				}
			}
		}

		// Token: 0x0600022A RID: 554 RVA: 0x0000C180 File Offset: 0x0000A380
		internal static Sprite CutSprite(Sprite sprite, bool leftmost)
		{
			if (sprite.border.x == 0f || sprite.border.z == 0f)
			{
				return sprite;
			}
			Rect rect = sprite.rect;
			Vector4 border = sprite.border;
			if (leftmost)
			{
				rect.xMax = border.z;
				border.z = 0f;
			}
			else
			{
				rect.xMin = border.x;
				border.x = 0f;
			}
			return Sprite.Create(sprite.texture, rect, sprite.pivot, sprite.pixelsPerUnit, 0U, SpriteMeshType.FullRect, border);
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0000C214 File Offset: 0x0000A414
		public void LayoutSides(Selectable[] sides = null)
		{
			sides = sides ?? this.sides;
			this.RecreateSprites(sides);
			RectTransform rectTransform = base.transform as RectTransform;
			float num = rectTransform.rect.width / 2f - this.separatorWidth;
			for (int i = 0; i < 2; i++)
			{
				float num2 = ((i == 0) ? 0f : (num + this.separatorWidth));
				RectTransform component = sides[i].GetComponent<RectTransform>();
				component.anchorMin = Vector2.zero;
				component.anchorMax = Vector2.zero;
				component.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, num2, num);
				component.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0f, rectTransform.rect.height);
			}
			if (this.separator)
			{
				Transform transform = base.gameObject.transform.Find("Separator");
				Graphic graphic = ((transform != null) ? transform.GetComponent<Graphic>() : Object.Instantiate<GameObject>(this.separator.gameObject).GetComponent<Graphic>());
				graphic.gameObject.name = "Separator";
				graphic.gameObject.SetActive(true);
				graphic.rectTransform.SetParent(base.transform, false);
				graphic.rectTransform.anchorMin = Vector2.zero;
				graphic.rectTransform.anchorMax = Vector2.zero;
				graphic.rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, num, this.separatorWidth);
				graphic.rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0f, rectTransform.rect.height);
			}
		}

		// Token: 0x040001C0 RID: 448
		private Selectable[] _sides;

		// Token: 0x040001C1 RID: 449
		[SerializeField]
		[Tooltip("The current step value of the control")]
		private int _value;

		// Token: 0x040001C2 RID: 450
		[SerializeField]
		[Tooltip("The minimum step value allowed by the control. When reached it will disable the '-' button")]
		private int _minimum;

		// Token: 0x040001C3 RID: 451
		[SerializeField]
		[Tooltip("The maximum step value allowed by the control. When reached it will disable the '+' button")]
		private int _maximum = 100;

		// Token: 0x040001C4 RID: 452
		[SerializeField]
		[Tooltip("The step increment used to increment / decrement the step value")]
		private int _step = 1;

		// Token: 0x040001C5 RID: 453
		[SerializeField]
		[Tooltip("Does the step value loop around from end to end")]
		private bool _wrap;

		// Token: 0x040001C6 RID: 454
		[SerializeField]
		[Tooltip("A GameObject with an Image to use as a separator between segments. Size of the RectTransform will determine the size of the separator used.\nNote, make sure to disable the separator GO so that it does not affect the scene")]
		private Graphic _separator;

		// Token: 0x040001C7 RID: 455
		private float _separatorWidth;

		// Token: 0x040001C8 RID: 456
		[SerializeField]
		private Stepper.StepperValueChangedEvent _onValueChanged = new Stepper.StepperValueChangedEvent();

		// Token: 0x0200011D RID: 285
		[Serializable]
		public class StepperValueChangedEvent : UnityEvent<int>
		{
		}
	}
}
