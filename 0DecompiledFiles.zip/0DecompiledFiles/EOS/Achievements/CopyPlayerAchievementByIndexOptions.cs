﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007EB RID: 2027
	public struct CopyPlayerAchievementByIndexOptions
	{
		// Token: 0x1700083F RID: 2111
		// (get) Token: 0x06002150 RID: 8528 RVA: 0x00027CB4 File Offset: 0x00025EB4
		// (set) Token: 0x06002151 RID: 8529 RVA: 0x00027CBC File Offset: 0x00025EBC
		public ProductUserId TargetUserId { readonly get; set; }

		// Token: 0x17000840 RID: 2112
		// (get) Token: 0x06002152 RID: 8530 RVA: 0x00027CC5 File Offset: 0x00025EC5
		// (set) Token: 0x06002153 RID: 8531 RVA: 0x00027CCD File Offset: 0x00025ECD
		public uint AchievementIndex { readonly get; set; }

		// Token: 0x17000841 RID: 2113
		// (get) Token: 0x06002154 RID: 8532 RVA: 0x00027CD6 File Offset: 0x00025ED6
		// (set) Token: 0x06002155 RID: 8533 RVA: 0x00027CDE File Offset: 0x00025EDE
		public ProductUserId LocalUserId { readonly get; set; }
	}
}
