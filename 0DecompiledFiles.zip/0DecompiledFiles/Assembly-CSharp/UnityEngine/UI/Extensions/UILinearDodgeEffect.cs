﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200005F RID: 95
	[AddComponentMenu("UI/Effects/Extensions/UILinearDodgeEffect")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class UILinearDodgeEffect : MonoBehaviour
	{
		// Token: 0x060002E2 RID: 738 RVA: 0x00012392 File Offset: 0x00010592
		private void Start()
		{
			this.SetMaterial();
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x0001239C File Offset: 0x0001059C
		public void SetMaterial()
		{
			this.mGraphic = base.GetComponent<MaskableGraphic>();
			if (this.mGraphic != null)
			{
				if (this.mGraphic.material == null || this.mGraphic.material.name == "Default UI Material")
				{
					this.mGraphic.material = new Material(ShaderLibrary.GetShaderInstance("UI Extensions/UILinearDodge"));
					return;
				}
			}
			else
			{
				Debug.LogError("Please attach component to a Graphical UI component");
			}
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x00012417 File Offset: 0x00010617
		public void OnValidate()
		{
			this.SetMaterial();
		}

		// Token: 0x04000240 RID: 576
		private MaskableGraphic mGraphic;
	}
}
