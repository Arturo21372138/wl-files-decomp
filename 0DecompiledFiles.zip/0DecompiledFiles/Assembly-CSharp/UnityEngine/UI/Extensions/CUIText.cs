﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000052 RID: 82
	[RequireComponent(typeof(RectTransform))]
	[RequireComponent(typeof(Text))]
	[AddComponentMenu("UI/Effects/Extensions/Curly UI Text")]
	public class CUIText : CUIGraphic
	{
		// Token: 0x06000291 RID: 657 RVA: 0x0000FB68 File Offset: 0x0000DD68
		public override void ReportSet()
		{
			if (this.uiGraphic == null)
			{
				this.uiGraphic = base.GetComponent<Text>();
			}
			base.ReportSet();
		}
	}
}
