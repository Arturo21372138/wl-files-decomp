﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200007D RID: 125
	public interface IFancyGridViewContext : IFancyScrollRectContext, IFancyCellGroupContext
	{
		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060003AF RID: 943
		// (set) Token: 0x060003B0 RID: 944
		Func<float> GetStartAxisSpacing { get; set; }

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060003B1 RID: 945
		// (set) Token: 0x060003B2 RID: 946
		Func<float> GetCellSize { get; set; }
	}
}
