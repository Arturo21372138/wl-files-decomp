﻿using System;
using UnityEngine;

namespace Cinemachine.PostFX
{
	// Token: 0x0200005E RID: 94
	[AddComponentMenu("")]
	public class CinemachineVolumeSettings : MonoBehaviour
	{
	}
}
