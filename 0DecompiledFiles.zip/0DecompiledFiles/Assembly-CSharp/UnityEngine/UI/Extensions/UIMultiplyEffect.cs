﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000060 RID: 96
	[AddComponentMenu("UI/Effects/Extensions/UIMultiplyEffect")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class UIMultiplyEffect : MonoBehaviour
	{
		// Token: 0x060002E6 RID: 742 RVA: 0x00012427 File Offset: 0x00010627
		private void Start()
		{
			this.SetMaterial();
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x00012430 File Offset: 0x00010630
		public void SetMaterial()
		{
			this.mGraphic = base.GetComponent<MaskableGraphic>();
			if (this.mGraphic != null)
			{
				if (this.mGraphic.material == null || this.mGraphic.material.name == "Default UI Material")
				{
					this.mGraphic.material = new Material(ShaderLibrary.GetShaderInstance("UI Extensions/UIMultiply"));
					return;
				}
			}
			else
			{
				Debug.LogError("Please attach component to a Graphical UI component");
			}
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x000124AB File Offset: 0x000106AB
		public void OnValidate()
		{
			this.SetMaterial();
		}

		// Token: 0x04000241 RID: 577
		private MaskableGraphic mGraphic;
	}
}
