﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E1 RID: 2017
	public struct CopyAchievementDefinitionByAchievementIdOptions
	{
		// Token: 0x17000838 RID: 2104
		// (get) Token: 0x06002138 RID: 8504 RVA: 0x00027B37 File Offset: 0x00025D37
		// (set) Token: 0x06002139 RID: 8505 RVA: 0x00027B3F File Offset: 0x00025D3F
		public Utf8String AchievementId { readonly get; set; }
	}
}
