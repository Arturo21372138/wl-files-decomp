﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C3 RID: 1987
	internal static class OnMessageToServerCallbackInternalImplementation
	{
		// Token: 0x17000822 RID: 2082
		// (get) Token: 0x060020D3 RID: 8403 RVA: 0x00027189 File Offset: 0x00025389
		public static OnMessageToServerCallbackInternal Delegate
		{
			get
			{
				if (OnMessageToServerCallbackInternalImplementation.s_Delegate == null)
				{
					OnMessageToServerCallbackInternalImplementation.s_Delegate = new OnMessageToServerCallbackInternal(OnMessageToServerCallbackInternalImplementation.EntryPoint);
				}
				return OnMessageToServerCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060020D4 RID: 8404 RVA: 0x000271A8 File Offset: 0x000253A8
		[MonoPInvokeCallback(typeof(OnMessageToServerCallbackInternal))]
		public static void EntryPoint(ref OnMessageToServerCallbackInfoInternal data)
		{
			OnMessageToServerCallback onMessageToServerCallback;
			OnMessageToServerCallbackInfo onMessageToServerCallbackInfo;
			if (Helper.TryGetCallback<OnMessageToServerCallbackInfoInternal, OnMessageToServerCallback, OnMessageToServerCallbackInfo>(ref data, out onMessageToServerCallback, out onMessageToServerCallbackInfo))
			{
				onMessageToServerCallback(ref onMessageToServerCallbackInfo);
			}
		}

		// Token: 0x040015DA RID: 5594
		private static OnMessageToServerCallbackInternal s_Delegate;
	}
}
