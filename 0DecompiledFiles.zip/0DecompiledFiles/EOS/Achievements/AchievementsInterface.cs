﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007DC RID: 2012
	public sealed class AchievementsInterface : Handle
	{
		// Token: 0x06002121 RID: 8481 RVA: 0x000275C4 File Offset: 0x000257C4
		public AchievementsInterface()
		{
		}

		// Token: 0x06002122 RID: 8482 RVA: 0x000275CC File Offset: 0x000257CC
		public AchievementsInterface(IntPtr innerHandle)
			: base(innerHandle)
		{
		}

		// Token: 0x06002123 RID: 8483 RVA: 0x000275D8 File Offset: 0x000257D8
		public ulong AddNotifyAchievementsUnlocked(ref AddNotifyAchievementsUnlockedOptions options, object clientData, OnAchievementsUnlockedCallback notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyAchievementsUnlockedOptionsInternal addNotifyAchievementsUnlockedOptionsInternal = default(AddNotifyAchievementsUnlockedOptionsInternal);
			addNotifyAchievementsUnlockedOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_Achievements_AddNotifyAchievementsUnlocked(base.InnerHandle, ref addNotifyAchievementsUnlockedOptionsInternal, zero, OnAchievementsUnlockedCallbackInternalImplementation.Delegate);
			Helper.Dispose<AddNotifyAchievementsUnlockedOptionsInternal>(ref addNotifyAchievementsUnlockedOptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x06002124 RID: 8484 RVA: 0x00027640 File Offset: 0x00025840
		public ulong AddNotifyAchievementsUnlockedV2(ref AddNotifyAchievementsUnlockedV2Options options, object clientData, OnAchievementsUnlockedCallbackV2 notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyAchievementsUnlockedV2OptionsInternal addNotifyAchievementsUnlockedV2OptionsInternal = default(AddNotifyAchievementsUnlockedV2OptionsInternal);
			addNotifyAchievementsUnlockedV2OptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_Achievements_AddNotifyAchievementsUnlockedV2(base.InnerHandle, ref addNotifyAchievementsUnlockedV2OptionsInternal, zero, OnAchievementsUnlockedCallbackV2InternalImplementation.Delegate);
			Helper.Dispose<AddNotifyAchievementsUnlockedV2OptionsInternal>(ref addNotifyAchievementsUnlockedV2OptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x06002125 RID: 8485 RVA: 0x000276A8 File Offset: 0x000258A8
		public Result CopyAchievementDefinitionByAchievementId(ref CopyAchievementDefinitionByAchievementIdOptions options, out Definition? outDefinition)
		{
			CopyAchievementDefinitionByAchievementIdOptionsInternal copyAchievementDefinitionByAchievementIdOptionsInternal = default(CopyAchievementDefinitionByAchievementIdOptionsInternal);
			copyAchievementDefinitionByAchievementIdOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyAchievementDefinitionByAchievementId(base.InnerHandle, ref copyAchievementDefinitionByAchievementIdOptionsInternal, out zero);
			Helper.Dispose<CopyAchievementDefinitionByAchievementIdOptionsInternal>(ref copyAchievementDefinitionByAchievementIdOptionsInternal);
			Helper.Get<DefinitionInternal, Definition>(zero, out outDefinition);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_Definition_Release(zero);
			}
			return result;
		}

		// Token: 0x06002126 RID: 8486 RVA: 0x000276FC File Offset: 0x000258FC
		public Result CopyAchievementDefinitionByIndex(ref CopyAchievementDefinitionByIndexOptions options, out Definition? outDefinition)
		{
			CopyAchievementDefinitionByIndexOptionsInternal copyAchievementDefinitionByIndexOptionsInternal = default(CopyAchievementDefinitionByIndexOptionsInternal);
			copyAchievementDefinitionByIndexOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyAchievementDefinitionByIndex(base.InnerHandle, ref copyAchievementDefinitionByIndexOptionsInternal, out zero);
			Helper.Dispose<CopyAchievementDefinitionByIndexOptionsInternal>(ref copyAchievementDefinitionByIndexOptionsInternal);
			Helper.Get<DefinitionInternal, Definition>(zero, out outDefinition);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_Definition_Release(zero);
			}
			return result;
		}

		// Token: 0x06002127 RID: 8487 RVA: 0x00027750 File Offset: 0x00025950
		public Result CopyAchievementDefinitionV2ByAchievementId(ref CopyAchievementDefinitionV2ByAchievementIdOptions options, out DefinitionV2? outDefinition)
		{
			CopyAchievementDefinitionV2ByAchievementIdOptionsInternal copyAchievementDefinitionV2ByAchievementIdOptionsInternal = default(CopyAchievementDefinitionV2ByAchievementIdOptionsInternal);
			copyAchievementDefinitionV2ByAchievementIdOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyAchievementDefinitionV2ByAchievementId(base.InnerHandle, ref copyAchievementDefinitionV2ByAchievementIdOptionsInternal, out zero);
			Helper.Dispose<CopyAchievementDefinitionV2ByAchievementIdOptionsInternal>(ref copyAchievementDefinitionV2ByAchievementIdOptionsInternal);
			Helper.Get<DefinitionV2Internal, DefinitionV2>(zero, out outDefinition);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_DefinitionV2_Release(zero);
			}
			return result;
		}

		// Token: 0x06002128 RID: 8488 RVA: 0x000277A4 File Offset: 0x000259A4
		public Result CopyAchievementDefinitionV2ByIndex(ref CopyAchievementDefinitionV2ByIndexOptions options, out DefinitionV2? outDefinition)
		{
			CopyAchievementDefinitionV2ByIndexOptionsInternal copyAchievementDefinitionV2ByIndexOptionsInternal = default(CopyAchievementDefinitionV2ByIndexOptionsInternal);
			copyAchievementDefinitionV2ByIndexOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyAchievementDefinitionV2ByIndex(base.InnerHandle, ref copyAchievementDefinitionV2ByIndexOptionsInternal, out zero);
			Helper.Dispose<CopyAchievementDefinitionV2ByIndexOptionsInternal>(ref copyAchievementDefinitionV2ByIndexOptionsInternal);
			Helper.Get<DefinitionV2Internal, DefinitionV2>(zero, out outDefinition);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_DefinitionV2_Release(zero);
			}
			return result;
		}

		// Token: 0x06002129 RID: 8489 RVA: 0x000277F8 File Offset: 0x000259F8
		public Result CopyPlayerAchievementByAchievementId(ref CopyPlayerAchievementByAchievementIdOptions options, out PlayerAchievement? outAchievement)
		{
			CopyPlayerAchievementByAchievementIdOptionsInternal copyPlayerAchievementByAchievementIdOptionsInternal = default(CopyPlayerAchievementByAchievementIdOptionsInternal);
			copyPlayerAchievementByAchievementIdOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyPlayerAchievementByAchievementId(base.InnerHandle, ref copyPlayerAchievementByAchievementIdOptionsInternal, out zero);
			Helper.Dispose<CopyPlayerAchievementByAchievementIdOptionsInternal>(ref copyPlayerAchievementByAchievementIdOptionsInternal);
			Helper.Get<PlayerAchievementInternal, PlayerAchievement>(zero, out outAchievement);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_PlayerAchievement_Release(zero);
			}
			return result;
		}

		// Token: 0x0600212A RID: 8490 RVA: 0x0002784C File Offset: 0x00025A4C
		public Result CopyPlayerAchievementByIndex(ref CopyPlayerAchievementByIndexOptions options, out PlayerAchievement? outAchievement)
		{
			CopyPlayerAchievementByIndexOptionsInternal copyPlayerAchievementByIndexOptionsInternal = default(CopyPlayerAchievementByIndexOptionsInternal);
			copyPlayerAchievementByIndexOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyPlayerAchievementByIndex(base.InnerHandle, ref copyPlayerAchievementByIndexOptionsInternal, out zero);
			Helper.Dispose<CopyPlayerAchievementByIndexOptionsInternal>(ref copyPlayerAchievementByIndexOptionsInternal);
			Helper.Get<PlayerAchievementInternal, PlayerAchievement>(zero, out outAchievement);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_PlayerAchievement_Release(zero);
			}
			return result;
		}

		// Token: 0x0600212B RID: 8491 RVA: 0x000278A0 File Offset: 0x00025AA0
		public Result CopyUnlockedAchievementByAchievementId(ref CopyUnlockedAchievementByAchievementIdOptions options, out UnlockedAchievement? outAchievement)
		{
			CopyUnlockedAchievementByAchievementIdOptionsInternal copyUnlockedAchievementByAchievementIdOptionsInternal = default(CopyUnlockedAchievementByAchievementIdOptionsInternal);
			copyUnlockedAchievementByAchievementIdOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyUnlockedAchievementByAchievementId(base.InnerHandle, ref copyUnlockedAchievementByAchievementIdOptionsInternal, out zero);
			Helper.Dispose<CopyUnlockedAchievementByAchievementIdOptionsInternal>(ref copyUnlockedAchievementByAchievementIdOptionsInternal);
			Helper.Get<UnlockedAchievementInternal, UnlockedAchievement>(zero, out outAchievement);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_UnlockedAchievement_Release(zero);
			}
			return result;
		}

		// Token: 0x0600212C RID: 8492 RVA: 0x000278F4 File Offset: 0x00025AF4
		public Result CopyUnlockedAchievementByIndex(ref CopyUnlockedAchievementByIndexOptions options, out UnlockedAchievement? outAchievement)
		{
			CopyUnlockedAchievementByIndexOptionsInternal copyUnlockedAchievementByIndexOptionsInternal = default(CopyUnlockedAchievementByIndexOptionsInternal);
			copyUnlockedAchievementByIndexOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Result result = Bindings.EOS_Achievements_CopyUnlockedAchievementByIndex(base.InnerHandle, ref copyUnlockedAchievementByIndexOptionsInternal, out zero);
			Helper.Dispose<CopyUnlockedAchievementByIndexOptionsInternal>(ref copyUnlockedAchievementByIndexOptionsInternal);
			Helper.Get<UnlockedAchievementInternal, UnlockedAchievement>(zero, out outAchievement);
			if (zero != IntPtr.Zero)
			{
				Bindings.EOS_Achievements_UnlockedAchievement_Release(zero);
			}
			return result;
		}

		// Token: 0x0600212D RID: 8493 RVA: 0x00027948 File Offset: 0x00025B48
		public uint GetAchievementDefinitionCount(ref GetAchievementDefinitionCountOptions options)
		{
			GetAchievementDefinitionCountOptionsInternal getAchievementDefinitionCountOptionsInternal = default(GetAchievementDefinitionCountOptionsInternal);
			getAchievementDefinitionCountOptionsInternal.Set(ref options);
			uint num = Bindings.EOS_Achievements_GetAchievementDefinitionCount(base.InnerHandle, ref getAchievementDefinitionCountOptionsInternal);
			Helper.Dispose<GetAchievementDefinitionCountOptionsInternal>(ref getAchievementDefinitionCountOptionsInternal);
			return num;
		}

		// Token: 0x0600212E RID: 8494 RVA: 0x0002797C File Offset: 0x00025B7C
		public uint GetPlayerAchievementCount(ref GetPlayerAchievementCountOptions options)
		{
			GetPlayerAchievementCountOptionsInternal getPlayerAchievementCountOptionsInternal = default(GetPlayerAchievementCountOptionsInternal);
			getPlayerAchievementCountOptionsInternal.Set(ref options);
			uint num = Bindings.EOS_Achievements_GetPlayerAchievementCount(base.InnerHandle, ref getPlayerAchievementCountOptionsInternal);
			Helper.Dispose<GetPlayerAchievementCountOptionsInternal>(ref getPlayerAchievementCountOptionsInternal);
			return num;
		}

		// Token: 0x0600212F RID: 8495 RVA: 0x000279B0 File Offset: 0x00025BB0
		public uint GetUnlockedAchievementCount(ref GetUnlockedAchievementCountOptions options)
		{
			GetUnlockedAchievementCountOptionsInternal getUnlockedAchievementCountOptionsInternal = default(GetUnlockedAchievementCountOptionsInternal);
			getUnlockedAchievementCountOptionsInternal.Set(ref options);
			uint num = Bindings.EOS_Achievements_GetUnlockedAchievementCount(base.InnerHandle, ref getUnlockedAchievementCountOptionsInternal);
			Helper.Dispose<GetUnlockedAchievementCountOptionsInternal>(ref getUnlockedAchievementCountOptionsInternal);
			return num;
		}

		// Token: 0x06002130 RID: 8496 RVA: 0x000279E4 File Offset: 0x00025BE4
		public void QueryDefinitions(ref QueryDefinitionsOptions options, object clientData, OnQueryDefinitionsCompleteCallback completionDelegate)
		{
			if (completionDelegate == null)
			{
				throw new ArgumentNullException("completionDelegate");
			}
			QueryDefinitionsOptionsInternal queryDefinitionsOptionsInternal = default(QueryDefinitionsOptionsInternal);
			queryDefinitionsOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { completionDelegate });
			Bindings.EOS_Achievements_QueryDefinitions(base.InnerHandle, ref queryDefinitionsOptionsInternal, zero, OnQueryDefinitionsCompleteCallbackInternalImplementation.Delegate);
			Helper.Dispose<QueryDefinitionsOptionsInternal>(ref queryDefinitionsOptionsInternal);
		}

		// Token: 0x06002131 RID: 8497 RVA: 0x00027A44 File Offset: 0x00025C44
		public void QueryPlayerAchievements(ref QueryPlayerAchievementsOptions options, object clientData, OnQueryPlayerAchievementsCompleteCallback completionDelegate)
		{
			if (completionDelegate == null)
			{
				throw new ArgumentNullException("completionDelegate");
			}
			QueryPlayerAchievementsOptionsInternal queryPlayerAchievementsOptionsInternal = default(QueryPlayerAchievementsOptionsInternal);
			queryPlayerAchievementsOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { completionDelegate });
			Bindings.EOS_Achievements_QueryPlayerAchievements(base.InnerHandle, ref queryPlayerAchievementsOptionsInternal, zero, OnQueryPlayerAchievementsCompleteCallbackInternalImplementation.Delegate);
			Helper.Dispose<QueryPlayerAchievementsOptionsInternal>(ref queryPlayerAchievementsOptionsInternal);
		}

		// Token: 0x06002132 RID: 8498 RVA: 0x00027AA1 File Offset: 0x00025CA1
		public void RemoveNotifyAchievementsUnlocked(ulong inId)
		{
			Bindings.EOS_Achievements_RemoveNotifyAchievementsUnlocked(base.InnerHandle, inId);
			Helper.RemoveCallbackByNotificationId(inId);
		}

		// Token: 0x06002133 RID: 8499 RVA: 0x00027AB8 File Offset: 0x00025CB8
		public void UnlockAchievements(ref UnlockAchievementsOptions options, object clientData, OnUnlockAchievementsCompleteCallback completionDelegate)
		{
			if (completionDelegate == null)
			{
				throw new ArgumentNullException("completionDelegate");
			}
			UnlockAchievementsOptionsInternal unlockAchievementsOptionsInternal = default(UnlockAchievementsOptionsInternal);
			unlockAchievementsOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { completionDelegate });
			Bindings.EOS_Achievements_UnlockAchievements(base.InnerHandle, ref unlockAchievementsOptionsInternal, zero, OnUnlockAchievementsCompleteCallbackInternalImplementation.Delegate);
			Helper.Dispose<UnlockAchievementsOptionsInternal>(ref unlockAchievementsOptionsInternal);
		}

		// Token: 0x0400160E RID: 5646
		public const int ACHIEVEMENT_UNLOCKTIME_UNDEFINED = -1;

		// Token: 0x0400160F RID: 5647
		public const int ADDNOTIFYACHIEVEMENTSUNLOCKEDV2_API_LATEST = 2;

		// Token: 0x04001610 RID: 5648
		public const int ADDNOTIFYACHIEVEMENTSUNLOCKED_API_LATEST = 1;

		// Token: 0x04001611 RID: 5649
		public const int COPYACHIEVEMENTDEFINITIONV2BYACHIEVEMENTID_API_LATEST = 2;

		// Token: 0x04001612 RID: 5650
		public const int COPYACHIEVEMENTDEFINITIONV2BYINDEX_API_LATEST = 2;

		// Token: 0x04001613 RID: 5651
		public const int COPYDEFINITIONBYACHIEVEMENTID_API_LATEST = 1;

		// Token: 0x04001614 RID: 5652
		public const int COPYDEFINITIONBYINDEX_API_LATEST = 1;

		// Token: 0x04001615 RID: 5653
		public const int COPYDEFINITIONV2BYACHIEVEMENTID_API_LATEST = 2;

		// Token: 0x04001616 RID: 5654
		public const int COPYDEFINITIONV2BYINDEX_API_LATEST = 2;

		// Token: 0x04001617 RID: 5655
		public const int COPYPLAYERACHIEVEMENTBYACHIEVEMENTID_API_LATEST = 2;

		// Token: 0x04001618 RID: 5656
		public const int COPYPLAYERACHIEVEMENTBYINDEX_API_LATEST = 2;

		// Token: 0x04001619 RID: 5657
		public const int COPYUNLOCKEDACHIEVEMENTBYACHIEVEMENTID_API_LATEST = 1;

		// Token: 0x0400161A RID: 5658
		public const int COPYUNLOCKEDACHIEVEMENTBYINDEX_API_LATEST = 1;

		// Token: 0x0400161B RID: 5659
		public const int DEFINITIONV2_API_LATEST = 2;

		// Token: 0x0400161C RID: 5660
		public const int DEFINITION_API_LATEST = 1;

		// Token: 0x0400161D RID: 5661
		public const int GETACHIEVEMENTDEFINITIONCOUNT_API_LATEST = 1;

		// Token: 0x0400161E RID: 5662
		public const int GETPLAYERACHIEVEMENTCOUNT_API_LATEST = 1;

		// Token: 0x0400161F RID: 5663
		public const int GETUNLOCKEDACHIEVEMENTCOUNT_API_LATEST = 1;

		// Token: 0x04001620 RID: 5664
		public const int PLAYERACHIEVEMENT_API_LATEST = 2;

		// Token: 0x04001621 RID: 5665
		public const int PLAYERSTATINFO_API_LATEST = 1;

		// Token: 0x04001622 RID: 5666
		public const int QUERYDEFINITIONS_API_LATEST = 3;

		// Token: 0x04001623 RID: 5667
		public const int QUERYPLAYERACHIEVEMENTS_API_LATEST = 2;

		// Token: 0x04001624 RID: 5668
		public const int STATTHRESHOLDS_API_LATEST = 1;

		// Token: 0x04001625 RID: 5669
		public const int STATTHRESHOLD_API_LATEST = 1;

		// Token: 0x04001626 RID: 5670
		public const int UNLOCKACHIEVEMENTS_API_LATEST = 1;

		// Token: 0x04001627 RID: 5671
		public const int UNLOCKEDACHIEVEMENT_API_LATEST = 1;
	}
}
