﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B0 RID: 1968
	public sealed class AntiCheatClientInterface : Handle
	{
		// Token: 0x06002088 RID: 8328 RVA: 0x00026A95 File Offset: 0x00024C95
		public AntiCheatClientInterface()
		{
		}

		// Token: 0x06002089 RID: 8329 RVA: 0x00026A9D File Offset: 0x00024C9D
		public AntiCheatClientInterface(IntPtr innerHandle)
			: base(innerHandle)
		{
		}

		// Token: 0x0600208A RID: 8330 RVA: 0x00026AA8 File Offset: 0x00024CA8
		public Result AddExternalIntegrityCatalog(ref AddExternalIntegrityCatalogOptions options)
		{
			AddExternalIntegrityCatalogOptionsInternal addExternalIntegrityCatalogOptionsInternal = default(AddExternalIntegrityCatalogOptionsInternal);
			addExternalIntegrityCatalogOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_AddExternalIntegrityCatalog(base.InnerHandle, ref addExternalIntegrityCatalogOptionsInternal);
			Helper.Dispose<AddExternalIntegrityCatalogOptionsInternal>(ref addExternalIntegrityCatalogOptionsInternal);
			return result;
		}

		// Token: 0x0600208B RID: 8331 RVA: 0x00026ADC File Offset: 0x00024CDC
		public ulong AddNotifyClientIntegrityViolated(ref AddNotifyClientIntegrityViolatedOptions options, object clientData, OnClientIntegrityViolatedCallback notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyClientIntegrityViolatedOptionsInternal addNotifyClientIntegrityViolatedOptionsInternal = default(AddNotifyClientIntegrityViolatedOptionsInternal);
			addNotifyClientIntegrityViolatedOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_AntiCheatClient_AddNotifyClientIntegrityViolated(base.InnerHandle, ref addNotifyClientIntegrityViolatedOptionsInternal, zero, OnClientIntegrityViolatedCallbackInternalImplementation.Delegate);
			Helper.Dispose<AddNotifyClientIntegrityViolatedOptionsInternal>(ref addNotifyClientIntegrityViolatedOptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x0600208C RID: 8332 RVA: 0x00026B44 File Offset: 0x00024D44
		public ulong AddNotifyMessageToPeer(ref AddNotifyMessageToPeerOptions options, object clientData, OnMessageToPeerCallback notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyMessageToPeerOptionsInternal addNotifyMessageToPeerOptionsInternal = default(AddNotifyMessageToPeerOptionsInternal);
			addNotifyMessageToPeerOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_AntiCheatClient_AddNotifyMessageToPeer(base.InnerHandle, ref addNotifyMessageToPeerOptionsInternal, zero, OnMessageToPeerCallbackInternalImplementation.Delegate);
			Helper.Dispose<AddNotifyMessageToPeerOptionsInternal>(ref addNotifyMessageToPeerOptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x0600208D RID: 8333 RVA: 0x00026BAC File Offset: 0x00024DAC
		public ulong AddNotifyMessageToServer(ref AddNotifyMessageToServerOptions options, object clientData, OnMessageToServerCallback notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyMessageToServerOptionsInternal addNotifyMessageToServerOptionsInternal = default(AddNotifyMessageToServerOptionsInternal);
			addNotifyMessageToServerOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_AntiCheatClient_AddNotifyMessageToServer(base.InnerHandle, ref addNotifyMessageToServerOptionsInternal, zero, OnMessageToServerCallbackInternalImplementation.Delegate);
			Helper.Dispose<AddNotifyMessageToServerOptionsInternal>(ref addNotifyMessageToServerOptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x0600208E RID: 8334 RVA: 0x00026C14 File Offset: 0x00024E14
		public ulong AddNotifyPeerActionRequired(ref AddNotifyPeerActionRequiredOptions options, object clientData, OnPeerActionRequiredCallback notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyPeerActionRequiredOptionsInternal addNotifyPeerActionRequiredOptionsInternal = default(AddNotifyPeerActionRequiredOptionsInternal);
			addNotifyPeerActionRequiredOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_AntiCheatClient_AddNotifyPeerActionRequired(base.InnerHandle, ref addNotifyPeerActionRequiredOptionsInternal, zero, OnPeerActionRequiredCallbackInternalImplementation.Delegate);
			Helper.Dispose<AddNotifyPeerActionRequiredOptionsInternal>(ref addNotifyPeerActionRequiredOptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x0600208F RID: 8335 RVA: 0x00026C7C File Offset: 0x00024E7C
		public ulong AddNotifyPeerAuthStatusChanged(ref AddNotifyPeerAuthStatusChangedOptions options, object clientData, OnPeerAuthStatusChangedCallback notificationFn)
		{
			if (notificationFn == null)
			{
				throw new ArgumentNullException("notificationFn");
			}
			AddNotifyPeerAuthStatusChangedOptionsInternal addNotifyPeerAuthStatusChangedOptionsInternal = default(AddNotifyPeerAuthStatusChangedOptionsInternal);
			addNotifyPeerAuthStatusChangedOptionsInternal.Set(ref options);
			IntPtr zero = IntPtr.Zero;
			Helper.AddCallback(out zero, clientData, new Delegate[] { notificationFn });
			ulong num = Bindings.EOS_AntiCheatClient_AddNotifyPeerAuthStatusChanged(base.InnerHandle, ref addNotifyPeerAuthStatusChangedOptionsInternal, zero, OnPeerAuthStatusChangedCallbackInternalImplementation.Delegate);
			Helper.Dispose<AddNotifyPeerAuthStatusChangedOptionsInternal>(ref addNotifyPeerAuthStatusChangedOptionsInternal);
			Helper.AssignNotificationIdToCallback(zero, num);
			return num;
		}

		// Token: 0x06002090 RID: 8336 RVA: 0x00026CE4 File Offset: 0x00024EE4
		public Result BeginSession(ref BeginSessionOptions options)
		{
			BeginSessionOptionsInternal beginSessionOptionsInternal = default(BeginSessionOptionsInternal);
			beginSessionOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_BeginSession(base.InnerHandle, ref beginSessionOptionsInternal);
			Helper.Dispose<BeginSessionOptionsInternal>(ref beginSessionOptionsInternal);
			return result;
		}

		// Token: 0x06002091 RID: 8337 RVA: 0x00026D18 File Offset: 0x00024F18
		public Result EndSession(ref EndSessionOptions options)
		{
			EndSessionOptionsInternal endSessionOptionsInternal = default(EndSessionOptionsInternal);
			endSessionOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_EndSession(base.InnerHandle, ref endSessionOptionsInternal);
			Helper.Dispose<EndSessionOptionsInternal>(ref endSessionOptionsInternal);
			return result;
		}

		// Token: 0x06002092 RID: 8338 RVA: 0x00026D4C File Offset: 0x00024F4C
		public Result GetProtectMessageOutputLength(ref GetProtectMessageOutputLengthOptions options, out uint outBufferSizeBytes)
		{
			GetProtectMessageOutputLengthOptionsInternal getProtectMessageOutputLengthOptionsInternal = default(GetProtectMessageOutputLengthOptionsInternal);
			getProtectMessageOutputLengthOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_GetProtectMessageOutputLength(base.InnerHandle, ref getProtectMessageOutputLengthOptionsInternal, out outBufferSizeBytes);
			Helper.Dispose<GetProtectMessageOutputLengthOptionsInternal>(ref getProtectMessageOutputLengthOptionsInternal);
			return result;
		}

		// Token: 0x06002093 RID: 8339 RVA: 0x00026D80 File Offset: 0x00024F80
		public Result PollStatus(ref PollStatusOptions options, out AntiCheatClientViolationType outViolationType, out Utf8String outMessage)
		{
			PollStatusOptionsInternal pollStatusOptionsInternal = default(PollStatusOptionsInternal);
			pollStatusOptionsInternal.Set(ref options);
			IntPtr intPtr = Helper.AddAllocation(options.OutMessageLength);
			Result result = Bindings.EOS_AntiCheatClient_PollStatus(base.InnerHandle, ref pollStatusOptionsInternal, out outViolationType, intPtr);
			Helper.Dispose<PollStatusOptionsInternal>(ref pollStatusOptionsInternal);
			Helper.Get(intPtr, out outMessage);
			Helper.Dispose(ref intPtr);
			return result;
		}

		// Token: 0x06002094 RID: 8340 RVA: 0x00026DD0 File Offset: 0x00024FD0
		public Result ProtectMessage(ref ProtectMessageOptions options, ArraySegment<byte> outBuffer, out uint outBytesWritten)
		{
			ProtectMessageOptionsInternal protectMessageOptionsInternal = default(ProtectMessageOptionsInternal);
			protectMessageOptionsInternal.Set(ref options);
			IntPtr intPtr = Helper.AddPinnedBuffer(outBuffer);
			Result result = Bindings.EOS_AntiCheatClient_ProtectMessage(base.InnerHandle, ref protectMessageOptionsInternal, intPtr, out outBytesWritten);
			Helper.Dispose<ProtectMessageOptionsInternal>(ref protectMessageOptionsInternal);
			Helper.Dispose(ref intPtr);
			return result;
		}

		// Token: 0x06002095 RID: 8341 RVA: 0x00026E14 File Offset: 0x00025014
		public Result ReceiveMessageFromPeer(ref ReceiveMessageFromPeerOptions options)
		{
			ReceiveMessageFromPeerOptionsInternal receiveMessageFromPeerOptionsInternal = default(ReceiveMessageFromPeerOptionsInternal);
			receiveMessageFromPeerOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_ReceiveMessageFromPeer(base.InnerHandle, ref receiveMessageFromPeerOptionsInternal);
			Helper.Dispose<ReceiveMessageFromPeerOptionsInternal>(ref receiveMessageFromPeerOptionsInternal);
			return result;
		}

		// Token: 0x06002096 RID: 8342 RVA: 0x00026E48 File Offset: 0x00025048
		public Result ReceiveMessageFromServer(ref ReceiveMessageFromServerOptions options)
		{
			ReceiveMessageFromServerOptionsInternal receiveMessageFromServerOptionsInternal = default(ReceiveMessageFromServerOptionsInternal);
			receiveMessageFromServerOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_ReceiveMessageFromServer(base.InnerHandle, ref receiveMessageFromServerOptionsInternal);
			Helper.Dispose<ReceiveMessageFromServerOptionsInternal>(ref receiveMessageFromServerOptionsInternal);
			return result;
		}

		// Token: 0x06002097 RID: 8343 RVA: 0x00026E7C File Offset: 0x0002507C
		public Result RegisterPeer(ref RegisterPeerOptions options)
		{
			RegisterPeerOptionsInternal registerPeerOptionsInternal = default(RegisterPeerOptionsInternal);
			registerPeerOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_RegisterPeer(base.InnerHandle, ref registerPeerOptionsInternal);
			Helper.Dispose<RegisterPeerOptionsInternal>(ref registerPeerOptionsInternal);
			return result;
		}

		// Token: 0x06002098 RID: 8344 RVA: 0x00026EAD File Offset: 0x000250AD
		public void RemoveNotifyClientIntegrityViolated(ulong notificationId)
		{
			Bindings.EOS_AntiCheatClient_RemoveNotifyClientIntegrityViolated(base.InnerHandle, notificationId);
			Helper.RemoveCallbackByNotificationId(notificationId);
		}

		// Token: 0x06002099 RID: 8345 RVA: 0x00026EC1 File Offset: 0x000250C1
		public void RemoveNotifyMessageToPeer(ulong notificationId)
		{
			Bindings.EOS_AntiCheatClient_RemoveNotifyMessageToPeer(base.InnerHandle, notificationId);
			Helper.RemoveCallbackByNotificationId(notificationId);
		}

		// Token: 0x0600209A RID: 8346 RVA: 0x00026ED5 File Offset: 0x000250D5
		public void RemoveNotifyMessageToServer(ulong notificationId)
		{
			Bindings.EOS_AntiCheatClient_RemoveNotifyMessageToServer(base.InnerHandle, notificationId);
			Helper.RemoveCallbackByNotificationId(notificationId);
		}

		// Token: 0x0600209B RID: 8347 RVA: 0x00026EE9 File Offset: 0x000250E9
		public void RemoveNotifyPeerActionRequired(ulong notificationId)
		{
			Bindings.EOS_AntiCheatClient_RemoveNotifyPeerActionRequired(base.InnerHandle, notificationId);
			Helper.RemoveCallbackByNotificationId(notificationId);
		}

		// Token: 0x0600209C RID: 8348 RVA: 0x00026EFD File Offset: 0x000250FD
		public void RemoveNotifyPeerAuthStatusChanged(ulong notificationId)
		{
			Bindings.EOS_AntiCheatClient_RemoveNotifyPeerAuthStatusChanged(base.InnerHandle, notificationId);
			Helper.RemoveCallbackByNotificationId(notificationId);
		}

		// Token: 0x0600209D RID: 8349 RVA: 0x00026F14 File Offset: 0x00025114
		public Result Reserved01(ref Reserved01Options options, out int outValue)
		{
			Reserved01OptionsInternal reserved01OptionsInternal = default(Reserved01OptionsInternal);
			reserved01OptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_Reserved01(base.InnerHandle, ref reserved01OptionsInternal, out outValue);
			Helper.Dispose<Reserved01OptionsInternal>(ref reserved01OptionsInternal);
			return result;
		}

		// Token: 0x0600209E RID: 8350 RVA: 0x00026F48 File Offset: 0x00025148
		public Result UnprotectMessage(ref UnprotectMessageOptions options, ArraySegment<byte> outBuffer, out uint outBytesWritten)
		{
			UnprotectMessageOptionsInternal unprotectMessageOptionsInternal = default(UnprotectMessageOptionsInternal);
			unprotectMessageOptionsInternal.Set(ref options);
			IntPtr intPtr = Helper.AddPinnedBuffer(outBuffer);
			Result result = Bindings.EOS_AntiCheatClient_UnprotectMessage(base.InnerHandle, ref unprotectMessageOptionsInternal, intPtr, out outBytesWritten);
			Helper.Dispose<UnprotectMessageOptionsInternal>(ref unprotectMessageOptionsInternal);
			Helper.Dispose(ref intPtr);
			return result;
		}

		// Token: 0x0600209F RID: 8351 RVA: 0x00026F8C File Offset: 0x0002518C
		public Result UnregisterPeer(ref UnregisterPeerOptions options)
		{
			UnregisterPeerOptionsInternal unregisterPeerOptionsInternal = default(UnregisterPeerOptionsInternal);
			unregisterPeerOptionsInternal.Set(ref options);
			Result result = Bindings.EOS_AntiCheatClient_UnregisterPeer(base.InnerHandle, ref unregisterPeerOptionsInternal);
			Helper.Dispose<UnregisterPeerOptionsInternal>(ref unregisterPeerOptionsInternal);
			return result;
		}

		// Token: 0x0400159E RID: 5534
		public const int ADDEXTERNALINTEGRITYCATALOG_API_LATEST = 1;

		// Token: 0x0400159F RID: 5535
		public const int ADDNOTIFYCLIENTINTEGRITYVIOLATED_API_LATEST = 1;

		// Token: 0x040015A0 RID: 5536
		public const int ADDNOTIFYMESSAGETOPEER_API_LATEST = 1;

		// Token: 0x040015A1 RID: 5537
		public const int ADDNOTIFYMESSAGETOSERVER_API_LATEST = 1;

		// Token: 0x040015A2 RID: 5538
		public const int ADDNOTIFYPEERACTIONREQUIRED_API_LATEST = 1;

		// Token: 0x040015A3 RID: 5539
		public const int ADDNOTIFYPEERAUTHSTATUSCHANGED_API_LATEST = 1;

		// Token: 0x040015A4 RID: 5540
		public const int BEGINSESSION_API_LATEST = 3;

		// Token: 0x040015A5 RID: 5541
		public const int ENDSESSION_API_LATEST = 1;

		// Token: 0x040015A6 RID: 5542
		public const int GETPROTECTMESSAGEOUTPUTLENGTH_API_LATEST = 1;

		// Token: 0x040015A7 RID: 5543
		public const int ONMESSAGETOPEERCALLBACK_MAX_MESSAGE_SIZE = 512;

		// Token: 0x040015A8 RID: 5544
		public const int ONMESSAGETOSERVERCALLBACK_MAX_MESSAGE_SIZE = 512;

		// Token: 0x040015A9 RID: 5545
		public static readonly IntPtr PEER_SELF = (IntPtr)(-1);

		// Token: 0x040015AA RID: 5546
		public const int POLLSTATUS_API_LATEST = 1;

		// Token: 0x040015AB RID: 5547
		public const int PROTECTMESSAGE_API_LATEST = 1;

		// Token: 0x040015AC RID: 5548
		public const int RECEIVEMESSAGEFROMPEER_API_LATEST = 1;

		// Token: 0x040015AD RID: 5549
		public const int RECEIVEMESSAGEFROMSERVER_API_LATEST = 1;

		// Token: 0x040015AE RID: 5550
		public const int REGISTERPEER_API_LATEST = 3;

		// Token: 0x040015AF RID: 5551
		public const int REGISTERPEER_MAX_AUTHENTICATIONTIMEOUT = 120;

		// Token: 0x040015B0 RID: 5552
		public const int REGISTERPEER_MIN_AUTHENTICATIONTIMEOUT = 40;

		// Token: 0x040015B1 RID: 5553
		public const int RESERVED01_API_LATEST = 1;

		// Token: 0x040015B2 RID: 5554
		public const int UNPROTECTMESSAGE_API_LATEST = 1;

		// Token: 0x040015B3 RID: 5555
		public const int UNREGISTERPEER_API_LATEST = 1;
	}
}
