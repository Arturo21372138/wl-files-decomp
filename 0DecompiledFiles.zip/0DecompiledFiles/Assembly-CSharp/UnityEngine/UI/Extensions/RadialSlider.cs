﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200003A RID: 58
	[AddComponentMenu("UI/Extensions/Radial Slider")]
	[RequireComponent(typeof(Image))]
	public class RadialSlider : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerDownHandler, IPointerUpHandler, IDragHandler
	{
		// Token: 0x1700002C RID: 44
		// (get) Token: 0x0600014F RID: 335 RVA: 0x00008373 File Offset: 0x00006573
		// (set) Token: 0x06000150 RID: 336 RVA: 0x00008386 File Offset: 0x00006586
		public float Angle
		{
			get
			{
				return this.RadialImage.fillAmount * 360f;
			}
			set
			{
				if (this.LerpToTarget)
				{
					this.StartLerp(value / 360f);
					return;
				}
				this.UpdateRadialImage(value / 360f);
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000151 RID: 337 RVA: 0x000083AB File Offset: 0x000065AB
		// (set) Token: 0x06000152 RID: 338 RVA: 0x000083B8 File Offset: 0x000065B8
		public float Value
		{
			get
			{
				return this.RadialImage.fillAmount;
			}
			set
			{
				if (this.LerpToTarget)
				{
					this.StartLerp(value);
					return;
				}
				this.UpdateRadialImage(value);
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000153 RID: 339 RVA: 0x000083D1 File Offset: 0x000065D1
		// (set) Token: 0x06000154 RID: 340 RVA: 0x000083D9 File Offset: 0x000065D9
		public Color EndColor
		{
			get
			{
				return this.m_endColor;
			}
			set
			{
				this.m_endColor = value;
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000155 RID: 341 RVA: 0x000083E2 File Offset: 0x000065E2
		// (set) Token: 0x06000156 RID: 342 RVA: 0x000083EA File Offset: 0x000065EA
		public Color StartColor
		{
			get
			{
				return this.m_startColor;
			}
			set
			{
				this.m_startColor = value;
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x06000157 RID: 343 RVA: 0x000083F3 File Offset: 0x000065F3
		// (set) Token: 0x06000158 RID: 344 RVA: 0x000083FB File Offset: 0x000065FB
		public bool LerpToTarget
		{
			get
			{
				return this.m_lerpToTarget;
			}
			set
			{
				this.m_lerpToTarget = value;
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000159 RID: 345 RVA: 0x00008404 File Offset: 0x00006604
		// (set) Token: 0x0600015A RID: 346 RVA: 0x0000840C File Offset: 0x0000660C
		public AnimationCurve LerpCurve
		{
			get
			{
				return this.m_lerpCurve;
			}
			set
			{
				this.m_lerpCurve = value;
				this.m_lerpTime = this.LerpCurve[this.LerpCurve.length - 1].time;
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x0600015B RID: 347 RVA: 0x00008446 File Offset: 0x00006646
		public bool LerpInProgress
		{
			get
			{
				return this.lerpInProgress;
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x0600015C RID: 348 RVA: 0x00008450 File Offset: 0x00006650
		public Image RadialImage
		{
			get
			{
				if (this.m_image == null)
				{
					this.m_image = base.GetComponent<Image>();
					this.m_image.type = Image.Type.Filled;
					this.m_image.fillMethod = Image.FillMethod.Radial360;
					this.m_image.fillAmount = 0f;
				}
				return this.m_image;
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600015D RID: 349 RVA: 0x000084A5 File Offset: 0x000066A5
		// (set) Token: 0x0600015E RID: 350 RVA: 0x000084AD File Offset: 0x000066AD
		public RadialSlider.RadialSliderValueChangedEvent onValueChanged
		{
			get
			{
				return this._onValueChanged;
			}
			set
			{
				this._onValueChanged = value;
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600015F RID: 351 RVA: 0x000084B6 File Offset: 0x000066B6
		// (set) Token: 0x06000160 RID: 352 RVA: 0x000084BE File Offset: 0x000066BE
		public RadialSlider.RadialSliderTextValueChangedEvent onTextValueChanged
		{
			get
			{
				return this._onTextValueChanged;
			}
			set
			{
				this._onTextValueChanged = value;
			}
		}

		// Token: 0x06000161 RID: 353 RVA: 0x000084C8 File Offset: 0x000066C8
		private void Awake()
		{
			if (this.LerpCurve != null && this.LerpCurve.length > 0)
			{
				this.m_lerpTime = this.LerpCurve[this.LerpCurve.length - 1].time;
				return;
			}
			this.m_lerpTime = 1f;
		}

		// Token: 0x06000162 RID: 354 RVA: 0x00008520 File Offset: 0x00006720
		private void Update()
		{
			if (this.isPointerDown)
			{
				this.m_targetAngle = this.GetAngleFromMousePoint();
				if (!this.lerpInProgress)
				{
					if (!this.LerpToTarget)
					{
						this.UpdateRadialImage(this.m_targetAngle);
						this.NotifyValueChanged();
					}
					else
					{
						if (this.isPointerReleased)
						{
							this.StartLerp(this.m_targetAngle);
						}
						this.isPointerReleased = false;
					}
				}
			}
			if (this.lerpInProgress && this.Value != this.m_lerpTargetAngle)
			{
				this.m_currentLerpTime += Time.deltaTime;
				float num = this.m_currentLerpTime / this.m_lerpTime;
				if (this.LerpCurve != null && this.LerpCurve.length > 0)
				{
					this.UpdateRadialImage(Mathf.Lerp(this.m_startAngle, this.m_lerpTargetAngle, this.LerpCurve.Evaluate(num)));
				}
				else
				{
					this.UpdateRadialImage(Mathf.Lerp(this.m_startAngle, this.m_lerpTargetAngle, num));
				}
			}
			if (this.m_currentLerpTime >= this.m_lerpTime || this.Value == this.m_lerpTargetAngle)
			{
				this.lerpInProgress = false;
				this.UpdateRadialImage(this.m_lerpTargetAngle);
				this.NotifyValueChanged();
			}
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00008641 File Offset: 0x00006841
		private void StartLerp(float targetAngle)
		{
			if (!this.lerpInProgress)
			{
				this.m_startAngle = this.Value;
				this.m_lerpTargetAngle = targetAngle;
				this.m_currentLerpTime = 0f;
				this.lerpInProgress = true;
			}
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00008670 File Offset: 0x00006870
		private float GetAngleFromMousePoint()
		{
			RectTransformUtility.ScreenPointToLocalPointInRectangle(base.transform as RectTransform, this.m_screenPos, this.m_eventCamera, out this.m_localPos);
			return (Mathf.Atan2(-this.m_localPos.y, this.m_localPos.x) * 180f / 3.1415927f + 180f) / 360f;
		}

		// Token: 0x06000165 RID: 357 RVA: 0x000086D4 File Offset: 0x000068D4
		private void UpdateRadialImage(float targetAngle)
		{
			this.RadialImage.fillAmount = targetAngle;
			this.RadialImage.color = Color.Lerp(this.m_startColor, this.m_endColor, targetAngle);
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00008700 File Offset: 0x00006900
		private void NotifyValueChanged()
		{
			this._onValueChanged.Invoke((int)(this.m_targetAngle * 360f));
			this._onTextValueChanged.Invoke(((int)(this.m_targetAngle * 360f)).ToString());
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00008745 File Offset: 0x00006945
		public void OnPointerEnter(PointerEventData eventData)
		{
			this.m_screenPos = eventData.position;
			this.m_eventCamera = eventData.enterEventCamera;
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000875F File Offset: 0x0000695F
		public void OnPointerDown(PointerEventData eventData)
		{
			this.m_screenPos = eventData.position;
			this.m_eventCamera = eventData.enterEventCamera;
			this.isPointerDown = true;
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00008780 File Offset: 0x00006980
		public void OnPointerUp(PointerEventData eventData)
		{
			this.m_screenPos = Vector2.zero;
			this.isPointerDown = false;
			this.isPointerReleased = true;
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000879B File Offset: 0x0000699B
		public void OnDrag(PointerEventData eventData)
		{
			this.m_screenPos = eventData.position;
		}

		// Token: 0x0400013F RID: 319
		private bool isPointerDown;

		// Token: 0x04000140 RID: 320
		private bool isPointerReleased;

		// Token: 0x04000141 RID: 321
		private bool lerpInProgress;

		// Token: 0x04000142 RID: 322
		private Vector2 m_localPos;

		// Token: 0x04000143 RID: 323
		private Vector2 m_screenPos;

		// Token: 0x04000144 RID: 324
		private float m_targetAngle;

		// Token: 0x04000145 RID: 325
		private float m_lerpTargetAngle;

		// Token: 0x04000146 RID: 326
		private float m_startAngle;

		// Token: 0x04000147 RID: 327
		private float m_currentLerpTime;

		// Token: 0x04000148 RID: 328
		private float m_lerpTime;

		// Token: 0x04000149 RID: 329
		private Camera m_eventCamera;

		// Token: 0x0400014A RID: 330
		private Image m_image;

		// Token: 0x0400014B RID: 331
		[SerializeField]
		[Tooltip("Radial Gradient Start Color")]
		private Color m_startColor = Color.green;

		// Token: 0x0400014C RID: 332
		[SerializeField]
		[Tooltip("Radial Gradient End Color")]
		private Color m_endColor = Color.red;

		// Token: 0x0400014D RID: 333
		[Tooltip("Move slider absolute or use Lerping?\nDragging only supported with absolute")]
		[SerializeField]
		private bool m_lerpToTarget;

		// Token: 0x0400014E RID: 334
		[Tooltip("Curve to apply to the Lerp\nMust be set to enable Lerp")]
		[SerializeField]
		private AnimationCurve m_lerpCurve;

		// Token: 0x0400014F RID: 335
		[Tooltip("Event fired when value of control changes, outputs an INT angle value")]
		[SerializeField]
		private RadialSlider.RadialSliderValueChangedEvent _onValueChanged = new RadialSlider.RadialSliderValueChangedEvent();

		// Token: 0x04000150 RID: 336
		[Tooltip("Event fired when value of control changes, outputs a TEXT angle value")]
		[SerializeField]
		private RadialSlider.RadialSliderTextValueChangedEvent _onTextValueChanged = new RadialSlider.RadialSliderTextValueChangedEvent();

		// Token: 0x02000112 RID: 274
		[Serializable]
		public class RadialSliderValueChangedEvent : UnityEvent<int>
		{
		}

		// Token: 0x02000113 RID: 275
		[Serializable]
		public class RadialSliderTextValueChangedEvent : UnityEvent<string>
		{
		}
	}
}
