﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000821 RID: 2081
	internal struct UnlockedAchievementInternal : IGettable<UnlockedAchievement>
	{
		// Token: 0x06002237 RID: 8759 RVA: 0x00028A48 File Offset: 0x00026C48
		public void Get(out UnlockedAchievement other)
		{
			other = default(UnlockedAchievement);
			Utf8String utf8String;
			Helper.Get(this.m_AchievementId, out utf8String);
			other.AchievementId = utf8String;
			DateTimeOffset? dateTimeOffset;
			Helper.Get(this.m_UnlockTime, out dateTimeOffset);
			other.UnlockTime = dateTimeOffset;
		}

		// Token: 0x040016DE RID: 5854
		private int m_ApiVersion;

		// Token: 0x040016DF RID: 5855
		private IntPtr m_AchievementId;

		// Token: 0x040016E0 RID: 5856
		private long m_UnlockTime;
	}
}
