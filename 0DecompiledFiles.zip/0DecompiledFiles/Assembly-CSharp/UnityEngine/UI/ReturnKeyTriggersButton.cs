﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI
{
	// Token: 0x0200002C RID: 44
	[RequireComponent(typeof(InputField))]
	[AddComponentMenu("UI/Extensions/Return Key Trigger")]
	public class ReturnKeyTriggersButton : MonoBehaviour, ISubmitHandler, IEventSystemHandler
	{
		// Token: 0x060000A0 RID: 160 RVA: 0x000054F0 File Offset: 0x000036F0
		private void Start()
		{
			this._system = EventSystem.current;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x000054FD File Offset: 0x000036FD
		private void RemoveHighlight()
		{
			this.button.OnPointerExit(new PointerEventData(this._system));
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00005518 File Offset: 0x00003718
		public void OnSubmit(BaseEventData eventData)
		{
			if (this.highlight)
			{
				this.button.OnPointerEnter(new PointerEventData(this._system));
			}
			this.button.OnPointerClick(new PointerEventData(this._system));
			if (this.highlight)
			{
				base.Invoke("RemoveHighlight", this.highlightDuration);
			}
		}

		// Token: 0x040000B3 RID: 179
		private EventSystem _system;

		// Token: 0x040000B4 RID: 180
		public Button button;

		// Token: 0x040000B5 RID: 181
		private bool highlight = true;

		// Token: 0x040000B6 RID: 182
		public float highlightDuration = 0.2f;
	}
}
