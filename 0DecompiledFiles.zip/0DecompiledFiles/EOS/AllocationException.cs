﻿using System;

namespace Epic.OnlineServices
{
	// Token: 0x0200000F RID: 15
	internal class AllocationException : Exception
	{
		// Token: 0x060000E2 RID: 226 RVA: 0x00006262 File Offset: 0x00004462
		public AllocationException(string message)
			: base(message)
		{
		}
	}
}
