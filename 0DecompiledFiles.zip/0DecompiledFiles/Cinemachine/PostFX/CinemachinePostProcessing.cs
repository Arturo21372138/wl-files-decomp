﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.SceneManagement;

namespace Cinemachine.PostFX
{
	// Token: 0x0200005D RID: 93
	[DocumentationSorting(DocumentationSortingAttribute.Level.UserRef)]
	[ExecuteAlways]
	[AddComponentMenu("")]
	[SaveDuringPlay]
	[DisallowMultipleComponent]
	[HelpURL("https://docs.unity3d.com/Packages/com.unity.cinemachine@2.9/manual/CinemachinePostProcessing.html")]
	public class CinemachinePostProcessing : CinemachineExtension
	{
		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060003AE RID: 942 RVA: 0x00016A3B File Offset: 0x00014C3B
		public bool IsValid
		{
			get
			{
				return this.m_Profile != null && this.m_Profile.settings.Count > 0;
			}
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00016A60 File Offset: 0x00014C60
		public void InvalidateCachedProfile()
		{
			List<CinemachinePostProcessing.VcamExtraState> allExtraStates = base.GetAllExtraStates<CinemachinePostProcessing.VcamExtraState>();
			for (int i = 0; i < allExtraStates.Count; i++)
			{
				allExtraStates[i].DestroyProfileCopy();
			}
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00016A91 File Offset: 0x00014C91
		protected override void OnEnable()
		{
			base.OnEnable();
			if (this.m_FocusTracksTarget)
			{
				this.m_FocusTracking = ((base.VirtualCamera.LookAt != null) ? CinemachinePostProcessing.FocusTrackingMode.LookAtTarget : CinemachinePostProcessing.FocusTrackingMode.Camera);
			}
			this.m_FocusTracksTarget = false;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00016AC5 File Offset: 0x00014CC5
		protected override void OnDestroy()
		{
			this.InvalidateCachedProfile();
			base.OnDestroy();
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00016AD4 File Offset: 0x00014CD4
		protected override void PostPipelineStageCallback(CinemachineVirtualCameraBase vcam, CinemachineCore.Stage stage, ref CameraState state, float deltaTime)
		{
			if (stage == CinemachineCore.Stage.Finalize)
			{
				CinemachinePostProcessing.VcamExtraState extraState = base.GetExtraState<CinemachinePostProcessing.VcamExtraState>(vcam);
				if (!this.IsValid)
				{
					extraState.DestroyProfileCopy();
					return;
				}
				PostProcessProfile postProcessProfile = this.m_Profile;
				if (this.m_FocusTracking == CinemachinePostProcessing.FocusTrackingMode.None)
				{
					extraState.DestroyProfileCopy();
				}
				else
				{
					if (extraState.mProfileCopy == null)
					{
						extraState.CreateProfileCopy(this.m_Profile);
					}
					postProcessProfile = extraState.mProfileCopy;
					DepthOfField depthOfField;
					if (postProcessProfile.TryGetSettings<DepthOfField>(out depthOfField))
					{
						float num = this.m_FocusOffset;
						if (this.m_FocusTracking == CinemachinePostProcessing.FocusTrackingMode.LookAtTarget)
						{
							num += (state.FinalPosition - state.ReferenceLookAt).magnitude;
						}
						else
						{
							Transform transform = null;
							CinemachinePostProcessing.FocusTrackingMode focusTracking = this.m_FocusTracking;
							if (focusTracking != CinemachinePostProcessing.FocusTrackingMode.FollowTarget)
							{
								if (focusTracking == CinemachinePostProcessing.FocusTrackingMode.CustomTarget)
								{
									transform = this.m_FocusTarget;
								}
							}
							else
							{
								transform = base.VirtualCamera.Follow;
							}
							if (transform != null)
							{
								num += (state.FinalPosition - transform.position).magnitude;
							}
						}
						state.Lens.FocusDistance = (depthOfField.focusDistance.value = Mathf.Max(0f, num));
					}
				}
				state.AddCustomBlendable(new CameraState.CustomBlendable(postProcessProfile, 1f));
			}
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00016C04 File Offset: 0x00014E04
		private static void OnCameraCut(CinemachineBrain brain)
		{
			PostProcessLayer pplayer = CinemachinePostProcessing.GetPPLayer(brain);
			if (pplayer != null && pplayer.isActiveAndEnabled)
			{
				pplayer.ResetHistory();
			}
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x00016C30 File Offset: 0x00014E30
		private static void ApplyPostFX(CinemachineBrain brain)
		{
			PostProcessLayer pplayer = CinemachinePostProcessing.GetPPLayer(brain);
			if (pplayer == null || !pplayer.enabled || pplayer.volumeLayer == 0)
			{
				return;
			}
			CameraState currentCameraState = brain.CurrentCameraState;
			int numCustomBlendables = currentCameraState.NumCustomBlendables;
			List<PostProcessVolume> dynamicBrainVolumes = CinemachinePostProcessing.GetDynamicBrainVolumes(brain, pplayer, numCustomBlendables);
			for (int i = 0; i < dynamicBrainVolumes.Count; i++)
			{
				dynamicBrainVolumes[i].weight = 0f;
				dynamicBrainVolumes[i].sharedProfile = null;
				dynamicBrainVolumes[i].profile = null;
			}
			PostProcessVolume postProcessVolume = null;
			int num = 0;
			for (int j = 0; j < numCustomBlendables; j++)
			{
				CameraState.CustomBlendable customBlendable = currentCameraState.GetCustomBlendable(j);
				PostProcessProfile postProcessProfile = customBlendable.m_Custom as PostProcessProfile;
				if (!(postProcessProfile == null))
				{
					PostProcessVolume postProcessVolume2 = dynamicBrainVolumes[j];
					if (postProcessVolume == null)
					{
						postProcessVolume = postProcessVolume2;
					}
					postProcessVolume2.sharedProfile = postProcessProfile;
					postProcessVolume2.isGlobal = true;
					postProcessVolume2.priority = CinemachinePostProcessing.s_VolumePriority - (float)(numCustomBlendables - j) - 1f;
					postProcessVolume2.weight = customBlendable.m_Weight;
					num++;
				}
				if (num > 1)
				{
					postProcessVolume.weight = 1f;
				}
			}
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00016D64 File Offset: 0x00014F64
		private static List<PostProcessVolume> GetDynamicBrainVolumes(CinemachineBrain brain, PostProcessLayer ppLayer, int minVolumes)
		{
			GameObject gameObject = null;
			Transform transform = brain.transform;
			int childCount = transform.childCount;
			CinemachinePostProcessing.sVolumes.Clear();
			int num = 0;
			while (gameObject == null && num < childCount)
			{
				GameObject gameObject2 = transform.GetChild(num).gameObject;
				if (gameObject2.hideFlags == HideFlags.HideAndDontSave)
				{
					gameObject2.GetComponents<PostProcessVolume>(CinemachinePostProcessing.sVolumes);
					if (CinemachinePostProcessing.sVolumes.Count > 0)
					{
						gameObject = gameObject2;
					}
				}
				num++;
			}
			if (minVolumes > 0)
			{
				if (gameObject == null)
				{
					gameObject = new GameObject(CinemachinePostProcessing.sVolumeOwnerName);
					gameObject.hideFlags = HideFlags.HideAndDontSave;
					gameObject.transform.parent = transform;
				}
				int value = ppLayer.volumeLayer.value;
				for (int i = 0; i < 32; i++)
				{
					if ((value & (1 << i)) != 0)
					{
						gameObject.layer = i;
						IL_00DE:
						while (CinemachinePostProcessing.sVolumes.Count < minVolumes)
						{
							CinemachinePostProcessing.sVolumes.Add(gameObject.gameObject.AddComponent<PostProcessVolume>());
						}
						goto IL_00EB;
					}
				}
				goto IL_00DE;
			}
			IL_00EB:
			return CinemachinePostProcessing.sVolumes;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00016E64 File Offset: 0x00015064
		private static PostProcessLayer GetPPLayer(CinemachineBrain brain)
		{
			PostProcessLayer postProcessLayer;
			bool flag = CinemachinePostProcessing.mBrainToLayer.TryGetValue(brain, out postProcessLayer);
			if (postProcessLayer != null)
			{
				return postProcessLayer;
			}
			if (flag && postProcessLayer != null)
			{
				brain.m_CameraCutEvent.RemoveListener(new UnityAction<CinemachineBrain>(CinemachinePostProcessing.OnCameraCut));
				CinemachinePostProcessing.mBrainToLayer.Remove(brain);
				postProcessLayer = null;
			}
			brain.TryGetComponent<PostProcessLayer>(out postProcessLayer);
			if (postProcessLayer != null)
			{
				brain.m_CameraCutEvent.AddListener(new UnityAction<CinemachineBrain>(CinemachinePostProcessing.OnCameraCut));
				CinemachinePostProcessing.mBrainToLayer[brain] = postProcessLayer;
			}
			return postProcessLayer;
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00016EF0 File Offset: 0x000150F0
		private static void CleanupLookupTable()
		{
			foreach (KeyValuePair<CinemachineBrain, PostProcessLayer> keyValuePair in CinemachinePostProcessing.mBrainToLayer)
			{
				CinemachineBrain key = keyValuePair.Key;
				if (key != null)
				{
					key.m_CameraCutEvent.RemoveListener(new UnityAction<CinemachineBrain>(CinemachinePostProcessing.OnCameraCut));
				}
			}
			CinemachinePostProcessing.mBrainToLayer.Clear();
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x00016F50 File Offset: 0x00015150
		[RuntimeInitializeOnLoadMethod]
		private static void InitializeModule()
		{
			CinemachineCore.CameraUpdatedEvent.RemoveListener(new UnityAction<CinemachineBrain>(CinemachinePostProcessing.ApplyPostFX));
			CinemachineCore.CameraUpdatedEvent.AddListener(new UnityAction<CinemachineBrain>(CinemachinePostProcessing.ApplyPostFX));
			SceneManager.sceneUnloaded += delegate(Scene scene)
			{
				CinemachinePostProcessing.CleanupLookupTable();
			};
		}

		// Token: 0x04000283 RID: 643
		public static float s_VolumePriority = 1000f;

		// Token: 0x04000284 RID: 644
		[HideInInspector]
		public bool m_FocusTracksTarget;

		// Token: 0x04000285 RID: 645
		[Tooltip("If the profile has the appropriate overrides, will set the base focus distance to be the distance from the selected target to the camera.The Focus Offset field will then modify that distance.")]
		public CinemachinePostProcessing.FocusTrackingMode m_FocusTracking;

		// Token: 0x04000286 RID: 646
		[Tooltip("The target to use if Focus Tracks Target is set to Custom Target")]
		public Transform m_FocusTarget;

		// Token: 0x04000287 RID: 647
		[Tooltip("Offset from target distance, to be used with Focus Tracks Target.  Offsets the sharpest point away from the location of the focus target.")]
		public float m_FocusOffset;

		// Token: 0x04000288 RID: 648
		[Tooltip("This Post-Processing profile will be applied whenever this virtual camera is live")]
		public PostProcessProfile m_Profile;

		// Token: 0x04000289 RID: 649
		private static string sVolumeOwnerName = "__CMVolumes";

		// Token: 0x0400028A RID: 650
		private static List<PostProcessVolume> sVolumes = new List<PostProcessVolume>();

		// Token: 0x0400028B RID: 651
		private static Dictionary<CinemachineBrain, PostProcessLayer> mBrainToLayer = new Dictionary<CinemachineBrain, PostProcessLayer>();

		// Token: 0x020000E6 RID: 230
		public enum FocusTrackingMode
		{
			// Token: 0x04000498 RID: 1176
			None,
			// Token: 0x04000499 RID: 1177
			LookAtTarget,
			// Token: 0x0400049A RID: 1178
			FollowTarget,
			// Token: 0x0400049B RID: 1179
			CustomTarget,
			// Token: 0x0400049C RID: 1180
			Camera
		}

		// Token: 0x020000E7 RID: 231
		private class VcamExtraState
		{
			// Token: 0x06000572 RID: 1394 RVA: 0x00023794 File Offset: 0x00021994
			public void CreateProfileCopy(PostProcessProfile source)
			{
				this.DestroyProfileCopy();
				PostProcessProfile postProcessProfile = ScriptableObject.CreateInstance<PostProcessProfile>();
				if (source != null)
				{
					foreach (PostProcessEffectSettings postProcessEffectSettings in source.settings)
					{
						PostProcessEffectSettings postProcessEffectSettings2 = Object.Instantiate<PostProcessEffectSettings>(postProcessEffectSettings);
						postProcessProfile.settings.Add(postProcessEffectSettings2);
					}
				}
				this.mProfileCopy = postProcessProfile;
			}

			// Token: 0x06000573 RID: 1395 RVA: 0x00023810 File Offset: 0x00021A10
			public void DestroyProfileCopy()
			{
				if (this.mProfileCopy != null)
				{
					RuntimeUtility.DestroyObject(this.mProfileCopy);
				}
				this.mProfileCopy = null;
			}

			// Token: 0x0400049D RID: 1181
			public PostProcessProfile mProfileCopy;
		}
	}
}
