﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000085 RID: 133
	public abstract class FancyScrollRectCell<TItemData> : FancyScrollRectCell<TItemData, FancyScrollRectContext>
	{
		// Token: 0x060003FD RID: 1021 RVA: 0x000181CA File Offset: 0x000163CA
		public sealed override void SetContext(FancyScrollRectContext context)
		{
			base.SetContext(context);
		}
	}
}
