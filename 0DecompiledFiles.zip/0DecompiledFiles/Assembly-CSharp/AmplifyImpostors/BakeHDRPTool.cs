﻿using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace AmplifyImpostors
{
	// Token: 0x020000EF RID: 239
	public class BakeHDRPTool
	{
		// Token: 0x06000762 RID: 1890 RVA: 0x0002A402 File Offset: 0x00028602
		public static void SetupShaderVariableGlobals(Matrix4x4 viewMat, Matrix4x4 projMatrix, CommandBuffer commandBuffer)
		{
		}
	}
}
