﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D3 RID: 211
	public class ColorSampler : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler, IDragHandler
	{
		// Token: 0x060006FE RID: 1790 RVA: 0x00027A98 File Offset: 0x00025C98
		protected virtual void OnEnable()
		{
			this.screenCapture = ScreenCapture.CaptureScreenshotAsTexture();
			this.sampleRectTransform = this.sampler.GetComponent<RectTransform>();
			this.sampler.gameObject.SetActive(true);
			this.sampler.onClick.AddListener(new UnityAction(this.SelectColor));
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x00027AEF File Offset: 0x00025CEF
		protected virtual void OnDisable()
		{
			Object.Destroy(this.screenCapture);
			this.sampler.gameObject.SetActive(false);
			this.sampler.onClick.RemoveListener(new UnityAction(this.SelectColor));
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00027B2C File Offset: 0x00025D2C
		protected virtual void Update()
		{
			if (this.screenCapture == null)
			{
				return;
			}
			this.sampleRectTransform.position = this.m_screenPos;
			this.color = this.screenCapture.GetPixel((int)this.m_screenPos.x, (int)this.m_screenPos.y);
			this.HandleSamplerColoring();
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00027B90 File Offset: 0x00025D90
		protected virtual void HandleSamplerColoring()
		{
			this.sampler.image.color = this.color;
			if (this.samplerOutline)
			{
				Color color = Color.Lerp(Color.white, Color.black, (float)((this.color.grayscale > 0.5f) ? 1 : 0));
				color.a = this.samplerOutline.effectColor.a;
				this.samplerOutline.effectColor = color;
			}
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x00027C0A File Offset: 0x00025E0A
		protected virtual void SelectColor()
		{
			if (this.oncolorSelected != null)
			{
				this.oncolorSelected.Invoke(this.color);
			}
			base.enabled = false;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x00027C2C File Offset: 0x00025E2C
		public void OnPointerDown(PointerEventData eventData)
		{
			this.m_screenPos = eventData.position;
		}

		// Token: 0x06000704 RID: 1796 RVA: 0x00027C3A File Offset: 0x00025E3A
		public void OnPointerUp(PointerEventData eventData)
		{
			this.m_screenPos = Vector2.zero;
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x00027C47 File Offset: 0x00025E47
		public void OnDrag(PointerEventData eventData)
		{
			this.m_screenPos = eventData.position;
		}

		// Token: 0x04000526 RID: 1318
		private Vector2 m_screenPos;

		// Token: 0x04000527 RID: 1319
		[SerializeField]
		protected Button sampler;

		// Token: 0x04000528 RID: 1320
		private RectTransform sampleRectTransform;

		// Token: 0x04000529 RID: 1321
		[SerializeField]
		protected Outline samplerOutline;

		// Token: 0x0400052A RID: 1322
		protected Texture2D screenCapture;

		// Token: 0x0400052B RID: 1323
		public ColorChangedEvent oncolorSelected = new ColorChangedEvent();

		// Token: 0x0400052C RID: 1324
		protected Color color;
	}
}
