﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000BD RID: 189
	internal static class SetPropertyUtility
	{
		// Token: 0x06000638 RID: 1592 RVA: 0x000249C8 File Offset: 0x00022BC8
		public static bool SetColor(ref Color currentValue, Color newValue)
		{
			if (currentValue.r == newValue.r && currentValue.g == newValue.g && currentValue.b == newValue.b && currentValue.a == newValue.a)
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x00024A17 File Offset: 0x00022C17
		public static bool SetStruct<T>(ref T currentValue, T newValue) where T : struct
		{
			if (currentValue.Equals(newValue))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x00024A38 File Offset: 0x00022C38
		public static bool SetClass<T>(ref T currentValue, T newValue) where T : class
		{
			if ((currentValue == null && newValue == null) || (currentValue != null && currentValue.Equals(newValue)))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}
	}
}
