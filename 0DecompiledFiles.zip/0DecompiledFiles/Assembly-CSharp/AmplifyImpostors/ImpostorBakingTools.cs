﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000F5 RID: 245
	public static class ImpostorBakingTools
	{
		// Token: 0x040005D6 RID: 1494
		public static readonly string PrefGlobalFolder = "IMPOSTORS_GLOBALFOLDER";

		// Token: 0x040005D7 RID: 1495
		public static readonly string PrefGlobalRelativeFolder = "IMPOSTORS_GLOBALRELATIVEFOLDER";

		// Token: 0x040005D8 RID: 1496
		public static readonly string PrefGlobalDefault = "IMPOSTORS_GLOBALDEFAULT";

		// Token: 0x040005D9 RID: 1497
		public static readonly string PrefGlobalTexImport = "IMPOSTORS_GLOBALTEXIMPORT";

		// Token: 0x040005DA RID: 1498
		public static readonly string PrefGlobalCreateLodGroup = "IMPOSTORS_GLOBALCREATELODGROUP ";

		// Token: 0x040005DB RID: 1499
		public static readonly string PrefGlobalGBuffer0Name = "IMPOSTORS_GLOBALGBUFFER0SUFFIX";

		// Token: 0x040005DC RID: 1500
		public static readonly string PrefGlobalGBuffer1Name = "IMPOSTORS_GLOBALGBUFFER1SUFFIX";

		// Token: 0x040005DD RID: 1501
		public static readonly string PrefGlobalGBuffer2Name = "IMPOSTORS_GLOBALGBUFFER2SUFFIX";

		// Token: 0x040005DE RID: 1502
		public static readonly string PrefGlobalGBuffer3Name = "IMPOSTORS_GLOBALGBUFFER3SUFFIX";

		// Token: 0x040005DF RID: 1503
		public static readonly string PrefGlobalBakingOptions = "IMPOSTORS_GLOBALBakingOptions";

		// Token: 0x040005E0 RID: 1504
		public static readonly string PrefDataImpType = "IMPOSTORS_DATAIMPTYPE";

		// Token: 0x040005E1 RID: 1505
		public static readonly string PrefDataTexSizeLocked = "IMPOSTORS_DATATEXSIZEXLOCKED";

		// Token: 0x040005E2 RID: 1506
		public static readonly string PrefDataTexSizeSelected = "IMPOSTORS_DATATEXSIZEXSELECTED";

		// Token: 0x040005E3 RID: 1507
		public static readonly string PrefDataTexSizeX = "IMPOSTORS_DATATEXSIZEX";

		// Token: 0x040005E4 RID: 1508
		public static readonly string PrefDataTexSizeY = "IMPOSTORS_DATATEXSIZEY";

		// Token: 0x040005E5 RID: 1509
		public static readonly string PrefDataDecoupledFrames = "IMPOSTORS_DATADECOUPLEDFRAMES";

		// Token: 0x040005E6 RID: 1510
		public static readonly string PrefDataXFrames = "IMPOSTORS_DATAXFRAMES";

		// Token: 0x040005E7 RID: 1511
		public static readonly string PrefDataYFrames = "IMPOSTORS_DATAYFRAMES";

		// Token: 0x040005E8 RID: 1512
		public static readonly string PrefDataPixelBleeding = "IMPOSTORS_DATAPIXELBLEEDING";

		// Token: 0x040005E9 RID: 1513
		public static readonly string PrefDataTolerance = "IMPOSTORS_DATATOLERANCE ";

		// Token: 0x040005EA RID: 1514
		public static readonly string PrefDataNormalScale = "IMPOSTORS_DATANORMALSCALE";

		// Token: 0x040005EB RID: 1515
		public static readonly string PrefDataMaxVertices = "IMPOSTORS_DATAMAXVERTICES";
	}
}
