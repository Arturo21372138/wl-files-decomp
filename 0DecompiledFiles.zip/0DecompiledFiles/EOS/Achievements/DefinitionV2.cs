﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F3 RID: 2035
	public struct DefinitionV2
	{
		// Token: 0x17000851 RID: 2129
		// (get) Token: 0x0600217B RID: 8571 RVA: 0x00027FBE File Offset: 0x000261BE
		// (set) Token: 0x0600217C RID: 8572 RVA: 0x00027FC6 File Offset: 0x000261C6
		public Utf8String AchievementId { readonly get; set; }

		// Token: 0x17000852 RID: 2130
		// (get) Token: 0x0600217D RID: 8573 RVA: 0x00027FCF File Offset: 0x000261CF
		// (set) Token: 0x0600217E RID: 8574 RVA: 0x00027FD7 File Offset: 0x000261D7
		public Utf8String UnlockedDisplayName { readonly get; set; }

		// Token: 0x17000853 RID: 2131
		// (get) Token: 0x0600217F RID: 8575 RVA: 0x00027FE0 File Offset: 0x000261E0
		// (set) Token: 0x06002180 RID: 8576 RVA: 0x00027FE8 File Offset: 0x000261E8
		public Utf8String UnlockedDescription { readonly get; set; }

		// Token: 0x17000854 RID: 2132
		// (get) Token: 0x06002181 RID: 8577 RVA: 0x00027FF1 File Offset: 0x000261F1
		// (set) Token: 0x06002182 RID: 8578 RVA: 0x00027FF9 File Offset: 0x000261F9
		public Utf8String LockedDisplayName { readonly get; set; }

		// Token: 0x17000855 RID: 2133
		// (get) Token: 0x06002183 RID: 8579 RVA: 0x00028002 File Offset: 0x00026202
		// (set) Token: 0x06002184 RID: 8580 RVA: 0x0002800A File Offset: 0x0002620A
		public Utf8String LockedDescription { readonly get; set; }

		// Token: 0x17000856 RID: 2134
		// (get) Token: 0x06002185 RID: 8581 RVA: 0x00028013 File Offset: 0x00026213
		// (set) Token: 0x06002186 RID: 8582 RVA: 0x0002801B File Offset: 0x0002621B
		public Utf8String FlavorText { readonly get; set; }

		// Token: 0x17000857 RID: 2135
		// (get) Token: 0x06002187 RID: 8583 RVA: 0x00028024 File Offset: 0x00026224
		// (set) Token: 0x06002188 RID: 8584 RVA: 0x0002802C File Offset: 0x0002622C
		public Utf8String UnlockedIconURL { readonly get; set; }

		// Token: 0x17000858 RID: 2136
		// (get) Token: 0x06002189 RID: 8585 RVA: 0x00028035 File Offset: 0x00026235
		// (set) Token: 0x0600218A RID: 8586 RVA: 0x0002803D File Offset: 0x0002623D
		public Utf8String LockedIconURL { readonly get; set; }

		// Token: 0x17000859 RID: 2137
		// (get) Token: 0x0600218B RID: 8587 RVA: 0x00028046 File Offset: 0x00026246
		// (set) Token: 0x0600218C RID: 8588 RVA: 0x0002804E File Offset: 0x0002624E
		public bool IsHidden { readonly get; set; }

		// Token: 0x1700085A RID: 2138
		// (get) Token: 0x0600218D RID: 8589 RVA: 0x00028057 File Offset: 0x00026257
		// (set) Token: 0x0600218E RID: 8590 RVA: 0x0002805F File Offset: 0x0002625F
		public StatThresholds[] StatThresholds { readonly get; set; }
	}
}
