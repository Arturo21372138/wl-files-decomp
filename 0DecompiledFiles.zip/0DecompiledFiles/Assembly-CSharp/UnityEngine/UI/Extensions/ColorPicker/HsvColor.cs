﻿using System;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D9 RID: 217
	public struct HsvColor
	{
		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000720 RID: 1824 RVA: 0x00028A50 File Offset: 0x00026C50
		// (set) Token: 0x06000721 RID: 1825 RVA: 0x00028A5F File Offset: 0x00026C5F
		public float NormalizedH
		{
			get
			{
				return (float)this.H / 360f;
			}
			set
			{
				this.H = (double)value * 360.0;
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000722 RID: 1826 RVA: 0x00028A73 File Offset: 0x00026C73
		// (set) Token: 0x06000723 RID: 1827 RVA: 0x00028A7C File Offset: 0x00026C7C
		public float NormalizedS
		{
			get
			{
				return (float)this.S;
			}
			set
			{
				this.S = (double)value;
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x06000724 RID: 1828 RVA: 0x00028A86 File Offset: 0x00026C86
		// (set) Token: 0x06000725 RID: 1829 RVA: 0x00028A8F File Offset: 0x00026C8F
		public float NormalizedV
		{
			get
			{
				return (float)this.V;
			}
			set
			{
				this.V = (double)value;
			}
		}

		// Token: 0x06000726 RID: 1830 RVA: 0x00028A99 File Offset: 0x00026C99
		public HsvColor(double h, double s, double v)
		{
			this.H = h;
			this.S = s;
			this.V = v;
		}

		// Token: 0x06000727 RID: 1831 RVA: 0x00028AB0 File Offset: 0x00026CB0
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				"{",
				this.H.ToString("f2"),
				",",
				this.S.ToString("f2"),
				",",
				this.V.ToString("f2"),
				"}"
			});
		}

		// Token: 0x04000541 RID: 1345
		public double H;

		// Token: 0x04000542 RID: 1346
		public double S;

		// Token: 0x04000543 RID: 1347
		public double V;
	}
}
