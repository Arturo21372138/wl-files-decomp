﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000064 RID: 100
	[ExecuteInEditMode]
	[RequireComponent(typeof(Image))]
	[AddComponentMenu("UI/Effects/Extensions/Shining Effect")]
	public class ShineEffector : MonoBehaviour
	{
		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060002F9 RID: 761 RVA: 0x000129A7 File Offset: 0x00010BA7
		// (set) Token: 0x060002FA RID: 762 RVA: 0x000129AF File Offset: 0x00010BAF
		public float YOffset
		{
			get
			{
				return this.yOffset;
			}
			set
			{
				this.ChangeVal(value);
				this.yOffset = value;
			}
		}

		// Token: 0x060002FB RID: 763 RVA: 0x000129C0 File Offset: 0x00010BC0
		private void OnEnable()
		{
			if (this.effector == null)
			{
				GameObject gameObject = new GameObject("effector");
				this.effectRoot = new GameObject("ShineEffect");
				this.effectRoot.transform.SetParent(base.transform);
				this.effectRoot.AddComponent<Image>().sprite = base.gameObject.GetComponent<Image>().sprite;
				this.effectRoot.GetComponent<Image>().type = base.gameObject.GetComponent<Image>().type;
				this.effectRoot.AddComponent<Mask>().showMaskGraphic = false;
				this.effectRoot.transform.localScale = Vector3.one;
				this.effectRoot.GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;
				this.effectRoot.GetComponent<RectTransform>().anchorMax = Vector2.one;
				this.effectRoot.GetComponent<RectTransform>().anchorMin = Vector2.zero;
				this.effectRoot.GetComponent<RectTransform>().offsetMax = Vector2.zero;
				this.effectRoot.GetComponent<RectTransform>().offsetMin = Vector2.zero;
				this.effectRoot.transform.SetAsFirstSibling();
				gameObject.AddComponent<RectTransform>();
				gameObject.transform.SetParent(this.effectRoot.transform);
				this.effectorRect = gameObject.GetComponent<RectTransform>();
				this.effectorRect.localScale = Vector3.one;
				this.effectorRect.anchoredPosition3D = Vector3.zero;
				this.effectorRect.gameObject.AddComponent<ShineEffect>();
				this.effectorRect.anchorMax = Vector2.one;
				this.effectorRect.anchorMin = Vector2.zero;
				this.effectorRect.Rotate(0f, 0f, -8f);
				this.effector = gameObject.GetComponent<ShineEffect>();
				this.effectorRect.offsetMax = Vector2.zero;
				this.effectorRect.offsetMin = Vector2.zero;
				this.OnValidate();
			}
		}

		// Token: 0x060002FC RID: 764 RVA: 0x00012BB4 File Offset: 0x00010DB4
		private void OnValidate()
		{
			this.effector.Yoffset = this.yOffset;
			this.effector.Width = this.width;
			if (this.yOffset <= -1f || this.yOffset >= 1f)
			{
				this.effectRoot.SetActive(false);
				return;
			}
			if (!this.effectRoot.activeSelf)
			{
				this.effectRoot.SetActive(true);
			}
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00012C24 File Offset: 0x00010E24
		private void ChangeVal(float value)
		{
			this.effector.Yoffset = value;
			if (value <= -1f || value >= 1f)
			{
				this.effectRoot.SetActive(false);
				return;
			}
			if (!this.effectRoot.activeSelf)
			{
				this.effectRoot.SetActive(true);
			}
		}

		// Token: 0x060002FE RID: 766 RVA: 0x00012C73 File Offset: 0x00010E73
		private void OnDestroy()
		{
			if (!Application.isPlaying)
			{
				Object.DestroyImmediate(this.effectRoot);
				return;
			}
			Object.Destroy(this.effectRoot);
		}

		// Token: 0x04000246 RID: 582
		public ShineEffect effector;

		// Token: 0x04000247 RID: 583
		[SerializeField]
		[HideInInspector]
		private GameObject effectRoot;

		// Token: 0x04000248 RID: 584
		[Range(-1f, 1f)]
		public float yOffset = -1f;

		// Token: 0x04000249 RID: 585
		[Range(0.1f, 1f)]
		public float width = 0.5f;

		// Token: 0x0400024A RID: 586
		private RectTransform effectorRect;
	}
}
