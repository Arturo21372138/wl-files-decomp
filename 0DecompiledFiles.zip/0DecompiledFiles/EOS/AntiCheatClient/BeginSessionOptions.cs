﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B3 RID: 1971
	public struct BeginSessionOptions
	{
		// Token: 0x17000819 RID: 2073
		// (get) Token: 0x060020A1 RID: 8353 RVA: 0x00026FCA File Offset: 0x000251CA
		// (set) Token: 0x060020A2 RID: 8354 RVA: 0x00026FD2 File Offset: 0x000251D2
		public ProductUserId LocalUserId { readonly get; set; }

		// Token: 0x1700081A RID: 2074
		// (get) Token: 0x060020A3 RID: 8355 RVA: 0x00026FDB File Offset: 0x000251DB
		// (set) Token: 0x060020A4 RID: 8356 RVA: 0x00026FE3 File Offset: 0x000251E3
		public AntiCheatClientMode Mode { readonly get; set; }
	}
}
