﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E9 RID: 2025
	public struct CopyPlayerAchievementByAchievementIdOptions
	{
		// Token: 0x1700083C RID: 2108
		// (get) Token: 0x06002148 RID: 8520 RVA: 0x00027C0F File Offset: 0x00025E0F
		// (set) Token: 0x06002149 RID: 8521 RVA: 0x00027C17 File Offset: 0x00025E17
		public ProductUserId TargetUserId { readonly get; set; }

		// Token: 0x1700083D RID: 2109
		// (get) Token: 0x0600214A RID: 8522 RVA: 0x00027C20 File Offset: 0x00025E20
		// (set) Token: 0x0600214B RID: 8523 RVA: 0x00027C28 File Offset: 0x00025E28
		public Utf8String AchievementId { readonly get; set; }

		// Token: 0x1700083E RID: 2110
		// (get) Token: 0x0600214C RID: 8524 RVA: 0x00027C31 File Offset: 0x00025E31
		// (set) Token: 0x0600214D RID: 8525 RVA: 0x00027C39 File Offset: 0x00025E39
		public ProductUserId LocalUserId { readonly get; set; }
	}
}
