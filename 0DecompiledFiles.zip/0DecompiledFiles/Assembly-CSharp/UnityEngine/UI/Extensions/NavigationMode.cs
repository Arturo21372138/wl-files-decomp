﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A4 RID: 164
	public enum NavigationMode
	{
		// Token: 0x0400040E RID: 1038
		Auto,
		// Token: 0x0400040F RID: 1039
		Manual
	}
}
