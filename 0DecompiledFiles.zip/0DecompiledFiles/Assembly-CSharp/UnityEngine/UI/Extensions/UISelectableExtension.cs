﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C6 RID: 198
	[AddComponentMenu("UI/Extensions/UI Selectable Extension")]
	[RequireComponent(typeof(Selectable))]
	public class UISelectableExtension : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler
	{
		// Token: 0x0600067B RID: 1659 RVA: 0x00025681 File Offset: 0x00023881
		void IPointerDownHandler.OnPointerDown(PointerEventData eventData)
		{
			if (this.OnButtonPress != null)
			{
				this.OnButtonPress.Invoke(eventData.button);
			}
			this._pressed = true;
			this._heldEventData = eventData;
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x000256AA File Offset: 0x000238AA
		void IPointerUpHandler.OnPointerUp(PointerEventData eventData)
		{
			if (this.OnButtonRelease != null)
			{
				this.OnButtonRelease.Invoke(eventData.button);
			}
			this._pressed = false;
			this._heldEventData = null;
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x000256D3 File Offset: 0x000238D3
		private void Update()
		{
			if (!this._pressed)
			{
				return;
			}
			if (this.OnButtonHeld != null)
			{
				this.OnButtonHeld.Invoke(this._heldEventData.button);
			}
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x000256FC File Offset: 0x000238FC
		public void TestClicked()
		{
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x000256FE File Offset: 0x000238FE
		public void TestPressed()
		{
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x00025700 File Offset: 0x00023900
		public void TestReleased()
		{
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x00025702 File Offset: 0x00023902
		public void TestHold()
		{
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x00025704 File Offset: 0x00023904
		private void OnDisable()
		{
			this._pressed = false;
		}

		// Token: 0x040004A8 RID: 1192
		[Tooltip("Event that fires when a button is initially pressed down")]
		public UISelectableExtension.UIButtonEvent OnButtonPress;

		// Token: 0x040004A9 RID: 1193
		[Tooltip("Event that fires when a button is released")]
		public UISelectableExtension.UIButtonEvent OnButtonRelease;

		// Token: 0x040004AA RID: 1194
		[Tooltip("Event that continually fires while a button is held down")]
		public UISelectableExtension.UIButtonEvent OnButtonHeld;

		// Token: 0x040004AB RID: 1195
		private bool _pressed;

		// Token: 0x040004AC RID: 1196
		private PointerEventData _heldEventData;

		// Token: 0x02000156 RID: 342
		[Serializable]
		public class UIButtonEvent : UnityEvent<PointerEventData.InputButton>
		{
		}
	}
}
