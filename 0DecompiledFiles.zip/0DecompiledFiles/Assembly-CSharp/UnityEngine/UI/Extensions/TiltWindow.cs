﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000030 RID: 48
	public class TiltWindow : MonoBehaviour, IDragHandler, IEventSystemHandler
	{
		// Token: 0x060000DD RID: 221 RVA: 0x00005FC1 File Offset: 0x000041C1
		private void Start()
		{
			this.mTrans = base.transform;
			this.mStart = this.mTrans.localRotation;
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00005FE0 File Offset: 0x000041E0
		private void Update()
		{
			Vector3 vector = this.m_screenPos;
			float num = (float)Screen.width * 0.5f;
			float num2 = (float)Screen.height * 0.5f;
			float num3 = Mathf.Clamp((vector.x - num) / num, -1f, 1f);
			float num4 = Mathf.Clamp((vector.y - num2) / num2, -1f, 1f);
			this.mRot = Vector2.Lerp(this.mRot, new Vector2(num3, num4), Time.deltaTime * 5f);
			this.mTrans.localRotation = this.mStart * Quaternion.Euler(-this.mRot.y * this.range.y, this.mRot.x * this.range.x, 0f);
		}

		// Token: 0x060000DF RID: 223 RVA: 0x000060B7 File Offset: 0x000042B7
		public void OnDrag(PointerEventData eventData)
		{
			this.m_screenPos = eventData.position;
		}

		// Token: 0x040000CB RID: 203
		public Vector2 range = new Vector2(5f, 3f);

		// Token: 0x040000CC RID: 204
		private Transform mTrans;

		// Token: 0x040000CD RID: 205
		private Quaternion mStart;

		// Token: 0x040000CE RID: 206
		private Vector2 mRot = Vector2.zero;

		// Token: 0x040000CF RID: 207
		private Vector2 m_screenPos;
	}
}
