﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000075 RID: 117
	public abstract class FancyScrollView<TItemData> : FancyScrollView<TItemData, NullContext>
	{
	}
}
