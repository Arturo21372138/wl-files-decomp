﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000056 RID: 86
	public enum GradientMode
	{
		// Token: 0x04000220 RID: 544
		Global,
		// Token: 0x04000221 RID: 545
		Local
	}
}
