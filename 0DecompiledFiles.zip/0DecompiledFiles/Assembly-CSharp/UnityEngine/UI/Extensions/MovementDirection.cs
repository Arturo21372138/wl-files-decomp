﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200007E RID: 126
	public enum MovementDirection
	{
		// Token: 0x040002E0 RID: 736
		Left,
		// Token: 0x040002E1 RID: 737
		Right,
		// Token: 0x040002E2 RID: 738
		Up,
		// Token: 0x040002E3 RID: 739
		Down
	}
}
