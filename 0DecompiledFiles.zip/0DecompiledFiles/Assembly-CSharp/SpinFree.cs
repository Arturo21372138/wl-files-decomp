﻿using System;
using UnityEngine;

// Token: 0x0200000B RID: 11
public class SpinFree : MonoBehaviour
{
	// Token: 0x06000019 RID: 25 RVA: 0x000028A4 File Offset: 0x00000AA4
	private void Update()
	{
		if (this.direction < 1f)
		{
			this.direction += Time.deltaTime / (this.directionChangeSpeed / 2f);
		}
		if (this.spin)
		{
			if (this.clockwise)
			{
				if (this.spinParent)
				{
					base.transform.parent.transform.Rotate(Vector3.up, this.speed * this.direction * Time.deltaTime);
					return;
				}
				base.transform.Rotate(Vector3.up, this.speed * this.direction * Time.deltaTime);
				return;
			}
			else
			{
				if (this.spinParent)
				{
					base.transform.parent.transform.Rotate(-Vector3.up, this.speed * this.direction * Time.deltaTime);
					return;
				}
				base.transform.Rotate(-Vector3.up, this.speed * this.direction * Time.deltaTime);
			}
		}
	}

	// Token: 0x04000016 RID: 22
	[Tooltip("Spin: Yes or No")]
	public bool spin;

	// Token: 0x04000017 RID: 23
	[Tooltip("Spin the parent object instead of the object this script is attached to")]
	public bool spinParent;

	// Token: 0x04000018 RID: 24
	public float speed = 10f;

	// Token: 0x04000019 RID: 25
	[HideInInspector]
	public bool clockwise = true;

	// Token: 0x0400001A RID: 26
	[HideInInspector]
	public float direction = 1f;

	// Token: 0x0400001B RID: 27
	[HideInInspector]
	public float directionChangeSpeed = 2f;
}
