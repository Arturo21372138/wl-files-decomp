﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007BE RID: 1982
	// (Invoke) Token: 0x060020C2 RID: 8386
	public delegate void OnMessageToPeerCallback(ref OnMessageToClientCallbackInfo data);
}
