﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E4 RID: 2020
	internal struct CopyAchievementDefinitionByIndexOptionsInternal : ISettable<CopyAchievementDefinitionByIndexOptions>, IDisposable
	{
		// Token: 0x0600213E RID: 8510 RVA: 0x00027B86 File Offset: 0x00025D86
		public void Set(ref CopyAchievementDefinitionByIndexOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			this.m_AchievementIndex = other.AchievementIndex;
		}

		// Token: 0x0600213F RID: 8511 RVA: 0x00027BA1 File Offset: 0x00025DA1
		public void Dispose()
		{
		}

		// Token: 0x0400162E RID: 5678
		private int m_ApiVersion;

		// Token: 0x0400162F RID: 5679
		private uint m_AchievementIndex;
	}
}
