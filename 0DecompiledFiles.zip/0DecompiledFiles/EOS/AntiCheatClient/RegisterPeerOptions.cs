﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D4 RID: 2004
	public struct RegisterPeerOptions
	{
		// Token: 0x1700082E RID: 2094
		// (get) Token: 0x06002105 RID: 8453 RVA: 0x0002740D File Offset: 0x0002560D
		// (set) Token: 0x06002106 RID: 8454 RVA: 0x00027415 File Offset: 0x00025615
		public IntPtr PeerHandle { readonly get; set; }

		// Token: 0x1700082F RID: 2095
		// (get) Token: 0x06002107 RID: 8455 RVA: 0x0002741E File Offset: 0x0002561E
		// (set) Token: 0x06002108 RID: 8456 RVA: 0x00027426 File Offset: 0x00025626
		public AntiCheatCommonClientType ClientType { readonly get; set; }

		// Token: 0x17000830 RID: 2096
		// (get) Token: 0x06002109 RID: 8457 RVA: 0x0002742F File Offset: 0x0002562F
		// (set) Token: 0x0600210A RID: 8458 RVA: 0x00027437 File Offset: 0x00025637
		public AntiCheatCommonClientPlatform ClientPlatform { readonly get; set; }

		// Token: 0x17000831 RID: 2097
		// (get) Token: 0x0600210B RID: 8459 RVA: 0x00027440 File Offset: 0x00025640
		// (set) Token: 0x0600210C RID: 8460 RVA: 0x00027448 File Offset: 0x00025648
		public uint AuthenticationTimeout { readonly get; set; }

		// Token: 0x17000832 RID: 2098
		// (get) Token: 0x0600210D RID: 8461 RVA: 0x00027451 File Offset: 0x00025651
		// (set) Token: 0x0600210E RID: 8462 RVA: 0x00027459 File Offset: 0x00025659
		public Utf8String AccountId_DEPRECATED { readonly get; set; }

		// Token: 0x17000833 RID: 2099
		// (get) Token: 0x0600210F RID: 8463 RVA: 0x00027462 File Offset: 0x00025662
		// (set) Token: 0x06002110 RID: 8464 RVA: 0x0002746A File Offset: 0x0002566A
		public Utf8String IpAddress { readonly get; set; }

		// Token: 0x17000834 RID: 2100
		// (get) Token: 0x06002111 RID: 8465 RVA: 0x00027473 File Offset: 0x00025673
		// (set) Token: 0x06002112 RID: 8466 RVA: 0x0002747B File Offset: 0x0002567B
		public ProductUserId PeerProductUserId { readonly get; set; }
	}
}
