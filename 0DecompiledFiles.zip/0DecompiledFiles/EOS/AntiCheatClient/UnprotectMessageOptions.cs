﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D8 RID: 2008
	public struct UnprotectMessageOptions
	{
		// Token: 0x17000835 RID: 2101
		// (get) Token: 0x06002117 RID: 8471 RVA: 0x00027535 File Offset: 0x00025735
		// (set) Token: 0x06002118 RID: 8472 RVA: 0x0002753D File Offset: 0x0002573D
		public ArraySegment<byte> Data { readonly get; set; }

		// Token: 0x17000836 RID: 2102
		// (get) Token: 0x06002119 RID: 8473 RVA: 0x00027546 File Offset: 0x00025746
		// (set) Token: 0x0600211A RID: 8474 RVA: 0x0002754E File Offset: 0x0002574E
		public uint OutBufferSizeBytes { readonly get; set; }
	}
}
