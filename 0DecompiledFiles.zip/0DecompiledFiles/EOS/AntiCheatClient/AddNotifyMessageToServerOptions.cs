﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007AA RID: 1962
	public struct AddNotifyMessageToServerOptions
	{
	}
}
