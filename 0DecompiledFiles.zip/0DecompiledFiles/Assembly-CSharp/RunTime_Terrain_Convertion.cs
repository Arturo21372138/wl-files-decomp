﻿using System;
using UnityEngine;
using UnityEngine.Rendering;
using VacuumShaders.TerrainToMesh;

// Token: 0x02000012 RID: 18
[AddComponentMenu("VacuumShaders/Terrain To Mesh/Example/Runtime Converter")]
public class RunTime_Terrain_Convertion : MonoBehaviour
{
	// Token: 0x0600002C RID: 44 RVA: 0x00002E8C File Offset: 0x0000108C
	private void Start()
	{
		if (this.sourceTerrain != null)
		{
			Mesh[] array = TerrainToMeshConverter.Convert(this.sourceTerrain, this.convertInfo, false, null);
			if (array != null)
			{
				Material material;
				if (this.generateBasemap)
				{
					material = this.GenerateMaterial_Basemap();
				}
				else
				{
					material = this.GenerateMaterial_Splatmap();
				}
				if (array.Length == 1)
				{
					MeshFilter meshFilter = base.gameObject.GetComponent<MeshFilter>();
					if (meshFilter == null)
					{
						meshFilter = base.gameObject.AddComponent<MeshFilter>();
					}
					meshFilter.sharedMesh = array[0];
					MeshRenderer meshRenderer = base.gameObject.GetComponent<MeshRenderer>();
					if (meshRenderer == null)
					{
						meshRenderer = base.gameObject.AddComponent<MeshRenderer>();
					}
					meshRenderer.sharedMaterial = material;
					if (this.attachMeshCollider)
					{
						base.gameObject.AddComponent<MeshCollider>().sharedMesh = meshFilter.sharedMesh;
						return;
					}
				}
				else
				{
					for (int i = 0; i < array.Length; i++)
					{
						GameObject gameObject = new GameObject(array[i].name);
						gameObject.transform.parent = base.gameObject.transform;
						gameObject.transform.localPosition = Vector3.zero;
						MeshFilter meshFilter2 = gameObject.AddComponent<MeshFilter>();
						meshFilter2.sharedMesh = array[i];
						gameObject.AddComponent<MeshRenderer>().sharedMaterial = material;
						if (this.attachMeshCollider)
						{
							gameObject.AddComponent<MeshCollider>().sharedMesh = meshFilter2.sharedMesh;
						}
					}
				}
			}
		}
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00002FE4 File Offset: 0x000011E4
	private Material GenerateMaterial_Basemap()
	{
		Texture2D texture2D = null;
		Texture2D texture2D2 = null;
		bool flag = QualitySettings.activeColorSpace == ColorSpace.Linear;
		TerrainToMeshConverter.ExtractBasemap(this.sourceTerrain, out texture2D, out texture2D2, 1024, 1024, flag);
		Material material;
		if (GraphicsSettings.renderPipelineAsset == null)
		{
			material = new Material(Shader.Find((texture2D2 != null) ? "Legacy Shaders/Bumped Diffuse" : "Legacy Shaders/Diffuse"));
			material.SetTexture("_MainTex", texture2D);
			material.SetColor("_Color", Color.white);
			if (texture2D2 != null)
			{
				material.SetTexture("_BumpMap", texture2D2);
			}
		}
		else
		{
			Shader shader = Shader.Find("Universal Render Pipeline/Lit");
			if (shader == null)
			{
				shader = Shader.Find("VacuumShaders/Terrain To Mesh/SRP Default");
			}
			material = new Material(shader);
			if (material.HasProperty("_MainTex"))
			{
				material.SetTexture("_MainTex", texture2D);
			}
			if (material.HasProperty("_BaseMap"))
			{
				material.SetTexture("_BaseMap", texture2D);
			}
			material.SetColor("_Color", Color.white);
			if (material.HasProperty("_BaseColor"))
			{
				material.SetColor("_BaseColor", Color.white);
			}
			if (texture2D2 != null)
			{
				material.SetTexture("_BumpMap", texture2D2);
			}
			if (material.HasProperty("_Smoothness"))
			{
				material.SetFloat("_Smoothness", 0f);
			}
		}
		return material;
	}

	// Token: 0x0600002E RID: 46 RVA: 0x0000313C File Offset: 0x0000133C
	private Material GenerateMaterial_Splatmap()
	{
		Material material = null;
		Texture2D[] array = TerrainToMeshConverter.ExtractSplatmaps(this.sourceTerrain);
		if (array == null || array.Length == 0)
		{
			return material;
		}
		Texture2D[] array2;
		Texture2D[] array3;
		Vector2[] array4;
		Vector2[] array5;
		float[] array6;
		float[] array7;
		int num = TerrainToMeshConverter.ExtractTexturesInfo(this.sourceTerrain, out array2, out array3, out array4, out array5, out array6, out array7);
		if (num == 0 || array2 == null)
		{
			Debug.LogWarning("usedTexturesCount == 0");
			return material;
		}
		if (num == 1)
		{
			if (GraphicsSettings.renderPipelineAsset == null)
			{
				Shader shader = Shader.Find("Legacy Shaders/Diffuse");
				if (shader != null)
				{
					material = new Material(shader);
					material.SetTexture("_MainTex", array2[0]);
					material.SetTextureScale("_MainTex", array4[0]);
					material.SetTextureOffset("_MainTex", array5[0]);
				}
			}
			else
			{
				Shader shader = Shader.Find("Universal Render Pipeline/Lit");
				if (shader != null)
				{
					material = new Material(shader);
					material.SetTexture("_BaseMap", array2[0]);
					material.SetTextureScale("_BaseMap", array4[0]);
					material.SetTextureOffset("_BaseMap", array5[0]);
				}
			}
			return material;
		}
		num = Mathf.Clamp(num, 2, 8);
		bool flag = false;
		if (array3 != null && num < 5)
		{
			flag = true;
		}
		string text;
		if (GraphicsSettings.renderPipelineAsset == null)
		{
			text = string.Format("VacuumShaders/Terrain To Mesh/Standard/" + (flag ? "Bumped" : "Diffuse") + "/{0} Textures", num);
		}
		else
		{
			text = string.Format("VacuumShaders/Terrain To Mesh/Universal Render Pipeline/Lit/{0} Textures", num);
		}
		Shader shader2 = Shader.Find(text);
		if (shader2 == null)
		{
			if (GraphicsSettings.renderPipelineAsset == null)
			{
				Debug.LogWarning("Shader not found: " + text);
			}
			else
			{
				Debug.LogWarning("Shader not found: '" + text + "'.\nUniversal Render Pipeline shaders (http://u3d.as/1jFw) are not installed.\n");
			}
			return material;
		}
		material = new Material(shader2);
		if (array.Length == 1)
		{
			material.SetTexture("_V_T2M_Control", array[0]);
		}
		else
		{
			if (array.Length > 2)
			{
				Debug.Log("TerrainToMesh shaders support max 2 control textures. Current terrain uses " + array.Length.ToString());
			}
			material.SetTexture("_V_T2M_Control", array[0]);
			material.SetTexture("_V_T2M_Control2", array[1]);
		}
		for (int i = 0; i < num; i++)
		{
			material.SetTexture(string.Format("_V_T2M_Splat{0}", i + 1), array2[i]);
			material.SetFloat(string.Format("_V_T2M_Splat{0}_uvScale", i + 1), array4[i].x);
			material.SetFloat(string.Format("_V_T2M_Splat{0}_Metallic", i + 1), 0f);
			material.SetFloat(string.Format("_V_T2M_Splat{0}_Glossiness", i + 1), 0f);
			if (flag)
			{
				material.SetTexture(string.Format("_V_T2M_Splat{0}_bumpMap", i + 1), array3[i]);
			}
		}
		return material;
	}

	// Token: 0x04000025 RID: 37
	public Terrain sourceTerrain;

	// Token: 0x04000026 RID: 38
	public TerrainConvertInfo convertInfo;

	// Token: 0x04000027 RID: 39
	public bool generateBasemap;

	// Token: 0x04000028 RID: 40
	public bool attachMeshCollider;
}
