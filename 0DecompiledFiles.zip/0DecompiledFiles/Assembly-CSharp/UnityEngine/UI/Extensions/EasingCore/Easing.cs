﻿using System;
using System.Runtime.CompilerServices;

namespace UnityEngine.UI.Extensions.EasingCore
{
	// Token: 0x020000CD RID: 205
	public static class Easing
	{
		// Token: 0x060006A8 RID: 1704 RVA: 0x00026928 File Offset: 0x00024B28
		public static EasingFunction Get(Ease type)
		{
			switch (type)
			{
			case Ease.Linear:
				return new EasingFunction(Easing.<Get>g__linear|0_0);
			case Ease.InBack:
				return new EasingFunction(Easing.<Get>g__inBack|0_1);
			case Ease.InBounce:
				return new EasingFunction(Easing.<Get>g__inBounce|0_4);
			case Ease.InCirc:
				return new EasingFunction(Easing.<Get>g__inCirc|0_7);
			case Ease.InCubic:
				return new EasingFunction(Easing.<Get>g__inCubic|0_10);
			case Ease.InElastic:
				return new EasingFunction(Easing.<Get>g__inElastic|0_13);
			case Ease.InExpo:
				return new EasingFunction(Easing.<Get>g__inExpo|0_16);
			case Ease.InQuad:
				return new EasingFunction(Easing.<Get>g__inQuad|0_19);
			case Ease.InQuart:
				return new EasingFunction(Easing.<Get>g__inQuart|0_22);
			case Ease.InQuint:
				return new EasingFunction(Easing.<Get>g__inQuint|0_25);
			case Ease.InSine:
				return new EasingFunction(Easing.<Get>g__inSine|0_28);
			case Ease.OutBack:
				return new EasingFunction(Easing.<Get>g__outBack|0_2);
			case Ease.OutBounce:
				return new EasingFunction(Easing.<Get>g__outBounce|0_5);
			case Ease.OutCirc:
				return new EasingFunction(Easing.<Get>g__outCirc|0_8);
			case Ease.OutCubic:
				return new EasingFunction(Easing.<Get>g__outCubic|0_11);
			case Ease.OutElastic:
				return new EasingFunction(Easing.<Get>g__outElastic|0_14);
			case Ease.OutExpo:
				return new EasingFunction(Easing.<Get>g__outExpo|0_17);
			case Ease.OutQuad:
				return new EasingFunction(Easing.<Get>g__outQuad|0_20);
			case Ease.OutQuart:
				return new EasingFunction(Easing.<Get>g__outQuart|0_23);
			case Ease.OutQuint:
				return new EasingFunction(Easing.<Get>g__outQuint|0_26);
			case Ease.OutSine:
				return new EasingFunction(Easing.<Get>g__outSine|0_29);
			case Ease.InOutBack:
				return new EasingFunction(Easing.<Get>g__inOutBack|0_3);
			case Ease.InOutBounce:
				return new EasingFunction(Easing.<Get>g__inOutBounce|0_6);
			case Ease.InOutCirc:
				return new EasingFunction(Easing.<Get>g__inOutCirc|0_9);
			case Ease.InOutCubic:
				return new EasingFunction(Easing.<Get>g__inOutCubic|0_12);
			case Ease.InOutElastic:
				return new EasingFunction(Easing.<Get>g__inOutElastic|0_15);
			case Ease.InOutExpo:
				return new EasingFunction(Easing.<Get>g__inOutExpo|0_18);
			case Ease.InOutQuad:
				return new EasingFunction(Easing.<Get>g__inOutQuad|0_21);
			case Ease.InOutQuart:
				return new EasingFunction(Easing.<Get>g__inOutQuart|0_24);
			case Ease.InOutQuint:
				return new EasingFunction(Easing.<Get>g__inOutQuint|0_27);
			case Ease.InOutSine:
				return new EasingFunction(Easing.<Get>g__inOutSine|0_30);
			default:
				return new EasingFunction(Easing.<Get>g__linear|0_0);
			}
		}

		// Token: 0x060006A9 RID: 1705 RVA: 0x00026B5B File Offset: 0x00024D5B
		[CompilerGenerated]
		internal static float <Get>g__linear|0_0(float t)
		{
			return t;
		}

		// Token: 0x060006AA RID: 1706 RVA: 0x00026B5E File Offset: 0x00024D5E
		[CompilerGenerated]
		internal static float <Get>g__inBack|0_1(float t)
		{
			return t * t * t - t * Mathf.Sin(t * 3.1415927f);
		}

		// Token: 0x060006AB RID: 1707 RVA: 0x00026B74 File Offset: 0x00024D74
		[CompilerGenerated]
		internal static float <Get>g__outBack|0_2(float t)
		{
			return 1f - Easing.<Get>g__inBack|0_1(1f - t);
		}

		// Token: 0x060006AC RID: 1708 RVA: 0x00026B88 File Offset: 0x00024D88
		[CompilerGenerated]
		internal static float <Get>g__inOutBack|0_3(float t)
		{
			if (t >= 0.5f)
			{
				return 0.5f * Easing.<Get>g__outBack|0_2(2f * t - 1f) + 0.5f;
			}
			return 0.5f * Easing.<Get>g__inBack|0_1(2f * t);
		}

		// Token: 0x060006AD RID: 1709 RVA: 0x00026BC3 File Offset: 0x00024DC3
		[CompilerGenerated]
		internal static float <Get>g__inBounce|0_4(float t)
		{
			return 1f - Easing.<Get>g__outBounce|0_5(1f - t);
		}

		// Token: 0x060006AE RID: 1710 RVA: 0x00026BD8 File Offset: 0x00024DD8
		[CompilerGenerated]
		internal static float <Get>g__outBounce|0_5(float t)
		{
			if (t < 0.36363637f)
			{
				return 121f * t * t / 16f;
			}
			if (t < 0.72727275f)
			{
				return 9.075f * t * t - 9.9f * t + 3.4f;
			}
			if (t >= 0.9f)
			{
				return 10.8f * t * t - 20.52f * t + 10.72f;
			}
			return 12.066482f * t * t - 19.635458f * t + 8.898061f;
		}

		// Token: 0x060006AF RID: 1711 RVA: 0x00026C54 File Offset: 0x00024E54
		[CompilerGenerated]
		internal static float <Get>g__inOutBounce|0_6(float t)
		{
			if (t >= 0.5f)
			{
				return 0.5f * Easing.<Get>g__outBounce|0_5(2f * t - 1f) + 0.5f;
			}
			return 0.5f * Easing.<Get>g__inBounce|0_4(2f * t);
		}

		// Token: 0x060006B0 RID: 1712 RVA: 0x00026C8F File Offset: 0x00024E8F
		[CompilerGenerated]
		internal static float <Get>g__inCirc|0_7(float t)
		{
			return 1f - Mathf.Sqrt(1f - t * t);
		}

		// Token: 0x060006B1 RID: 1713 RVA: 0x00026CA5 File Offset: 0x00024EA5
		[CompilerGenerated]
		internal static float <Get>g__outCirc|0_8(float t)
		{
			return Mathf.Sqrt((2f - t) * t);
		}

		// Token: 0x060006B2 RID: 1714 RVA: 0x00026CB8 File Offset: 0x00024EB8
		[CompilerGenerated]
		internal static float <Get>g__inOutCirc|0_9(float t)
		{
			if (t >= 0.5f)
			{
				return 0.5f * (Mathf.Sqrt(-(2f * t - 3f) * (2f * t - 1f)) + 1f);
			}
			return 0.5f * (1f - Mathf.Sqrt(1f - 4f * (t * t)));
		}

		// Token: 0x060006B3 RID: 1715 RVA: 0x00026D1B File Offset: 0x00024F1B
		[CompilerGenerated]
		internal static float <Get>g__inCubic|0_10(float t)
		{
			return t * t * t;
		}

		// Token: 0x060006B4 RID: 1716 RVA: 0x00026D22 File Offset: 0x00024F22
		[CompilerGenerated]
		internal static float <Get>g__outCubic|0_11(float t)
		{
			return Easing.<Get>g__inCubic|0_10(t - 1f) + 1f;
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x00026D36 File Offset: 0x00024F36
		[CompilerGenerated]
		internal static float <Get>g__inOutCubic|0_12(float t)
		{
			if (t >= 0.5f)
			{
				return 0.5f * Easing.<Get>g__inCubic|0_10(2f * t - 2f) + 1f;
			}
			return 4f * t * t * t;
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x00026D6A File Offset: 0x00024F6A
		[CompilerGenerated]
		internal static float <Get>g__inElastic|0_13(float t)
		{
			return Mathf.Sin(20.420353f * t) * Mathf.Pow(2f, 10f * (t - 1f));
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x00026D90 File Offset: 0x00024F90
		[CompilerGenerated]
		internal static float <Get>g__outElastic|0_14(float t)
		{
			return Mathf.Sin(-20.420353f * (t + 1f)) * Mathf.Pow(2f, -10f * t) + 1f;
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x00026DBC File Offset: 0x00024FBC
		[CompilerGenerated]
		internal static float <Get>g__inOutElastic|0_15(float t)
		{
			if (t >= 0.5f)
			{
				return 0.5f * (Mathf.Sin(-20.420353f * (2f * t - 1f + 1f)) * Mathf.Pow(2f, -10f * (2f * t - 1f)) + 2f);
			}
			return 0.5f * Mathf.Sin(20.420353f * (2f * t)) * Mathf.Pow(2f, 10f * (2f * t - 1f));
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x00026E50 File Offset: 0x00025050
		[CompilerGenerated]
		internal static float <Get>g__inExpo|0_16(float t)
		{
			if (!Mathf.Approximately(0f, t))
			{
				return Mathf.Pow(2f, 10f * (t - 1f));
			}
			return t;
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00026E78 File Offset: 0x00025078
		[CompilerGenerated]
		internal static float <Get>g__outExpo|0_17(float t)
		{
			if (!Mathf.Approximately(1f, t))
			{
				return 1f - Mathf.Pow(2f, -10f * t);
			}
			return t;
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x00026EA0 File Offset: 0x000250A0
		[CompilerGenerated]
		internal static float <Get>g__inOutExpo|0_18(float v)
		{
			if (Mathf.Approximately(0f, v) || Mathf.Approximately(1f, v))
			{
				return v;
			}
			if (v >= 0.5f)
			{
				return -0.5f * Mathf.Pow(2f, -20f * v + 10f) + 1f;
			}
			return 0.5f * Mathf.Pow(2f, 20f * v - 10f);
		}

		// Token: 0x060006BC RID: 1724 RVA: 0x00026F12 File Offset: 0x00025112
		[CompilerGenerated]
		internal static float <Get>g__inQuad|0_19(float t)
		{
			return t * t;
		}

		// Token: 0x060006BD RID: 1725 RVA: 0x00026F17 File Offset: 0x00025117
		[CompilerGenerated]
		internal static float <Get>g__outQuad|0_20(float t)
		{
			return -t * (t - 2f);
		}

		// Token: 0x060006BE RID: 1726 RVA: 0x00026F23 File Offset: 0x00025123
		[CompilerGenerated]
		internal static float <Get>g__inOutQuad|0_21(float t)
		{
			if (t >= 0.5f)
			{
				return -2f * t * t + 4f * t - 1f;
			}
			return 2f * t * t;
		}

		// Token: 0x060006BF RID: 1727 RVA: 0x00026F4E File Offset: 0x0002514E
		[CompilerGenerated]
		internal static float <Get>g__inQuart|0_22(float t)
		{
			return t * t * t * t;
		}

		// Token: 0x060006C0 RID: 1728 RVA: 0x00026F58 File Offset: 0x00025158
		[CompilerGenerated]
		internal static float <Get>g__outQuart|0_23(float t)
		{
			float num = t - 1f;
			return num * num * num * (1f - t) + 1f;
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00026F80 File Offset: 0x00025180
		[CompilerGenerated]
		internal static float <Get>g__inOutQuart|0_24(float t)
		{
			if (t >= 0.5f)
			{
				return -8f * Easing.<Get>g__inQuart|0_22(t - 1f) + 1f;
			}
			return 8f * Easing.<Get>g__inQuart|0_22(t);
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x00026FAF File Offset: 0x000251AF
		[CompilerGenerated]
		internal static float <Get>g__inQuint|0_25(float t)
		{
			return t * t * t * t * t;
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x00026FBA File Offset: 0x000251BA
		[CompilerGenerated]
		internal static float <Get>g__outQuint|0_26(float t)
		{
			return Easing.<Get>g__inQuint|0_25(t - 1f) + 1f;
		}

		// Token: 0x060006C4 RID: 1732 RVA: 0x00026FCE File Offset: 0x000251CE
		[CompilerGenerated]
		internal static float <Get>g__inOutQuint|0_27(float t)
		{
			if (t >= 0.5f)
			{
				return 0.5f * Easing.<Get>g__inQuint|0_25(2f * t - 2f) + 1f;
			}
			return 16f * Easing.<Get>g__inQuint|0_25(t);
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x00027003 File Offset: 0x00025203
		[CompilerGenerated]
		internal static float <Get>g__inSine|0_28(float t)
		{
			return Mathf.Sin((t - 1f) * 1.5707964f) + 1f;
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x0002701D File Offset: 0x0002521D
		[CompilerGenerated]
		internal static float <Get>g__outSine|0_29(float t)
		{
			return Mathf.Sin(t * 1.5707964f);
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x0002702B File Offset: 0x0002522B
		[CompilerGenerated]
		internal static float <Get>g__inOutSine|0_30(float t)
		{
			return 0.5f * (1f - Mathf.Cos(t * 3.1415927f));
		}
	}
}
