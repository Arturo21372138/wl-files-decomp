﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E0 RID: 224
	public enum FolderMode
	{
		// Token: 0x0400055D RID: 1373
		RelativeToPrefab,
		// Token: 0x0400055E RID: 1374
		Global
	}
}
