﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B1 RID: 177
	public static class ExtentionMethods
	{
		// Token: 0x060005F3 RID: 1523 RVA: 0x00023CB8 File Offset: 0x00021EB8
		public static T GetOrAddComponent<T>(this GameObject child) where T : Component
		{
			T t = child.GetComponent<T>();
			if (t == null)
			{
				t = child.AddComponent<T>();
			}
			return t;
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x00023CE4 File Offset: 0x00021EE4
		public static bool IsPrefab(this GameObject gameObject)
		{
			if (gameObject == null)
			{
				throw new ArgumentNullException("gameObject");
			}
			return !gameObject.scene.IsValid() && !gameObject.scene.isLoaded && gameObject.GetInstanceID() >= 0 && !gameObject.hideFlags.HasFlag(HideFlags.HideInHierarchy);
		}
	}
}
