﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000095 RID: 149
	public abstract class Menu : MonoBehaviour
	{
		// Token: 0x060004D6 RID: 1238
		public abstract void OnBackPressed();

		// Token: 0x0400039A RID: 922
		[Tooltip("Destroy the Game Object when menu is closed (reduces memory usage)")]
		public bool DestroyWhenClosed = true;

		// Token: 0x0400039B RID: 923
		[Tooltip("Disable menus that are under this one in the stack")]
		public bool DisableMenusUnderneath = true;
	}
}
