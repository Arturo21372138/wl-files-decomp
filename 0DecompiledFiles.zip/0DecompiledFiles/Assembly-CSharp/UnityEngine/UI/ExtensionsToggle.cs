﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

namespace UnityEngine.UI
{
	// Token: 0x0200002A RID: 42
	[AddComponentMenu("UI/Extensions/Extensions Toggle", 31)]
	[RequireComponent(typeof(RectTransform))]
	public class ExtensionsToggle : Selectable, IPointerClickHandler, IEventSystemHandler, ISubmitHandler, ICanvasElement
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600007D RID: 125 RVA: 0x00005004 File Offset: 0x00003204
		// (set) Token: 0x0600007E RID: 126 RVA: 0x0000500C File Offset: 0x0000320C
		public ExtensionsToggleGroup Group
		{
			get
			{
				return this.m_Group;
			}
			set
			{
				this.m_Group = value;
				this.SetToggleGroup(this.m_Group, true);
				this.PlayEffect(true);
			}
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00005029 File Offset: 0x00003229
		protected ExtensionsToggle()
		{
		}

		// Token: 0x06000080 RID: 128 RVA: 0x0000504E File Offset: 0x0000324E
		public virtual void Rebuild(CanvasUpdate executing)
		{
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00005050 File Offset: 0x00003250
		public virtual void LayoutComplete()
		{
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00005052 File Offset: 0x00003252
		public virtual void GraphicUpdateComplete()
		{
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00005054 File Offset: 0x00003254
		protected override void OnEnable()
		{
			base.OnEnable();
			this.SetToggleGroup(this.m_Group, false);
			this.PlayEffect(true);
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00005070 File Offset: 0x00003270
		protected override void OnDisable()
		{
			this.SetToggleGroup(null, false);
			base.OnDisable();
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00005080 File Offset: 0x00003280
		protected override void OnDidApplyAnimationProperties()
		{
			if (this.graphic != null)
			{
				bool flag = !Mathf.Approximately(this.graphic.canvasRenderer.GetColor().a, 0f);
				if (this.m_IsOn != flag)
				{
					this.m_IsOn = flag;
					this.Set(!flag);
				}
			}
			base.OnDidApplyAnimationProperties();
		}

		// Token: 0x06000086 RID: 134 RVA: 0x000050E0 File Offset: 0x000032E0
		private void SetToggleGroup(ExtensionsToggleGroup newGroup, bool setMemberValue)
		{
			ExtensionsToggleGroup group = this.m_Group;
			if (this.m_Group != null)
			{
				this.m_Group.UnregisterToggle(this);
			}
			if (setMemberValue)
			{
				this.m_Group = newGroup;
			}
			if (this.m_Group != null && this.IsActive())
			{
				this.m_Group.RegisterToggle(this);
			}
			if (newGroup != null && newGroup != group && this.IsOn && this.IsActive())
			{
				this.m_Group.NotifyToggleOn(this);
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00005168 File Offset: 0x00003368
		// (set) Token: 0x06000088 RID: 136 RVA: 0x00005170 File Offset: 0x00003370
		public bool IsOn
		{
			get
			{
				return this.m_IsOn;
			}
			set
			{
				this.Set(value);
			}
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00005179 File Offset: 0x00003379
		private void Set(bool value)
		{
			this.Set(value, true);
		}

		// Token: 0x0600008A RID: 138 RVA: 0x00005184 File Offset: 0x00003384
		private void Set(bool value, bool sendCallback)
		{
			if (this.m_IsOn == value)
			{
				return;
			}
			this.m_IsOn = value;
			if (this.m_Group != null && this.IsActive() && (this.m_IsOn || (!this.m_Group.AnyTogglesOn() && !this.m_Group.AllowSwitchOff)))
			{
				this.m_IsOn = true;
				this.m_Group.NotifyToggleOn(this);
			}
			this.PlayEffect(this.toggleTransition == ExtensionsToggle.ToggleTransition.None);
			if (sendCallback)
			{
				this.onValueChanged.Invoke(this.m_IsOn);
				this.onToggleChanged.Invoke(this);
			}
		}

		// Token: 0x0600008B RID: 139 RVA: 0x0000521C File Offset: 0x0000341C
		private void PlayEffect(bool instant)
		{
			if (this.graphic == null)
			{
				return;
			}
			this.graphic.CrossFadeAlpha(this.m_IsOn ? 1f : 0f, instant ? 0f : 0.1f, true);
		}

		// Token: 0x0600008C RID: 140 RVA: 0x0000525C File Offset: 0x0000345C
		protected override void Start()
		{
			this.PlayEffect(true);
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00005265 File Offset: 0x00003465
		private void InternalToggle()
		{
			if (!this.IsActive() || !this.IsInteractable())
			{
				return;
			}
			this.IsOn = !this.IsOn;
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00005287 File Offset: 0x00003487
		public virtual void OnPointerClick(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.InternalToggle();
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00005298 File Offset: 0x00003498
		public virtual void OnSubmit(BaseEventData eventData)
		{
			this.InternalToggle();
		}

		// Token: 0x06000090 RID: 144 RVA: 0x000052A0 File Offset: 0x000034A0
		Transform ICanvasElement.get_transform()
		{
			return base.transform;
		}

		// Token: 0x040000A7 RID: 167
		public string UniqueID;

		// Token: 0x040000A8 RID: 168
		public ExtensionsToggle.ToggleTransition toggleTransition = ExtensionsToggle.ToggleTransition.Fade;

		// Token: 0x040000A9 RID: 169
		public Graphic graphic;

		// Token: 0x040000AA RID: 170
		[SerializeField]
		private ExtensionsToggleGroup m_Group;

		// Token: 0x040000AB RID: 171
		[Tooltip("Use this event if you only need the bool state of the toggle that was changed")]
		public ExtensionsToggle.ToggleEvent onValueChanged = new ExtensionsToggle.ToggleEvent();

		// Token: 0x040000AC RID: 172
		[Tooltip("Use this event if you need access to the toggle that was changed")]
		public ExtensionsToggle.ToggleEventObject onToggleChanged = new ExtensionsToggle.ToggleEventObject();

		// Token: 0x040000AD RID: 173
		[FormerlySerializedAs("m_IsActive")]
		[Tooltip("Is the toggle currently on or off?")]
		[SerializeField]
		private bool m_IsOn;

		// Token: 0x020000FF RID: 255
		public enum ToggleTransition
		{
			// Token: 0x0400060B RID: 1547
			None,
			// Token: 0x0400060C RID: 1548
			Fade
		}

		// Token: 0x02000100 RID: 256
		[Serializable]
		public class ToggleEvent : UnityEvent<bool>
		{
		}

		// Token: 0x02000101 RID: 257
		[Serializable]
		public class ToggleEventObject : UnityEvent<ExtensionsToggle>
		{
		}
	}
}
