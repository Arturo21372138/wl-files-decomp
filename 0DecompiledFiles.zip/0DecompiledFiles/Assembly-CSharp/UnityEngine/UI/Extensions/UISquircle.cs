﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A3 RID: 163
	[AddComponentMenu("UI/Extensions/Primitives/Squircle")]
	public class UISquircle : UIPrimitiveBase
	{
		// Token: 0x06000582 RID: 1410 RVA: 0x00020DA0 File Offset: 0x0001EFA0
		private float SquircleFunc(float t, bool xByY)
		{
			if (xByY)
			{
				return (float)Math.Pow(1.0 - Math.Pow((double)(t / this.a), (double)this.n), (double)(1f / this.n)) * this.b;
			}
			return (float)Math.Pow(1.0 - Math.Pow((double)(t / this.b), (double)this.n), (double)(1f / this.n)) * this.a;
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x00020E24 File Offset: 0x0001F024
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			float num = 0f;
			float num2 = 0f;
			float num3 = base.rectTransform.rect.width / 2f;
			float num4 = base.rectTransform.rect.height / 2f;
			if (this.squircleType == UISquircle.Type.Classic)
			{
				this.a = num3;
				this.b = num4;
			}
			else
			{
				this.a = Mathf.Min(new float[] { num3, num4, this.radius });
				this.b = this.a;
				num = num3 - this.a;
				num2 = num4 - this.a;
			}
			float num5 = 0f;
			float num6 = 1f;
			this.vert.Clear();
			this.vert.Add(new Vector2(0f, num4));
			while (num5 < num6)
			{
				num6 = this.SquircleFunc(num5, true);
				this.vert.Add(new Vector2(num + num5, num2 + num6));
				num5 += this.delta;
			}
			if (float.IsNaN(this.vert.Last<Vector2>().y))
			{
				this.vert.RemoveAt(this.vert.Count - 1);
			}
			while (num6 > 0f)
			{
				num5 = this.SquircleFunc(num6, false);
				this.vert.Add(new Vector2(num + num5, num2 + num6));
				num6 -= this.delta;
			}
			this.vert.Add(new Vector2(num3, 0f));
			for (int i = 1; i < this.vert.Count - 1; i++)
			{
				if (this.vert[i].x < this.vert[i].y)
				{
					if (this.vert[i - 1].y - this.vert[i].y < this.quality)
					{
						this.vert.RemoveAt(i);
						i--;
					}
				}
				else if (this.vert[i].x - this.vert[i - 1].x < this.quality)
				{
					this.vert.RemoveAt(i);
					i--;
				}
			}
			this.vert.AddRange(from t in this.vert.AsEnumerable<Vector2>().Reverse<Vector2>()
				select new Vector2(t.x, -t.y));
			this.vert.AddRange(from t in this.vert.AsEnumerable<Vector2>().Reverse<Vector2>()
				select new Vector2(-t.x, t.y));
			vh.Clear();
			for (int j = 0; j < this.vert.Count - 1; j++)
			{
				vh.AddVert(this.vert[j], this.color, Vector2.zero);
				vh.AddVert(this.vert[j + 1], this.color, Vector2.zero);
				vh.AddVert(Vector2.zero, this.color, Vector2.zero);
				vh.AddTriangle(j * 3, j * 3 + 1, j * 3 + 2);
			}
		}

		// Token: 0x04000404 RID: 1028
		private const float C = 1f;

		// Token: 0x04000405 RID: 1029
		[Space]
		public UISquircle.Type squircleType = UISquircle.Type.Scaled;

		// Token: 0x04000406 RID: 1030
		[Range(1f, 40f)]
		public float n = 4f;

		// Token: 0x04000407 RID: 1031
		[Min(0.1f)]
		public float delta = 5f;

		// Token: 0x04000408 RID: 1032
		public float quality = 0.1f;

		// Token: 0x04000409 RID: 1033
		[Min(0f)]
		public float radius = 1000f;

		// Token: 0x0400040A RID: 1034
		private float a;

		// Token: 0x0400040B RID: 1035
		private float b;

		// Token: 0x0400040C RID: 1036
		private List<Vector2> vert = new List<Vector2>();

		// Token: 0x02000147 RID: 327
		public enum Type
		{
			// Token: 0x040006AD RID: 1709
			Classic,
			// Token: 0x040006AE RID: 1710
			Scaled
		}
	}
}
