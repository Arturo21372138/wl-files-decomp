﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000EC RID: 236
	public enum PresetPipeline
	{
		// Token: 0x040005C3 RID: 1475
		Legacy,
		// Token: 0x040005C4 RID: 1476
		Lightweight,
		// Token: 0x040005C5 RID: 1477
		HighDefinition
	}
}
