﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F8 RID: 2040
	internal struct GetPlayerAchievementCountOptionsInternal : ISettable<GetPlayerAchievementCountOptions>, IDisposable
	{
		// Token: 0x06002194 RID: 8596 RVA: 0x00028173 File Offset: 0x00026373
		public void Set(ref GetPlayerAchievementCountOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.UserId, ref this.m_UserId);
		}

		// Token: 0x06002195 RID: 8597 RVA: 0x00028193 File Offset: 0x00026393
		public void Dispose()
		{
			Helper.Dispose(ref this.m_UserId);
		}

		// Token: 0x0400167E RID: 5758
		private int m_ApiVersion;

		// Token: 0x0400167F RID: 5759
		private IntPtr m_UserId;
	}
}
