﻿using System;
using System.Collections;
using System.Collections.Generic;
using HawkNetworking;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceProviders;
using UnityEngine.SceneManagement;

// Token: 0x02000002 RID: 2
public class ArcadeMachine : HawkNetworkBehaviour
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	protected override void NetworkStart(HawkNetworkObject networkObject)
	{
		base.NetworkStart(networkObject);
		this.actionInteract.onPlayerEntered += this.OnPlayerEntered;
		this.actionInteract.onPlayerExited += this.OnPlayerExited;
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00002088 File Offset: 0x00000288
	protected override void OnDestroy()
	{
		base.OnDestroy();
		if (this.actionInteract)
		{
			this.actionInteract.onPlayerEntered -= this.OnPlayerEntered;
			this.actionInteract.onPlayerExited -= this.OnPlayerExited;
			this.actionInteract = null;
		}
	}

	// Token: 0x06000003 RID: 3 RVA: 0x000020E0 File Offset: 0x000002E0
	private void OnPlayerEntered(PlayerController controller)
	{
		if (controller && controller.IsLocal())
		{
			if (this.uiInstances == null)
			{
				this.uiInstances = new Dictionary<PlayerController, UIPlayerBasedArcadeMachineCanvas>();
			}
			UIPlayerBasedArcadeMachineCanvas uiplayerBasedArcadeMachineCanvas;
			if (this.uiInstances.TryGetValue(controller, out uiplayerBasedArcadeMachineCanvas) && uiplayerBasedArcadeMachineCanvas)
			{
				Addressables.ReleaseInstance(uiplayerBasedArcadeMachineCanvas.gameObject);
			}
			if (this.sceneHandle.IsValid())
			{
				Addressables.UnloadSceneAsync(this.sceneHandle, true);
			}
			this.uiInstances[controller] = null;
			PlayerControllerUI playerControllerUI = controller.GetPlayerControllerUI();
			if (playerControllerUI && this.arcadeMachineUI != null && this.arcadeMachineUI.RuntimeKeyIsValid())
			{
				playerControllerUI.CreateUIOnGameplayCanvas(this.arcadeMachineUI, delegate(UIElement x)
				{
					if (x)
					{
						if (this.uiInstances.ContainsKey(controller))
						{
							UIPlayerBasedArcadeMachineCanvas uiplayerBasedArcadeMachineCanvas2 = x as UIPlayerBasedArcadeMachineCanvas;
							if (uiplayerBasedArcadeMachineCanvas2)
							{
								this.uiInstances[controller] = uiplayerBasedArcadeMachineCanvas2;
								uiplayerBasedArcadeMachineCanvas2.Show();
								LoadSceneParameters loadSceneParameters = default(LoadSceneParameters);
								loadSceneParameters.loadSceneMode = LoadSceneMode.Additive;
								loadSceneParameters.localPhysicsMode = this.physicsMode;
								this.sceneHandle = Addressables.LoadSceneAsync(this.sceneAddress, loadSceneParameters, true, 100);
								this.StartCoroutine(this.LoadingGame(this.sceneHandle, controller, uiplayerBasedArcadeMachineCanvas2));
								return;
							}
							Addressables.ReleaseInstance(x.gameObject);
							return;
						}
						else
						{
							Addressables.ReleaseInstance(x.gameObject);
						}
					}
				});
			}
		}
	}

	// Token: 0x06000004 RID: 4 RVA: 0x000021CC File Offset: 0x000003CC
	private void OnPlayerExited(PlayerController controller)
	{
		UIPlayerBasedArcadeMachineCanvas uiplayerBasedArcadeMachineCanvas;
		if (controller && controller.IsLocal() && this.uiInstances.TryGetValue(controller, out uiplayerBasedArcadeMachineCanvas))
		{
			if (uiplayerBasedArcadeMachineCanvas)
			{
				uiplayerBasedArcadeMachineCanvas.Hide();
				Addressables.ReleaseInstance(uiplayerBasedArcadeMachineCanvas.gameObject);
			}
			this.uiInstances.Remove(controller);
			if (this.sceneHandle.IsValid())
			{
				Addressables.UnloadSceneAsync(this.sceneHandle, true);
			}
		}
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000223A File Offset: 0x0000043A
	private IEnumerator LoadingGame(AsyncOperationHandle<SceneInstance> handle, PlayerController playerController, UIPlayerBasedArcadeMachineCanvas ui)
	{
		yield return handle;
		if (handle.Status == AsyncOperationStatus.Succeeded)
		{
			GameObject[] rootGameObjects = handle.Result.Scene.GetRootGameObjects();
			ArcadeMachineGame arcadeMachineGame = null;
			GameObject[] array = rootGameObjects;
			for (int i = 0; i < array.Length; i++)
			{
				arcadeMachineGame = array[i].GetComponentInChildren<ArcadeMachineGame>();
				if (arcadeMachineGame)
				{
					break;
				}
			}
			if (arcadeMachineGame && playerController && ui)
			{
				arcadeMachineGame.StartGame(this, playerController, ui, handle.Result, this.physicsMode);
			}
			else
			{
				Addressables.UnloadSceneAsync(handle, true);
			}
		}
		yield break;
	}

	// Token: 0x04000001 RID: 1
	[SerializeField]
	private ActionEnterExitInteract actionInteract;

	// Token: 0x04000002 RID: 2
	[SerializeField]
	private AssetReference arcadeMachineUI;

	// Token: 0x04000003 RID: 3
	[SerializeField]
	private string sceneAddress;

	// Token: 0x04000004 RID: 4
	[SerializeField]
	private LocalPhysicsMode physicsMode = LocalPhysicsMode.Physics2D;

	// Token: 0x04000005 RID: 5
	private Dictionary<PlayerController, UIPlayerBasedArcadeMachineCanvas> uiInstances;

	// Token: 0x04000006 RID: 6
	private AsyncOperationHandle<SceneInstance> sceneHandle;
}
