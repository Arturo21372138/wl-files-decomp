﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000036 RID: 54
	[Serializable]
	public class DropDownListItem
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000129 RID: 297 RVA: 0x00007F38 File Offset: 0x00006138
		// (set) Token: 0x0600012A RID: 298 RVA: 0x00007F40 File Offset: 0x00006140
		public string Caption
		{
			get
			{
				return this._caption;
			}
			set
			{
				this._caption = value;
				if (this.OnUpdate != null)
				{
					this.OnUpdate();
				}
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x0600012B RID: 299 RVA: 0x00007F5C File Offset: 0x0000615C
		// (set) Token: 0x0600012C RID: 300 RVA: 0x00007F64 File Offset: 0x00006164
		public Sprite Image
		{
			get
			{
				return this._image;
			}
			set
			{
				this._image = value;
				if (this.OnUpdate != null)
				{
					this.OnUpdate();
				}
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x0600012D RID: 301 RVA: 0x00007F80 File Offset: 0x00006180
		// (set) Token: 0x0600012E RID: 302 RVA: 0x00007F88 File Offset: 0x00006188
		public bool IsDisabled
		{
			get
			{
				return this._isDisabled;
			}
			set
			{
				this._isDisabled = value;
				if (this.OnUpdate != null)
				{
					this.OnUpdate();
				}
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x0600012F RID: 303 RVA: 0x00007FA4 File Offset: 0x000061A4
		// (set) Token: 0x06000130 RID: 304 RVA: 0x00007FAC File Offset: 0x000061AC
		public string ID
		{
			get
			{
				return this._id;
			}
			set
			{
				this._id = value;
			}
		}

		// Token: 0x06000131 RID: 305 RVA: 0x00007FB5 File Offset: 0x000061B5
		public DropDownListItem(string caption = "", string inId = "", Sprite image = null, bool disabled = false, Action onSelect = null)
		{
			this._caption = caption;
			this._image = image;
			this._id = inId;
			this._isDisabled = disabled;
			this.OnSelect = onSelect;
		}

		// Token: 0x0400012A RID: 298
		[SerializeField]
		private string _caption;

		// Token: 0x0400012B RID: 299
		[SerializeField]
		private Sprite _image;

		// Token: 0x0400012C RID: 300
		[SerializeField]
		private bool _isDisabled;

		// Token: 0x0400012D RID: 301
		[SerializeField]
		private string _id;

		// Token: 0x0400012E RID: 302
		public Action OnSelect;

		// Token: 0x0400012F RID: 303
		internal Action OnUpdate;
	}
}
