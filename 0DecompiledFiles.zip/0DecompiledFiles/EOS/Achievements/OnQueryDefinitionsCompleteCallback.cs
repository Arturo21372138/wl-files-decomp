﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000805 RID: 2053
	// (Invoke) Token: 0x060021C5 RID: 8645
	public delegate void OnQueryDefinitionsCompleteCallback(ref OnQueryDefinitionsCompleteCallbackInfo data);
}
