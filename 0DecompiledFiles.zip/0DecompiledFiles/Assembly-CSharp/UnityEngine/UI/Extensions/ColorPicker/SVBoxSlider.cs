﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000DA RID: 218
	[RequireComponent(typeof(BoxSlider), typeof(RawImage))]
	[ExecuteInEditMode]
	public class SVBoxSlider : MonoBehaviour
	{
		// Token: 0x17000131 RID: 305
		// (get) Token: 0x06000728 RID: 1832 RVA: 0x00028B21 File Offset: 0x00026D21
		public RectTransform RectTransform
		{
			get
			{
				return base.transform as RectTransform;
			}
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x00028B2E File Offset: 0x00026D2E
		private void Awake()
		{
			this.slider = base.GetComponent<BoxSlider>();
			this.image = base.GetComponent<RawImage>();
			this.RegenerateSVTexture();
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x00028B50 File Offset: 0x00026D50
		private void OnEnable()
		{
			if (Application.isPlaying && this.picker != null)
			{
				this.slider.OnValueChanged.AddListener(new UnityAction<float, float>(this.SliderChanged));
				this.picker.onHSVChanged.AddListener(new UnityAction<float, float, float>(this.HSVChanged));
			}
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x00028BAC File Offset: 0x00026DAC
		private void OnDisable()
		{
			if (this.picker != null)
			{
				this.slider.OnValueChanged.RemoveListener(new UnityAction<float, float>(this.SliderChanged));
				this.picker.onHSVChanged.RemoveListener(new UnityAction<float, float, float>(this.HSVChanged));
			}
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x00028BFF File Offset: 0x00026DFF
		private void OnDestroy()
		{
			if (this.image.texture != null)
			{
				Object.DestroyImmediate(this.image.texture);
			}
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x00028C24 File Offset: 0x00026E24
		private void SliderChanged(float saturation, float value)
		{
			if (this.listen)
			{
				this.picker.AssignColor(ColorValues.Saturation, saturation);
				this.picker.AssignColor(ColorValues.Value, value);
			}
			this.listen = true;
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x00028C50 File Offset: 0x00026E50
		private void HSVChanged(float h, float s, float v)
		{
			if (this.lastH != h)
			{
				this.lastH = h;
				this.RegenerateSVTexture();
			}
			if (s != this.slider.NormalizedValueX)
			{
				this.listen = false;
				this.slider.NormalizedValueX = s;
			}
			if (v != this.slider.NormalizedValueY)
			{
				this.listen = false;
				this.slider.NormalizedValueY = v;
			}
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x00028CB8 File Offset: 0x00026EB8
		private void RegenerateSVTexture()
		{
			double num = (double)((this.picker != null) ? (this.picker.H * 360f) : 0f);
			if (this.image.texture != null)
			{
				Object.DestroyImmediate(this.image.texture);
			}
			Texture2D texture2D = new Texture2D(100, 100)
			{
				hideFlags = HideFlags.DontSave
			};
			for (int i = 0; i < 100; i++)
			{
				Color32[] array = new Color32[100];
				for (int j = 0; j < 100; j++)
				{
					array[j] = HSVUtil.ConvertHsvToRgb(num, (double)((float)i / 100f), (double)((float)j / 100f), 1f);
				}
				texture2D.SetPixels32(i, 0, 1, 100, array);
			}
			texture2D.Apply();
			this.image.texture = texture2D;
		}

		// Token: 0x04000544 RID: 1348
		public ColorPickerControl picker;

		// Token: 0x04000545 RID: 1349
		private BoxSlider slider;

		// Token: 0x04000546 RID: 1350
		private RawImage image;

		// Token: 0x04000547 RID: 1351
		private float lastH = -1f;

		// Token: 0x04000548 RID: 1352
		private bool listen = true;
	}
}
