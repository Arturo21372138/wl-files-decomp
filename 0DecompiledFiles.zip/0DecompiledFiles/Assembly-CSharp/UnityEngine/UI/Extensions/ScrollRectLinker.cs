﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000BA RID: 186
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("UI/Extensions/ScrollRectLinker")]
	public class ScrollRectLinker : MonoBehaviour
	{
		// Token: 0x0600061C RID: 1564 RVA: 0x000245F0 File Offset: 0x000227F0
		private void Awake()
		{
			this.scrollRect = base.GetComponent<ScrollRect>();
			if (this.controllingScrollRect != null)
			{
				this.controllingScrollRect.onValueChanged.AddListener(new UnityAction<Vector2>(this.MirrorPos));
			}
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00024628 File Offset: 0x00022828
		private void MirrorPos(Vector2 scrollPos)
		{
			if (this.clamp)
			{
				this.scrollRect.normalizedPosition = new Vector2(Mathf.Clamp01(scrollPos.x), Mathf.Clamp01(scrollPos.y));
				return;
			}
			this.scrollRect.normalizedPosition = scrollPos;
		}

		// Token: 0x04000479 RID: 1145
		public bool clamp = true;

		// Token: 0x0400047A RID: 1146
		[SerializeField]
		private ScrollRect controllingScrollRect;

		// Token: 0x0400047B RID: 1147
		private ScrollRect scrollRect;
	}
}
