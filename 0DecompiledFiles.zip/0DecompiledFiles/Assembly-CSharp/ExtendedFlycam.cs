﻿using System;
using UnityEngine;

// Token: 0x02000006 RID: 6
public class ExtendedFlycam : MonoBehaviour
{
	// Token: 0x0600000F RID: 15 RVA: 0x00002240 File Offset: 0x00000440
	private void Start()
	{
		Cursor.lockState = CursorLockMode.Locked;
		Cursor.visible = false;
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00002250 File Offset: 0x00000450
	private void Update()
	{
		if (Cursor.lockState != CursorLockMode.None)
		{
			this.rotationX += Input.GetAxis("Mouse X") * this.cameraSensitivity * Time.deltaTime;
			this.rotationY += Input.GetAxis("Mouse Y") * this.cameraSensitivity * Time.deltaTime;
		}
		this.rotationY = Mathf.Clamp(this.rotationY, -90f, 90f);
		Quaternion quaternion = Quaternion.AngleAxis(this.rotationX, Vector3.up);
		quaternion *= Quaternion.AngleAxis(this.rotationY, Vector3.left);
		base.transform.localRotation = Quaternion.Lerp(base.transform.localRotation, quaternion, Time.deltaTime * 5f);
		if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
		{
			base.transform.position += base.transform.forward * (this.normalMoveSpeed * this.fastMoveFactor) * Input.GetAxis("Vertical") * Time.deltaTime;
			base.transform.position += base.transform.right * (this.normalMoveSpeed * this.fastMoveFactor) * Input.GetAxis("Horizontal") * Time.deltaTime;
			if (Input.GetKey(KeyCode.Q))
			{
				base.transform.position += Vector3.up * this.climbSpeed * this.fastMoveFactor * Time.deltaTime;
			}
			if (Input.GetKey(KeyCode.E))
			{
				base.transform.position -= Vector3.up * this.climbSpeed * this.fastMoveFactor * Time.deltaTime;
			}
		}
		else if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
		{
			base.transform.position += base.transform.forward * (this.normalMoveSpeed * this.slowMoveFactor) * Input.GetAxis("Vertical") * Time.deltaTime;
			base.transform.position += base.transform.right * (this.normalMoveSpeed * this.slowMoveFactor) * Input.GetAxis("Horizontal") * Time.deltaTime;
			if (Input.GetKey(KeyCode.Q))
			{
				base.transform.position += Vector3.up * this.climbSpeed * this.slowMoveFactor * Time.deltaTime;
			}
			if (Input.GetKey(KeyCode.E))
			{
				base.transform.position -= Vector3.up * this.climbSpeed * this.slowMoveFactor * Time.deltaTime;
			}
		}
		else
		{
			base.transform.position += base.transform.forward * this.normalMoveSpeed * Input.GetAxis("Vertical") * Time.deltaTime;
			base.transform.position += base.transform.right * this.normalMoveSpeed * Input.GetAxis("Horizontal") * Time.deltaTime;
			if (Input.GetKey(KeyCode.Q))
			{
				base.transform.position += Vector3.up * this.climbSpeed * Time.deltaTime;
			}
			if (Input.GetKey(KeyCode.E))
			{
				base.transform.position -= Vector3.up * this.climbSpeed * Time.deltaTime;
			}
		}
		if (Input.GetKeyDown(KeyCode.End) || Input.GetKeyDown(KeyCode.Escape))
		{
			if (Cursor.lockState == CursorLockMode.None)
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
				return;
			}
			Cursor.lockState = CursorLockMode.None;
			Cursor.visible = true;
		}
	}

	// Token: 0x0400000B RID: 11
	public float cameraSensitivity = 90f;

	// Token: 0x0400000C RID: 12
	public float climbSpeed = 4f;

	// Token: 0x0400000D RID: 13
	public float normalMoveSpeed = 10f;

	// Token: 0x0400000E RID: 14
	public float slowMoveFactor = 0.25f;

	// Token: 0x0400000F RID: 15
	public float fastMoveFactor = 3f;

	// Token: 0x04000010 RID: 16
	private float rotationX;

	// Token: 0x04000011 RID: 17
	private float rotationY;
}
