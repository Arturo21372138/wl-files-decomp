﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200003D RID: 61
	[DisallowMultipleComponent]
	public class ReorderableListContent : MonoBehaviour
	{
		// Token: 0x060001A5 RID: 421 RVA: 0x00009487 File Offset: 0x00007687
		private void OnEnable()
		{
			if (this._rect)
			{
				base.StartCoroutine(this.RefreshChildren());
			}
		}

		// Token: 0x060001A6 RID: 422 RVA: 0x000094A3 File Offset: 0x000076A3
		public void OnTransformChildrenChanged()
		{
			if (base.isActiveAndEnabled)
			{
				base.StartCoroutine(this.RefreshChildren());
			}
		}

		// Token: 0x060001A7 RID: 423 RVA: 0x000094BC File Offset: 0x000076BC
		public void Init(ReorderableList extList)
		{
			if (this._started)
			{
				base.StopCoroutine(this.RefreshChildren());
			}
			this._extList = extList;
			this._rect = base.GetComponent<RectTransform>();
			this._cachedChildren = new List<Transform>();
			this._cachedListElement = new List<ReorderableListElement>();
			base.StartCoroutine(this.RefreshChildren());
			this._started = true;
		}

		// Token: 0x060001A8 RID: 424 RVA: 0x0000951A File Offset: 0x0000771A
		private IEnumerator RefreshChildren()
		{
			for (int i = 0; i < this._rect.childCount; i++)
			{
				if (!this._cachedChildren.Contains(this._rect.GetChild(i)))
				{
					this._ele = this._rect.GetChild(i).gameObject.GetComponent<ReorderableListElement>() ?? this._rect.GetChild(i).gameObject.AddComponent<ReorderableListElement>();
					this._ele.Init(this._extList);
					this._cachedChildren.Add(this._rect.GetChild(i));
					this._cachedListElement.Add(this._ele);
				}
			}
			yield return 0;
			for (int j = this._cachedChildren.Count - 1; j >= 0; j--)
			{
				if (this._cachedChildren[j] == null)
				{
					this._cachedChildren.RemoveAt(j);
					this._cachedListElement.RemoveAt(j);
				}
			}
			yield break;
		}

		// Token: 0x04000179 RID: 377
		private List<Transform> _cachedChildren;

		// Token: 0x0400017A RID: 378
		private List<ReorderableListElement> _cachedListElement;

		// Token: 0x0400017B RID: 379
		private ReorderableListElement _ele;

		// Token: 0x0400017C RID: 380
		private ReorderableList _extList;

		// Token: 0x0400017D RID: 381
		private RectTransform _rect;

		// Token: 0x0400017E RID: 382
		private bool _started;
	}
}
