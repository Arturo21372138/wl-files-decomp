﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F9 RID: 2041
	public struct GetUnlockedAchievementCountOptions
	{
		// Token: 0x1700085C RID: 2140
		// (get) Token: 0x06002196 RID: 8598 RVA: 0x000281A0 File Offset: 0x000263A0
		// (set) Token: 0x06002197 RID: 8599 RVA: 0x000281A8 File Offset: 0x000263A8
		public ProductUserId UserId { readonly get; set; }
	}
}
