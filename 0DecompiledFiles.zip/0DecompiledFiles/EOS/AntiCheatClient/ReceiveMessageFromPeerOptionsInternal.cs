﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D1 RID: 2001
	internal struct ReceiveMessageFromPeerOptionsInternal : ISettable<ReceiveMessageFromPeerOptions>, IDisposable
	{
		// Token: 0x060020FF RID: 8447 RVA: 0x0002738A File Offset: 0x0002558A
		public void Set(ref ReceiveMessageFromPeerOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			this.m_PeerHandle = other.PeerHandle;
			Helper.Set(other.Data, ref this.m_Data, out this.m_DataLengthBytes);
		}

		// Token: 0x06002100 RID: 8448 RVA: 0x000273BC File Offset: 0x000255BC
		public void Dispose()
		{
			Helper.Dispose(ref this.m_Data);
		}

		// Token: 0x040015ED RID: 5613
		private int m_ApiVersion;

		// Token: 0x040015EE RID: 5614
		private IntPtr m_PeerHandle;

		// Token: 0x040015EF RID: 5615
		private uint m_DataLengthBytes;

		// Token: 0x040015F0 RID: 5616
		private IntPtr m_Data;
	}
}
