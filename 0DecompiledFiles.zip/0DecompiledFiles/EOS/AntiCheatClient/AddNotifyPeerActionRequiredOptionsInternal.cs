﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007AD RID: 1965
	internal struct AddNotifyPeerActionRequiredOptionsInternal : ISettable<AddNotifyPeerActionRequiredOptions>, IDisposable
	{
		// Token: 0x06002084 RID: 8324 RVA: 0x00026A73 File Offset: 0x00024C73
		public void Set(ref AddNotifyPeerActionRequiredOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002085 RID: 8325 RVA: 0x00026A82 File Offset: 0x00024C82
		public void Dispose()
		{
		}

		// Token: 0x0400159C RID: 5532
		private int m_ApiVersion;
	}
}
