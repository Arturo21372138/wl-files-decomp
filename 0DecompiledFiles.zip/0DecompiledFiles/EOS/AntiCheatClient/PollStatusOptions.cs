﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007CC RID: 1996
	public struct PollStatusOptions
	{
		// Token: 0x17000828 RID: 2088
		// (get) Token: 0x060020F1 RID: 8433 RVA: 0x000272D9 File Offset: 0x000254D9
		// (set) Token: 0x060020F2 RID: 8434 RVA: 0x000272E1 File Offset: 0x000254E1
		public uint OutMessageLength { readonly get; set; }
	}
}
