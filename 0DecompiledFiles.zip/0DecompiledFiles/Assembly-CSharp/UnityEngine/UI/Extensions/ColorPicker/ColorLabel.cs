﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000CF RID: 207
	[RequireComponent(typeof(Text))]
	public class ColorLabel : MonoBehaviour
	{
		// Token: 0x060006CC RID: 1740 RVA: 0x000270A3 File Offset: 0x000252A3
		private void Awake()
		{
			this.label = base.GetComponent<Text>();
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x000270B4 File Offset: 0x000252B4
		private void OnEnable()
		{
			if (Application.isPlaying && this.picker != null)
			{
				this.picker.onValueChanged.AddListener(new UnityAction<Color>(this.ColorChanged));
				this.picker.onHSVChanged.AddListener(new UnityAction<float, float, float>(this.HSVChanged));
			}
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x00027110 File Offset: 0x00025310
		private void OnDestroy()
		{
			if (this.picker != null)
			{
				this.picker.onValueChanged.RemoveListener(new UnityAction<Color>(this.ColorChanged));
				this.picker.onHSVChanged.RemoveListener(new UnityAction<float, float, float>(this.HSVChanged));
			}
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x00027163 File Offset: 0x00025363
		private void ColorChanged(Color color)
		{
			this.UpdateValue();
		}

		// Token: 0x060006D0 RID: 1744 RVA: 0x0002716B File Offset: 0x0002536B
		private void HSVChanged(float hue, float sateration, float value)
		{
			this.UpdateValue();
		}

		// Token: 0x060006D1 RID: 1745 RVA: 0x00027174 File Offset: 0x00025374
		private void UpdateValue()
		{
			if (this.picker == null)
			{
				this.label.text = this.prefix + "-";
				return;
			}
			float num = this.minValue + this.picker.GetValue(this.type) * (this.maxValue - this.minValue);
			this.label.text = this.prefix + this.ConvertToDisplayString(num);
		}

		// Token: 0x060006D2 RID: 1746 RVA: 0x000271F0 File Offset: 0x000253F0
		private string ConvertToDisplayString(float value)
		{
			if (this.precision > 0)
			{
				return value.ToString("f " + this.precision.ToString());
			}
			return Mathf.FloorToInt(value).ToString();
		}

		// Token: 0x04000506 RID: 1286
		public ColorPickerControl picker;

		// Token: 0x04000507 RID: 1287
		public ColorValues type;

		// Token: 0x04000508 RID: 1288
		public string prefix = "R: ";

		// Token: 0x04000509 RID: 1289
		public float minValue;

		// Token: 0x0400050A RID: 1290
		public float maxValue = 255f;

		// Token: 0x0400050B RID: 1291
		public int precision;

		// Token: 0x0400050C RID: 1292
		private Text label;
	}
}
