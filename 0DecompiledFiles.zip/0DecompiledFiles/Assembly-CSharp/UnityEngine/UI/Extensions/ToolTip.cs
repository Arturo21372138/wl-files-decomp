﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A9 RID: 169
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/Tooltip/Tooltip")]
	public class ToolTip : MonoBehaviour
	{
		// Token: 0x17000105 RID: 261
		// (get) Token: 0x060005A3 RID: 1443 RVA: 0x00021EA9 File Offset: 0x000200A9
		public Camera GuiCamera
		{
			get
			{
				if (!this._guiCamera)
				{
					this._guiCamera = Camera.main;
				}
				return this._guiCamera;
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x00021EC9 File Offset: 0x000200C9
		public static ToolTip Instance
		{
			get
			{
				if (ToolTip.instance == null)
				{
					ToolTip.instance = Object.FindObjectOfType<ToolTip>();
				}
				return ToolTip.instance;
			}
		}

		// Token: 0x060005A5 RID: 1445 RVA: 0x00021EE7 File Offset: 0x000200E7
		private void Reset()
		{
			this.canvas = base.GetComponentInParent<Canvas>();
			this.canvas = this.canvas.rootCanvas;
		}

		// Token: 0x060005A6 RID: 1446 RVA: 0x00021F08 File Offset: 0x00020108
		public void Awake()
		{
			ToolTip.instance = this;
			if (!this.canvas)
			{
				this.canvas = base.GetComponentInParent<Canvas>();
				this.canvas = this.canvas.rootCanvas;
			}
			this._guiCamera = this.canvas.worldCamera;
			this.guiMode = this.canvas.renderMode;
			this._rectTransform = base.GetComponent<RectTransform>();
			this.canvasRectTransform = this.canvas.GetComponent<RectTransform>();
			this._layoutGroup = base.GetComponentInChildren<LayoutGroup>();
			this._text = base.GetComponentInChildren<Text>();
			this._inside = false;
			base.gameObject.SetActive(false);
		}

		// Token: 0x060005A7 RID: 1447 RVA: 0x00021FAF File Offset: 0x000201AF
		public void SetTooltip(string ttext)
		{
			this.SetTooltip(ttext, base.transform.position, false);
		}

		// Token: 0x060005A8 RID: 1448 RVA: 0x00021FC4 File Offset: 0x000201C4
		public void SetTooltip(string ttext, Vector3 basePos, bool refreshCanvasesBeforeGetSize = false)
		{
			this.baseTooltipPos = basePos;
			if (this._text)
			{
				this._text.text = ttext;
			}
			else
			{
				Debug.LogWarning("[ToolTip] Couldn't set tooltip text, tooltip has no child Text component");
			}
			this.ContextualTooltipUpdate(refreshCanvasesBeforeGetSize);
		}

		// Token: 0x060005A9 RID: 1449 RVA: 0x00021FF9 File Offset: 0x000201F9
		public void HideTooltip()
		{
			base.gameObject.SetActive(false);
			this._inside = false;
		}

		// Token: 0x060005AA RID: 1450 RVA: 0x0002200E File Offset: 0x0002020E
		private void Update()
		{
			if (this._inside)
			{
				this.ContextualTooltipUpdate(false);
			}
		}

		// Token: 0x060005AB RID: 1451 RVA: 0x0002201F File Offset: 0x0002021F
		public void RefreshTooltipSize()
		{
			if (this.tooltipTriggersCanForceCanvasUpdate)
			{
				Canvas.ForceUpdateCanvases();
				if (this._layoutGroup)
				{
					this._layoutGroup.enabled = false;
					this._layoutGroup.enabled = true;
				}
			}
		}

		// Token: 0x060005AC RID: 1452 RVA: 0x00022054 File Offset: 0x00020254
		public void ContextualTooltipUpdate(bool refreshCanvasesBeforeGettingSize = false)
		{
			RenderMode renderMode = this.guiMode;
			if (renderMode != RenderMode.ScreenSpaceOverlay)
			{
				if (renderMode == RenderMode.ScreenSpaceCamera)
				{
					this.OnScreenSpaceCamera(refreshCanvasesBeforeGettingSize);
					return;
				}
			}
			else
			{
				this.OnScreenSpaceOverlay(refreshCanvasesBeforeGettingSize);
			}
		}

		// Token: 0x060005AD RID: 1453 RVA: 0x00022080 File Offset: 0x00020280
		public void OnScreenSpaceCamera(bool refreshCanvasesBeforeGettingSize = false)
		{
			this.shiftingVector.x = this.xShift;
			this.shiftingVector.y = this.YShift;
			this.baseTooltipPos.z = this.canvas.planeDistance;
			this.newTTPos = this.GuiCamera.ScreenToViewportPoint(this.baseTooltipPos - this.shiftingVector);
			this.adjustedNewTTPos = this.GuiCamera.ViewportToWorldPoint(this.newTTPos);
			base.gameObject.SetActive(true);
			if (refreshCanvasesBeforeGettingSize)
			{
				this.RefreshTooltipSize();
			}
			this.width = base.transform.lossyScale.x * this._rectTransform.sizeDelta[0];
			this.height = base.transform.lossyScale.y * this._rectTransform.sizeDelta[1];
			RectTransformUtility.ScreenPointToWorldPointInRectangle(this.canvasRectTransform, Vector2.zero, this.GuiCamera, out this.screenLowerLeft);
			RectTransformUtility.ScreenPointToWorldPointInRectangle(this.canvasRectTransform, new Vector2((float)Screen.width, (float)Screen.height), this.GuiCamera, out this.screenUpperRight);
			this.borderTest = this.adjustedNewTTPos.x + this.width / 2f;
			if (this.borderTest > this.screenUpperRight.x)
			{
				this.shifterForBorders.x = this.borderTest - this.screenUpperRight.x;
				this.adjustedNewTTPos.x = this.adjustedNewTTPos.x - this.shifterForBorders.x;
			}
			this.borderTest = this.adjustedNewTTPos.x - this.width / 2f;
			if (this.borderTest < this.screenLowerLeft.x)
			{
				this.shifterForBorders.x = this.screenLowerLeft.x - this.borderTest;
				this.adjustedNewTTPos.x = this.adjustedNewTTPos.x + this.shifterForBorders.x;
			}
			this.borderTest = this.adjustedNewTTPos.y - this.height / 2f;
			if (this.borderTest < this.screenLowerLeft.y)
			{
				this.shifterForBorders.y = this.screenLowerLeft.y - this.borderTest;
				this.adjustedNewTTPos.y = this.adjustedNewTTPos.y + this.shifterForBorders.y;
			}
			this.borderTest = this.adjustedNewTTPos.y + this.height / 2f;
			if (this.borderTest > this.screenUpperRight.y)
			{
				this.shifterForBorders.y = this.borderTest - this.screenUpperRight.y;
				this.adjustedNewTTPos.y = this.adjustedNewTTPos.y - this.shifterForBorders.y;
			}
			this.adjustedNewTTPos = base.transform.rotation * this.adjustedNewTTPos;
			base.transform.position = this.adjustedNewTTPos;
			this.adjustedTTLocalPos = base.transform.localPosition;
			this.adjustedTTLocalPos.z = 0f;
			base.transform.localPosition = this.adjustedTTLocalPos;
			this._inside = true;
		}

		// Token: 0x060005AE RID: 1454 RVA: 0x000223B8 File Offset: 0x000205B8
		public void OnScreenSpaceOverlay(bool refreshCanvasesBeforeGettingSize = false)
		{
			this.shiftingVector.x = this.xShift;
			this.shiftingVector.y = this.YShift;
			this.newTTPos = (this.baseTooltipPos - this.shiftingVector) / this.canvas.scaleFactor;
			this.adjustedNewTTPos = this.newTTPos;
			base.gameObject.SetActive(true);
			if (refreshCanvasesBeforeGettingSize)
			{
				this.RefreshTooltipSize();
			}
			this.width = this._rectTransform.sizeDelta[0];
			this.height = this._rectTransform.sizeDelta[1];
			this.screenLowerLeft = Vector3.zero;
			this.screenUpperRight = this.canvasRectTransform.sizeDelta;
			this.borderTest = this.newTTPos.x + this.width / 2f;
			if (this.borderTest > this.screenUpperRight.x)
			{
				this.shifterForBorders.x = this.borderTest - this.screenUpperRight.x;
				this.adjustedNewTTPos.x = this.adjustedNewTTPos.x - this.shifterForBorders.x;
			}
			this.borderTest = this.adjustedNewTTPos.x - this.width / 2f;
			if (this.borderTest < this.screenLowerLeft.x)
			{
				this.shifterForBorders.x = this.screenLowerLeft.x - this.borderTest;
				this.adjustedNewTTPos.x = this.adjustedNewTTPos.x + this.shifterForBorders.x;
			}
			this.borderTest = this.adjustedNewTTPos.y - this.height / 2f;
			if (this.borderTest < this.screenLowerLeft.y)
			{
				this.shifterForBorders.y = this.screenLowerLeft.y - this.borderTest;
				this.adjustedNewTTPos.y = this.adjustedNewTTPos.y + this.shifterForBorders.y;
			}
			this.borderTest = this.adjustedNewTTPos.y + this.height / 2f;
			if (this.borderTest > this.screenUpperRight.y)
			{
				this.shifterForBorders.y = this.borderTest - this.screenUpperRight.y;
				this.adjustedNewTTPos.y = this.adjustedNewTTPos.y - this.shifterForBorders.y;
			}
			this.adjustedNewTTPos *= this.canvas.scaleFactor;
			base.transform.position = this.adjustedNewTTPos;
			this._inside = true;
		}

		// Token: 0x0400042E RID: 1070
		private Text _text;

		// Token: 0x0400042F RID: 1071
		private RectTransform _rectTransform;

		// Token: 0x04000430 RID: 1072
		private RectTransform canvasRectTransform;

		// Token: 0x04000431 RID: 1073
		[Tooltip("The canvas used by the tooltip as positioning and scaling reference. Should usually be the root Canvas of the hierarchy this component is in")]
		public Canvas canvas;

		// Token: 0x04000432 RID: 1074
		[Tooltip("Sets if tooltip triggers will run ForceUpdateCanvases and refresh the tooltip's layout group (if any) when hovered, in order to prevent momentousness misplacement sometimes caused by ContentSizeFitters")]
		public bool tooltipTriggersCanForceCanvasUpdate;

		// Token: 0x04000433 RID: 1075
		private LayoutGroup _layoutGroup;

		// Token: 0x04000434 RID: 1076
		private bool _inside;

		// Token: 0x04000435 RID: 1077
		private float width;

		// Token: 0x04000436 RID: 1078
		private float height;

		// Token: 0x04000437 RID: 1079
		public float YShift;

		// Token: 0x04000438 RID: 1080
		public float xShift;

		// Token: 0x04000439 RID: 1081
		[HideInInspector]
		public RenderMode guiMode;

		// Token: 0x0400043A RID: 1082
		private Camera _guiCamera;

		// Token: 0x0400043B RID: 1083
		private Vector3 screenLowerLeft;

		// Token: 0x0400043C RID: 1084
		private Vector3 screenUpperRight;

		// Token: 0x0400043D RID: 1085
		private Vector3 shiftingVector;

		// Token: 0x0400043E RID: 1086
		private Vector3 baseTooltipPos;

		// Token: 0x0400043F RID: 1087
		private Vector3 newTTPos;

		// Token: 0x04000440 RID: 1088
		private Vector3 adjustedNewTTPos;

		// Token: 0x04000441 RID: 1089
		private Vector3 adjustedTTLocalPos;

		// Token: 0x04000442 RID: 1090
		private Vector3 shifterForBorders;

		// Token: 0x04000443 RID: 1091
		private float borderTest;

		// Token: 0x04000444 RID: 1092
		private static ToolTip instance;
	}
}
