﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000045 RID: 69
	public class ExampleSelectable : MonoBehaviour, IBoxSelectable
	{
		// Token: 0x1700004E RID: 78
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x0000B63C File Offset: 0x0000983C
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x0000B644 File Offset: 0x00009844
		public bool selected
		{
			get
			{
				return this._selected;
			}
			set
			{
				this._selected = value;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x060001F4 RID: 500 RVA: 0x0000B64D File Offset: 0x0000984D
		// (set) Token: 0x060001F5 RID: 501 RVA: 0x0000B655 File Offset: 0x00009855
		public bool preSelected
		{
			get
			{
				return this._preSelected;
			}
			set
			{
				this._preSelected = value;
			}
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000B65E File Offset: 0x0000985E
		private void Start()
		{
			this.spriteRenderer = base.transform.GetComponent<SpriteRenderer>();
			this.image = base.transform.GetComponent<Image>();
			this.text = base.transform.GetComponent<Text>();
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000B694 File Offset: 0x00009894
		private void Update()
		{
			Color color = Color.white;
			if (this.preSelected)
			{
				color = Color.yellow;
			}
			if (this.selected)
			{
				color = Color.green;
			}
			if (this.spriteRenderer)
			{
				this.spriteRenderer.color = color;
				return;
			}
			if (this.text)
			{
				this.text.color = color;
				return;
			}
			if (this.image)
			{
				this.image.color = color;
				return;
			}
			if (base.GetComponent<Renderer>())
			{
				base.GetComponent<Renderer>().material.color = color;
			}
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x0000B737 File Offset: 0x00009937
		Transform IBoxSelectable.get_transform()
		{
			return base.transform;
		}

		// Token: 0x040001B1 RID: 433
		private bool _selected;

		// Token: 0x040001B2 RID: 434
		private bool _preSelected;

		// Token: 0x040001B3 RID: 435
		private SpriteRenderer spriteRenderer;

		// Token: 0x040001B4 RID: 436
		private Image image;

		// Token: 0x040001B5 RID: 437
		private Text text;
	}
}
