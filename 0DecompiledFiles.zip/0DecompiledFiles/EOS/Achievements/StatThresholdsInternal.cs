﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200081D RID: 2077
	internal struct StatThresholdsInternal : IGettable<StatThresholds>
	{
		// Token: 0x0600222C RID: 8748 RVA: 0x00028980 File Offset: 0x00026B80
		public void Get(out StatThresholds other)
		{
			other = default(StatThresholds);
			Utf8String utf8String;
			Helper.Get(this.m_Name, out utf8String);
			other.Name = utf8String;
			other.Threshold = this.m_Threshold;
		}

		// Token: 0x040016D3 RID: 5843
		private int m_ApiVersion;

		// Token: 0x040016D4 RID: 5844
		private IntPtr m_Name;

		// Token: 0x040016D5 RID: 5845
		private int m_Threshold;
	}
}
