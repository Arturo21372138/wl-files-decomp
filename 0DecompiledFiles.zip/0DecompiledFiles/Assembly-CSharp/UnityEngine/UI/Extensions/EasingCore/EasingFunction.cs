﻿using System;

namespace UnityEngine.UI.Extensions.EasingCore
{
	// Token: 0x020000CC RID: 204
	// (Invoke) Token: 0x060006A5 RID: 1701
	public delegate float EasingFunction(float t);
}
