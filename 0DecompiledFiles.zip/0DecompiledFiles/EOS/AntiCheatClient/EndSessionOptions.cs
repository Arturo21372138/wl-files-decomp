﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B5 RID: 1973
	public struct EndSessionOptions
	{
	}
}
