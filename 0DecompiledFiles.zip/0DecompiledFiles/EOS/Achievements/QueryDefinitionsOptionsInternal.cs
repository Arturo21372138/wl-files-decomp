﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000819 RID: 2073
	internal struct QueryDefinitionsOptionsInternal : ISettable<QueryDefinitionsOptions>, IDisposable
	{
		// Token: 0x06002220 RID: 8736 RVA: 0x0002887C File Offset: 0x00026A7C
		public void Set(ref QueryDefinitionsOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 3;
			Helper.Set(other.LocalUserId, ref this.m_LocalUserId);
			Helper.Set(other.EpicUserId_DEPRECATED, ref this.m_EpicUserId_DEPRECATED);
			Helper.Set(other.HiddenAchievementIds_DEPRECATED, ref this.m_HiddenAchievementIds_DEPRECATED, out this.m_HiddenAchievementsCount_DEPRECATED, true);
		}

		// Token: 0x06002221 RID: 8737 RVA: 0x000288D0 File Offset: 0x00026AD0
		public void Dispose()
		{
			Helper.Dispose(ref this.m_LocalUserId);
			Helper.Dispose(ref this.m_EpicUserId_DEPRECATED);
			Helper.Dispose(ref this.m_HiddenAchievementIds_DEPRECATED);
		}

		// Token: 0x040016C7 RID: 5831
		private int m_ApiVersion;

		// Token: 0x040016C8 RID: 5832
		private IntPtr m_LocalUserId;

		// Token: 0x040016C9 RID: 5833
		private IntPtr m_EpicUserId_DEPRECATED;

		// Token: 0x040016CA RID: 5834
		private IntPtr m_HiddenAchievementIds_DEPRECATED;

		// Token: 0x040016CB RID: 5835
		private uint m_HiddenAchievementsCount_DEPRECATED;
	}
}
