﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000069 RID: 105
	[RequireComponent(typeof(Rigidbody))]
	public class CardPopup2D : MonoBehaviour
	{
		// Token: 0x0600031A RID: 794 RVA: 0x00014377 File Offset: 0x00012577
		private void Start()
		{
			this.rbody = base.GetComponent<Rigidbody>();
			this.rbody.useGravity = false;
			this.startZPos = base.transform.position.z;
		}

		// Token: 0x0600031B RID: 795 RVA: 0x000143A8 File Offset: 0x000125A8
		private void Update()
		{
			if (this.isFalling)
			{
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, Quaternion.Euler(this.cardFallRotation), Time.deltaTime * this.rotationSpeed);
			}
			if (this.fallToZero)
			{
				base.transform.position = Vector3.Lerp(base.transform.position, new Vector3(0f, 0f, this.startZPos), Time.deltaTime * this.centeringSpeed);
				base.transform.rotation = Quaternion.Lerp(base.transform.rotation, Quaternion.Euler(Vector3.zero), Time.deltaTime * this.centeringSpeed);
				if (Vector3.Distance(base.transform.position, new Vector3(0f, 0f, this.startZPos)) < 0.0025f)
				{
					base.transform.position = new Vector3(0f, 0f, this.startZPos);
					this.fallToZero = false;
				}
			}
			if (base.transform.position.y < -4f)
			{
				this.isFalling = false;
				this.rbody.useGravity = false;
				this.rbody.velocity = Vector3.zero;
				base.transform.position = new Vector3(0f, 8f, this.startZPos);
				if (this.singleScene)
				{
					this.CardEnter();
				}
			}
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00014522 File Offset: 0x00012722
		public void CardEnter()
		{
			this.fallToZero = true;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0001452B File Offset: 0x0001272B
		public void CardFallAway(float fallRotation)
		{
			this.rbody.useGravity = true;
			this.isFalling = true;
			this.cardFallRotation = new Vector3(0f, 0f, fallRotation);
		}

		// Token: 0x04000277 RID: 631
		[SerializeField]
		private float rotationSpeed = 1f;

		// Token: 0x04000278 RID: 632
		[SerializeField]
		private float centeringSpeed = 4f;

		// Token: 0x04000279 RID: 633
		[SerializeField]
		private bool singleScene;

		// Token: 0x0400027A RID: 634
		private Rigidbody rbody;

		// Token: 0x0400027B RID: 635
		private bool isFalling;

		// Token: 0x0400027C RID: 636
		private Vector3 cardFallRotation;

		// Token: 0x0400027D RID: 637
		private bool fallToZero;

		// Token: 0x0400027E RID: 638
		private float startZPos;
	}
}
