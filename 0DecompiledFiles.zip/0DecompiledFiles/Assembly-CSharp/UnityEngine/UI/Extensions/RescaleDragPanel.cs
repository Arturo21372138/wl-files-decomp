﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000040 RID: 64
	[AddComponentMenu("UI/Extensions/RescalePanels/RescaleDragPanel")]
	public class RescaleDragPanel : MonoBehaviour, IPointerDownHandler, IEventSystemHandler, IDragHandler
	{
		// Token: 0x060001B9 RID: 441 RVA: 0x0000A764 File Offset: 0x00008964
		private void Awake()
		{
			Canvas componentInParent = base.GetComponentInParent<Canvas>();
			if (componentInParent != null)
			{
				this.canvasRectTransform = componentInParent.transform as RectTransform;
				this.panelRectTransform = base.transform.parent as RectTransform;
				this.goTransform = base.transform.parent;
			}
		}

		// Token: 0x060001BA RID: 442 RVA: 0x0000A7B9 File Offset: 0x000089B9
		public void OnPointerDown(PointerEventData data)
		{
			this.panelRectTransform.SetAsLastSibling();
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.panelRectTransform, data.position, data.pressEventCamera, out this.pointerOffset);
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0000A7E4 File Offset: 0x000089E4
		public void OnDrag(PointerEventData data)
		{
			if (this.panelRectTransform == null)
			{
				return;
			}
			Vector2 vector = this.ClampToWindow(data);
			Vector2 vector2;
			if (RectTransformUtility.ScreenPointToLocalPointInRectangle(this.canvasRectTransform, vector, data.pressEventCamera, out vector2))
			{
				this.panelRectTransform.localPosition = vector2 - new Vector2(this.pointerOffset.x * this.goTransform.localScale.x, this.pointerOffset.y * this.goTransform.localScale.y);
			}
		}

		// Token: 0x060001BC RID: 444 RVA: 0x0000A874 File Offset: 0x00008A74
		private Vector2 ClampToWindow(PointerEventData data)
		{
			Vector2 position = data.position;
			Vector3[] array = new Vector3[4];
			this.canvasRectTransform.GetWorldCorners(array);
			float num = Mathf.Clamp(position.x, array[0].x, array[2].x);
			float num2 = Mathf.Clamp(position.y, array[0].y, array[2].y);
			return new Vector2(num, num2);
		}

		// Token: 0x04000195 RID: 405
		private Vector2 pointerOffset;

		// Token: 0x04000196 RID: 406
		private RectTransform canvasRectTransform;

		// Token: 0x04000197 RID: 407
		private RectTransform panelRectTransform;

		// Token: 0x04000198 RID: 408
		private Transform goTransform;
	}
}
