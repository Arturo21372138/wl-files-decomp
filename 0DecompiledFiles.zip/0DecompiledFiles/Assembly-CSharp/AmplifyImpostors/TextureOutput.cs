﻿using System;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x020000ED RID: 237
	[Serializable]
	public class TextureOutput
	{
		// Token: 0x0600075E RID: 1886 RVA: 0x0002A335 File Offset: 0x00028535
		public TextureOutput()
		{
		}

		// Token: 0x0600075F RID: 1887 RVA: 0x0002A36C File Offset: 0x0002856C
		public TextureOutput(bool a, string n, TextureScale s, bool sr, TextureChannels c, TextureCompression nc, ImageFormat i)
		{
			this.Active = a;
			this.Name = n;
			this.Scale = s;
			this.SRGB = sr;
			this.Channels = c;
			this.Compression = nc;
			this.ImageFormat = i;
		}

		// Token: 0x06000760 RID: 1888 RVA: 0x0002A3E2 File Offset: 0x000285E2
		public TextureOutput Clone()
		{
			return (TextureOutput)base.MemberwiseClone();
		}

		// Token: 0x040005C6 RID: 1478
		[SerializeField]
		public int Index = -1;

		// Token: 0x040005C7 RID: 1479
		[SerializeField]
		public OverrideMask OverrideMask;

		// Token: 0x040005C8 RID: 1480
		public bool Active = true;

		// Token: 0x040005C9 RID: 1481
		public string Name = string.Empty;

		// Token: 0x040005CA RID: 1482
		public TextureScale Scale = TextureScale.Full;

		// Token: 0x040005CB RID: 1483
		public bool SRGB;

		// Token: 0x040005CC RID: 1484
		public TextureChannels Channels;

		// Token: 0x040005CD RID: 1485
		public TextureCompression Compression = TextureCompression.Normal;

		// Token: 0x040005CE RID: 1486
		public ImageFormat ImageFormat = ImageFormat.TGA;
	}
}
