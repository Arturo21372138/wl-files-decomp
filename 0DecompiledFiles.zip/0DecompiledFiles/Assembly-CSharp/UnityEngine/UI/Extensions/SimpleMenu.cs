﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000098 RID: 152
	public abstract class SimpleMenu<T> : Menu<T> where T : SimpleMenu<T>
	{
		// Token: 0x060004E9 RID: 1257 RVA: 0x0001D20C File Offset: 0x0001B40C
		public static void Show()
		{
			Menu<T>.Open();
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x0001D213 File Offset: 0x0001B413
		public static void Hide()
		{
			Menu<T>.Close();
		}
	}
}
