﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000035 RID: 53
	[RequireComponent(typeof(RectTransform), typeof(Button))]
	public class DropDownListButton
	{
		// Token: 0x06000128 RID: 296 RVA: 0x00007EC4 File Offset: 0x000060C4
		public DropDownListButton(GameObject btnObj)
		{
			this.gameobject = btnObj;
			this.rectTransform = btnObj.GetComponent<RectTransform>();
			this.btnImg = btnObj.GetComponent<Image>();
			this.btn = btnObj.GetComponent<Button>();
			this.txt = this.rectTransform.Find("Text").GetComponent<Text>();
			this.img = this.rectTransform.Find("Image").GetComponent<Image>();
		}

		// Token: 0x04000124 RID: 292
		public RectTransform rectTransform;

		// Token: 0x04000125 RID: 293
		public Button btn;

		// Token: 0x04000126 RID: 294
		public Text txt;

		// Token: 0x04000127 RID: 295
		public Image btnImg;

		// Token: 0x04000128 RID: 296
		public Image img;

		// Token: 0x04000129 RID: 297
		public GameObject gameobject;
	}
}
