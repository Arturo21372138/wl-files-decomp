﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200008B RID: 139
	[AddComponentMenu("Layout/Extensions/Radial Layout")]
	public class RadialLayout : LayoutGroup
	{
		// Token: 0x0600042E RID: 1070 RVA: 0x000193C2 File Offset: 0x000175C2
		protected override void OnEnable()
		{
			base.OnEnable();
			this.CalculateRadial();
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x000193D0 File Offset: 0x000175D0
		public override void SetLayoutHorizontal()
		{
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x000193D2 File Offset: 0x000175D2
		public override void SetLayoutVertical()
		{
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x000193D4 File Offset: 0x000175D4
		public override void CalculateLayoutInputVertical()
		{
			this.CalculateRadial();
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x000193DC File Offset: 0x000175DC
		public override void CalculateLayoutInputHorizontal()
		{
			this.CalculateRadial();
		}

		// Token: 0x06000433 RID: 1075 RVA: 0x000193E4 File Offset: 0x000175E4
		private void CalculateRadial()
		{
			this.m_Tracker.Clear();
			if (base.transform.childCount == 0)
			{
				return;
			}
			int num = 0;
			if (this.OnlyLayoutVisible)
			{
				for (int i = 0; i < base.transform.childCount; i++)
				{
					RectTransform rectTransform = (RectTransform)base.transform.GetChild(i);
					if (rectTransform != null && rectTransform.gameObject.activeSelf)
					{
						num++;
					}
				}
			}
			else
			{
				num = base.transform.childCount;
			}
			float num2 = (this.MaxAngle - this.MinAngle) / (float)num;
			float num3 = this.StartAngle;
			for (int j = 0; j < base.transform.childCount; j++)
			{
				RectTransform rectTransform2 = (RectTransform)base.transform.GetChild(j);
				if (rectTransform2 != null && (!this.OnlyLayoutVisible || rectTransform2.gameObject.activeSelf))
				{
					this.m_Tracker.Add(this, rectTransform2, DrivenTransformProperties.AnchoredPositionX | DrivenTransformProperties.AnchoredPositionY | DrivenTransformProperties.AnchorMinX | DrivenTransformProperties.AnchorMinY | DrivenTransformProperties.AnchorMaxX | DrivenTransformProperties.AnchorMaxY | DrivenTransformProperties.PivotX | DrivenTransformProperties.PivotY);
					Vector3 vector = new Vector3(Mathf.Cos(num3 * 0.017453292f), Mathf.Sin(num3 * 0.017453292f), 0f);
					rectTransform2.localPosition = vector * this.fDistance;
					RectTransform rectTransform3 = rectTransform2;
					RectTransform rectTransform4 = rectTransform2;
					RectTransform rectTransform5 = rectTransform2;
					Vector2 vector2 = new Vector2(0.5f, 0.5f);
					rectTransform5.pivot = vector2;
					rectTransform3.anchorMin = (rectTransform4.anchorMax = vector2);
					num3 += num2;
				}
			}
		}

		// Token: 0x04000314 RID: 788
		public float fDistance;

		// Token: 0x04000315 RID: 789
		[Range(0f, 360f)]
		public float MinAngle;

		// Token: 0x04000316 RID: 790
		[Range(0f, 360f)]
		public float MaxAngle;

		// Token: 0x04000317 RID: 791
		[Range(0f, 360f)]
		public float StartAngle;

		// Token: 0x04000318 RID: 792
		public bool OnlyLayoutVisible;
	}
}
