﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000049 RID: 73
	[RequireComponent(typeof(Selectable))]
	public class StepperSide : UIBehaviour, IPointerClickHandler, IEventSystemHandler, ISubmitHandler, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, ISelectHandler, IDeselectHandler
	{
		// Token: 0x1700005C RID: 92
		// (get) Token: 0x0600022C RID: 556 RVA: 0x0000C38C File Offset: 0x0000A58C
		private Selectable button
		{
			get
			{
				return base.GetComponent<Selectable>();
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600022D RID: 557 RVA: 0x0000C394 File Offset: 0x0000A594
		private Stepper stepper
		{
			get
			{
				return base.GetComponentInParent<Stepper>();
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600022E RID: 558 RVA: 0x0000C39C File Offset: 0x0000A59C
		private bool leftmost
		{
			get
			{
				return this.button == this.stepper.sides[0];
			}
		}

		// Token: 0x0600022F RID: 559 RVA: 0x0000C3B6 File Offset: 0x0000A5B6
		protected StepperSide()
		{
		}

		// Token: 0x06000230 RID: 560 RVA: 0x0000C3BE File Offset: 0x0000A5BE
		public virtual void OnPointerClick(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.Press();
			this.AdjustSprite(false);
		}

		// Token: 0x06000231 RID: 561 RVA: 0x0000C3D6 File Offset: 0x0000A5D6
		public virtual void OnSubmit(BaseEventData eventData)
		{
			this.Press();
			this.AdjustSprite(true);
		}

		// Token: 0x06000232 RID: 562 RVA: 0x0000C3E5 File Offset: 0x0000A5E5
		public virtual void OnPointerEnter(PointerEventData eventData)
		{
			this.AdjustSprite(false);
		}

		// Token: 0x06000233 RID: 563 RVA: 0x0000C3EE File Offset: 0x0000A5EE
		public virtual void OnPointerExit(PointerEventData eventData)
		{
			this.AdjustSprite(true);
		}

		// Token: 0x06000234 RID: 564 RVA: 0x0000C3F7 File Offset: 0x0000A5F7
		public virtual void OnPointerDown(PointerEventData eventData)
		{
			this.AdjustSprite(false);
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000C400 File Offset: 0x0000A600
		public virtual void OnPointerUp(PointerEventData eventData)
		{
			this.AdjustSprite(false);
		}

		// Token: 0x06000236 RID: 566 RVA: 0x0000C409 File Offset: 0x0000A609
		public virtual void OnSelect(BaseEventData eventData)
		{
			this.AdjustSprite(false);
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0000C412 File Offset: 0x0000A612
		public virtual void OnDeselect(BaseEventData eventData)
		{
			this.AdjustSprite(true);
		}

		// Token: 0x06000238 RID: 568 RVA: 0x0000C41B File Offset: 0x0000A61B
		private void Press()
		{
			if (!this.button.IsActive() || !this.button.IsInteractable())
			{
				return;
			}
			if (this.leftmost)
			{
				this.stepper.StepDown();
				return;
			}
			this.stepper.StepUp();
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000C458 File Offset: 0x0000A658
		private void AdjustSprite(bool restore)
		{
			Image image = this.button.image;
			if (!image || image.overrideSprite == this.cutSprite)
			{
				return;
			}
			if (restore)
			{
				image.overrideSprite = this.cutSprite;
				return;
			}
			image.overrideSprite = Stepper.CutSprite(image.overrideSprite, this.leftmost);
		}

		// Token: 0x040001C9 RID: 457
		internal Sprite cutSprite;
	}
}
