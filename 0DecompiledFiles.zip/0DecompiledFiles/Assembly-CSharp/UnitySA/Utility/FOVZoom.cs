﻿using System;
using System.Collections;
using UnityEngine;

namespace UnitySA.Utility
{
	// Token: 0x0200001E RID: 30
	[Serializable]
	public class FOVZoom
	{
		// Token: 0x06000059 RID: 89 RVA: 0x0000447F File Offset: 0x0000267F
		public void Setup(Camera camera)
		{
			this.CheckStatus(camera);
			this.Camera = camera;
			this.originalFov = camera.fieldOfView;
		}

		// Token: 0x0600005A RID: 90 RVA: 0x0000449B File Offset: 0x0000269B
		private void CheckStatus(Camera camera)
		{
			if (camera == null)
			{
				throw new Exception("FOVKick camera is null, please supply the camera to the constructor");
			}
			if (this.IncreaseCurve == null)
			{
				throw new Exception("FOVKick Increase curve is null, please define the curve for the field of view kicks");
			}
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000044C4 File Offset: 0x000026C4
		public void ChangeCamera(Camera camera)
		{
			this.Camera = camera;
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000044CD File Offset: 0x000026CD
		public IEnumerator FOVKickUp()
		{
			float t = Mathf.Abs((this.Camera.fieldOfView - this.originalFov) / this.FOVIncrease);
			while (t < this.TimeToIncrease)
			{
				this.Camera.fieldOfView = this.originalFov + this.IncreaseCurve.Evaluate(t / this.TimeToIncrease) * this.FOVIncrease;
				t += Time.deltaTime;
				yield return new WaitForEndOfFrame();
			}
			yield break;
		}

		// Token: 0x0600005D RID: 93 RVA: 0x000044DC File Offset: 0x000026DC
		public IEnumerator FOVKickDown()
		{
			float t = Mathf.Abs((this.Camera.fieldOfView - this.originalFov) / this.FOVIncrease);
			while (t > 0f)
			{
				this.Camera.fieldOfView = this.originalFov + this.IncreaseCurve.Evaluate(t / this.TimeToDecrease) * this.FOVIncrease;
				t -= Time.deltaTime;
				yield return new WaitForEndOfFrame();
			}
			this.Camera.fieldOfView = this.originalFov;
			yield break;
		}

		// Token: 0x04000081 RID: 129
		public Camera Camera;

		// Token: 0x04000082 RID: 130
		[HideInInspector]
		public float originalFov;

		// Token: 0x04000083 RID: 131
		public float FOVIncrease = 3f;

		// Token: 0x04000084 RID: 132
		public float TimeToIncrease = 1f;

		// Token: 0x04000085 RID: 133
		public float TimeToDecrease = 1f;

		// Token: 0x04000086 RID: 134
		public AnimationCurve IncreaseCurve;
	}
}
