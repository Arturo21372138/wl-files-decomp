﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200080C RID: 2060
	internal static class OnQueryPlayerAchievementsCompleteCallbackInternalImplementation
	{
		// Token: 0x1700086C RID: 2156
		// (get) Token: 0x060021DE RID: 8670 RVA: 0x0002849C File Offset: 0x0002669C
		public static OnQueryPlayerAchievementsCompleteCallbackInternal Delegate
		{
			get
			{
				if (OnQueryPlayerAchievementsCompleteCallbackInternalImplementation.s_Delegate == null)
				{
					OnQueryPlayerAchievementsCompleteCallbackInternalImplementation.s_Delegate = new OnQueryPlayerAchievementsCompleteCallbackInternal(OnQueryPlayerAchievementsCompleteCallbackInternalImplementation.EntryPoint);
				}
				return OnQueryPlayerAchievementsCompleteCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060021DF RID: 8671 RVA: 0x000284BC File Offset: 0x000266BC
		[MonoPInvokeCallback(typeof(OnQueryPlayerAchievementsCompleteCallbackInternal))]
		public static void EntryPoint(ref OnQueryPlayerAchievementsCompleteCallbackInfoInternal data)
		{
			OnQueryPlayerAchievementsCompleteCallback onQueryPlayerAchievementsCompleteCallback;
			OnQueryPlayerAchievementsCompleteCallbackInfo onQueryPlayerAchievementsCompleteCallbackInfo;
			if (Helper.TryGetAndRemoveCallback<OnQueryPlayerAchievementsCompleteCallbackInfoInternal, OnQueryPlayerAchievementsCompleteCallback, OnQueryPlayerAchievementsCompleteCallbackInfo>(ref data, out onQueryPlayerAchievementsCompleteCallback, out onQueryPlayerAchievementsCompleteCallbackInfo))
			{
				onQueryPlayerAchievementsCompleteCallback(ref onQueryPlayerAchievementsCompleteCallbackInfo);
			}
		}

		// Token: 0x04001699 RID: 5785
		private static OnQueryPlayerAchievementsCompleteCallbackInternal s_Delegate;
	}
}
