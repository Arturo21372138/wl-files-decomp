﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000068 RID: 104
	public class CardExpanding2D : MonoBehaviour
	{
		// Token: 0x06000316 RID: 790 RVA: 0x00013D48 File Offset: 0x00011F48
		private void Start()
		{
			this.rectTrans = base.GetComponent<RectTransform>();
			this.buttonRect.GetComponent<Image>().color = new Color32(228, 0, 0, 0);
			this.closeButtonMin = new Vector2(this.pageMin.x + this.pageSize.x - 64f, this.pageMin.y + this.pageSize.y - 64f);
			this.closeButtonMax = new Vector2(this.pageMax.x - 16f, this.pageMax.y - 16f);
			this.cardMin = new Vector2(this.cardCenter.x - this.cardSize.x * 0.5f, this.cardCenter.y - this.cardSize.y * 0.5f);
			this.cardMax = new Vector2(this.cardCenter.x + this.cardSize.x * 0.5f, this.cardCenter.y + this.cardSize.y * 0.5f);
			this.pageMin = new Vector2(this.pageCenter.x - this.pageSize.x * 0.5f, this.pageCenter.y - this.pageSize.y * 0.5f);
			this.pageMax = new Vector2(this.pageCenter.x + this.pageSize.x * 0.5f, this.pageCenter.y + this.pageSize.y * 0.5f);
		}

		// Token: 0x06000317 RID: 791 RVA: 0x00013F0C File Offset: 0x0001210C
		private void Update()
		{
			if (this.animationActive == 1)
			{
				this.rectTrans.offsetMin = Vector2.Lerp(this.rectTrans.offsetMin, this.pageMin, Time.deltaTime * this.lerpSpeed);
				this.rectTrans.offsetMax = Vector2.Lerp(this.rectTrans.offsetMax, this.pageMax, Time.deltaTime * this.lerpSpeed);
				if (this.rectTrans.offsetMin.x < this.pageMin.x * 0.995f && this.rectTrans.offsetMin.y < this.pageMin.y * 0.995f && this.rectTrans.offsetMax.x > this.pageMax.x * 0.995f && this.rectTrans.offsetMax.y > this.pageMax.y * 0.995f)
				{
					this.rectTrans.offsetMin = this.pageMin;
					this.rectTrans.offsetMax = this.pageMax;
					this.buttonRect.GetComponent<Image>().color = Color32.Lerp(this.buttonRect.GetComponent<Image>().color, new Color32(228, 0, 0, 191), Time.deltaTime * this.lerpSpeed);
					if (Mathf.Abs(this.buttonRect.GetComponent<Image>().color.a - 191f) < 2f)
					{
						this.buttonRect.GetComponent<Image>().color = new Color32(228, 0, 0, 191);
						this.animationActive = 0;
						CardStack2D.canUseHorizontalAxis = true;
						return;
					}
				}
			}
			else if (this.animationActive == -1)
			{
				this.buttonRect.GetComponent<Image>().color = Color32.Lerp(this.buttonRect.GetComponent<Image>().color, new Color32(228, 0, 0, 0), Time.deltaTime * this.lerpSpeed * 1.25f);
				this.rectTrans.offsetMin = Vector2.Lerp(this.rectTrans.offsetMin, this.cardMin, Time.deltaTime * this.lerpSpeed);
				this.rectTrans.offsetMax = Vector2.Lerp(this.rectTrans.offsetMax, this.cardMax, Time.deltaTime * this.lerpSpeed);
				if (this.rectTrans.offsetMin.x > this.cardMin.x * 1.005f && this.rectTrans.offsetMin.y > this.cardMin.y * 1.005f && this.rectTrans.offsetMax.x < this.cardMax.x * 1.005f && this.rectTrans.offsetMax.y < this.cardMax.y * 1.005f)
				{
					this.rectTrans.offsetMin = this.cardMin;
					this.rectTrans.offsetMax = this.cardMax;
					this.buttonRect.offsetMin = Vector2.zero;
					this.buttonRect.offsetMax = Vector2.zero;
					this.animationActive = 0;
					CardStack2D.canUseHorizontalAxis = true;
				}
			}
		}

		// Token: 0x06000318 RID: 792 RVA: 0x00014278 File Offset: 0x00012478
		public void ToggleCard()
		{
			CardStack2D.canUseHorizontalAxis = false;
			if (this.animationActive != 1)
			{
				this.animationActive = 1;
				this.cardCenter = base.transform.localPosition;
				this.buttonRect.offsetMin = this.closeButtonMin;
				this.buttonRect.offsetMax = this.closeButtonMax;
				return;
			}
			if (this.animationActive != -1)
			{
				this.animationActive = -1;
			}
		}

		// Token: 0x04000269 RID: 617
		[SerializeField]
		private float lerpSpeed = 8f;

		// Token: 0x0400026A RID: 618
		[SerializeField]
		private RectTransform buttonRect;

		// Token: 0x0400026B RID: 619
		private Vector2 closeButtonMin = Vector2.zero;

		// Token: 0x0400026C RID: 620
		private Vector2 closeButtonMax = Vector2.zero;

		// Token: 0x0400026D RID: 621
		[SerializeField]
		private Vector2 cardSize = Vector2.zero;

		// Token: 0x0400026E RID: 622
		[SerializeField]
		private Vector2 pageSize = Vector2.zero;

		// Token: 0x0400026F RID: 623
		private Vector2 cardCenter = Vector2.zero;

		// Token: 0x04000270 RID: 624
		private Vector2 pageCenter = Vector2.zero;

		// Token: 0x04000271 RID: 625
		private Vector2 cardMin = Vector2.zero;

		// Token: 0x04000272 RID: 626
		private Vector2 cardMax = Vector2.zero;

		// Token: 0x04000273 RID: 627
		private Vector2 pageMin = Vector2.zero;

		// Token: 0x04000274 RID: 628
		private Vector2 pageMax = Vector2.zero;

		// Token: 0x04000275 RID: 629
		private RectTransform rectTrans;

		// Token: 0x04000276 RID: 630
		private int animationActive = -1;
	}
}
