﻿using System;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C4 RID: 196
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("UI/Extensions/UIScrollToSelection")]
	public class UIScrollToSelection : MonoBehaviour
	{
		// Token: 0x17000117 RID: 279
		// (get) Token: 0x0600065C RID: 1628 RVA: 0x00025075 File Offset: 0x00023275
		protected RectTransform LayoutListGroup
		{
			get
			{
				if (!(this.TargetScrollRect != null))
				{
					return null;
				}
				return this.TargetScrollRect.content;
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x0600065D RID: 1629 RVA: 0x00025092 File Offset: 0x00023292
		protected UIScrollToSelection.ScrollType ScrollDirection
		{
			get
			{
				return this.scrollDirection;
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x0600065E RID: 1630 RVA: 0x0002509A File Offset: 0x0002329A
		protected float ScrollSpeed
		{
			get
			{
				return this.scrollSpeed;
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x0600065F RID: 1631 RVA: 0x000250A2 File Offset: 0x000232A2
		protected bool CancelScrollOnInput
		{
			get
			{
				return this.cancelScrollOnInput;
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000660 RID: 1632 RVA: 0x000250AA File Offset: 0x000232AA
		protected List<KeyCode> CancelScrollKeycodes
		{
			get
			{
				return this.cancelScrollKeycodes;
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000661 RID: 1633 RVA: 0x000250B2 File Offset: 0x000232B2
		// (set) Token: 0x06000662 RID: 1634 RVA: 0x000250BA File Offset: 0x000232BA
		protected RectTransform ScrollWindow { get; set; }

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000663 RID: 1635 RVA: 0x000250C3 File Offset: 0x000232C3
		// (set) Token: 0x06000664 RID: 1636 RVA: 0x000250CB File Offset: 0x000232CB
		protected ScrollRect TargetScrollRect { get; set; }

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x06000665 RID: 1637 RVA: 0x000250D4 File Offset: 0x000232D4
		protected EventSystem CurrentEventSystem
		{
			get
			{
				return EventSystem.current;
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000666 RID: 1638 RVA: 0x000250DB File Offset: 0x000232DB
		// (set) Token: 0x06000667 RID: 1639 RVA: 0x000250E3 File Offset: 0x000232E3
		protected GameObject LastCheckedGameObject { get; set; }

		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000668 RID: 1640 RVA: 0x000250EC File Offset: 0x000232EC
		protected GameObject CurrentSelectedGameObject
		{
			get
			{
				return EventSystem.current.currentSelectedGameObject;
			}
		}

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000669 RID: 1641 RVA: 0x000250F8 File Offset: 0x000232F8
		// (set) Token: 0x0600066A RID: 1642 RVA: 0x00025100 File Offset: 0x00023300
		protected RectTransform CurrentTargetRectTransform { get; set; }

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x0600066B RID: 1643 RVA: 0x00025109 File Offset: 0x00023309
		// (set) Token: 0x0600066C RID: 1644 RVA: 0x00025111 File Offset: 0x00023311
		protected bool IsManualScrollingAvailable { get; set; }

		// Token: 0x0600066D RID: 1645 RVA: 0x0002511A File Offset: 0x0002331A
		protected virtual void Awake()
		{
			this.TargetScrollRect = base.GetComponent<ScrollRect>();
			this.ScrollWindow = this.TargetScrollRect.GetComponent<RectTransform>();
		}

		// Token: 0x0600066E RID: 1646 RVA: 0x00025139 File Offset: 0x00023339
		protected virtual void Start()
		{
		}

		// Token: 0x0600066F RID: 1647 RVA: 0x0002513B File Offset: 0x0002333B
		protected virtual void Update()
		{
			this.UpdateReferences();
			this.CheckIfScrollingShouldBeLocked();
			this.ScrollRectToLevelSelection();
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x00025150 File Offset: 0x00023350
		private void UpdateReferences()
		{
			if (this.CurrentSelectedGameObject != this.LastCheckedGameObject)
			{
				this.CurrentTargetRectTransform = ((this.CurrentSelectedGameObject != null) ? this.CurrentSelectedGameObject.GetComponent<RectTransform>() : null);
				if (this.CurrentSelectedGameObject != null && this.CurrentSelectedGameObject.transform.parent == this.LayoutListGroup.transform)
				{
					this.IsManualScrollingAvailable = false;
				}
			}
			this.LastCheckedGameObject = this.CurrentSelectedGameObject;
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x000251D8 File Offset: 0x000233D8
		private void CheckIfScrollingShouldBeLocked()
		{
			if (!this.CancelScrollOnInput || this.IsManualScrollingAvailable)
			{
				return;
			}
			for (int i = 0; i < this.CancelScrollKeycodes.Count; i++)
			{
				if (UIExtensionsInputManager.GetKeyDown(this.CancelScrollKeycodes[i]))
				{
					this.IsManualScrollingAvailable = true;
					return;
				}
			}
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x00025228 File Offset: 0x00023428
		private void ScrollRectToLevelSelection()
		{
			if (this.TargetScrollRect == null || this.LayoutListGroup == null || this.ScrollWindow == null || this.IsManualScrollingAvailable)
			{
				return;
			}
			RectTransform currentTargetRectTransform = this.CurrentTargetRectTransform;
			if (currentTargetRectTransform == null || currentTargetRectTransform.transform.parent != this.LayoutListGroup.transform)
			{
				return;
			}
			switch (this.ScrollDirection)
			{
			case UIScrollToSelection.ScrollType.VERTICAL:
				this.UpdateVerticalScrollPosition(currentTargetRectTransform);
				return;
			case UIScrollToSelection.ScrollType.HORIZONTAL:
				this.UpdateHorizontalScrollPosition(currentTargetRectTransform);
				return;
			case UIScrollToSelection.ScrollType.BOTH:
				this.UpdateVerticalScrollPosition(currentTargetRectTransform);
				this.UpdateHorizontalScrollPosition(currentTargetRectTransform);
				return;
			default:
				return;
			}
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x000252D4 File Offset: 0x000234D4
		private void UpdateVerticalScrollPosition(RectTransform selection)
		{
			float num = -selection.anchoredPosition.y - selection.rect.height * (1f - selection.pivot.y);
			float height = selection.rect.height;
			float height2 = this.ScrollWindow.rect.height;
			float y = this.LayoutListGroup.anchoredPosition.y;
			float scrollOffset = this.GetScrollOffset(num, y, height, height2);
			this.TargetScrollRect.verticalNormalizedPosition += scrollOffset / this.LayoutListGroup.rect.height * Time.unscaledDeltaTime * this.scrollSpeed;
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x00025388 File Offset: 0x00023588
		private void UpdateHorizontalScrollPosition(RectTransform selection)
		{
			float num = -selection.anchoredPosition.x - selection.rect.width * (1f - selection.pivot.x);
			float width = selection.rect.width;
			float width2 = this.ScrollWindow.rect.width;
			float num2 = -this.LayoutListGroup.anchoredPosition.x;
			float num3 = -this.GetScrollOffset(num, num2, width, width2);
			this.TargetScrollRect.horizontalNormalizedPosition += num3 / this.LayoutListGroup.rect.width * Time.unscaledDeltaTime * this.scrollSpeed;
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x0002543E File Offset: 0x0002363E
		private float GetScrollOffset(float position, float listAnchorPosition, float targetLength, float maskLength)
		{
			if (position < listAnchorPosition + targetLength / 2f)
			{
				return listAnchorPosition + maskLength - (position - targetLength);
			}
			if (position + targetLength > listAnchorPosition + maskLength)
			{
				return listAnchorPosition + maskLength - (position + targetLength);
			}
			return 0f;
		}

		// Token: 0x04000499 RID: 1177
		[Header("[ Settings ]")]
		[SerializeField]
		private UIScrollToSelection.ScrollType scrollDirection = UIScrollToSelection.ScrollType.BOTH;

		// Token: 0x0400049A RID: 1178
		[SerializeField]
		private float scrollSpeed = 10f;

		// Token: 0x0400049B RID: 1179
		[Header("[ Input ]")]
		[SerializeField]
		private bool cancelScrollOnInput;

		// Token: 0x0400049C RID: 1180
		[SerializeField]
		private List<KeyCode> cancelScrollKeycodes = new List<KeyCode>();

		// Token: 0x02000155 RID: 341
		public enum ScrollType
		{
			// Token: 0x040006CF RID: 1743
			VERTICAL,
			// Token: 0x040006D0 RID: 1744
			HORIZONTAL,
			// Token: 0x040006D1 RID: 1745
			BOTH
		}
	}
}
