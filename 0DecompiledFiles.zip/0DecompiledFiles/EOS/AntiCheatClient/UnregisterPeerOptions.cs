﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007DA RID: 2010
	public struct UnregisterPeerOptions
	{
		// Token: 0x17000837 RID: 2103
		// (get) Token: 0x0600211D RID: 8477 RVA: 0x00027596 File Offset: 0x00025796
		// (set) Token: 0x0600211E RID: 8478 RVA: 0x0002759E File Offset: 0x0002579E
		public IntPtr PeerHandle { readonly get; set; }
	}
}
