﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000811 RID: 2065
	internal static class OnUnlockAchievementsCompleteCallbackInternalImplementation
	{
		// Token: 0x17000872 RID: 2162
		// (get) Token: 0x060021F4 RID: 8692 RVA: 0x0002859C File Offset: 0x0002679C
		public static OnUnlockAchievementsCompleteCallbackInternal Delegate
		{
			get
			{
				if (OnUnlockAchievementsCompleteCallbackInternalImplementation.s_Delegate == null)
				{
					OnUnlockAchievementsCompleteCallbackInternalImplementation.s_Delegate = new OnUnlockAchievementsCompleteCallbackInternal(OnUnlockAchievementsCompleteCallbackInternalImplementation.EntryPoint);
				}
				return OnUnlockAchievementsCompleteCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060021F5 RID: 8693 RVA: 0x000285BC File Offset: 0x000267BC
		[MonoPInvokeCallback(typeof(OnUnlockAchievementsCompleteCallbackInternal))]
		public static void EntryPoint(ref OnUnlockAchievementsCompleteCallbackInfoInternal data)
		{
			OnUnlockAchievementsCompleteCallback onUnlockAchievementsCompleteCallback;
			OnUnlockAchievementsCompleteCallbackInfo onUnlockAchievementsCompleteCallbackInfo;
			if (Helper.TryGetAndRemoveCallback<OnUnlockAchievementsCompleteCallbackInfoInternal, OnUnlockAchievementsCompleteCallback, OnUnlockAchievementsCompleteCallbackInfo>(ref data, out onUnlockAchievementsCompleteCallback, out onUnlockAchievementsCompleteCallbackInfo))
			{
				onUnlockAchievementsCompleteCallback(ref onUnlockAchievementsCompleteCallbackInfo);
			}
		}

		// Token: 0x040016A2 RID: 5794
		private static OnUnlockAchievementsCompleteCallbackInternal s_Delegate;
	}
}
