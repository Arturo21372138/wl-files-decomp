﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B4 RID: 180
	[AddComponentMenu("UI/Extensions/Pagination Manager")]
	public class PaginationManager : ToggleGroup
	{
		// Token: 0x17000111 RID: 273
		// (get) Token: 0x060005FC RID: 1532 RVA: 0x00023DCD File Offset: 0x00021FCD
		public int CurrentPage
		{
			get
			{
				return this.scrollSnap.CurrentPage;
			}
		}

		// Token: 0x060005FD RID: 1533 RVA: 0x00023DDA File Offset: 0x00021FDA
		protected PaginationManager()
		{
		}

		// Token: 0x060005FE RID: 1534 RVA: 0x00023DE4 File Offset: 0x00021FE4
		protected override void Start()
		{
			base.Start();
			if (this.scrollSnap == null)
			{
				Debug.LogError("A ScrollSnap script must be attached");
				return;
			}
			if (this.scrollSnap.Pagination)
			{
				this.scrollSnap.Pagination = null;
			}
			this.scrollSnap.OnSelectionPageChangedEvent.AddListener(new UnityAction<int>(this.SetToggleGraphics));
			this.scrollSnap.OnSelectionChangeEndEvent.AddListener(new UnityAction<int>(this.OnPageChangeEnd));
			this.ResetPaginationChildren();
		}

		// Token: 0x060005FF RID: 1535 RVA: 0x00023E6C File Offset: 0x0002206C
		public void ResetPaginationChildren()
		{
			this.m_PaginationChildren = base.GetComponentsInChildren<Toggle>().ToList<Toggle>();
			for (int i = 0; i < this.m_PaginationChildren.Count; i++)
			{
				this.m_PaginationChildren[i].onValueChanged.AddListener(new UnityAction<bool>(this.ToggleClick));
				this.m_PaginationChildren[i].group = this;
				this.m_PaginationChildren[i].isOn = false;
			}
			this.SetToggleGraphics(this.CurrentPage);
			if (this.m_PaginationChildren.Count != this.scrollSnap._scroll_rect.content.childCount)
			{
				Debug.LogWarning("Uneven pagination icon to page count");
			}
		}

		// Token: 0x06000600 RID: 1536 RVA: 0x00023F1E File Offset: 0x0002211E
		public void GoToScreen(int pageNo)
		{
			this.scrollSnap.GoToScreen(pageNo);
		}

		// Token: 0x06000601 RID: 1537 RVA: 0x00023F2C File Offset: 0x0002212C
		private void ToggleClick(Toggle target)
		{
			if (!target.isOn)
			{
				this.isAClick = true;
				this.GoToScreen(this.m_PaginationChildren.IndexOf(target));
			}
		}

		// Token: 0x06000602 RID: 1538 RVA: 0x00023F50 File Offset: 0x00022150
		private void ToggleClick(bool toggle)
		{
			if (toggle)
			{
				for (int i = 0; i < this.m_PaginationChildren.Count; i++)
				{
					if (this.m_PaginationChildren[i].isOn && !this.scrollSnap._suspendEvents)
					{
						this.GoToScreen(i);
						return;
					}
				}
			}
		}

		// Token: 0x06000603 RID: 1539 RVA: 0x00023F9E File Offset: 0x0002219E
		private void ToggleClick(int target)
		{
			this.isAClick = true;
			this.GoToScreen(target);
		}

		// Token: 0x06000604 RID: 1540 RVA: 0x00023FAE File Offset: 0x000221AE
		private void SetToggleGraphics(int pageNo)
		{
			if (!this.isAClick)
			{
				this.m_PaginationChildren[pageNo].isOn = true;
			}
		}

		// Token: 0x06000605 RID: 1541 RVA: 0x00023FCA File Offset: 0x000221CA
		private void OnPageChangeEnd(int pageNo)
		{
			this.isAClick = false;
		}

		// Token: 0x0400046C RID: 1132
		private List<Toggle> m_PaginationChildren;

		// Token: 0x0400046D RID: 1133
		[SerializeField]
		private ScrollSnapBase scrollSnap;

		// Token: 0x0400046E RID: 1134
		private bool isAClick;
	}
}
