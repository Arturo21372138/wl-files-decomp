﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000EB RID: 235
	[Flags]
	public enum OverrideMask
	{
		// Token: 0x040005BC RID: 1468
		OutputToggle = 1,
		// Token: 0x040005BD RID: 1469
		NameSuffix = 2,
		// Token: 0x040005BE RID: 1470
		RelativeScale = 4,
		// Token: 0x040005BF RID: 1471
		ColorSpace = 8,
		// Token: 0x040005C0 RID: 1472
		QualityCompression = 16,
		// Token: 0x040005C1 RID: 1473
		FileFormat = 32
	}
}
