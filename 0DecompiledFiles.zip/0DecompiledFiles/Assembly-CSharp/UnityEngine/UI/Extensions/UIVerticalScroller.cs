﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000092 RID: 146
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("Layout/Extensions/Vertical Scroller")]
	public class UIVerticalScroller : MonoBehaviour
	{
		// Token: 0x170000CB RID: 203
		// (get) Token: 0x060004AD RID: 1197 RVA: 0x0001BEC9 File Offset: 0x0001A0C9
		// (set) Token: 0x060004AE RID: 1198 RVA: 0x0001BED1 File Offset: 0x0001A0D1
		public int focusedElementIndex { get; private set; }

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x060004AF RID: 1199 RVA: 0x0001BEDA File Offset: 0x0001A0DA
		// (set) Token: 0x060004B0 RID: 1200 RVA: 0x0001BEE2 File Offset: 0x0001A0E2
		public string result { get; private set; }

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x060004B1 RID: 1201 RVA: 0x0001BEEB File Offset: 0x0001A0EB
		[HideInInspector]
		public RectTransform scrollingPanel
		{
			get
			{
				return this.scrollRect.content;
			}
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x0001BEF8 File Offset: 0x0001A0F8
		public UIVerticalScroller()
		{
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x0001BF4C File Offset: 0x0001A14C
		public UIVerticalScroller(RectTransform center, RectTransform elementSize, ScrollRect scrollRect, GameObject[] arrayOfElements)
		{
			this.center = center;
			this.elementSize = elementSize;
			this.scrollRect = scrollRect;
			this._arrayOfElements = arrayOfElements;
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x0001BFBC File Offset: 0x0001A1BC
		public void Awake()
		{
			if (!this.scrollRect)
			{
				this.scrollRect = base.GetComponent<ScrollRect>();
			}
			if (!this.center)
			{
				Debug.LogError("Please define the RectTransform for the Center viewport of the scrollable area");
			}
			if (!this.elementSize)
			{
				this.elementSize = this.center;
			}
			if (this._arrayOfElements == null || this._arrayOfElements.Length == 0)
			{
				this._arrayOfElements = new GameObject[this.scrollingPanel.childCount];
				for (int i = 0; i < this.scrollingPanel.childCount; i++)
				{
					this._arrayOfElements[i] = this.scrollingPanel.GetChild(i).gameObject;
				}
			}
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0001C068 File Offset: 0x0001A268
		public void updateChildren(int startingIndex = -1, GameObject[] arrayOfElements = null)
		{
			if (arrayOfElements != null)
			{
				this._arrayOfElements = arrayOfElements;
			}
			else
			{
				this._arrayOfElements = new GameObject[this.scrollingPanel.childCount];
				for (int i = 0; i < this.scrollingPanel.childCount; i++)
				{
					this._arrayOfElements[i] = this.scrollingPanel.GetChild(i).gameObject;
				}
			}
			for (int k = 0; k < this._arrayOfElements.Length; k++)
			{
				int j = k;
				this._arrayOfElements[k].GetComponent<Button>().onClick.RemoveAllListeners();
				if (this.OnButtonClicked != null)
				{
					this._arrayOfElements[k].GetComponent<Button>().onClick.AddListener(delegate
					{
						this.OnButtonClicked.Invoke(j);
					});
				}
				RectTransform component = this._arrayOfElements[k].GetComponent<RectTransform>();
				Vector2 vector = new Vector2(0.5f, 0.5f);
				component.pivot = vector;
				component.anchorMax = (component.anchorMin = vector);
				component.localPosition = new Vector2(0f, (float)k * this.elementSize.rect.size.y);
				component.sizeDelta = this.elementSize.rect.size;
			}
			this.distance = new float[this._arrayOfElements.Length];
			this.distReposition = new float[this._arrayOfElements.Length];
			this.focusedElementIndex = -1;
			if (startingIndex > -1)
			{
				startingIndex = ((startingIndex > this._arrayOfElements.Length) ? (this._arrayOfElements.Length - 1) : startingIndex);
				this.SnapToElement(startingIndex);
			}
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0001C208 File Offset: 0x0001A408
		public void Start()
		{
			if (this.scrollUpButton)
			{
				this.scrollUpButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.ScrollUp();
				});
			}
			if (this.scrollDownButton)
			{
				this.scrollDownButton.GetComponent<Button>().onClick.AddListener(delegate
				{
					this.ScrollDown();
				});
			}
			this.updateChildren(this.startingIndex, this._arrayOfElements);
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x0001C284 File Offset: 0x0001A484
		public void Update()
		{
			if (this._arrayOfElements.Length < 1)
			{
				return;
			}
			for (int i = 0; i < this._arrayOfElements.Length; i++)
			{
				this.distReposition[i] = this.center.GetComponent<RectTransform>().position.y - this._arrayOfElements[i].GetComponent<RectTransform>().position.y;
				this.distance[i] = Mathf.Abs(this.distReposition[i]);
				Vector2 vector = Vector2.Max(this.minScale, new Vector2(1f / (1f + this.distance[i] * this.elementShrinkage.x), 1f / (1f + this.distance[i] * this.elementShrinkage.y)));
				this._arrayOfElements[i].GetComponent<RectTransform>().transform.localScale = new Vector3(vector.x, vector.y, 1f);
			}
			float num = Mathf.Min(this.distance);
			int focusedElementIndex = this.focusedElementIndex;
			for (int j = 0; j < this._arrayOfElements.Length; j++)
			{
				this._arrayOfElements[j].GetComponent<CanvasGroup>().interactable = !this.disableUnfocused || num == this.distance[j];
				if (num == this.distance[j])
				{
					this.focusedElementIndex = j;
					this.result = this._arrayOfElements[j].GetComponentInChildren<Text>().text;
				}
			}
			if (this.focusedElementIndex != focusedElementIndex && this.OnFocusChanged != null)
			{
				this.OnFocusChanged.Invoke(this.focusedElementIndex);
			}
			if (!UIExtensionsInputManager.GetMouseButton(0))
			{
				this.ScrollingElements();
			}
			if (this.stopMomentumOnEnd && (this._arrayOfElements[0].GetComponent<RectTransform>().position.y > this.center.position.y || this._arrayOfElements[this._arrayOfElements.Length - 1].GetComponent<RectTransform>().position.y < this.center.position.y))
			{
				this.scrollRect.velocity = Vector2.zero;
			}
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x0001C4A4 File Offset: 0x0001A6A4
		private void ScrollingElements()
		{
			float num = Mathf.Lerp(this.scrollingPanel.anchoredPosition.y, this.scrollingPanel.anchoredPosition.y + this.distReposition[this.focusedElementIndex], Time.deltaTime * 2f);
			Vector2 vector = new Vector2(this.scrollingPanel.anchoredPosition.x, num);
			this.scrollingPanel.anchoredPosition = vector;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x0001C514 File Offset: 0x0001A714
		public void SnapToElement(int element)
		{
			float num = this.elementSize.rect.height * (float)element;
			Vector2 vector = new Vector2(this.scrollingPanel.anchoredPosition.x, -num);
			this.scrollingPanel.anchoredPosition = vector;
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x0001C560 File Offset: 0x0001A760
		public void ScrollUp()
		{
			float num = this.elementSize.rect.height / 1.2f;
			Vector2 vector = new Vector2(this.scrollingPanel.anchoredPosition.x, this.scrollingPanel.anchoredPosition.y - num);
			this.scrollingPanel.anchoredPosition = Vector2.Lerp(this.scrollingPanel.anchoredPosition, vector, 1f);
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x0001C5D4 File Offset: 0x0001A7D4
		public void ScrollDown()
		{
			float num = this.elementSize.rect.height / 1.2f;
			Vector2 vector = new Vector2(this.scrollingPanel.anchoredPosition.x, this.scrollingPanel.anchoredPosition.y + num);
			this.scrollingPanel.anchoredPosition = vector;
		}

		// Token: 0x04000387 RID: 903
		[Tooltip("desired ScrollRect")]
		public ScrollRect scrollRect;

		// Token: 0x04000388 RID: 904
		[Tooltip("Center display area (position of zoomed content)")]
		public RectTransform center;

		// Token: 0x04000389 RID: 905
		[Tooltip("Size / spacing of elements")]
		public RectTransform elementSize;

		// Token: 0x0400038A RID: 906
		[Tooltip("Scale = 1/ (1+distance from center * shrinkage)")]
		public Vector2 elementShrinkage = new Vector2(0.005f, 0.005f);

		// Token: 0x0400038B RID: 907
		[Tooltip("Minimum element scale (furthest from center)")]
		public Vector2 minScale = new Vector2(0.7f, 0.7f);

		// Token: 0x0400038C RID: 908
		[Tooltip("Select the item to be in center on start.")]
		public int startingIndex = -1;

		// Token: 0x0400038D RID: 909
		[Tooltip("Stop scrolling past last element from inertia.")]
		public bool stopMomentumOnEnd = true;

		// Token: 0x0400038E RID: 910
		[Tooltip("Set Items out of center to not interactible.")]
		public bool disableUnfocused = true;

		// Token: 0x0400038F RID: 911
		[Tooltip("Button to go to the next page. (optional)")]
		public GameObject scrollUpButton;

		// Token: 0x04000390 RID: 912
		[Tooltip("Button to go to the previous page. (optional)")]
		public GameObject scrollDownButton;

		// Token: 0x04000391 RID: 913
		[Tooltip("Event fired when a specific item is clicked, exposes index number of item. (optional)")]
		public UIVerticalScroller.IntEvent OnButtonClicked;

		// Token: 0x04000392 RID: 914
		[Tooltip("Event fired when the focused item is Changed. (optional)")]
		public UIVerticalScroller.IntEvent OnFocusChanged;

		// Token: 0x04000393 RID: 915
		[HideInInspector]
		public GameObject[] _arrayOfElements;

		// Token: 0x04000396 RID: 918
		private float[] distReposition;

		// Token: 0x04000397 RID: 919
		private float[] distance;

		// Token: 0x0200013F RID: 319
		[Serializable]
		public class IntEvent : UnityEvent<int>
		{
		}
	}
}
