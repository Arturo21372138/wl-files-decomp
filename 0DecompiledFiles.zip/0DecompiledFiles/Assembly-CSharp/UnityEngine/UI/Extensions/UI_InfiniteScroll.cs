﻿using System;
using System.Collections.Generic;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C7 RID: 199
	[AddComponentMenu("UI/Extensions/UI Infinite Scroll")]
	public class UI_InfiniteScroll : MonoBehaviour
	{
		// Token: 0x06000684 RID: 1668 RVA: 0x00025715 File Offset: 0x00023915
		protected virtual void Awake()
		{
			if (!this.InitByUser)
			{
				this.Init();
			}
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x00025728 File Offset: 0x00023928
		public virtual void SetNewItems(ref List<Transform> newItems)
		{
			if (this._scrollRect != null)
			{
				if (this._scrollRect.content == null && newItems == null)
				{
					return;
				}
				if (this.items != null)
				{
					this.items.Clear();
				}
				for (int i = this._scrollRect.content.childCount - 1; i >= 0; i--)
				{
					Transform child = this._scrollRect.content.GetChild(i);
					child.SetParent(null);
					Object.DestroyImmediate(child.gameObject);
				}
				foreach (Transform transform in newItems)
				{
					transform.SetParent(this._scrollRect.content);
				}
				this.SetItems();
			}
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x00025800 File Offset: 0x00023A00
		private void SetItems()
		{
			for (int i = 0; i < this._scrollRect.content.childCount; i++)
			{
				this.items.Add(this._scrollRect.content.GetChild(i).GetComponent<RectTransform>());
			}
			this._itemCount = this._scrollRect.content.childCount;
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x00025860 File Offset: 0x00023A60
		public void Init()
		{
			if (base.GetComponent<ScrollRect>() != null)
			{
				this._scrollRect = base.GetComponent<ScrollRect>();
				this._scrollRect.onValueChanged.AddListener(new UnityAction<Vector2>(this.OnScroll));
				this._scrollRect.movementType = ScrollRect.MovementType.Unrestricted;
				if (this._scrollRect.content.GetComponent<VerticalLayoutGroup>() != null)
				{
					this._verticalLayoutGroup = this._scrollRect.content.GetComponent<VerticalLayoutGroup>();
				}
				if (this._scrollRect.content.GetComponent<HorizontalLayoutGroup>() != null)
				{
					this._horizontalLayoutGroup = this._scrollRect.content.GetComponent<HorizontalLayoutGroup>();
				}
				if (this._scrollRect.content.GetComponent<GridLayoutGroup>() != null)
				{
					this._gridLayoutGroup = this._scrollRect.content.GetComponent<GridLayoutGroup>();
				}
				if (this._scrollRect.content.GetComponent<ContentSizeFitter>() != null)
				{
					this._contentSizeFitter = this._scrollRect.content.GetComponent<ContentSizeFitter>();
				}
				this._isHorizontal = this._scrollRect.horizontal;
				this._isVertical = this._scrollRect.vertical;
				if (this._isHorizontal && this._isVertical)
				{
					Debug.LogError("UI_InfiniteScroll doesn't support scrolling in both directions, please choose one direction (horizontal or vertical)");
				}
				this.SetItems();
				return;
			}
			Debug.LogError("UI_InfiniteScroll => No ScrollRect component found");
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x000259B8 File Offset: 0x00023BB8
		private void DisableGridComponents()
		{
			if (this._isVertical)
			{
				this._recordOffsetY = this.items[1].GetComponent<RectTransform>().anchoredPosition.y - this.items[0].GetComponent<RectTransform>().anchoredPosition.y;
				if (this._recordOffsetY < 0f)
				{
					this._recordOffsetY *= -1f;
				}
				this._disableMarginY = this._recordOffsetY * (float)this._itemCount / 2f;
			}
			if (this._isHorizontal)
			{
				this._recordOffsetX = this.items[1].GetComponent<RectTransform>().anchoredPosition.x - this.items[0].GetComponent<RectTransform>().anchoredPosition.x;
				if (this._recordOffsetX < 0f)
				{
					this._recordOffsetX *= -1f;
				}
				this._disableMarginX = this._recordOffsetX * (float)this._itemCount / 2f;
			}
			if (this._verticalLayoutGroup)
			{
				this._verticalLayoutGroup.enabled = false;
			}
			if (this._horizontalLayoutGroup)
			{
				this._horizontalLayoutGroup.enabled = false;
			}
			if (this._contentSizeFitter)
			{
				this._contentSizeFitter.enabled = false;
			}
			if (this._gridLayoutGroup)
			{
				this._gridLayoutGroup.enabled = false;
			}
			this._hasDisabledGridComponents = true;
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x00025B2C File Offset: 0x00023D2C
		public void OnScroll(Vector2 pos)
		{
			if (!this._hasDisabledGridComponents)
			{
				this.DisableGridComponents();
			}
			for (int i = 0; i < this.items.Count; i++)
			{
				if (this._isHorizontal)
				{
					if (this._scrollRect.transform.InverseTransformPoint(this.items[i].gameObject.transform.position).x > this._disableMarginX + this._threshold)
					{
						this._newAnchoredPosition = this.items[i].anchoredPosition;
						this._newAnchoredPosition.x = this._newAnchoredPosition.x - (float)this._itemCount * this._recordOffsetX;
						this.items[i].anchoredPosition = this._newAnchoredPosition;
						this._scrollRect.content.GetChild(this._itemCount - 1).transform.SetAsFirstSibling();
					}
					else if (this._scrollRect.transform.InverseTransformPoint(this.items[i].gameObject.transform.position).x < -this._disableMarginX)
					{
						this._newAnchoredPosition = this.items[i].anchoredPosition;
						this._newAnchoredPosition.x = this._newAnchoredPosition.x + (float)this._itemCount * this._recordOffsetX;
						this.items[i].anchoredPosition = this._newAnchoredPosition;
						this._scrollRect.content.GetChild(0).transform.SetAsLastSibling();
					}
				}
				if (this._isVertical)
				{
					if (this._scrollRect.transform.InverseTransformPoint(this.items[i].gameObject.transform.position).y > this._disableMarginY + this._threshold)
					{
						this._newAnchoredPosition = this.items[i].anchoredPosition;
						this._newAnchoredPosition.y = this._newAnchoredPosition.y - (float)this._itemCount * this._recordOffsetY;
						this.items[i].anchoredPosition = this._newAnchoredPosition;
						this._scrollRect.content.GetChild(this._itemCount - 1).transform.SetAsFirstSibling();
					}
					else if (this._scrollRect.transform.InverseTransformPoint(this.items[i].gameObject.transform.position).y < -this._disableMarginY)
					{
						this._newAnchoredPosition = this.items[i].anchoredPosition;
						this._newAnchoredPosition.y = this._newAnchoredPosition.y + (float)this._itemCount * this._recordOffsetY;
						this.items[i].anchoredPosition = this._newAnchoredPosition;
						this._scrollRect.content.GetChild(0).transform.SetAsLastSibling();
					}
				}
			}
		}

		// Token: 0x040004AD RID: 1197
		[Tooltip("If false, will Init automatically, otherwise you need to call Init() method")]
		public bool InitByUser;

		// Token: 0x040004AE RID: 1198
		protected ScrollRect _scrollRect;

		// Token: 0x040004AF RID: 1199
		private ContentSizeFitter _contentSizeFitter;

		// Token: 0x040004B0 RID: 1200
		private VerticalLayoutGroup _verticalLayoutGroup;

		// Token: 0x040004B1 RID: 1201
		private HorizontalLayoutGroup _horizontalLayoutGroup;

		// Token: 0x040004B2 RID: 1202
		private GridLayoutGroup _gridLayoutGroup;

		// Token: 0x040004B3 RID: 1203
		protected bool _isVertical;

		// Token: 0x040004B4 RID: 1204
		protected bool _isHorizontal;

		// Token: 0x040004B5 RID: 1205
		private float _disableMarginX;

		// Token: 0x040004B6 RID: 1206
		private float _disableMarginY;

		// Token: 0x040004B7 RID: 1207
		private bool _hasDisabledGridComponents;

		// Token: 0x040004B8 RID: 1208
		protected List<RectTransform> items = new List<RectTransform>();

		// Token: 0x040004B9 RID: 1209
		private Vector2 _newAnchoredPosition = Vector2.zero;

		// Token: 0x040004BA RID: 1210
		private float _threshold = 100f;

		// Token: 0x040004BB RID: 1211
		private int _itemCount;

		// Token: 0x040004BC RID: 1212
		private float _recordOffsetX;

		// Token: 0x040004BD RID: 1213
		private float _recordOffsetY;
	}
}
