﻿using System;
using UnityEngine;

namespace NatureRendererDemo
{
	// Token: 0x02000018 RID: 24
	[ExecuteInEditMode]
	public class RenderPipelineLighting : MonoBehaviour
	{
		// Token: 0x06000038 RID: 56 RVA: 0x000034FF File Offset: 0x000016FF
		private void OnValidate()
		{
			this.Awake();
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00003507 File Offset: 0x00001707
		private void Awake()
		{
		}

		// Token: 0x0400002D RID: 45
		[Header("Input")]
		[SerializeField]
		private GameObject _legacyInputSystem;

		// Token: 0x0400002E RID: 46
		[SerializeField]
		private GameObject _newInputSystem;

		// Token: 0x0400002F RID: 47
		[Header("Standard")]
		[SerializeField]
		private GameObject _standardLighting;

		// Token: 0x04000030 RID: 48
		[SerializeField]
		private Material _standardSky;

		// Token: 0x04000031 RID: 49
		[SerializeField]
		private Material _standardTerrain;

		// Token: 0x04000032 RID: 50
		[SerializeField]
		private GameObject _standardVolume;

		// Token: 0x04000033 RID: 51
		[SerializeField]
		private Material _standardLineMaterial;

		// Token: 0x04000034 RID: 52
		[SerializeField]
		private Material _standardCameraIconMaterial;

		// Token: 0x04000035 RID: 53
		[SerializeField]
		private GameObject _standardPaintDecal;

		// Token: 0x04000036 RID: 54
		[Header("Universal")]
		[SerializeField]
		private GameObject _universalLighting;

		// Token: 0x04000037 RID: 55
		[SerializeField]
		private Material _universalSky;

		// Token: 0x04000038 RID: 56
		[SerializeField]
		private Material _universalTerrain;

		// Token: 0x04000039 RID: 57
		[SerializeField]
		private GameObject _universalVolume;

		// Token: 0x0400003A RID: 58
		[SerializeField]
		private Material _universalLineMaterial;

		// Token: 0x0400003B RID: 59
		[SerializeField]
		private Material _universalCameraIconMaterial;

		// Token: 0x0400003C RID: 60
		[SerializeField]
		private GameObject _universalPaintDecal;

		// Token: 0x0400003D RID: 61
		[Header("HD")]
		[SerializeField]
		private GameObject _highDefinitionLighting;

		// Token: 0x0400003E RID: 62
		[SerializeField]
		private Material _highDefinitionSky;

		// Token: 0x0400003F RID: 63
		[SerializeField]
		private GameObject _highDefinitionVolume;

		// Token: 0x04000040 RID: 64
		[SerializeField]
		private Material _highDefinitionTerrain;

		// Token: 0x04000041 RID: 65
		[SerializeField]
		private Material _highDefinitionLineMaterial;

		// Token: 0x04000042 RID: 66
		[SerializeField]
		private Material _highDefinitionCameraIconMaterial;

		// Token: 0x04000043 RID: 67
		[SerializeField]
		private GameObject _highDefinitionPaintDecal;
	}
}
