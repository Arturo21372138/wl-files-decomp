﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F5 RID: 2037
	public struct GetAchievementDefinitionCountOptions
	{
	}
}
