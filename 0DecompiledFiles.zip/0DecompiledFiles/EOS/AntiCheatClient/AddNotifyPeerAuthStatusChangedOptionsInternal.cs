﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007AF RID: 1967
	internal struct AddNotifyPeerAuthStatusChangedOptionsInternal : ISettable<AddNotifyPeerAuthStatusChangedOptions>, IDisposable
	{
		// Token: 0x06002086 RID: 8326 RVA: 0x00026A84 File Offset: 0x00024C84
		public void Set(ref AddNotifyPeerAuthStatusChangedOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002087 RID: 8327 RVA: 0x00026A93 File Offset: 0x00024C93
		public void Dispose()
		{
		}

		// Token: 0x0400159D RID: 5533
		private int m_ApiVersion;
	}
}
