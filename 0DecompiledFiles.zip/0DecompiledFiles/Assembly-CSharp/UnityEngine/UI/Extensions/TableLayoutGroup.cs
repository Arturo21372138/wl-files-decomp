﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000090 RID: 144
	[AddComponentMenu("Layout/Extensions/Table Layout Group")]
	public class TableLayoutGroup : LayoutGroup
	{
		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x0600048E RID: 1166 RVA: 0x0001B7C3 File Offset: 0x000199C3
		// (set) Token: 0x0600048F RID: 1167 RVA: 0x0001B7CB File Offset: 0x000199CB
		public TableLayoutGroup.Corner StartCorner
		{
			get
			{
				return this.startCorner;
			}
			set
			{
				base.SetProperty<TableLayoutGroup.Corner>(ref this.startCorner, value);
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x06000490 RID: 1168 RVA: 0x0001B7DA File Offset: 0x000199DA
		// (set) Token: 0x06000491 RID: 1169 RVA: 0x0001B7E2 File Offset: 0x000199E2
		public float[] ColumnWidths
		{
			get
			{
				return this.columnWidths;
			}
			set
			{
				base.SetProperty<float[]>(ref this.columnWidths, value);
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x06000492 RID: 1170 RVA: 0x0001B7F1 File Offset: 0x000199F1
		// (set) Token: 0x06000493 RID: 1171 RVA: 0x0001B7F9 File Offset: 0x000199F9
		public float MinimumRowHeight
		{
			get
			{
				return this.minimumRowHeight;
			}
			set
			{
				base.SetProperty<float>(ref this.minimumRowHeight, value);
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x06000494 RID: 1172 RVA: 0x0001B808 File Offset: 0x00019A08
		// (set) Token: 0x06000495 RID: 1173 RVA: 0x0001B810 File Offset: 0x00019A10
		public bool FlexibleRowHeight
		{
			get
			{
				return this.flexibleRowHeight;
			}
			set
			{
				base.SetProperty<bool>(ref this.flexibleRowHeight, value);
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000496 RID: 1174 RVA: 0x0001B81F File Offset: 0x00019A1F
		// (set) Token: 0x06000497 RID: 1175 RVA: 0x0001B827 File Offset: 0x00019A27
		public float ColumnSpacing
		{
			get
			{
				return this.columnSpacing;
			}
			set
			{
				base.SetProperty<float>(ref this.columnSpacing, value);
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000498 RID: 1176 RVA: 0x0001B836 File Offset: 0x00019A36
		// (set) Token: 0x06000499 RID: 1177 RVA: 0x0001B83E File Offset: 0x00019A3E
		public float RowSpacing
		{
			get
			{
				return this.rowSpacing;
			}
			set
			{
				base.SetProperty<float>(ref this.rowSpacing, value);
			}
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x0001B850 File Offset: 0x00019A50
		public override void CalculateLayoutInputHorizontal()
		{
			base.CalculateLayoutInputHorizontal();
			float num = (float)base.padding.horizontal;
			int num2 = Mathf.Min(base.rectChildren.Count, this.columnWidths.Length);
			for (int i = 0; i < num2; i++)
			{
				num += this.columnWidths[i];
				num += this.columnSpacing;
			}
			num -= this.columnSpacing;
			base.SetLayoutInputForAxis(num, num, 0f, 0);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x0001B8C0 File Offset: 0x00019AC0
		public override void CalculateLayoutInputVertical()
		{
			int num = this.columnWidths.Length;
			int num2 = Mathf.CeilToInt((float)base.rectChildren.Count / (float)num);
			this.preferredRowHeights = new float[num2];
			float num3 = (float)base.padding.vertical;
			float num4 = (float)base.padding.vertical;
			if (num2 > 1)
			{
				float num5 = (float)(num2 - 1) * this.rowSpacing;
				num3 += num5;
				num4 += num5;
			}
			if (this.flexibleRowHeight)
			{
				for (int i = 0; i < num2; i++)
				{
					float num6 = this.minimumRowHeight;
					float num7 = this.minimumRowHeight;
					for (int j = 0; j < num; j++)
					{
						int num8 = i * num + j;
						if (num8 == base.rectChildren.Count)
						{
							break;
						}
						num7 = Mathf.Max(LayoutUtility.GetPreferredHeight(base.rectChildren[num8]), num7);
						num6 = Mathf.Max(LayoutUtility.GetMinHeight(base.rectChildren[num8]), num6);
					}
					num3 += num6;
					num4 += num7;
					this.preferredRowHeights[i] = num7;
				}
			}
			else
			{
				for (int k = 0; k < num2; k++)
				{
					this.preferredRowHeights[k] = this.minimumRowHeight;
				}
				num3 += (float)num2 * this.minimumRowHeight;
				num4 = num3;
			}
			num4 = Mathf.Max(num3, num4);
			base.SetLayoutInputForAxis(num3, num4, 1f, 1);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x0001BA24 File Offset: 0x00019C24
		public override void SetLayoutHorizontal()
		{
			if (this.columnWidths.Length == 0)
			{
				this.columnWidths = new float[1];
			}
			int num = this.columnWidths.Length;
			int num2 = (int)(this.startCorner % TableLayoutGroup.Corner.LowerLeft);
			float num3 = 0f;
			int num4 = Mathf.Min(base.rectChildren.Count, this.columnWidths.Length);
			for (int i = 0; i < num4; i++)
			{
				num3 += this.columnWidths[i];
				num3 += this.columnSpacing;
			}
			num3 -= this.columnSpacing;
			float num5 = base.GetStartOffset(0, num3);
			if (num2 == 1)
			{
				num5 += num3;
			}
			float num6 = num5;
			for (int j = 0; j < base.rectChildren.Count; j++)
			{
				int num7 = j % num;
				if (num7 == 0)
				{
					num6 = num5;
				}
				if (num2 == 1)
				{
					num6 -= this.columnWidths[num7];
				}
				base.SetChildAlongAxis(base.rectChildren[j], 0, num6, this.columnWidths[num7]);
				if (num2 == 1)
				{
					num6 -= this.columnSpacing;
				}
				else
				{
					num6 += this.columnWidths[num7] + this.columnSpacing;
				}
			}
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x0001BB40 File Offset: 0x00019D40
		public override void SetLayoutVertical()
		{
			int num = this.columnWidths.Length;
			int num2 = this.preferredRowHeights.Length;
			int num3 = (int)(this.startCorner / TableLayoutGroup.Corner.LowerLeft);
			float num4 = 0f;
			for (int i = 0; i < num2; i++)
			{
				num4 += this.preferredRowHeights[i];
			}
			if (num2 > 1)
			{
				num4 += (float)(num2 - 1) * this.rowSpacing;
			}
			float num5 = base.GetStartOffset(1, num4);
			if (num3 == 1)
			{
				num5 += num4;
			}
			float num6 = num5;
			for (int j = 0; j < num2; j++)
			{
				if (num3 == 1)
				{
					num6 -= this.preferredRowHeights[j];
				}
				for (int k = 0; k < num; k++)
				{
					int num7 = j * num + k;
					if (num7 == base.rectChildren.Count)
					{
						break;
					}
					base.SetChildAlongAxis(base.rectChildren[num7], 1, num6, this.preferredRowHeights[j]);
				}
				if (num3 == 1)
				{
					num6 -= this.rowSpacing;
				}
				else
				{
					num6 += this.preferredRowHeights[j] + this.rowSpacing;
				}
			}
			this.preferredRowHeights = null;
		}

		// Token: 0x0400037C RID: 892
		[SerializeField]
		protected TableLayoutGroup.Corner startCorner;

		// Token: 0x0400037D RID: 893
		[SerializeField]
		protected float[] columnWidths = new float[] { 96f };

		// Token: 0x0400037E RID: 894
		[SerializeField]
		protected float minimumRowHeight = 32f;

		// Token: 0x0400037F RID: 895
		[SerializeField]
		protected bool flexibleRowHeight = true;

		// Token: 0x04000380 RID: 896
		[SerializeField]
		protected float columnSpacing;

		// Token: 0x04000381 RID: 897
		[SerializeField]
		protected float rowSpacing;

		// Token: 0x04000382 RID: 898
		private float[] preferredRowHeights;

		// Token: 0x0200013E RID: 318
		public enum Corner
		{
			// Token: 0x0400068A RID: 1674
			UpperLeft,
			// Token: 0x0400068B RID: 1675
			UpperRight,
			// Token: 0x0400068C RID: 1676
			LowerLeft,
			// Token: 0x0400068D RID: 1677
			LowerRight
		}
	}
}
