﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200076B RID: 1899
	public enum AntiCheatCommonClientAuthStatus
	{
		// Token: 0x04001478 RID: 5240
		Invalid,
		// Token: 0x04001479 RID: 5241
		LocalAuthComplete,
		// Token: 0x0400147A RID: 5242
		RemoteAuthComplete
	}
}
