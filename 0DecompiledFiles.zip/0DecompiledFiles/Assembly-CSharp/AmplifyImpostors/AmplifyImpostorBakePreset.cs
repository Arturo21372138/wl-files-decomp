﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x020000EE RID: 238
	[CreateAssetMenu(fileName = "New Bake Preset", order = 86)]
	public class AmplifyImpostorBakePreset : ScriptableObject
	{
		// Token: 0x040005CF RID: 1487
		[SerializeField]
		public Shader BakeShader;

		// Token: 0x040005D0 RID: 1488
		[SerializeField]
		public Shader RuntimeShader;

		// Token: 0x040005D1 RID: 1489
		[SerializeField]
		public PresetPipeline Pipeline;

		// Token: 0x040005D2 RID: 1490
		[SerializeField]
		public int AlphaIndex;

		// Token: 0x040005D3 RID: 1491
		[SerializeField]
		public List<TextureOutput> Output = new List<TextureOutput>();
	}
}
