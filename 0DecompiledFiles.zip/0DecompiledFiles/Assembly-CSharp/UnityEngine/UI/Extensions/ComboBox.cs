﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000033 RID: 51
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/ComboBox")]
	public class ComboBox : MonoBehaviour
	{
		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000FD RID: 253 RVA: 0x00006C81 File Offset: 0x00004E81
		// (set) Token: 0x060000FE RID: 254 RVA: 0x00006C89 File Offset: 0x00004E89
		public DropDownListItem SelectedItem { get; private set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000FF RID: 255 RVA: 0x00006C92 File Offset: 0x00004E92
		// (set) Token: 0x06000100 RID: 256 RVA: 0x00006C9A File Offset: 0x00004E9A
		public string Text { get; private set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000101 RID: 257 RVA: 0x00006CA3 File Offset: 0x00004EA3
		// (set) Token: 0x06000102 RID: 258 RVA: 0x00006CAB File Offset: 0x00004EAB
		public float ScrollBarWidth
		{
			get
			{
				return this._scrollBarWidth;
			}
			set
			{
				this._scrollBarWidth = value;
				this.RedrawPanel();
			}
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000103 RID: 259 RVA: 0x00006CBA File Offset: 0x00004EBA
		// (set) Token: 0x06000104 RID: 260 RVA: 0x00006CC2 File Offset: 0x00004EC2
		public int ItemsToDisplay
		{
			get
			{
				return this._itemsToDisplay;
			}
			set
			{
				this._itemsToDisplay = value;
				this.RedrawPanel();
			}
		}

		// Token: 0x06000105 RID: 261 RVA: 0x00006CD1 File Offset: 0x00004ED1
		public void Awake()
		{
			this.Initialize();
		}

		// Token: 0x06000106 RID: 262 RVA: 0x00006CDC File Offset: 0x00004EDC
		private bool Initialize()
		{
			bool flag = true;
			try
			{
				this._rectTransform = base.GetComponent<RectTransform>();
				this._inputRT = this._rectTransform.Find("InputField").GetComponent<RectTransform>();
				this._mainInput = this._inputRT.GetComponent<InputField>();
				this._overlayRT = this._rectTransform.Find("Overlay").GetComponent<RectTransform>();
				this._overlayRT.gameObject.SetActive(false);
				this._scrollPanelRT = this._overlayRT.Find("ScrollPanel").GetComponent<RectTransform>();
				this._scrollBarRT = this._scrollPanelRT.Find("Scrollbar").GetComponent<RectTransform>();
				this._slidingAreaRT = this._scrollBarRT.Find("SlidingArea").GetComponent<RectTransform>();
				this._itemsPanelRT = this._scrollPanelRT.Find("Items").GetComponent<RectTransform>();
				this._canvas = base.GetComponentInParent<Canvas>();
				this._canvasRT = this._canvas.GetComponent<RectTransform>();
				this._scrollRect = this._scrollPanelRT.GetComponent<ScrollRect>();
				this._scrollRect.scrollSensitivity = this._rectTransform.sizeDelta.y / 2f;
				this._scrollRect.movementType = ScrollRect.MovementType.Clamped;
				this._scrollRect.content = this._itemsPanelRT;
				this.itemTemplate = this._rectTransform.Find("ItemTemplate").gameObject;
				this.itemTemplate.SetActive(false);
			}
			catch (NullReferenceException ex)
			{
				Debug.LogException(ex);
				Debug.LogError("Something is setup incorrectly with the dropdownlist component causing a Null Reference Exception");
				flag = false;
			}
			this.panelObjects = new Dictionary<string, GameObject>();
			this._panelItems = this.AvailableOptions.ToList<string>();
			this.RebuildPanel();
			return flag;
		}

		// Token: 0x06000107 RID: 263 RVA: 0x00006EA4 File Offset: 0x000050A4
		public void AddItem(string item)
		{
			this.AvailableOptions.Add(item);
			this.RebuildPanel();
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00006EB8 File Offset: 0x000050B8
		public void RemoveItem(string item)
		{
			this.AvailableOptions.Remove(item);
			this.RebuildPanel();
		}

		// Token: 0x06000109 RID: 265 RVA: 0x00006ECD File Offset: 0x000050CD
		public void SetAvailableOptions(List<string> newOptions)
		{
			this.AvailableOptions.Clear();
			this.AvailableOptions = newOptions;
			this.RebuildPanel();
		}

		// Token: 0x0600010A RID: 266 RVA: 0x00006EE8 File Offset: 0x000050E8
		public void SetAvailableOptions(string[] newOptions)
		{
			this.AvailableOptions.Clear();
			for (int i = 0; i < newOptions.Length; i++)
			{
				this.AvailableOptions.Add(newOptions[i]);
			}
			this.RebuildPanel();
		}

		// Token: 0x0600010B RID: 267 RVA: 0x00006F22 File Offset: 0x00005122
		public void ResetItems()
		{
			this.AvailableOptions.Clear();
			this.RebuildPanel();
		}

		// Token: 0x0600010C RID: 268 RVA: 0x00006F38 File Offset: 0x00005138
		private void RebuildPanel()
		{
			this._panelItems.Clear();
			foreach (string text in this.AvailableOptions)
			{
				this._panelItems.Add(text.ToLower());
			}
			if (this._sortItems)
			{
				this._panelItems.Sort();
			}
			List<GameObject> list = new List<GameObject>(this.panelObjects.Values);
			this.panelObjects.Clear();
			int num = 0;
			while (list.Count < this.AvailableOptions.Count)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.itemTemplate);
				gameObject.name = "Item " + num.ToString();
				gameObject.transform.SetParent(this._itemsPanelRT, false);
				list.Add(gameObject);
				num++;
			}
			for (int i = 0; i < list.Count; i++)
			{
				list[i].SetActive(i <= this.AvailableOptions.Count);
				if (i < this.AvailableOptions.Count)
				{
					list[i].name = "Item " + i.ToString() + " " + this._panelItems[i];
					list[i].transform.Find("Text").GetComponent<Text>().text = this._panelItems[i];
					Button component = list[i].GetComponent<Button>();
					component.onClick.RemoveAllListeners();
					string textOfItem = this._panelItems[i];
					component.onClick.AddListener(delegate
					{
						this.OnItemClicked(textOfItem);
					});
					this.panelObjects[this._panelItems[i]] = list[i];
				}
			}
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00007148 File Offset: 0x00005348
		private void OnItemClicked(string item)
		{
			this.Text = item;
			this._mainInput.text = this.Text;
			this.ToggleDropdownPanel(true);
		}

		// Token: 0x0600010E RID: 270 RVA: 0x0000716C File Offset: 0x0000536C
		private void RedrawPanel()
		{
			float num = ((this._panelItems.Count > this.ItemsToDisplay) ? this._scrollBarWidth : 0f);
			this._scrollBarRT.gameObject.SetActive(this._panelItems.Count > this.ItemsToDisplay);
			if (!this._hasDrawnOnce || this._rectTransform.sizeDelta != this._inputRT.sizeDelta)
			{
				this._hasDrawnOnce = true;
				this._inputRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._rectTransform.sizeDelta.x);
				this._inputRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this._rectTransform.sizeDelta.y);
				this._scrollPanelRT.SetParent(base.transform, true);
				this._scrollPanelRT.anchoredPosition = new Vector2(0f, -this._rectTransform.sizeDelta.y);
				this._overlayRT.SetParent(this._canvas.transform, false);
				this._overlayRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._canvasRT.sizeDelta.x);
				this._overlayRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this._canvasRT.sizeDelta.y);
				this._overlayRT.SetParent(base.transform, true);
				this._scrollPanelRT.SetParent(this._overlayRT, true);
			}
			if (this._panelItems.Count < 1)
			{
				return;
			}
			float num2 = this._rectTransform.sizeDelta.y * (float)Mathf.Min(this._itemsToDisplay, this._panelItems.Count);
			this._scrollPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2);
			this._scrollPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._rectTransform.sizeDelta.x);
			this._itemsPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._scrollPanelRT.sizeDelta.x - num - 5f);
			this._itemsPanelRT.anchoredPosition = new Vector2(5f, 0f);
			this._scrollBarRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, num);
			this._scrollBarRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2);
			this._slidingAreaRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, 0f);
			this._slidingAreaRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2 - this._scrollBarRT.sizeDelta.x);
		}

		// Token: 0x0600010F RID: 271 RVA: 0x000073B8 File Offset: 0x000055B8
		public void OnValueChanged(string currText)
		{
			this.Text = currText;
			this.RedrawPanel();
			if (this._panelItems.Count == 0)
			{
				this._isPanelActive = true;
				this.ToggleDropdownPanel(false);
			}
			else if (!this._isPanelActive)
			{
				this.ToggleDropdownPanel(false);
			}
			this.OnSelectionChanged.Invoke(this.Text);
		}

		// Token: 0x06000110 RID: 272 RVA: 0x0000740F File Offset: 0x0000560F
		public void ToggleDropdownPanel(bool directClick)
		{
			this._isPanelActive = !this._isPanelActive;
			this._overlayRT.gameObject.SetActive(this._isPanelActive);
			if (this._isPanelActive)
			{
				base.transform.SetAsLastSibling();
				return;
			}
		}

		// Token: 0x040000F5 RID: 245
		public Color disabledTextColor;

		// Token: 0x040000F7 RID: 247
		public List<string> AvailableOptions;

		// Token: 0x040000F8 RID: 248
		[SerializeField]
		private float _scrollBarWidth = 20f;

		// Token: 0x040000F9 RID: 249
		[SerializeField]
		private int _itemsToDisplay;

		// Token: 0x040000FA RID: 250
		[SerializeField]
		private bool _sortItems = true;

		// Token: 0x040000FB RID: 251
		public ComboBox.SelectionChangedEvent OnSelectionChanged;

		// Token: 0x040000FC RID: 252
		private bool _isPanelActive;

		// Token: 0x040000FD RID: 253
		private bool _hasDrawnOnce;

		// Token: 0x040000FE RID: 254
		private InputField _mainInput;

		// Token: 0x040000FF RID: 255
		private RectTransform _inputRT;

		// Token: 0x04000100 RID: 256
		private RectTransform _rectTransform;

		// Token: 0x04000101 RID: 257
		private RectTransform _overlayRT;

		// Token: 0x04000102 RID: 258
		private RectTransform _scrollPanelRT;

		// Token: 0x04000103 RID: 259
		private RectTransform _scrollBarRT;

		// Token: 0x04000104 RID: 260
		private RectTransform _slidingAreaRT;

		// Token: 0x04000105 RID: 261
		private RectTransform _itemsPanelRT;

		// Token: 0x04000106 RID: 262
		private Canvas _canvas;

		// Token: 0x04000107 RID: 263
		private RectTransform _canvasRT;

		// Token: 0x04000108 RID: 264
		private ScrollRect _scrollRect;

		// Token: 0x04000109 RID: 265
		private List<string> _panelItems;

		// Token: 0x0400010A RID: 266
		private Dictionary<string, GameObject> panelObjects;

		// Token: 0x0400010B RID: 267
		private GameObject itemTemplate;

		// Token: 0x0200010D RID: 269
		[Serializable]
		public class SelectionChangedEvent : UnityEvent<string>
		{
		}
	}
}
