﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200081B RID: 2075
	internal struct QueryPlayerAchievementsOptionsInternal : ISettable<QueryPlayerAchievementsOptions>, IDisposable
	{
		// Token: 0x06002226 RID: 8742 RVA: 0x00028915 File Offset: 0x00026B15
		public void Set(ref QueryPlayerAchievementsOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 2;
			Helper.Set(other.TargetUserId, ref this.m_TargetUserId);
			Helper.Set(other.LocalUserId, ref this.m_LocalUserId);
		}

		// Token: 0x06002227 RID: 8743 RVA: 0x00028946 File Offset: 0x00026B46
		public void Dispose()
		{
			Helper.Dispose(ref this.m_TargetUserId);
			Helper.Dispose(ref this.m_LocalUserId);
		}

		// Token: 0x040016CE RID: 5838
		private int m_ApiVersion;

		// Token: 0x040016CF RID: 5839
		private IntPtr m_TargetUserId;

		// Token: 0x040016D0 RID: 5840
		private IntPtr m_LocalUserId;
	}
}
