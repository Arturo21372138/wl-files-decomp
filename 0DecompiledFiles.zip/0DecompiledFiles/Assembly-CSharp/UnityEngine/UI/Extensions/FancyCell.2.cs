﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000072 RID: 114
	public abstract class FancyCell<TItemData> : FancyCell<TItemData, NullContext>
	{
		// Token: 0x0600036F RID: 879 RVA: 0x00016877 File Offset: 0x00014A77
		public sealed override void SetContext(NullContext context)
		{
			base.SetContext(context);
		}
	}
}
