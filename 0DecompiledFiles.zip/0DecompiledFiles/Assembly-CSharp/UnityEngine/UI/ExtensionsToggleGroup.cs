﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI
{
	// Token: 0x0200002B RID: 43
	[AddComponentMenu("UI/Extensions/Extensions Toggle Group")]
	[DisallowMultipleComponent]
	public class ExtensionsToggleGroup : UIBehaviour
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000091 RID: 145 RVA: 0x000052A8 File Offset: 0x000034A8
		// (set) Token: 0x06000092 RID: 146 RVA: 0x000052B0 File Offset: 0x000034B0
		public bool AllowSwitchOff
		{
			get
			{
				return this.m_AllowSwitchOff;
			}
			set
			{
				this.m_AllowSwitchOff = value;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000093 RID: 147 RVA: 0x000052B9 File Offset: 0x000034B9
		// (set) Token: 0x06000094 RID: 148 RVA: 0x000052C1 File Offset: 0x000034C1
		public ExtensionsToggle SelectedToggle { get; private set; }

		// Token: 0x06000095 RID: 149 RVA: 0x000052CA File Offset: 0x000034CA
		protected ExtensionsToggleGroup()
		{
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000052F3 File Offset: 0x000034F3
		private void ValidateToggleIsInGroup(ExtensionsToggle toggle)
		{
			if (toggle == null || !this.m_Toggles.Contains(toggle))
			{
				throw new ArgumentException(string.Format("Toggle {0} is not part of ToggleGroup {1}", new object[] { toggle, this }));
			}
		}

		// Token: 0x06000097 RID: 151 RVA: 0x0000532C File Offset: 0x0000352C
		public void NotifyToggleOn(ExtensionsToggle toggle)
		{
			this.ValidateToggleIsInGroup(toggle);
			for (int i = 0; i < this.m_Toggles.Count; i++)
			{
				if (this.m_Toggles[i] == toggle)
				{
					this.SelectedToggle = toggle;
				}
				else
				{
					this.m_Toggles[i].IsOn = false;
				}
			}
			this.onToggleGroupChanged.Invoke(this.AnyTogglesOn());
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00005396 File Offset: 0x00003596
		public void UnregisterToggle(ExtensionsToggle toggle)
		{
			if (this.m_Toggles.Contains(toggle))
			{
				this.m_Toggles.Remove(toggle);
				toggle.onValueChanged.RemoveListener(new UnityAction<bool>(this.NotifyToggleChanged));
			}
		}

		// Token: 0x06000099 RID: 153 RVA: 0x000053CA File Offset: 0x000035CA
		private void NotifyToggleChanged(bool isOn)
		{
			this.onToggleGroupToggleChanged.Invoke(isOn);
		}

		// Token: 0x0600009A RID: 154 RVA: 0x000053D8 File Offset: 0x000035D8
		public void RegisterToggle(ExtensionsToggle toggle)
		{
			if (!this.m_Toggles.Contains(toggle))
			{
				this.m_Toggles.Add(toggle);
				toggle.onValueChanged.AddListener(new UnityAction<bool>(this.NotifyToggleChanged));
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x0000540B File Offset: 0x0000360B
		public bool AnyTogglesOn()
		{
			return this.m_Toggles.Find((ExtensionsToggle x) => x.IsOn) != null;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x0000543D File Offset: 0x0000363D
		public IEnumerable<ExtensionsToggle> ActiveToggles()
		{
			return this.m_Toggles.Where((ExtensionsToggle x) => x.IsOn);
		}

		// Token: 0x0600009D RID: 157 RVA: 0x0000546C File Offset: 0x0000366C
		public void SetAllTogglesOff()
		{
			bool allowSwitchOff = this.m_AllowSwitchOff;
			this.m_AllowSwitchOff = true;
			for (int i = 0; i < this.m_Toggles.Count; i++)
			{
				this.m_Toggles[i].IsOn = false;
			}
			this.m_AllowSwitchOff = allowSwitchOff;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x000054B6 File Offset: 0x000036B6
		public void HasTheGroupToggle(bool value)
		{
			Debug.Log("Testing, the group has toggled [" + value.ToString() + "]");
		}

		// Token: 0x0600009F RID: 159 RVA: 0x000054D3 File Offset: 0x000036D3
		public void HasAToggleFlipped(bool value)
		{
			Debug.Log("Testing, a toggle has toggled [" + value.ToString() + "]");
		}

		// Token: 0x040000AE RID: 174
		[SerializeField]
		private bool m_AllowSwitchOff;

		// Token: 0x040000AF RID: 175
		private List<ExtensionsToggle> m_Toggles = new List<ExtensionsToggle>();

		// Token: 0x040000B0 RID: 176
		public ExtensionsToggleGroup.ToggleGroupEvent onToggleGroupChanged = new ExtensionsToggleGroup.ToggleGroupEvent();

		// Token: 0x040000B1 RID: 177
		public ExtensionsToggleGroup.ToggleGroupEvent onToggleGroupToggleChanged = new ExtensionsToggleGroup.ToggleGroupEvent();

		// Token: 0x02000102 RID: 258
		[Serializable]
		public class ToggleGroupEvent : UnityEvent<bool>
		{
		}
	}
}
