﻿using System;
using System.Collections;
using UnityEngine;

namespace UnitySA.Utility
{
	// Token: 0x0200001F RID: 31
	[Serializable]
	public class LerpCtrlBob
	{
		// Token: 0x0600005F RID: 95 RVA: 0x00004514 File Offset: 0x00002714
		public float Offset()
		{
			return this.m_Offset;
		}

		// Token: 0x06000060 RID: 96 RVA: 0x0000451C File Offset: 0x0000271C
		public IEnumerator DoBobCycle()
		{
			float t = 0f;
			while (t < this.BobDuration)
			{
				this.m_Offset = Mathf.Lerp(0f, this.BobAmount, t / this.BobDuration);
				t += Time.deltaTime;
				yield return new WaitForFixedUpdate();
			}
			t = 0f;
			while (t < this.BobDuration)
			{
				this.m_Offset = Mathf.Lerp(this.BobAmount, 0f, t / this.BobDuration);
				t += Time.deltaTime;
				yield return new WaitForFixedUpdate();
			}
			this.m_Offset = 0f;
			yield break;
		}

		// Token: 0x04000087 RID: 135
		public float BobDuration;

		// Token: 0x04000088 RID: 136
		public float BobAmount;

		// Token: 0x04000089 RID: 137
		private float m_Offset;
	}
}
