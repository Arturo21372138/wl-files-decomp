﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200076C RID: 1900
	[Flags]
	public enum AntiCheatCommonClientFlags
	{
		// Token: 0x0400147C RID: 5244
		None = 0,
		// Token: 0x0400147D RID: 5245
		Admin = 1
	}
}
