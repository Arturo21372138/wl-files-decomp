﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000084 RID: 132
	public abstract class FancyScrollRectCell<TItemData, TContext> : FancyCell<TItemData, TContext> where TContext : class, IFancyScrollRectContext, new()
	{
		// Token: 0x060003FA RID: 1018 RVA: 0x00018120 File Offset: 0x00016320
		public override void UpdatePosition(float position)
		{
			ValueTuple<float, float> valueTuple = base.Context.CalculateScrollSize();
			float item = valueTuple.Item1;
			float item2 = valueTuple.Item2;
			float num = (Mathf.Lerp(0f, item, position) - item2) / (item - item2 * 2f);
			float num2 = 0.5f * item;
			float num3 = -num2;
			this.UpdatePosition(num, Mathf.Lerp(num2, num3, position));
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00018184 File Offset: 0x00016384
		protected virtual void UpdatePosition(float normalizedPosition, float localPosition)
		{
			base.transform.localPosition = ((base.Context.ScrollDirection == ScrollDirection.Horizontal) ? new Vector2(-localPosition, 0f) : new Vector2(0f, localPosition));
		}
	}
}
