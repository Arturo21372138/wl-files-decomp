﻿using System;

namespace VisualDesignCafe.Rendering.Nature
{
	// Token: 0x02000014 RID: 20
	public static class NatureRendererSrp
	{
	}
}
