﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F1 RID: 2033
	public struct Definition
	{
		// Token: 0x17000846 RID: 2118
		// (get) Token: 0x06002164 RID: 8548 RVA: 0x00027E02 File Offset: 0x00026002
		// (set) Token: 0x06002165 RID: 8549 RVA: 0x00027E0A File Offset: 0x0002600A
		public Utf8String AchievementId { readonly get; set; }

		// Token: 0x17000847 RID: 2119
		// (get) Token: 0x06002166 RID: 8550 RVA: 0x00027E13 File Offset: 0x00026013
		// (set) Token: 0x06002167 RID: 8551 RVA: 0x00027E1B File Offset: 0x0002601B
		public Utf8String DisplayName { readonly get; set; }

		// Token: 0x17000848 RID: 2120
		// (get) Token: 0x06002168 RID: 8552 RVA: 0x00027E24 File Offset: 0x00026024
		// (set) Token: 0x06002169 RID: 8553 RVA: 0x00027E2C File Offset: 0x0002602C
		public Utf8String Description { readonly get; set; }

		// Token: 0x17000849 RID: 2121
		// (get) Token: 0x0600216A RID: 8554 RVA: 0x00027E35 File Offset: 0x00026035
		// (set) Token: 0x0600216B RID: 8555 RVA: 0x00027E3D File Offset: 0x0002603D
		public Utf8String LockedDisplayName { readonly get; set; }

		// Token: 0x1700084A RID: 2122
		// (get) Token: 0x0600216C RID: 8556 RVA: 0x00027E46 File Offset: 0x00026046
		// (set) Token: 0x0600216D RID: 8557 RVA: 0x00027E4E File Offset: 0x0002604E
		public Utf8String LockedDescription { readonly get; set; }

		// Token: 0x1700084B RID: 2123
		// (get) Token: 0x0600216E RID: 8558 RVA: 0x00027E57 File Offset: 0x00026057
		// (set) Token: 0x0600216F RID: 8559 RVA: 0x00027E5F File Offset: 0x0002605F
		public Utf8String HiddenDescription { readonly get; set; }

		// Token: 0x1700084C RID: 2124
		// (get) Token: 0x06002170 RID: 8560 RVA: 0x00027E68 File Offset: 0x00026068
		// (set) Token: 0x06002171 RID: 8561 RVA: 0x00027E70 File Offset: 0x00026070
		public Utf8String CompletionDescription { readonly get; set; }

		// Token: 0x1700084D RID: 2125
		// (get) Token: 0x06002172 RID: 8562 RVA: 0x00027E79 File Offset: 0x00026079
		// (set) Token: 0x06002173 RID: 8563 RVA: 0x00027E81 File Offset: 0x00026081
		public Utf8String UnlockedIconId { readonly get; set; }

		// Token: 0x1700084E RID: 2126
		// (get) Token: 0x06002174 RID: 8564 RVA: 0x00027E8A File Offset: 0x0002608A
		// (set) Token: 0x06002175 RID: 8565 RVA: 0x00027E92 File Offset: 0x00026092
		public Utf8String LockedIconId { readonly get; set; }

		// Token: 0x1700084F RID: 2127
		// (get) Token: 0x06002176 RID: 8566 RVA: 0x00027E9B File Offset: 0x0002609B
		// (set) Token: 0x06002177 RID: 8567 RVA: 0x00027EA3 File Offset: 0x000260A3
		public bool IsHidden { readonly get; set; }

		// Token: 0x17000850 RID: 2128
		// (get) Token: 0x06002178 RID: 8568 RVA: 0x00027EAC File Offset: 0x000260AC
		// (set) Token: 0x06002179 RID: 8569 RVA: 0x00027EB4 File Offset: 0x000260B4
		public StatThresholds[] StatThresholds { readonly get; set; }
	}
}
