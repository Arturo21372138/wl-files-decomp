﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000773 RID: 1907
	public sealed class AntiCheatCommonInterface
	{
		// Token: 0x040014A5 RID: 5285
		public const int LOGEVENT_API_LATEST = 1;

		// Token: 0x040014A6 RID: 5286
		public const int LOGEVENT_STRING_MAX_LENGTH = 39;

		// Token: 0x040014A7 RID: 5287
		public const int LOGGAMEROUNDEND_API_LATEST = 1;

		// Token: 0x040014A8 RID: 5288
		public const int LOGGAMEROUNDSTART_API_LATEST = 2;

		// Token: 0x040014A9 RID: 5289
		public const int LOGPLAYERDESPAWN_API_LATEST = 1;

		// Token: 0x040014AA RID: 5290
		public const int LOGPLAYERREVIVE_API_LATEST = 1;

		// Token: 0x040014AB RID: 5291
		public const int LOGPLAYERSPAWN_API_LATEST = 1;

		// Token: 0x040014AC RID: 5292
		public const int LOGPLAYERTAKEDAMAGE_API_LATEST = 4;

		// Token: 0x040014AD RID: 5293
		public const int LOGPLAYERTICK_API_LATEST = 3;

		// Token: 0x040014AE RID: 5294
		public const int LOGPLAYERUSEABILITY_API_LATEST = 1;

		// Token: 0x040014AF RID: 5295
		public const int LOGPLAYERUSEWEAPON_API_LATEST = 2;

		// Token: 0x040014B0 RID: 5296
		public const int LOGPLAYERUSEWEAPON_WEAPONNAME_MAX_LENGTH = 32;

		// Token: 0x040014B1 RID: 5297
		public const int REGISTEREVENT_API_LATEST = 1;

		// Token: 0x040014B2 RID: 5298
		public const int REGISTEREVENT_CUSTOMEVENTBASE = 268435456;

		// Token: 0x040014B3 RID: 5299
		public const int REGISTEREVENT_MAX_PARAMDEFSCOUNT = 12;

		// Token: 0x040014B4 RID: 5300
		public const int SETCLIENTDETAILS_API_LATEST = 1;

		// Token: 0x040014B5 RID: 5301
		public const int SETGAMESESSIONID_API_LATEST = 1;
	}
}
