﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000772 RID: 1906
	public enum AntiCheatCommonGameRoundCompetitionType
	{
		// Token: 0x040014A1 RID: 5281
		None,
		// Token: 0x040014A2 RID: 5282
		Casual,
		// Token: 0x040014A3 RID: 5283
		Ranked,
		// Token: 0x040014A4 RID: 5284
		Competitive
	}
}
