﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D6 RID: 2006
	public struct Reserved01Options
	{
	}
}
