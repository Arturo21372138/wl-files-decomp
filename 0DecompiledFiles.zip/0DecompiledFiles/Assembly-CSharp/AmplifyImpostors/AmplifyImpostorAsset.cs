﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x020000E6 RID: 230
	[CreateAssetMenu(fileName = "New Impostor", order = 85)]
	public class AmplifyImpostorAsset : ScriptableObject
	{
		// Token: 0x04000599 RID: 1433
		[SerializeField]
		public Material Material;

		// Token: 0x0400059A RID: 1434
		[SerializeField]
		public Mesh Mesh;

		// Token: 0x0400059B RID: 1435
		[HideInInspector]
		[SerializeField]
		public int Version;

		// Token: 0x0400059C RID: 1436
		[SerializeField]
		public ImpostorType ImpostorType = ImpostorType.Octahedron;

		// Token: 0x0400059D RID: 1437
		[HideInInspector]
		[SerializeField]
		public bool LockedSizes = true;

		// Token: 0x0400059E RID: 1438
		[HideInInspector]
		[SerializeField]
		public int SelectedSize = 2048;

		// Token: 0x0400059F RID: 1439
		[SerializeField]
		public Vector2 TexSize = new Vector2(2048f, 2048f);

		// Token: 0x040005A0 RID: 1440
		[HideInInspector]
		[SerializeField]
		public bool DecoupleAxisFrames;

		// Token: 0x040005A1 RID: 1441
		[SerializeField]
		[Range(1f, 32f)]
		public int HorizontalFrames = 16;

		// Token: 0x040005A2 RID: 1442
		[SerializeField]
		[Range(1f, 33f)]
		public int VerticalFrames = 16;

		// Token: 0x040005A3 RID: 1443
		[SerializeField]
		[Range(0f, 64f)]
		public int PixelPadding = 32;

		// Token: 0x040005A4 RID: 1444
		[SerializeField]
		[Range(4f, 16f)]
		public int MaxVertices = 8;

		// Token: 0x040005A5 RID: 1445
		[SerializeField]
		[Range(0f, 0.2f)]
		public float Tolerance = 0.15f;

		// Token: 0x040005A6 RID: 1446
		[SerializeField]
		[Range(0f, 1f)]
		public float NormalScale = 0.01f;

		// Token: 0x040005A7 RID: 1447
		[SerializeField]
		public Vector2[] ShapePoints = new Vector2[]
		{
			new Vector2(0.15f, 0f),
			new Vector2(0.85f, 0f),
			new Vector2(1f, 0.15f),
			new Vector2(1f, 0.85f),
			new Vector2(0.85f, 1f),
			new Vector2(0.15f, 1f),
			new Vector2(0f, 0.85f),
			new Vector2(0f, 0.15f)
		};

		// Token: 0x040005A8 RID: 1448
		[SerializeField]
		public AmplifyImpostorBakePreset Preset;

		// Token: 0x040005A9 RID: 1449
		[SerializeField]
		public List<TextureOutput> OverrideOutput = new List<TextureOutput>();
	}
}
