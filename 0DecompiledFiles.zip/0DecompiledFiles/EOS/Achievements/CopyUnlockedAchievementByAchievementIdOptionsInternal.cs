﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007EE RID: 2030
	internal struct CopyUnlockedAchievementByAchievementIdOptionsInternal : ISettable<CopyUnlockedAchievementByAchievementIdOptions>, IDisposable
	{
		// Token: 0x0600215C RID: 8540 RVA: 0x00027D5E File Offset: 0x00025F5E
		public void Set(ref CopyUnlockedAchievementByAchievementIdOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.UserId, ref this.m_UserId);
			Helper.Set(other.AchievementId, ref this.m_AchievementId);
		}

		// Token: 0x0600215D RID: 8541 RVA: 0x00027D8F File Offset: 0x00025F8F
		public void Dispose()
		{
			Helper.Dispose(ref this.m_UserId);
			Helper.Dispose(ref this.m_AchievementId);
		}

		// Token: 0x04001646 RID: 5702
		private int m_ApiVersion;

		// Token: 0x04001647 RID: 5703
		private IntPtr m_UserId;

		// Token: 0x04001648 RID: 5704
		private IntPtr m_AchievementId;
	}
}
