﻿using System;
using UnityEngine;

namespace UnitySA.Utility
{
	// Token: 0x0200001D RID: 29
	[Serializable]
	public class CurveCtrlBob
	{
		// Token: 0x06000056 RID: 86 RVA: 0x000042A0 File Offset: 0x000024A0
		public void Setup(Camera camera, float bobBaseInterval)
		{
			this.m_BobBaseInterval = bobBaseInterval;
			this.m_OriginalCameraPosition = camera.transform.localPosition;
			this.m_Time = this.Bobcurve[this.Bobcurve.length - 1].time;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x000042EC File Offset: 0x000024EC
		public Vector3 DoHeadBob(float speed)
		{
			float num = this.m_OriginalCameraPosition.x + this.Bobcurve.Evaluate(this.m_CyclePositionX) * this.HorizontalBobRange;
			float num2 = this.m_OriginalCameraPosition.y + this.Bobcurve.Evaluate(this.m_CyclePositionY) * this.VerticalBobRange;
			this.m_CyclePositionX += speed * Time.deltaTime / this.m_BobBaseInterval;
			this.m_CyclePositionY += speed * Time.deltaTime / this.m_BobBaseInterval * this.VerticaltoHorizontalRatio;
			if (this.m_CyclePositionX > this.m_Time)
			{
				this.m_CyclePositionX -= this.m_Time;
			}
			if (this.m_CyclePositionY > this.m_Time)
			{
				this.m_CyclePositionY -= this.m_Time;
			}
			return new Vector3(num, num2, 0f);
		}

		// Token: 0x04000078 RID: 120
		public float HorizontalBobRange = 0.33f;

		// Token: 0x04000079 RID: 121
		public float VerticalBobRange = 0.33f;

		// Token: 0x0400007A RID: 122
		public AnimationCurve Bobcurve = new AnimationCurve(new Keyframe[]
		{
			new Keyframe(0f, 0f),
			new Keyframe(0.5f, 1f),
			new Keyframe(1f, 0f),
			new Keyframe(1.5f, -1f),
			new Keyframe(2f, 0f)
		});

		// Token: 0x0400007B RID: 123
		public float VerticaltoHorizontalRatio = 1f;

		// Token: 0x0400007C RID: 124
		private float m_CyclePositionX;

		// Token: 0x0400007D RID: 125
		private float m_CyclePositionY;

		// Token: 0x0400007E RID: 126
		private float m_BobBaseInterval;

		// Token: 0x0400007F RID: 127
		private Vector3 m_OriginalCameraPosition;

		// Token: 0x04000080 RID: 128
		private float m_Time;
	}
}
