﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E2 RID: 2018
	internal struct CopyAchievementDefinitionByAchievementIdOptionsInternal : ISettable<CopyAchievementDefinitionByAchievementIdOptions>, IDisposable
	{
		// Token: 0x0600213A RID: 8506 RVA: 0x00027B48 File Offset: 0x00025D48
		public void Set(ref CopyAchievementDefinitionByAchievementIdOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.AchievementId, ref this.m_AchievementId);
		}

		// Token: 0x0600213B RID: 8507 RVA: 0x00027B68 File Offset: 0x00025D68
		public void Dispose()
		{
			Helper.Dispose(ref this.m_AchievementId);
		}

		// Token: 0x0400162B RID: 5675
		private int m_ApiVersion;

		// Token: 0x0400162C RID: 5676
		private IntPtr m_AchievementId;
	}
}
