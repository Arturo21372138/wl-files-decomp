﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200003B RID: 59
	[AddComponentMenu("UI/Extensions/Range Slider", 34)]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class RangeSlider : Selectable, IDragHandler, IEventSystemHandler, IInitializePotentialDragHandler, ICanvasElement
	{
		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600016C RID: 364 RVA: 0x000087DD File Offset: 0x000069DD
		// (set) Token: 0x0600016D RID: 365 RVA: 0x000087E5 File Offset: 0x000069E5
		public RectTransform FillRect
		{
			get
			{
				return this.m_FillRect;
			}
			set
			{
				if (RangeSlider.SetClass<RectTransform>(ref this.m_FillRect, value))
				{
					this.UpdateCachedReferences();
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x0600016E RID: 366 RVA: 0x00008801 File Offset: 0x00006A01
		// (set) Token: 0x0600016F RID: 367 RVA: 0x00008809 File Offset: 0x00006A09
		public RectTransform LowHandleRect
		{
			get
			{
				return this.m_LowHandleRect;
			}
			set
			{
				if (RangeSlider.SetClass<RectTransform>(ref this.m_LowHandleRect, value))
				{
					this.UpdateCachedReferences();
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x06000170 RID: 368 RVA: 0x00008825 File Offset: 0x00006A25
		// (set) Token: 0x06000171 RID: 369 RVA: 0x0000882D File Offset: 0x00006A2D
		public RectTransform HighHandleRect
		{
			get
			{
				return this.m_HighHandleRect;
			}
			set
			{
				if (RangeSlider.SetClass<RectTransform>(ref this.m_HighHandleRect, value))
				{
					this.UpdateCachedReferences();
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x06000172 RID: 370 RVA: 0x00008849 File Offset: 0x00006A49
		// (set) Token: 0x06000173 RID: 371 RVA: 0x00008851 File Offset: 0x00006A51
		public float MinValue
		{
			get
			{
				return this.m_MinValue;
			}
			set
			{
				if (RangeSlider.SetStruct<float>(ref this.m_MinValue, value))
				{
					this.SetLow(this.m_LowValue);
					this.SetHigh(this.m_HighValue);
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x06000174 RID: 372 RVA: 0x0000887F File Offset: 0x00006A7F
		// (set) Token: 0x06000175 RID: 373 RVA: 0x00008887 File Offset: 0x00006A87
		public float MaxValue
		{
			get
			{
				return this.m_MaxValue;
			}
			set
			{
				if (RangeSlider.SetStruct<float>(ref this.m_MaxValue, value))
				{
					this.SetLow(this.m_LowValue);
					this.SetHigh(this.m_HighValue);
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000176 RID: 374 RVA: 0x000088B5 File Offset: 0x00006AB5
		// (set) Token: 0x06000177 RID: 375 RVA: 0x000088BD File Offset: 0x00006ABD
		public bool WholeNumbers
		{
			get
			{
				return this.m_WholeNumbers;
			}
			set
			{
				if (RangeSlider.SetStruct<bool>(ref this.m_WholeNumbers, value))
				{
					this.SetLow(this.m_LowValue);
					this.SetHigh(this.m_HighValue);
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000178 RID: 376 RVA: 0x000088EB File Offset: 0x00006AEB
		// (set) Token: 0x06000179 RID: 377 RVA: 0x00008907 File Offset: 0x00006B07
		public virtual float LowValue
		{
			get
			{
				if (this.WholeNumbers)
				{
					return Mathf.Round(this.m_LowValue);
				}
				return this.m_LowValue;
			}
			set
			{
				this.SetLow(value);
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x0600017A RID: 378 RVA: 0x00008910 File Offset: 0x00006B10
		// (set) Token: 0x0600017B RID: 379 RVA: 0x00008942 File Offset: 0x00006B42
		public float NormalizedLowValue
		{
			get
			{
				if (Mathf.Approximately(this.MinValue, this.MaxValue))
				{
					return 0f;
				}
				return Mathf.InverseLerp(this.MinValue, this.MaxValue, this.LowValue);
			}
			set
			{
				this.LowValue = Mathf.Lerp(this.MinValue, this.MaxValue, value);
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x0600017C RID: 380 RVA: 0x0000895C File Offset: 0x00006B5C
		// (set) Token: 0x0600017D RID: 381 RVA: 0x00008978 File Offset: 0x00006B78
		public virtual float HighValue
		{
			get
			{
				if (this.WholeNumbers)
				{
					return Mathf.Round(this.m_HighValue);
				}
				return this.m_HighValue;
			}
			set
			{
				this.SetHigh(value);
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600017E RID: 382 RVA: 0x00008981 File Offset: 0x00006B81
		// (set) Token: 0x0600017F RID: 383 RVA: 0x000089B3 File Offset: 0x00006BB3
		public float NormalizedHighValue
		{
			get
			{
				if (Mathf.Approximately(this.MinValue, this.MaxValue))
				{
					return 0f;
				}
				return Mathf.InverseLerp(this.MinValue, this.MaxValue, this.HighValue);
			}
			set
			{
				this.HighValue = Mathf.Lerp(this.MinValue, this.MaxValue, value);
			}
		}

		// Token: 0x06000180 RID: 384 RVA: 0x000089CD File Offset: 0x00006BCD
		public virtual void SetValueWithoutNotify(float low, float high)
		{
			this.SetLow(low, false);
			this.SetHigh(high, false);
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000181 RID: 385 RVA: 0x000089DF File Offset: 0x00006BDF
		// (set) Token: 0x06000182 RID: 386 RVA: 0x000089E7 File Offset: 0x00006BE7
		public RangeSlider.RangeSliderEvent OnValueChanged
		{
			get
			{
				return this.m_OnValueChanged;
			}
			set
			{
				this.m_OnValueChanged = value;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000183 RID: 387 RVA: 0x000089F0 File Offset: 0x00006BF0
		private float StepSize
		{
			get
			{
				if (!this.WholeNumbers)
				{
					return (this.MaxValue - this.MinValue) * 0.1f;
				}
				return 1f;
			}
		}

		// Token: 0x06000184 RID: 388 RVA: 0x00008A13 File Offset: 0x00006C13
		protected RangeSlider()
		{
		}

		// Token: 0x06000185 RID: 389 RVA: 0x00008A4E File Offset: 0x00006C4E
		public virtual void Rebuild(CanvasUpdate executing)
		{
		}

		// Token: 0x06000186 RID: 390 RVA: 0x00008A50 File Offset: 0x00006C50
		public virtual void LayoutComplete()
		{
		}

		// Token: 0x06000187 RID: 391 RVA: 0x00008A52 File Offset: 0x00006C52
		public virtual void GraphicUpdateComplete()
		{
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00008A54 File Offset: 0x00006C54
		public static bool SetClass<T>(ref T currentValue, T newValue) where T : class
		{
			if ((currentValue == null && newValue == null) || (currentValue != null && currentValue.Equals(newValue)))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00008AA1 File Offset: 0x00006CA1
		public static bool SetStruct<T>(ref T currentValue, T newValue) where T : struct
		{
			if (currentValue.Equals(newValue))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x0600018A RID: 394 RVA: 0x00008AC1 File Offset: 0x00006CC1
		protected override void OnEnable()
		{
			base.OnEnable();
			this.UpdateCachedReferences();
			this.SetLow(this.LowValue, false);
			this.SetHigh(this.HighValue, false);
			this.UpdateVisuals();
		}

		// Token: 0x0600018B RID: 395 RVA: 0x00008AEF File Offset: 0x00006CEF
		protected override void OnDisable()
		{
			this.m_Tracker.Clear();
			base.OnDisable();
		}

		// Token: 0x0600018C RID: 396 RVA: 0x00008B02 File Offset: 0x00006D02
		protected virtual void Update()
		{
			if (this.m_DelayedUpdateVisuals)
			{
				this.m_DelayedUpdateVisuals = false;
				this.UpdateVisuals();
			}
		}

		// Token: 0x0600018D RID: 397 RVA: 0x00008B19 File Offset: 0x00006D19
		protected override void OnDidApplyAnimationProperties()
		{
			base.OnDidApplyAnimationProperties();
		}

		// Token: 0x0600018E RID: 398 RVA: 0x00008B24 File Offset: 0x00006D24
		private void UpdateCachedReferences()
		{
			if (this.m_FillRect && this.m_FillRect != (RectTransform)base.transform)
			{
				this.m_FillTransform = this.m_FillRect.transform;
				this.m_FillImage = this.m_FillRect.GetComponent<Image>();
				if (this.m_FillTransform.parent != null)
				{
					this.m_FillContainerRect = this.m_FillTransform.parent.GetComponent<RectTransform>();
				}
			}
			else
			{
				this.m_FillRect = null;
				this.m_FillContainerRect = null;
				this.m_FillImage = null;
			}
			if (this.m_HighHandleRect && this.m_HighHandleRect != (RectTransform)base.transform)
			{
				this.m_HighHandleTransform = this.m_HighHandleRect.transform;
				if (this.m_HighHandleTransform.parent != null)
				{
					this.m_HighHandleContainerRect = this.m_HighHandleTransform.parent.GetComponent<RectTransform>();
				}
			}
			else
			{
				this.m_HighHandleRect = null;
				this.m_HighHandleContainerRect = null;
			}
			if (this.m_LowHandleRect && this.m_LowHandleRect != (RectTransform)base.transform)
			{
				this.m_LowHandleTransform = this.m_LowHandleRect.transform;
				if (this.m_LowHandleTransform.parent != null)
				{
					this.m_LowHandleContainerRect = this.m_LowHandleTransform.parent.GetComponent<RectTransform>();
					return;
				}
			}
			else
			{
				this.m_LowHandleRect = null;
				this.m_LowHandleContainerRect = null;
			}
		}

		// Token: 0x0600018F RID: 399 RVA: 0x00008C95 File Offset: 0x00006E95
		private void SetLow(float input)
		{
			this.SetLow(input, true);
		}

		// Token: 0x06000190 RID: 400 RVA: 0x00008CA0 File Offset: 0x00006EA0
		protected virtual void SetLow(float input, bool sendCallback)
		{
			float num = Mathf.Clamp(input, this.MinValue, this.HighValue);
			if (this.WholeNumbers)
			{
				num = Mathf.Round(num);
			}
			if (this.m_LowValue == num)
			{
				return;
			}
			this.m_LowValue = num;
			this.UpdateVisuals();
			if (sendCallback)
			{
				UISystemProfilerApi.AddMarker("RangeSlider.lowValue", this);
				this.m_OnValueChanged.Invoke(num, this.HighValue);
			}
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00008D06 File Offset: 0x00006F06
		private void SetHigh(float input)
		{
			this.SetHigh(input, true);
		}

		// Token: 0x06000192 RID: 402 RVA: 0x00008D10 File Offset: 0x00006F10
		protected virtual void SetHigh(float input, bool sendCallback)
		{
			float num = Mathf.Clamp(input, this.LowValue, this.MaxValue);
			if (this.WholeNumbers)
			{
				num = Mathf.Round(num);
			}
			if (this.m_HighValue == num)
			{
				return;
			}
			this.m_HighValue = num;
			this.UpdateVisuals();
			if (sendCallback)
			{
				UISystemProfilerApi.AddMarker("RangeSlider.highValue", this);
				this.m_OnValueChanged.Invoke(this.LowValue, num);
			}
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00008D76 File Offset: 0x00006F76
		protected override void OnRectTransformDimensionsChange()
		{
			base.OnRectTransformDimensionsChange();
			if (!this.IsActive())
			{
				return;
			}
			this.UpdateVisuals();
		}

		// Token: 0x06000194 RID: 404 RVA: 0x00008D90 File Offset: 0x00006F90
		private void UpdateVisuals()
		{
			this.m_Tracker.Clear();
			if (this.m_FillContainerRect != null)
			{
				this.m_Tracker.Add(this, this.m_FillRect, DrivenTransformProperties.Anchors);
				Vector2 zero = Vector2.zero;
				Vector2 one = Vector2.one;
				zero[0] = this.NormalizedLowValue;
				one[0] = this.NormalizedHighValue;
				this.m_FillRect.anchorMin = zero;
				this.m_FillRect.anchorMax = one;
			}
			if (this.m_LowHandleContainerRect != null)
			{
				this.m_Tracker.Add(this, this.m_LowHandleRect, DrivenTransformProperties.Anchors);
				Vector2 zero2 = Vector2.zero;
				Vector2 one2 = Vector2.one;
				zero2[0] = (one2[0] = this.NormalizedLowValue);
				this.m_LowHandleRect.anchorMin = zero2;
				this.m_LowHandleRect.anchorMax = one2;
			}
			if (this.m_HighHandleContainerRect != null)
			{
				this.m_Tracker.Add(this, this.m_HighHandleRect, DrivenTransformProperties.Anchors);
				Vector2 zero3 = Vector2.zero;
				Vector2 one3 = Vector2.one;
				zero3[0] = (one3[0] = this.NormalizedHighValue);
				this.m_HighHandleRect.anchorMin = zero3;
				this.m_HighHandleRect.anchorMax = one3;
			}
		}

		// Token: 0x06000195 RID: 405 RVA: 0x00008EDC File Offset: 0x000070DC
		private void UpdateDrag(PointerEventData eventData, Camera cam)
		{
			switch (this.interactionState)
			{
			case RangeSlider.InteractionState.Low:
				this.NormalizedLowValue = this.CalculateDrag(eventData, cam, this.m_LowHandleContainerRect, this.m_LowOffset);
				return;
			case RangeSlider.InteractionState.High:
				this.NormalizedHighValue = this.CalculateDrag(eventData, cam, this.m_HighHandleContainerRect, this.m_HighOffset);
				return;
			case RangeSlider.InteractionState.Bar:
				this.CalculateBarDrag(eventData, cam);
				break;
			case RangeSlider.InteractionState.None:
				break;
			default:
				return;
			}
		}

		// Token: 0x06000196 RID: 406 RVA: 0x00008F48 File Offset: 0x00007148
		private float CalculateDrag(PointerEventData eventData, Camera cam, RectTransform containerRect, Vector2 offset)
		{
			RectTransform rectTransform = containerRect ?? this.m_FillContainerRect;
			if (!(rectTransform != null) || rectTransform.rect.size[0] <= 0f)
			{
				return 0f;
			}
			Vector2 vector;
			if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(rectTransform, eventData.position, cam, out vector))
			{
				return 0f;
			}
			vector -= rectTransform.rect.position;
			return Mathf.Clamp01((vector - offset)[0] / rectTransform.rect.size[0]);
		}

		// Token: 0x06000197 RID: 407 RVA: 0x00008FE8 File Offset: 0x000071E8
		private void CalculateBarDrag(PointerEventData eventData, Camera cam)
		{
			RectTransform fillContainerRect = this.m_FillContainerRect;
			if (fillContainerRect != null && fillContainerRect.rect.size[0] > 0f)
			{
				Vector2 vector;
				if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(fillContainerRect, eventData.position, cam, out vector))
				{
					return;
				}
				vector -= fillContainerRect.rect.position;
				if (this.NormalizedLowValue >= 0f && this.NormalizedHighValue <= 1f)
				{
					float num = (this.NormalizedHighValue + this.NormalizedLowValue) / 2f;
					float num2 = Mathf.Clamp01(vector[0] / fillContainerRect.rect.size[0]) - num;
					if (this.NormalizedLowValue + num2 < 0f)
					{
						num2 = -this.NormalizedLowValue;
					}
					else if (this.NormalizedHighValue + num2 > 1f)
					{
						num2 = 1f - this.NormalizedHighValue;
					}
					this.NormalizedLowValue += num2;
					this.NormalizedHighValue += num2;
				}
			}
		}

		// Token: 0x06000198 RID: 408 RVA: 0x00009106 File Offset: 0x00007306
		private bool MayDrag(PointerEventData eventData)
		{
			return this.IsActive() && this.IsInteractable() && eventData.button == PointerEventData.InputButton.Left;
		}

		// Token: 0x06000199 RID: 409 RVA: 0x00009124 File Offset: 0x00007324
		public override void OnPointerDown(PointerEventData eventData)
		{
			if (!this.MayDrag(eventData))
			{
				return;
			}
			this.m_LowOffset = (this.m_HighOffset = Vector2.zero);
			if (this.m_HighHandleRect != null && RectTransformUtility.RectangleContainsScreenPoint(this.m_HighHandleRect, eventData.position, eventData.enterEventCamera))
			{
				Vector2 vector;
				if (RectTransformUtility.ScreenPointToLocalPointInRectangle(this.m_HighHandleRect, eventData.position, eventData.pressEventCamera, out vector))
				{
					this.m_HighOffset = vector;
				}
				this.interactionState = RangeSlider.InteractionState.High;
				if (base.transition == Selectable.Transition.ColorTint)
				{
					base.targetGraphic = this.m_HighHandleRect.GetComponent<Graphic>();
				}
			}
			else if (this.m_LowHandleRect != null && RectTransformUtility.RectangleContainsScreenPoint(this.m_LowHandleRect, eventData.position, eventData.enterEventCamera))
			{
				Vector2 vector;
				if (RectTransformUtility.ScreenPointToLocalPointInRectangle(this.m_LowHandleRect, eventData.position, eventData.pressEventCamera, out vector))
				{
					this.m_LowOffset = vector;
				}
				this.interactionState = RangeSlider.InteractionState.Low;
				if (base.transition == Selectable.Transition.ColorTint)
				{
					base.targetGraphic = this.m_LowHandleRect.GetComponent<Graphic>();
				}
			}
			else
			{
				this.UpdateDrag(eventData, eventData.pressEventCamera);
				this.interactionState = RangeSlider.InteractionState.Bar;
				if (base.transition == Selectable.Transition.ColorTint)
				{
					base.targetGraphic = this.m_FillImage;
				}
			}
			base.OnPointerDown(eventData);
		}

		// Token: 0x0600019A RID: 410 RVA: 0x0000925D File Offset: 0x0000745D
		public virtual void OnDrag(PointerEventData eventData)
		{
			if (!this.MayDrag(eventData))
			{
				return;
			}
			this.UpdateDrag(eventData, eventData.pressEventCamera);
		}

		// Token: 0x0600019B RID: 411 RVA: 0x00009276 File Offset: 0x00007476
		public override void OnPointerUp(PointerEventData eventData)
		{
			base.OnPointerUp(eventData);
			this.interactionState = RangeSlider.InteractionState.None;
		}

		// Token: 0x0600019C RID: 412 RVA: 0x00009286 File Offset: 0x00007486
		public override void OnMove(AxisEventData eventData)
		{
		}

		// Token: 0x0600019D RID: 413 RVA: 0x00009288 File Offset: 0x00007488
		public virtual void OnInitializePotentialDrag(PointerEventData eventData)
		{
			eventData.useDragThreshold = false;
		}

		// Token: 0x0600019E RID: 414 RVA: 0x00009291 File Offset: 0x00007491
		Transform ICanvasElement.get_transform()
		{
			return base.transform;
		}

		// Token: 0x04000151 RID: 337
		[SerializeField]
		private RectTransform m_FillRect;

		// Token: 0x04000152 RID: 338
		[SerializeField]
		private RectTransform m_LowHandleRect;

		// Token: 0x04000153 RID: 339
		[SerializeField]
		private RectTransform m_HighHandleRect;

		// Token: 0x04000154 RID: 340
		[Space]
		[SerializeField]
		private float m_MinValue;

		// Token: 0x04000155 RID: 341
		[SerializeField]
		private float m_MaxValue = 1f;

		// Token: 0x04000156 RID: 342
		[SerializeField]
		private bool m_WholeNumbers;

		// Token: 0x04000157 RID: 343
		[SerializeField]
		private float m_LowValue;

		// Token: 0x04000158 RID: 344
		[SerializeField]
		private float m_HighValue;

		// Token: 0x04000159 RID: 345
		[Space]
		[SerializeField]
		private RangeSlider.RangeSliderEvent m_OnValueChanged = new RangeSlider.RangeSliderEvent();

		// Token: 0x0400015A RID: 346
		private RangeSlider.InteractionState interactionState = RangeSlider.InteractionState.None;

		// Token: 0x0400015B RID: 347
		private Image m_FillImage;

		// Token: 0x0400015C RID: 348
		private Transform m_FillTransform;

		// Token: 0x0400015D RID: 349
		private RectTransform m_FillContainerRect;

		// Token: 0x0400015E RID: 350
		private Transform m_HighHandleTransform;

		// Token: 0x0400015F RID: 351
		private RectTransform m_HighHandleContainerRect;

		// Token: 0x04000160 RID: 352
		private Transform m_LowHandleTransform;

		// Token: 0x04000161 RID: 353
		private RectTransform m_LowHandleContainerRect;

		// Token: 0x04000162 RID: 354
		private Vector2 m_LowOffset = Vector2.zero;

		// Token: 0x04000163 RID: 355
		private Vector2 m_HighOffset = Vector2.zero;

		// Token: 0x04000164 RID: 356
		private DrivenRectTransformTracker m_Tracker;

		// Token: 0x04000165 RID: 357
		private bool m_DelayedUpdateVisuals;

		// Token: 0x02000114 RID: 276
		[Serializable]
		public class RangeSliderEvent : UnityEvent<float, float>
		{
		}

		// Token: 0x02000115 RID: 277
		private enum InteractionState
		{
			// Token: 0x04000624 RID: 1572
			Low,
			// Token: 0x04000625 RID: 1573
			High,
			// Token: 0x04000626 RID: 1574
			Bar,
			// Token: 0x04000627 RID: 1575
			None
		}
	}
}
