﻿using System;
using System.Collections;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000CA RID: 202
	[AddComponentMenu("UI/Extensions/UI Tween Scale")]
	public class UI_TweenScale : MonoBehaviour
	{
		// Token: 0x0600069F RID: 1695 RVA: 0x00026899 File Offset: 0x00024A99
		private void Awake()
		{
			this.myTransform = base.GetComponent<Transform>();
			this.initScale = this.myTransform.localScale;
			if (this.playAtAwake)
			{
				this.Play();
			}
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x000268C6 File Offset: 0x00024AC6
		public void Play()
		{
			base.StartCoroutine("Tween");
		}

		// Token: 0x060006A1 RID: 1697 RVA: 0x000268D4 File Offset: 0x00024AD4
		private IEnumerator Tween()
		{
			this.myTransform.localScale = this.initScale;
			float t = 0f;
			float maxT = this.animCurve.keys[this.animCurve.length - 1].time;
			while (t < maxT || this.isLoop)
			{
				t += this.speed * Time.deltaTime;
				if (!this.isUniform)
				{
					this.newScale.x = 1f * this.animCurve.Evaluate(t);
					this.newScale.y = 1f * this.animCurveY.Evaluate(t);
					this.myTransform.localScale = this.newScale;
				}
				else
				{
					this.myTransform.localScale = Vector3.one * this.animCurve.Evaluate(t);
				}
				yield return null;
			}
			yield break;
		}

		// Token: 0x060006A2 RID: 1698 RVA: 0x000268E3 File Offset: 0x00024AE3
		public void ResetTween()
		{
			base.StopCoroutine("Tween");
			this.myTransform.localScale = this.initScale;
		}

		// Token: 0x040004DB RID: 1243
		public AnimationCurve animCurve;

		// Token: 0x040004DC RID: 1244
		[Tooltip("Animation speed multiplier")]
		public float speed = 1f;

		// Token: 0x040004DD RID: 1245
		[Tooltip("If true animation will loop, for best effect set animation curve to loop on start and end point")]
		public bool isLoop;

		// Token: 0x040004DE RID: 1246
		[Tooltip("If true animation will start automatically, otherwise you need to call Play() method to start the animation")]
		public bool playAtAwake;

		// Token: 0x040004DF RID: 1247
		[Space(10f)]
		[Header("Non uniform scale")]
		[Tooltip("If true component will scale by the same amount in X and Y axis, otherwise use animCurve for X scale and animCurveY for Y scale")]
		public bool isUniform = true;

		// Token: 0x040004E0 RID: 1248
		public AnimationCurve animCurveY;

		// Token: 0x040004E1 RID: 1249
		private Vector3 initScale;

		// Token: 0x040004E2 RID: 1250
		private Transform myTransform;

		// Token: 0x040004E3 RID: 1251
		private Vector3 newScale = Vector3.one;
	}
}
