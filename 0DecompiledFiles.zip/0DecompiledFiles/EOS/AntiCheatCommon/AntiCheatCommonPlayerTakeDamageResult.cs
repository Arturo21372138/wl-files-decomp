﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000775 RID: 1909
	public enum AntiCheatCommonPlayerTakeDamageResult
	{
		// Token: 0x040014C0 RID: 5312
		None,
		// Token: 0x040014C1 RID: 5313
		DownedDeprecated,
		// Token: 0x040014C2 RID: 5314
		EliminatedDeprecated,
		// Token: 0x040014C3 RID: 5315
		NormalToDowned,
		// Token: 0x040014C4 RID: 5316
		NormalToEliminated,
		// Token: 0x040014C5 RID: 5317
		DownedToEliminated
	}
}
