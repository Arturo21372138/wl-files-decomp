﻿using System;

namespace UnityEngine.UI.Extensions.Tweens
{
	// Token: 0x020000DC RID: 220
	internal interface ITweenValue
	{
		// Token: 0x06000740 RID: 1856
		void TweenValue(float floatPercentage);

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000741 RID: 1857
		bool ignoreTimeScale { get; }

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x06000742 RID: 1858
		float duration { get; }

		// Token: 0x06000743 RID: 1859
		bool ValidTarget();

		// Token: 0x06000744 RID: 1860
		void Finished();
	}
}
