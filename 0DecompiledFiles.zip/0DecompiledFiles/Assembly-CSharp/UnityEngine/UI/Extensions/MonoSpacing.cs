﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200005A RID: 90
	[AddComponentMenu("UI/Effects/Extensions/Mono Spacing")]
	[RequireComponent(typeof(Text))]
	[RequireComponent(typeof(RectTransform))]
	public class MonoSpacing : BaseMeshEffect
	{
		// Token: 0x060002C6 RID: 710 RVA: 0x000115FF File Offset: 0x0000F7FF
		protected MonoSpacing()
		{
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00011612 File Offset: 0x0000F812
		protected override void Awake()
		{
			this.text = base.GetComponent<Text>();
			if (this.text == null)
			{
				Debug.LogWarning("MonoSpacing: Missing Text component");
				return;
			}
			this.rectTransform = this.text.GetComponent<RectTransform>();
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060002C8 RID: 712 RVA: 0x0001164A File Offset: 0x0000F84A
		// (set) Token: 0x060002C9 RID: 713 RVA: 0x00011652 File Offset: 0x0000F852
		public float Spacing
		{
			get
			{
				return this.m_spacing;
			}
			set
			{
				if (this.m_spacing == value)
				{
					return;
				}
				this.m_spacing = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00011680 File Offset: 0x0000F880
		public override void ModifyMesh(VertexHelper vh)
		{
			if (!this.IsActive())
			{
				return;
			}
			List<UIVertex> list = new List<UIVertex>();
			vh.GetUIVertexStream(list);
			string[] array = this.text.text.Split('\n', StringSplitOptions.None);
			float num = this.Spacing * (float)this.text.fontSize / 100f;
			float num2 = 0f;
			int num3 = 0;
			switch (this.text.alignment)
			{
			case TextAnchor.UpperLeft:
			case TextAnchor.MiddleLeft:
			case TextAnchor.LowerLeft:
				num2 = 0f;
				break;
			case TextAnchor.UpperCenter:
			case TextAnchor.MiddleCenter:
			case TextAnchor.LowerCenter:
				num2 = 0.5f;
				break;
			case TextAnchor.UpperRight:
			case TextAnchor.MiddleRight:
			case TextAnchor.LowerRight:
				num2 = 1f;
				break;
			}
			foreach (string text in array)
			{
				float num4 = -((float)(text.Length - 1) * num * num2 - (num2 - 0.5f) * this.rectTransform.rect.width) + num / 2f * (1f - num2 * 2f);
				for (int j = 0; j < text.Length; j++)
				{
					int num5 = num3 * 6;
					int num6 = num3 * 6 + 1;
					int num7 = num3 * 6 + 2;
					int num8 = num3 * 6 + 3;
					int num9 = num3 * 6 + 4;
					int num10 = num3 * 6 + 5;
					if (num10 > list.Count - 1)
					{
						return;
					}
					UIVertex uivertex = list[num5];
					UIVertex uivertex2 = list[num6];
					UIVertex uivertex3 = list[num7];
					UIVertex uivertex4 = list[num8];
					UIVertex uivertex5 = list[num9];
					UIVertex uivertex6 = list[num10];
					float x = (uivertex2.position - uivertex.position).x;
					bool flag = this.UseHalfCharWidth && x < this.HalfCharWidth;
					float num11 = (flag ? (-num / 4f) : 0f);
					uivertex.position += new Vector3(-uivertex.position.x + num4 + -0.5f * x + num11, 0f, 0f);
					uivertex2.position += new Vector3(-uivertex2.position.x + num4 + 0.5f * x + num11, 0f, 0f);
					uivertex3.position += new Vector3(-uivertex3.position.x + num4 + 0.5f * x + num11, 0f, 0f);
					uivertex4.position += new Vector3(-uivertex4.position.x + num4 + 0.5f * x + num11, 0f, 0f);
					uivertex5.position += new Vector3(-uivertex5.position.x + num4 + -0.5f * x + num11, 0f, 0f);
					uivertex6.position += new Vector3(-uivertex6.position.x + num4 + -0.5f * x + num11, 0f, 0f);
					if (flag)
					{
						num4 += num / 2f;
					}
					else
					{
						num4 += num;
					}
					list[num5] = uivertex;
					list[num6] = uivertex2;
					list[num7] = uivertex3;
					list[num8] = uivertex4;
					list[num9] = uivertex5;
					list[num10] = uivertex6;
					num3++;
				}
				num3++;
			}
			vh.Clear();
			vh.AddUIVertexTriangleStream(list);
		}

		// Token: 0x0400022E RID: 558
		[SerializeField]
		private float m_spacing;

		// Token: 0x0400022F RID: 559
		public float HalfCharWidth = 1f;

		// Token: 0x04000230 RID: 560
		public bool UseHalfCharWidth;

		// Token: 0x04000231 RID: 561
		private RectTransform rectTransform;

		// Token: 0x04000232 RID: 562
		private Text text;
	}
}
