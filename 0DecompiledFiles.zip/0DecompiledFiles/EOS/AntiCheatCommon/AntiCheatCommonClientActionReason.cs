﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200076A RID: 1898
	public enum AntiCheatCommonClientActionReason
	{
		// Token: 0x0400146C RID: 5228
		Invalid,
		// Token: 0x0400146D RID: 5229
		InternalError,
		// Token: 0x0400146E RID: 5230
		InvalidMessage,
		// Token: 0x0400146F RID: 5231
		AuthenticationFailed,
		// Token: 0x04001470 RID: 5232
		NullClient,
		// Token: 0x04001471 RID: 5233
		HeartbeatTimeout,
		// Token: 0x04001472 RID: 5234
		ClientViolation,
		// Token: 0x04001473 RID: 5235
		BackendViolation,
		// Token: 0x04001474 RID: 5236
		TemporaryCooldown,
		// Token: 0x04001475 RID: 5237
		TemporaryBanned,
		// Token: 0x04001476 RID: 5238
		PermanentBanned
	}
}
