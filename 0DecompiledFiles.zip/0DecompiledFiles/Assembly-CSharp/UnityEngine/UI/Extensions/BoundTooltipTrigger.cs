﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A7 RID: 167
	[AddComponentMenu("UI/Extensions/Bound Tooltip/Bound Tooltip Trigger")]
	public class BoundTooltipTrigger : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler
	{
		// Token: 0x06000590 RID: 1424 RVA: 0x00021614 File Offset: 0x0001F814
		public void OnPointerEnter(PointerEventData eventData)
		{
			if (this.useMousePosition)
			{
				this.StartHover(new Vector3(eventData.position.x, eventData.position.y, 0f));
				return;
			}
			this.StartHover(base.transform.position + this.offset);
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x0002166C File Offset: 0x0001F86C
		public void OnSelect(BaseEventData eventData)
		{
			this.StartHover(base.transform.position);
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0002167F File Offset: 0x0001F87F
		public void OnPointerExit(PointerEventData eventData)
		{
			this.StopHover();
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x00021687 File Offset: 0x0001F887
		public void OnDeselect(BaseEventData eventData)
		{
			this.StopHover();
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0002168F File Offset: 0x0001F88F
		private void StartHover(Vector3 position)
		{
			BoundTooltipItem.Instance.ShowTooltip(this.text, position);
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x000216A2 File Offset: 0x0001F8A2
		private void StopHover()
		{
			BoundTooltipItem.Instance.HideTooltip();
		}

		// Token: 0x04000419 RID: 1049
		[TextArea]
		public string text;

		// Token: 0x0400041A RID: 1050
		public bool useMousePosition;

		// Token: 0x0400041B RID: 1051
		public Vector3 offset;
	}
}
