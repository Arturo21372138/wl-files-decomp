﻿using System;
using UnityEngine;

namespace NatureRendererDemo
{
	// Token: 0x02000017 RID: 23
	public class OpenWebsiteButton : MonoBehaviour
	{
		// Token: 0x06000036 RID: 54 RVA: 0x000034EB File Offset: 0x000016EB
		public void OnButtonClicked()
		{
			Application.OpenURL("https://v3.visualdesigncafe.com/nature-renderer/docs/2022/quickstart?utm_source=unity-editor&utm_medium=referral&utm_campaign=nature-renderer-2022-demo-scene");
		}
	}
}
