﻿using System;
using UnityEngine;

namespace Cinemachine
{
	// Token: 0x02000030 RID: 48
	internal class StaticPointVirtualCamera : ICinemachineCamera
	{
		// Token: 0x06000233 RID: 563 RVA: 0x00011609 File Offset: 0x0000F809
		public StaticPointVirtualCamera(CameraState state, string name)
		{
			this.State = state;
			this.Name = name;
		}

		// Token: 0x06000234 RID: 564 RVA: 0x0001161F File Offset: 0x0000F81F
		public void SetState(CameraState state)
		{
			this.State = state;
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000235 RID: 565 RVA: 0x00011628 File Offset: 0x0000F828
		// (set) Token: 0x06000236 RID: 566 RVA: 0x00011630 File Offset: 0x0000F830
		public string Name { get; private set; }

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000237 RID: 567 RVA: 0x00011639 File Offset: 0x0000F839
		public string Description
		{
			get
			{
				return "";
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000238 RID: 568 RVA: 0x00011640 File Offset: 0x0000F840
		// (set) Token: 0x06000239 RID: 569 RVA: 0x00011648 File Offset: 0x0000F848
		public int Priority { get; set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x0600023A RID: 570 RVA: 0x00011651 File Offset: 0x0000F851
		// (set) Token: 0x0600023B RID: 571 RVA: 0x00011659 File Offset: 0x0000F859
		public Transform LookAt { get; set; }

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x0600023C RID: 572 RVA: 0x00011662 File Offset: 0x0000F862
		// (set) Token: 0x0600023D RID: 573 RVA: 0x0001166A File Offset: 0x0000F86A
		public Transform Follow { get; set; }

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x0600023E RID: 574 RVA: 0x00011673 File Offset: 0x0000F873
		// (set) Token: 0x0600023F RID: 575 RVA: 0x0001167B File Offset: 0x0000F87B
		public CameraState State { get; private set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000240 RID: 576 RVA: 0x00011684 File Offset: 0x0000F884
		public GameObject VirtualCameraGameObject
		{
			get
			{
				return null;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06000241 RID: 577 RVA: 0x00011687 File Offset: 0x0000F887
		public bool IsValid
		{
			get
			{
				return true;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000242 RID: 578 RVA: 0x0001168A File Offset: 0x0000F88A
		public ICinemachineCamera ParentCamera
		{
			get
			{
				return null;
			}
		}

		// Token: 0x06000243 RID: 579 RVA: 0x0001168D File Offset: 0x0000F88D
		public bool IsLiveChild(ICinemachineCamera vcam, bool dominantChildOnly = false)
		{
			return false;
		}

		// Token: 0x06000244 RID: 580 RVA: 0x00011690 File Offset: 0x0000F890
		public void UpdateCameraState(Vector3 worldUp, float deltaTime)
		{
		}

		// Token: 0x06000245 RID: 581 RVA: 0x00011692 File Offset: 0x0000F892
		public void InternalUpdateCameraState(Vector3 worldUp, float deltaTime)
		{
		}

		// Token: 0x06000246 RID: 582 RVA: 0x00011694 File Offset: 0x0000F894
		public void OnTransitionFromCamera(ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime)
		{
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00011696 File Offset: 0x0000F896
		public void OnTargetObjectWarped(Transform target, Vector3 positionDelta)
		{
		}
	}
}
