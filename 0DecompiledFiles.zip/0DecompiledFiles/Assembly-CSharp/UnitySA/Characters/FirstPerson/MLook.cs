﻿using System;
using UnityEngine;

namespace UnitySA.Characters.FirstPerson
{
	// Token: 0x0200001C RID: 28
	[Serializable]
	public class MLook
	{
		// Token: 0x0600004F RID: 79 RVA: 0x00004017 File Offset: 0x00002217
		public void Init(Transform character, Transform camera)
		{
			this.m_CharacterTargetRot = character.localRotation;
			this.m_CameraTargetRot = camera.localRotation;
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004034 File Offset: 0x00002234
		public void LookRotation(Transform character, Transform camera)
		{
			float num = Input.GetAxis("Mouse X") * this.XSensitivity;
			float num2 = Input.GetAxis("Mouse Y") * this.YSensitivity;
			this.m_CharacterTargetRot *= Quaternion.Euler(0f, num, 0f);
			this.m_CameraTargetRot *= Quaternion.Euler(-num2, 0f, 0f);
			if (this.clampVerticalRotation)
			{
				this.m_CameraTargetRot = this.ClampRotationAroundXAxis(this.m_CameraTargetRot);
			}
			if (this.smooth)
			{
				character.localRotation = Quaternion.Slerp(character.localRotation, this.m_CharacterTargetRot, this.smoothTime * Time.deltaTime);
				camera.localRotation = Quaternion.Slerp(camera.localRotation, this.m_CameraTargetRot, this.smoothTime * Time.deltaTime);
			}
			else
			{
				character.localRotation = this.m_CharacterTargetRot;
				camera.localRotation = this.m_CameraTargetRot;
			}
			this.UpdateCursorLock();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00004130 File Offset: 0x00002330
		public void SetCursorLock(bool value)
		{
			this.lockCursor = value;
			if (!this.lockCursor)
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x0000414D File Offset: 0x0000234D
		public void UpdateCursorLock()
		{
			if (this.lockCursor)
			{
				this.InternalLockUpdate();
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00004160 File Offset: 0x00002360
		private void InternalLockUpdate()
		{
			if (Input.GetKeyUp(KeyCode.Escape))
			{
				this.m_cursorIsLocked = false;
			}
			else if (Input.GetMouseButtonUp(0))
			{
				this.m_cursorIsLocked = true;
			}
			if (this.m_cursorIsLocked)
			{
				Cursor.lockState = CursorLockMode.Locked;
				Cursor.visible = false;
				return;
			}
			if (!this.m_cursorIsLocked)
			{
				Cursor.lockState = CursorLockMode.None;
				Cursor.visible = true;
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000041B8 File Offset: 0x000023B8
		private Quaternion ClampRotationAroundXAxis(Quaternion q)
		{
			q.x /= q.w;
			q.y /= q.w;
			q.z /= q.w;
			q.w = 1f;
			float num = 114.59156f * Mathf.Atan(q.x);
			num = Mathf.Clamp(num, this.MinimumX, this.MaximumX);
			q.x = Mathf.Tan(0.008726646f * num);
			return q;
		}

		// Token: 0x0400006D RID: 109
		public float XSensitivity = 2f;

		// Token: 0x0400006E RID: 110
		public float YSensitivity = 2f;

		// Token: 0x0400006F RID: 111
		public bool clampVerticalRotation = true;

		// Token: 0x04000070 RID: 112
		public float MinimumX = -90f;

		// Token: 0x04000071 RID: 113
		public float MaximumX = 90f;

		// Token: 0x04000072 RID: 114
		public bool smooth;

		// Token: 0x04000073 RID: 115
		public float smoothTime = 5f;

		// Token: 0x04000074 RID: 116
		public bool lockCursor = true;

		// Token: 0x04000075 RID: 117
		private Quaternion m_CharacterTargetRot;

		// Token: 0x04000076 RID: 118
		private Quaternion m_CameraTargetRot;

		// Token: 0x04000077 RID: 119
		private bool m_cursorIsLocked = true;
	}
}
