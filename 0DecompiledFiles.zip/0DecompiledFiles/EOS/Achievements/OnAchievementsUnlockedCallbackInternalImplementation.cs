﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007FD RID: 2045
	internal static class OnAchievementsUnlockedCallbackInternalImplementation
	{
		// Token: 0x1700085D RID: 2141
		// (get) Token: 0x060021A2 RID: 8610 RVA: 0x000281DE File Offset: 0x000263DE
		public static OnAchievementsUnlockedCallbackInternal Delegate
		{
			get
			{
				if (OnAchievementsUnlockedCallbackInternalImplementation.s_Delegate == null)
				{
					OnAchievementsUnlockedCallbackInternalImplementation.s_Delegate = new OnAchievementsUnlockedCallbackInternal(OnAchievementsUnlockedCallbackInternalImplementation.EntryPoint);
				}
				return OnAchievementsUnlockedCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060021A3 RID: 8611 RVA: 0x00028200 File Offset: 0x00026400
		[MonoPInvokeCallback(typeof(OnAchievementsUnlockedCallbackInternal))]
		public static void EntryPoint(ref OnAchievementsUnlockedCallbackInfoInternal data)
		{
			OnAchievementsUnlockedCallback onAchievementsUnlockedCallback;
			OnAchievementsUnlockedCallbackInfo onAchievementsUnlockedCallbackInfo;
			if (Helper.TryGetCallback<OnAchievementsUnlockedCallbackInfoInternal, OnAchievementsUnlockedCallback, OnAchievementsUnlockedCallbackInfo>(ref data, out onAchievementsUnlockedCallback, out onAchievementsUnlockedCallbackInfo))
			{
				onAchievementsUnlockedCallback(ref onAchievementsUnlockedCallbackInfo);
			}
		}

		// Token: 0x04001683 RID: 5763
		private static OnAchievementsUnlockedCallbackInternal s_Delegate;
	}
}
