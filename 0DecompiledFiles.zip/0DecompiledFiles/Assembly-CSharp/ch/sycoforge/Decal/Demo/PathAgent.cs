﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000025 RID: 37
	[RequireComponent(typeof(NavMeshAgent))]
	[RequireComponent(typeof(LineRenderer))]
	public class PathAgent : MonoBehaviour
	{
		// Token: 0x06000070 RID: 112 RVA: 0x00004C10 File Offset: 0x00002E10
		private void Start()
		{
			this.TargetAimDecal.gameObject.SetActive(false);
			this.agent = base.GetComponent<NavMeshAgent>();
			this.lineRenderer = base.GetComponent<LineRenderer>();
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00004C3C File Offset: 0x00002E3C
		private void Update()
		{
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			this.CreatePath(ray);
			this.SetTarget(ray);
		}

		// Token: 0x06000072 RID: 114 RVA: 0x00004C68 File Offset: 0x00002E68
		private void SetTarget(Ray mouseRay)
		{
			RaycastHit raycastHit;
			if (Input.GetMouseButtonUp(0) && Physics.Raycast(mouseRay, out raycastHit, 50f))
			{
				this.agent.SetDestination(raycastHit.point);
				EasyDecal.ProjectAt(this.TargetPointDecalPrefab, raycastHit.collider.gameObject, raycastHit.point + this.decalOffset, Quaternion.identity, true);
			}
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00004CD0 File Offset: 0x00002ED0
		private void CreatePath(Ray mouseRay)
		{
			RaycastHit raycastHit;
			if (Physics.Raycast(mouseRay, out raycastHit, 50f))
			{
				Vector3 position = base.transform.position;
				Vector3 point = raycastHit.point;
				this.path.Clear();
				NavMeshPath navMeshPath = new NavMeshPath();
				if (NavMesh.CalculatePath(position, point, -1, navMeshPath) && navMeshPath.status == NavMeshPathStatus.PathComplete)
				{
					int num = navMeshPath.corners.Length;
					Vector3 vector = base.transform.up;
					for (int i = 0; i < num; i++)
					{
						RaycastHit raycastHit2;
						if (i > 0 && this.NormalPathOffset > 0f && Physics.Raycast(navMeshPath.corners[i], Vector3.down, out raycastHit2, this.NormalPathOffset * 10f))
						{
							vector = raycastHit.normal;
						}
						Vector3 vector2 = navMeshPath.corners[i] + vector * this.NormalPathOffset;
						this.path.Add(vector2);
					}
					Vector3[] array = BezierUtil.InterpolatePath(this.path, 10, this.Radius, this.AngleThreshold).ToArray();
					this.lineRenderer.SetVertexCount(array.Length);
					this.lineRenderer.SetPositions(array);
					this.TargetAimDecal.gameObject.SetActive(true);
					this.TargetAimDecal.gameObject.transform.position = navMeshPath.corners[num - 1] + this.decalOffset;
					return;
				}
			}
			this.TargetAimDecal.gameObject.SetActive(false);
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00004E50 File Offset: 0x00003050
		private void OnDrawGizmos()
		{
			if (this.DrawGizmos)
			{
				Gizmos.color = Color.red;
				foreach (Vector3 vector in this.path)
				{
					Gizmos.DrawSphere(vector, 0.05f);
				}
			}
		}

		// Token: 0x04000095 RID: 149
		public float PathThickness = 1f;

		// Token: 0x04000096 RID: 150
		[Tooltip("Distance from the ground.")]
		public float NormalPathOffset;

		// Token: 0x04000097 RID: 151
		[Tooltip("Max radius between segments.")]
		[Range(0.001f, 0.5f)]
		public float Radius = 0.25f;

		// Token: 0x04000098 RID: 152
		[Tooltip("Discard segments when their angle is smaller than this value.")]
		public float AngleThreshold = 5f;

		// Token: 0x04000099 RID: 153
		public bool DrawGizmos;

		// Token: 0x0400009A RID: 154
		public EasyDecal TargetAimDecal;

		// Token: 0x0400009B RID: 155
		public GameObject TargetPointDecalPrefab;

		// Token: 0x0400009C RID: 156
		private List<Vector3> path = new List<Vector3>();

		// Token: 0x0400009D RID: 157
		private NavMeshAgent agent;

		// Token: 0x0400009E RID: 158
		private LineRenderer lineRenderer;

		// Token: 0x0400009F RID: 159
		private Vector3 decalOffset = Vector3.up * 0.5f;

		// Token: 0x040000A0 RID: 160
		private const int MAXDISTANCE = 50;
	}
}
