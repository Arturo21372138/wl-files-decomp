﻿using System;
using UnityEngine;

namespace AmplifyImpostors
{
	// Token: 0x020000F3 RID: 243
	public static class RenderTextureEx
	{
		// Token: 0x0600076A RID: 1898 RVA: 0x0002A900 File Offset: 0x00028B00
		public static RenderTexture GetTemporary(RenderTexture renderTexture)
		{
			return RenderTexture.GetTemporary(renderTexture.width, renderTexture.height, renderTexture.depth, renderTexture.format);
		}
	}
}
