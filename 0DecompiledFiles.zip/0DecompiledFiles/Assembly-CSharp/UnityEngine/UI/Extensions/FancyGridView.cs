﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine.UI.Extensions.EasingCore;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000077 RID: 119
	public abstract class FancyGridView<TItemData, TContext> : FancyScrollRect<TItemData[], TContext> where TContext : class, IFancyGridViewContext, new()
	{
		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000389 RID: 905 RVA: 0x00016CEB File Offset: 0x00014EEB
		protected sealed override GameObject CellPrefab
		{
			get
			{
				return this.cellGroupTemplate;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x0600038A RID: 906 RVA: 0x00016CF3 File Offset: 0x00014EF3
		protected override float CellSize
		{
			get
			{
				if (base.Scroller.ScrollDirection != ScrollDirection.Horizontal)
				{
					return this.cellSize.y;
				}
				return this.cellSize.x;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x0600038B RID: 907 RVA: 0x00016D1A File Offset: 0x00014F1A
		// (set) Token: 0x0600038C RID: 908 RVA: 0x00016D22 File Offset: 0x00014F22
		public int DataCount { get; private set; }

		// Token: 0x0600038D RID: 909 RVA: 0x00016D2C File Offset: 0x00014F2C
		protected override void Initialize()
		{
			base.Initialize();
			base.Context.ScrollDirection = base.Scroller.ScrollDirection;
			base.Context.GetGroupCount = () => this.startAxisCellCount;
			base.Context.GetStartAxisSpacing = () => this.startAxisSpacing;
			base.Context.GetCellSize = delegate
			{
				if (base.Scroller.ScrollDirection != ScrollDirection.Horizontal)
				{
					return this.cellSize.x;
				}
				return this.cellSize.y;
			};
			this.SetupCellTemplate();
		}

		// Token: 0x0600038E RID: 910
		protected abstract void SetupCellTemplate();

		// Token: 0x0600038F RID: 911 RVA: 0x00016DB4 File Offset: 0x00014FB4
		protected virtual void Setup<TGroup>(FancyCell<TItemData, TContext> cellTemplate) where TGroup : FancyCell<TItemData[], TContext>
		{
			base.Context.CellTemplate = cellTemplate.gameObject;
			this.cellGroupTemplate = new GameObject("Group").AddComponent<TGroup>().gameObject;
			this.cellGroupTemplate.transform.SetParent(this.cellContainer, false);
			this.cellGroupTemplate.SetActive(false);
		}

		// Token: 0x06000390 RID: 912 RVA: 0x00016E1C File Offset: 0x0001501C
		public virtual void UpdateContents(IList<TItemData> items)
		{
			this.DataCount = items.Count;
			TItemData[][] array = (from x in items.Select((TItemData item, int index) => new ValueTuple<TItemData, int>(item, index))
				group x.Item1 by x.Item2 / this.startAxisCellCount into @group
				select @group.ToArray<TItemData>()).ToArray<TItemData[]>();
			this.UpdateContents(array);
		}

		// Token: 0x06000391 RID: 913 RVA: 0x00016EBC File Offset: 0x000150BC
		protected override void JumpTo(int itemIndex, float alignment = 0.5f)
		{
			int num = itemIndex / this.startAxisCellCount;
			base.JumpTo(num, alignment);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00016EDC File Offset: 0x000150DC
		protected override void ScrollTo(int itemIndex, float duration, float alignment = 0.5f, Action onComplete = null)
		{
			int num = itemIndex / this.startAxisCellCount;
			base.ScrollTo(num, duration, alignment, onComplete);
		}

		// Token: 0x06000393 RID: 915 RVA: 0x00016F00 File Offset: 0x00015100
		protected override void ScrollTo(int itemIndex, float duration, Ease easing, float alignment = 0.5f, Action onComplete = null)
		{
			int num = itemIndex / this.startAxisCellCount;
			base.ScrollTo(num, duration, easing, alignment, onComplete);
		}

		// Token: 0x040002D4 RID: 724
		[SerializeField]
		protected float startAxisSpacing;

		// Token: 0x040002D5 RID: 725
		[SerializeField]
		protected int startAxisCellCount = 4;

		// Token: 0x040002D6 RID: 726
		[SerializeField]
		protected Vector2 cellSize = new Vector2(100f, 100f);

		// Token: 0x040002D8 RID: 728
		private GameObject cellGroupTemplate;

		// Token: 0x02000130 RID: 304
		protected abstract class DefaultCellGroup : FancyCellGroup<TItemData, TContext>
		{
		}
	}
}
