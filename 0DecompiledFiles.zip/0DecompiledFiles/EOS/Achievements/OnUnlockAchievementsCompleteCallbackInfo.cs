﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000812 RID: 2066
	public struct OnUnlockAchievementsCompleteCallbackInfo : ICallbackInfo
	{
		// Token: 0x17000873 RID: 2163
		// (get) Token: 0x060021F6 RID: 8694 RVA: 0x000285DD File Offset: 0x000267DD
		// (set) Token: 0x060021F7 RID: 8695 RVA: 0x000285E5 File Offset: 0x000267E5
		public Result ResultCode { readonly get; set; }

		// Token: 0x17000874 RID: 2164
		// (get) Token: 0x060021F8 RID: 8696 RVA: 0x000285EE File Offset: 0x000267EE
		// (set) Token: 0x060021F9 RID: 8697 RVA: 0x000285F6 File Offset: 0x000267F6
		public object ClientData { readonly get; set; }

		// Token: 0x17000875 RID: 2165
		// (get) Token: 0x060021FA RID: 8698 RVA: 0x000285FF File Offset: 0x000267FF
		// (set) Token: 0x060021FB RID: 8699 RVA: 0x00028607 File Offset: 0x00026807
		public ProductUserId UserId { readonly get; set; }

		// Token: 0x17000876 RID: 2166
		// (get) Token: 0x060021FC RID: 8700 RVA: 0x00028610 File Offset: 0x00026810
		// (set) Token: 0x060021FD RID: 8701 RVA: 0x00028618 File Offset: 0x00026818
		public uint AchievementsCount { readonly get; set; }

		// Token: 0x060021FE RID: 8702 RVA: 0x00028621 File Offset: 0x00026821
		public object GetClientData()
		{
			return this.ClientData;
		}

		// Token: 0x060021FF RID: 8703 RVA: 0x00028629 File Offset: 0x00026829
		public Result? GetResultCode()
		{
			return new Result?(this.ResultCode);
		}
	}
}
