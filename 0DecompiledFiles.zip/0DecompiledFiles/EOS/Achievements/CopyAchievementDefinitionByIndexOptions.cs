﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E3 RID: 2019
	public struct CopyAchievementDefinitionByIndexOptions
	{
		// Token: 0x17000839 RID: 2105
		// (get) Token: 0x0600213C RID: 8508 RVA: 0x00027B75 File Offset: 0x00025D75
		// (set) Token: 0x0600213D RID: 8509 RVA: 0x00027B7D File Offset: 0x00025D7D
		public uint AchievementIndex { readonly get; set; }
	}
}
