﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000BE RID: 190
	public static class ShaderLibrary
	{
		// Token: 0x0600063B RID: 1595 RVA: 0x00024A88 File Offset: 0x00022C88
		public static Shader GetShaderInstance(string shaderName)
		{
			if (ShaderLibrary.shaderInstances.ContainsKey(shaderName))
			{
				return ShaderLibrary.shaderInstances[shaderName];
			}
			Shader shader = Shader.Find(shaderName);
			if (shader != null)
			{
				ShaderLibrary.shaderInstances.Add(shaderName, shader);
			}
			return shader;
		}

		// Token: 0x04000488 RID: 1160
		public static Dictionary<string, Shader> shaderInstances = new Dictionary<string, Shader>();

		// Token: 0x04000489 RID: 1161
		public static Shader[] preLoadedShaders;
	}
}
