﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007A7 RID: 1959
	internal struct AddNotifyClientIntegrityViolatedOptionsInternal : ISettable<AddNotifyClientIntegrityViolatedOptions>, IDisposable
	{
		// Token: 0x0600207E RID: 8318 RVA: 0x00026A40 File Offset: 0x00024C40
		public void Set(ref AddNotifyClientIntegrityViolatedOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x0600207F RID: 8319 RVA: 0x00026A4F File Offset: 0x00024C4F
		public void Dispose()
		{
		}

		// Token: 0x04001599 RID: 5529
		private int m_ApiVersion;
	}
}
