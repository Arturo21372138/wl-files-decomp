﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F7 RID: 2039
	public struct GetPlayerAchievementCountOptions
	{
		// Token: 0x1700085B RID: 2139
		// (get) Token: 0x06002192 RID: 8594 RVA: 0x00028162 File Offset: 0x00026362
		// (set) Token: 0x06002193 RID: 8595 RVA: 0x0002816A File Offset: 0x0002636A
		public ProductUserId UserId { readonly get; set; }
	}
}
