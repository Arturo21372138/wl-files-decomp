﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007EC RID: 2028
	internal struct CopyPlayerAchievementByIndexOptionsInternal : ISettable<CopyPlayerAchievementByIndexOptions>, IDisposable
	{
		// Token: 0x06002156 RID: 8534 RVA: 0x00027CE7 File Offset: 0x00025EE7
		public void Set(ref CopyPlayerAchievementByIndexOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 2;
			Helper.Set(other.TargetUserId, ref this.m_TargetUserId);
			this.m_AchievementIndex = other.AchievementIndex;
			Helper.Set(other.LocalUserId, ref this.m_LocalUserId);
		}

		// Token: 0x06002157 RID: 8535 RVA: 0x00027D24 File Offset: 0x00025F24
		public void Dispose()
		{
			Helper.Dispose(ref this.m_TargetUserId);
			Helper.Dispose(ref this.m_LocalUserId);
		}

		// Token: 0x04001640 RID: 5696
		private int m_ApiVersion;

		// Token: 0x04001641 RID: 5697
		private IntPtr m_TargetUserId;

		// Token: 0x04001642 RID: 5698
		private uint m_AchievementIndex;

		// Token: 0x04001643 RID: 5699
		private IntPtr m_LocalUserId;
	}
}
