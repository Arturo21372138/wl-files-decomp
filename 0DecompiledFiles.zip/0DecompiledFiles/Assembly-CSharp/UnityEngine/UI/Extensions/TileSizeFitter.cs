﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000091 RID: 145
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("Layout/Extensions/Tile Size Fitter")]
	public class TileSizeFitter : UIBehaviour, ILayoutSelfController, ILayoutController
	{
		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x0600049F RID: 1183 RVA: 0x0001BC87 File Offset: 0x00019E87
		// (set) Token: 0x060004A0 RID: 1184 RVA: 0x0001BC8F File Offset: 0x00019E8F
		public Vector2 Border
		{
			get
			{
				return this.m_Border;
			}
			set
			{
				if (SetPropertyUtility.SetStruct<Vector2>(ref this.m_Border, value))
				{
					this.SetDirty();
				}
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x060004A1 RID: 1185 RVA: 0x0001BCA5 File Offset: 0x00019EA5
		// (set) Token: 0x060004A2 RID: 1186 RVA: 0x0001BCAD File Offset: 0x00019EAD
		public Vector2 TileSize
		{
			get
			{
				return this.m_TileSize;
			}
			set
			{
				if (SetPropertyUtility.SetStruct<Vector2>(ref this.m_TileSize, value))
				{
					this.SetDirty();
				}
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x060004A3 RID: 1187 RVA: 0x0001BCC3 File Offset: 0x00019EC3
		private RectTransform rectTransform
		{
			get
			{
				if (this.m_Rect == null)
				{
					this.m_Rect = base.GetComponent<RectTransform>();
				}
				return this.m_Rect;
			}
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x0001BCE5 File Offset: 0x00019EE5
		protected override void OnEnable()
		{
			base.OnEnable();
			this.SetDirty();
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0001BCF3 File Offset: 0x00019EF3
		protected override void OnDisable()
		{
			this.m_Tracker.Clear();
			LayoutRebuilder.MarkLayoutForRebuild(this.rectTransform);
			base.OnDisable();
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0001BD11 File Offset: 0x00019F11
		protected override void OnRectTransformDimensionsChange()
		{
			this.UpdateRect();
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0001BD1C File Offset: 0x00019F1C
		private void UpdateRect()
		{
			if (!this.IsActive())
			{
				return;
			}
			this.m_Tracker.Clear();
			this.m_Tracker.Add(this, this.rectTransform, DrivenTransformProperties.AnchoredPositionX | DrivenTransformProperties.AnchoredPositionY | DrivenTransformProperties.AnchorMinX | DrivenTransformProperties.AnchorMinY | DrivenTransformProperties.AnchorMaxX | DrivenTransformProperties.AnchorMaxY);
			this.rectTransform.anchorMin = Vector2.zero;
			this.rectTransform.anchorMax = Vector2.one;
			this.rectTransform.anchoredPosition = Vector2.zero;
			this.m_Tracker.Add(this, this.rectTransform, DrivenTransformProperties.SizeDelta);
			Vector2 vector = this.GetParentSize() - this.Border;
			if (this.TileSize.x > 0.001f)
			{
				vector.x -= Mathf.Floor(vector.x / this.TileSize.x) * this.TileSize.x;
			}
			else
			{
				vector.x = 0f;
			}
			if (this.TileSize.y > 0.001f)
			{
				vector.y -= Mathf.Floor(vector.y / this.TileSize.y) * this.TileSize.y;
			}
			else
			{
				vector.y = 0f;
			}
			this.rectTransform.sizeDelta = -vector;
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0001BE5C File Offset: 0x0001A05C
		private Vector2 GetParentSize()
		{
			RectTransform rectTransform = this.rectTransform.parent as RectTransform;
			if (!rectTransform)
			{
				return Vector2.zero;
			}
			return rectTransform.rect.size;
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x0001BE96 File Offset: 0x0001A096
		public virtual void SetLayoutHorizontal()
		{
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x0001BE98 File Offset: 0x0001A098
		public virtual void SetLayoutVertical()
		{
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x0001BE9A File Offset: 0x0001A09A
		protected void SetDirty()
		{
			if (!this.IsActive())
			{
				return;
			}
			this.UpdateRect();
		}

		// Token: 0x04000383 RID: 899
		[SerializeField]
		private Vector2 m_Border = Vector2.zero;

		// Token: 0x04000384 RID: 900
		[SerializeField]
		private Vector2 m_TileSize = Vector2.zero;

		// Token: 0x04000385 RID: 901
		[NonSerialized]
		private RectTransform m_Rect;

		// Token: 0x04000386 RID: 902
		private DrivenRectTransformTracker m_Tracker;
	}
}
