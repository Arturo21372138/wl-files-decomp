﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C9 RID: 1993
	// (Invoke) Token: 0x060020E8 RID: 8424
	public delegate void OnPeerAuthStatusChangedCallback(ref OnClientAuthStatusChangedCallbackInfo data);
}
