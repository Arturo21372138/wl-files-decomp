﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000AE RID: 174
	public class Circle
	{
		// Token: 0x1700010E RID: 270
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x00023665 File Offset: 0x00021865
		// (set) Token: 0x060005E1 RID: 1505 RVA: 0x0002366D File Offset: 0x0002186D
		public float X
		{
			get
			{
				return this.xAxis;
			}
			set
			{
				this.xAxis = value;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x00023676 File Offset: 0x00021876
		// (set) Token: 0x060005E3 RID: 1507 RVA: 0x0002367E File Offset: 0x0002187E
		public float Y
		{
			get
			{
				return this.yAxis;
			}
			set
			{
				this.yAxis = value;
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x00023687 File Offset: 0x00021887
		// (set) Token: 0x060005E5 RID: 1509 RVA: 0x0002368F File Offset: 0x0002188F
		public int Steps
		{
			get
			{
				return this.steps;
			}
			set
			{
				this.steps = value;
			}
		}

		// Token: 0x060005E6 RID: 1510 RVA: 0x00023698 File Offset: 0x00021898
		public Circle(float radius)
		{
			this.xAxis = radius;
			this.yAxis = radius;
			this.steps = 1;
		}

		// Token: 0x060005E7 RID: 1511 RVA: 0x000236B5 File Offset: 0x000218B5
		public Circle(float radius, int steps)
		{
			this.xAxis = radius;
			this.yAxis = radius;
			this.steps = steps;
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x000236D2 File Offset: 0x000218D2
		public Circle(float xAxis, float yAxis)
		{
			this.xAxis = xAxis;
			this.yAxis = yAxis;
			this.steps = 10;
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x000236F0 File Offset: 0x000218F0
		public Circle(float xAxis, float yAxis, int steps)
		{
			this.xAxis = xAxis;
			this.yAxis = yAxis;
			this.steps = steps;
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x00023710 File Offset: 0x00021910
		public Vector2 Evaluate(float t)
		{
			float num = 360f / (float)this.steps;
			float num2 = 0.017453292f * num * t;
			float num3 = Mathf.Sin(num2) * this.xAxis;
			float num4 = Mathf.Cos(num2) * this.yAxis;
			return new Vector2(num3, num4);
		}

		// Token: 0x060005EB RID: 1515 RVA: 0x00023758 File Offset: 0x00021958
		public void Evaluate(float t, out Vector2 eval)
		{
			float num = 360f / (float)this.steps;
			float num2 = 0.017453292f * num * t;
			eval.x = Mathf.Sin(num2) * this.xAxis;
			eval.y = Mathf.Cos(num2) * this.yAxis;
		}

		// Token: 0x0400045D RID: 1117
		[SerializeField]
		private float xAxis;

		// Token: 0x0400045E RID: 1118
		[SerializeField]
		private float yAxis;

		// Token: 0x0400045F RID: 1119
		[SerializeField]
		private int steps;
	}
}
