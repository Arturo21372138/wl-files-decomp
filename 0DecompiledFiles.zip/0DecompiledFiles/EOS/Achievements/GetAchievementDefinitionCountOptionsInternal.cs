﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F6 RID: 2038
	internal struct GetAchievementDefinitionCountOptionsInternal : ISettable<GetAchievementDefinitionCountOptions>, IDisposable
	{
		// Token: 0x06002190 RID: 8592 RVA: 0x00028151 File Offset: 0x00026351
		public void Set(ref GetAchievementDefinitionCountOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002191 RID: 8593 RVA: 0x00028160 File Offset: 0x00026360
		public void Dispose()
		{
		}

		// Token: 0x0400167C RID: 5756
		private int m_ApiVersion;
	}
}
