﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200004B RID: 75
	[RequireComponent(typeof(Image))]
	[AddComponentMenu("UI/Extensions/UI_Knob")]
	public class UI_Knob : Selectable, IPointerDownHandler, IEventSystemHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IDragHandler, IInitializePotentialDragHandler
	{
		// Token: 0x06000250 RID: 592 RVA: 0x0000D9FD File Offset: 0x0000BBFD
		protected override void Awake()
		{
			this._screenSpaceOverlay = base.GetComponentInParent<Canvas>().rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay;
		}

		// Token: 0x06000251 RID: 593 RVA: 0x0000DA18 File Offset: 0x0000BC18
		protected override void Start()
		{
			this.CheckForParentTouchMask();
		}

		// Token: 0x06000252 RID: 594 RVA: 0x0000DA20 File Offset: 0x0000BC20
		private void CheckForParentTouchMask()
		{
			if (this.ParentTouchMask)
			{
				this.ParentTouchMask.gameObject.GetOrAddComponent<Image>().color = this.MaskBackground;
				EventTrigger orAddComponent = this.ParentTouchMask.gameObject.GetOrAddComponent<EventTrigger>();
				orAddComponent.triggers.Clear();
				EventTrigger.Entry entry = new EventTrigger.Entry();
				entry.eventID = EventTriggerType.PointerDown;
				entry.callback.AddListener(delegate(BaseEventData data)
				{
					this.OnPointerDown((PointerEventData)data);
				});
				orAddComponent.triggers.Add(entry);
				EventTrigger.Entry entry2 = new EventTrigger.Entry();
				entry2.eventID = EventTriggerType.PointerUp;
				entry2.callback.AddListener(delegate(BaseEventData data)
				{
					this.OnPointerUp((PointerEventData)data);
				});
				orAddComponent.triggers.Add(entry2);
				EventTrigger.Entry entry3 = new EventTrigger.Entry();
				entry3.eventID = EventTriggerType.PointerEnter;
				entry3.callback.AddListener(delegate(BaseEventData data)
				{
					this.OnPointerEnter((PointerEventData)data);
				});
				orAddComponent.triggers.Add(entry3);
				EventTrigger.Entry entry4 = new EventTrigger.Entry();
				entry4.eventID = EventTriggerType.PointerExit;
				entry4.callback.AddListener(delegate(BaseEventData data)
				{
					this.OnPointerExit((PointerEventData)data);
				});
				orAddComponent.triggers.Add(entry4);
				EventTrigger.Entry entry5 = new EventTrigger.Entry();
				entry5.eventID = EventTriggerType.Drag;
				entry5.callback.AddListener(delegate(BaseEventData data)
				{
					this.OnDrag((PointerEventData)data);
				});
				orAddComponent.triggers.Add(entry5);
			}
		}

		// Token: 0x06000253 RID: 595 RVA: 0x0000DB66 File Offset: 0x0000BD66
		public override void OnPointerUp(PointerEventData eventData)
		{
			this._canDrag = false;
		}

		// Token: 0x06000254 RID: 596 RVA: 0x0000DB6F File Offset: 0x0000BD6F
		public override void OnPointerEnter(PointerEventData eventData)
		{
			this._canDrag = true;
		}

		// Token: 0x06000255 RID: 597 RVA: 0x0000DB78 File Offset: 0x0000BD78
		public override void OnPointerExit(PointerEventData eventData)
		{
			this._canDrag = false;
		}

		// Token: 0x06000256 RID: 598 RVA: 0x0000DB84 File Offset: 0x0000BD84
		public override void OnPointerDown(PointerEventData eventData)
		{
			this._canDrag = true;
			base.OnPointerDown(eventData);
			this._initRotation = base.transform.rotation;
			if (this._screenSpaceOverlay)
			{
				this._currentVector = eventData.position - base.transform.position;
			}
			else
			{
				this._currentVector = eventData.position - Camera.main.WorldToScreenPoint(base.transform.position);
			}
			this._initAngle = Mathf.Atan2(this._currentVector.y, this._currentVector.x) * 57.29578f;
		}

		// Token: 0x06000257 RID: 599 RVA: 0x0000DC30 File Offset: 0x0000BE30
		public void OnDrag(PointerEventData eventData)
		{
			if (!this._canDrag)
			{
				return;
			}
			if (this._screenSpaceOverlay)
			{
				this._currentVector = eventData.position - base.transform.position;
			}
			else
			{
				this._currentVector = eventData.position - Camera.main.WorldToScreenPoint(base.transform.position);
			}
			this._currentAngle = Mathf.Atan2(this._currentVector.y, this._currentVector.x) * 57.29578f;
			Quaternion quaternion = Quaternion.AngleAxis(this._currentAngle - this._initAngle, base.transform.forward);
			quaternion.eulerAngles = new Vector3(0f, 0f, quaternion.eulerAngles.z);
			Quaternion quaternion2 = this._initRotation * quaternion;
			if (this.direction == UI_Knob.Direction.CW)
			{
				this.KnobValue = 1f - quaternion2.eulerAngles.z / 360f;
				if (this.SnapToPosition)
				{
					this.SnapToPositionValue(ref this.KnobValue);
					quaternion2.eulerAngles = new Vector3(0f, 0f, 360f - 360f * this.KnobValue);
				}
			}
			else
			{
				this.KnobValue = quaternion2.eulerAngles.z / 360f;
				if (this.SnapToPosition)
				{
					this.SnapToPositionValue(ref this.KnobValue);
					quaternion2.eulerAngles = new Vector3(0f, 0f, 360f * this.KnobValue);
				}
			}
			this.UpdateKnobValue();
			base.transform.rotation = quaternion2;
			this.InvokeEvents(this.KnobValue + this._currentLoops);
			this._previousValue = this.KnobValue;
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0000DDF8 File Offset: 0x0000BFF8
		private void UpdateKnobValue()
		{
			if (Mathf.Abs(this.KnobValue - this._previousValue) > 0.5f)
			{
				if (this.KnobValue < 0.5f && this.Loops > 1 && this._currentLoops < (float)(this.Loops - 1))
				{
					this._currentLoops += 1f;
				}
				else if (this.KnobValue > 0.5f && this._currentLoops >= 1f)
				{
					this._currentLoops -= 1f;
				}
				else
				{
					if (this.KnobValue > 0.5f && this._currentLoops == 0f)
					{
						this.KnobValue = 0f;
						base.transform.localEulerAngles = Vector3.zero;
						this.InvokeEvents(this.KnobValue + this._currentLoops);
						return;
					}
					if (this.KnobValue < 0.5f && this._currentLoops == (float)(this.Loops - 1))
					{
						this.KnobValue = 1f;
						base.transform.localEulerAngles = Vector3.zero;
						this.InvokeEvents(this.KnobValue + this._currentLoops);
						return;
					}
				}
			}
			if (this.MaxValue > 0f && this.KnobValue + this._currentLoops > this.MaxValue)
			{
				this.KnobValue = this.MaxValue;
				float num = ((this.direction == UI_Knob.Direction.CW) ? (360f - 360f * this.MaxValue) : (360f * this.MaxValue));
				base.transform.localEulerAngles = new Vector3(0f, 0f, num);
				this.InvokeEvents(this.KnobValue);
				return;
			}
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0000DFA8 File Offset: 0x0000C1A8
		public void SetKnobValue(float value, int loops = 0)
		{
			Quaternion identity = Quaternion.identity;
			this.KnobValue = value;
			this._currentLoops = (float)loops;
			if (this.SnapToPosition)
			{
				this.SnapToPositionValue(ref this.KnobValue);
			}
			if (this.direction == UI_Knob.Direction.CW)
			{
				identity.eulerAngles = new Vector3(0f, 0f, 360f - 360f * this.KnobValue);
			}
			else
			{
				identity.eulerAngles = new Vector3(0f, 0f, 360f * this.KnobValue);
			}
			this.UpdateKnobValue();
			base.transform.rotation = identity;
			this.InvokeEvents(this.KnobValue + this._currentLoops);
			this._previousValue = this.KnobValue;
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000E064 File Offset: 0x0000C264
		private void SnapToPositionValue(ref float knobValue)
		{
			float num = 1f / (float)this.SnapStepsPerLoop;
			float num2 = Mathf.Round(knobValue / num) * num;
			knobValue = num2;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x0000E08E File Offset: 0x0000C28E
		private void InvokeEvents(float value)
		{
			if (this.ClampOutput01)
			{
				value /= (float)this.Loops;
			}
			this.OnValueChanged.Invoke(value);
		}

		// Token: 0x0600025C RID: 604 RVA: 0x0000E0AF File Offset: 0x0000C2AF
		public virtual void OnInitializePotentialDrag(PointerEventData eventData)
		{
			eventData.useDragThreshold = false;
		}

		// Token: 0x040001F0 RID: 496
		[Tooltip("Direction of rotation CW - clockwise, CCW - counterClockwise")]
		public UI_Knob.Direction direction;

		// Token: 0x040001F1 RID: 497
		[HideInInspector]
		public float KnobValue;

		// Token: 0x040001F2 RID: 498
		[Tooltip("Max value of the knob, maximum RAW output value knob can reach, overrides snap step, IF set to 0 or higher than loops, max value will be set by loops")]
		public float MaxValue;

		// Token: 0x040001F3 RID: 499
		[Tooltip("How many rotations knob can do, if higher than max value, the latter will limit max value")]
		public int Loops;

		// Token: 0x040001F4 RID: 500
		[Tooltip("Clamp output value between 0 and 1, useful with loops > 1")]
		public bool ClampOutput01;

		// Token: 0x040001F5 RID: 501
		[Tooltip("snap to position?")]
		public bool SnapToPosition;

		// Token: 0x040001F6 RID: 502
		[Tooltip("Number of positions to snap")]
		public int SnapStepsPerLoop = 10;

		// Token: 0x040001F7 RID: 503
		[Tooltip("Parent touch area to extend the touch radius")]
		public RectTransform ParentTouchMask;

		// Token: 0x040001F8 RID: 504
		[Tooltip("Default background color of the touch mask. Defaults as transparent")]
		public Color MaskBackground = new Color(0f, 0f, 0f, 0f);

		// Token: 0x040001F9 RID: 505
		[Space(30f)]
		public KnobFloatValueEvent OnValueChanged;

		// Token: 0x040001FA RID: 506
		private float _currentLoops;

		// Token: 0x040001FB RID: 507
		private float _previousValue;

		// Token: 0x040001FC RID: 508
		private float _initAngle;

		// Token: 0x040001FD RID: 509
		private float _currentAngle;

		// Token: 0x040001FE RID: 510
		private Vector2 _currentVector;

		// Token: 0x040001FF RID: 511
		private Quaternion _initRotation;

		// Token: 0x04000200 RID: 512
		private bool _canDrag;

		// Token: 0x04000201 RID: 513
		private bool _screenSpaceOverlay;

		// Token: 0x02000123 RID: 291
		public enum Direction
		{
			// Token: 0x04000646 RID: 1606
			CW,
			// Token: 0x04000647 RID: 1607
			CCW
		}
	}
}
