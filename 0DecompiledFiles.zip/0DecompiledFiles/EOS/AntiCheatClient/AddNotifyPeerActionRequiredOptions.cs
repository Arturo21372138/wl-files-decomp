﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007AC RID: 1964
	public struct AddNotifyPeerActionRequiredOptions
	{
	}
}
