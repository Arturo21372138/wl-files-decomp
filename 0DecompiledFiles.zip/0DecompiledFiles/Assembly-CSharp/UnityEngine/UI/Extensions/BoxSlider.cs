﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200002F RID: 47
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/BoxSlider")]
	public class BoxSlider : Selectable, IDragHandler, IEventSystemHandler, IInitializePotentialDragHandler, ICanvasElement
	{
		// Token: 0x1700000A RID: 10
		// (get) Token: 0x060000B5 RID: 181 RVA: 0x00005957 File Offset: 0x00003B57
		// (set) Token: 0x060000B6 RID: 182 RVA: 0x0000595F File Offset: 0x00003B5F
		public RectTransform HandleRect
		{
			get
			{
				return this.m_HandleRect;
			}
			set
			{
				if (BoxSlider.SetClass<RectTransform>(ref this.m_HandleRect, value))
				{
					this.UpdateCachedReferences();
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x060000B7 RID: 183 RVA: 0x0000597B File Offset: 0x00003B7B
		// (set) Token: 0x060000B8 RID: 184 RVA: 0x00005983 File Offset: 0x00003B83
		public float MinValue
		{
			get
			{
				return this.m_MinValue;
			}
			set
			{
				if (BoxSlider.SetStruct<float>(ref this.m_MinValue, value))
				{
					this.SetX(this.m_ValueX);
					this.SetY(this.m_ValueY);
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x060000B9 RID: 185 RVA: 0x000059B1 File Offset: 0x00003BB1
		// (set) Token: 0x060000BA RID: 186 RVA: 0x000059B9 File Offset: 0x00003BB9
		public float MaxValue
		{
			get
			{
				return this.m_MaxValue;
			}
			set
			{
				if (BoxSlider.SetStruct<float>(ref this.m_MaxValue, value))
				{
					this.SetX(this.m_ValueX);
					this.SetY(this.m_ValueY);
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x060000BB RID: 187 RVA: 0x000059E7 File Offset: 0x00003BE7
		// (set) Token: 0x060000BC RID: 188 RVA: 0x000059EF File Offset: 0x00003BEF
		public bool WholeNumbers
		{
			get
			{
				return this.m_WholeNumbers;
			}
			set
			{
				if (BoxSlider.SetStruct<bool>(ref this.m_WholeNumbers, value))
				{
					this.SetX(this.m_ValueX);
					this.SetY(this.m_ValueY);
					this.UpdateVisuals();
				}
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x060000BD RID: 189 RVA: 0x00005A1D File Offset: 0x00003C1D
		// (set) Token: 0x060000BE RID: 190 RVA: 0x00005A39 File Offset: 0x00003C39
		public float ValueX
		{
			get
			{
				if (this.WholeNumbers)
				{
					return Mathf.Round(this.m_ValueX);
				}
				return this.m_ValueX;
			}
			set
			{
				this.SetX(value);
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x060000BF RID: 191 RVA: 0x00005A42 File Offset: 0x00003C42
		// (set) Token: 0x060000C0 RID: 192 RVA: 0x00005A74 File Offset: 0x00003C74
		public float NormalizedValueX
		{
			get
			{
				if (Mathf.Approximately(this.MinValue, this.MaxValue))
				{
					return 0f;
				}
				return Mathf.InverseLerp(this.MinValue, this.MaxValue, this.ValueX);
			}
			set
			{
				this.ValueX = Mathf.Lerp(this.MinValue, this.MaxValue, value);
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x060000C1 RID: 193 RVA: 0x00005A8E File Offset: 0x00003C8E
		// (set) Token: 0x060000C2 RID: 194 RVA: 0x00005AAA File Offset: 0x00003CAA
		public float ValueY
		{
			get
			{
				if (this.WholeNumbers)
				{
					return Mathf.Round(this.m_ValueY);
				}
				return this.m_ValueY;
			}
			set
			{
				this.SetY(value);
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x060000C3 RID: 195 RVA: 0x00005AB3 File Offset: 0x00003CB3
		// (set) Token: 0x060000C4 RID: 196 RVA: 0x00005AE5 File Offset: 0x00003CE5
		public float NormalizedValueY
		{
			get
			{
				if (Mathf.Approximately(this.MinValue, this.MaxValue))
				{
					return 0f;
				}
				return Mathf.InverseLerp(this.MinValue, this.MaxValue, this.ValueY);
			}
			set
			{
				this.ValueY = Mathf.Lerp(this.MinValue, this.MaxValue, value);
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x00005AFF File Offset: 0x00003CFF
		// (set) Token: 0x060000C6 RID: 198 RVA: 0x00005B07 File Offset: 0x00003D07
		public BoxSlider.BoxSliderEvent OnValueChanged
		{
			get
			{
				return this.m_OnValueChanged;
			}
			set
			{
				this.m_OnValueChanged = value;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x060000C7 RID: 199 RVA: 0x00005B10 File Offset: 0x00003D10
		private float StepSize
		{
			get
			{
				if (!this.WholeNumbers)
				{
					return (this.MaxValue - this.MinValue) * 0.1f;
				}
				return 1f;
			}
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00005B33 File Offset: 0x00003D33
		protected BoxSlider()
		{
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x00005B72 File Offset: 0x00003D72
		public virtual void Rebuild(CanvasUpdate executing)
		{
		}

		// Token: 0x060000CA RID: 202 RVA: 0x00005B74 File Offset: 0x00003D74
		public void LayoutComplete()
		{
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00005B76 File Offset: 0x00003D76
		public void GraphicUpdateComplete()
		{
		}

		// Token: 0x060000CC RID: 204 RVA: 0x00005B78 File Offset: 0x00003D78
		public static bool SetClass<T>(ref T currentValue, T newValue) where T : class
		{
			if ((currentValue == null && newValue == null) || (currentValue != null && currentValue.Equals(newValue)))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00005BC5 File Offset: 0x00003DC5
		public static bool SetStruct<T>(ref T currentValue, T newValue) where T : struct
		{
			if (currentValue.Equals(newValue))
			{
				return false;
			}
			currentValue = newValue;
			return true;
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00005BE5 File Offset: 0x00003DE5
		protected override void OnEnable()
		{
			base.OnEnable();
			this.UpdateCachedReferences();
			this.SetX(this.m_ValueX, false);
			this.SetY(this.m_ValueY, false);
			this.UpdateVisuals();
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00005C13 File Offset: 0x00003E13
		protected override void OnDisable()
		{
			this.m_Tracker.Clear();
			base.OnDisable();
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x00005C28 File Offset: 0x00003E28
		private void UpdateCachedReferences()
		{
			if (this.m_HandleRect)
			{
				this.m_HandleTransform = this.m_HandleRect.transform;
				if (this.m_HandleTransform.parent != null)
				{
					this.m_HandleContainerRect = this.m_HandleTransform.parent.GetComponent<RectTransform>();
					return;
				}
			}
			else
			{
				this.m_HandleContainerRect = null;
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00005C84 File Offset: 0x00003E84
		private void SetX(float input)
		{
			this.SetX(input, true);
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00005C90 File Offset: 0x00003E90
		private void SetX(float input, bool sendCallback)
		{
			float num = Mathf.Clamp(input, this.MinValue, this.MaxValue);
			if (this.WholeNumbers)
			{
				num = Mathf.Round(num);
			}
			if (this.m_ValueX == num)
			{
				return;
			}
			this.m_ValueX = num;
			this.UpdateVisuals();
			if (sendCallback)
			{
				this.m_OnValueChanged.Invoke(num, this.ValueY);
			}
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00005CEB File Offset: 0x00003EEB
		private void SetY(float input)
		{
			this.SetY(input, true);
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00005CF8 File Offset: 0x00003EF8
		private void SetY(float input, bool sendCallback)
		{
			float num = Mathf.Clamp(input, this.MinValue, this.MaxValue);
			if (this.WholeNumbers)
			{
				num = Mathf.Round(num);
			}
			if (this.m_ValueY == num)
			{
				return;
			}
			this.m_ValueY = num;
			this.UpdateVisuals();
			if (sendCallback)
			{
				this.m_OnValueChanged.Invoke(this.ValueX, num);
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00005D53 File Offset: 0x00003F53
		protected override void OnRectTransformDimensionsChange()
		{
			base.OnRectTransformDimensionsChange();
			this.UpdateVisuals();
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00005D64 File Offset: 0x00003F64
		private void UpdateVisuals()
		{
			this.m_Tracker.Clear();
			if (this.m_HandleContainerRect != null)
			{
				this.m_Tracker.Add(this, this.m_HandleRect, DrivenTransformProperties.Anchors);
				Vector2 zero = Vector2.zero;
				Vector2 one = Vector2.one;
				zero[0] = (one[0] = this.NormalizedValueX);
				zero[1] = (one[1] = this.NormalizedValueY);
				if (Application.isPlaying)
				{
					this.m_HandleRect.anchorMin = zero;
					this.m_HandleRect.anchorMax = one;
				}
			}
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00005E00 File Offset: 0x00004000
		private void UpdateDrag(PointerEventData eventData, Camera cam)
		{
			RectTransform handleContainerRect = this.m_HandleContainerRect;
			if (handleContainerRect != null && handleContainerRect.rect.size[0] > 0f)
			{
				Vector2 vector;
				if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(handleContainerRect, eventData.position, cam, out vector))
				{
					return;
				}
				vector -= handleContainerRect.rect.position;
				float num = Mathf.Clamp01((vector - this.m_Offset)[0] / handleContainerRect.rect.size[0]);
				this.NormalizedValueX = num;
				float num2 = Mathf.Clamp01((vector - this.m_Offset)[1] / handleContainerRect.rect.size[1]);
				this.NormalizedValueY = num2;
			}
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00005EE0 File Offset: 0x000040E0
		private bool CanDrag(PointerEventData eventData)
		{
			return this.IsActive() && this.IsInteractable() && eventData.button == PointerEventData.InputButton.Left;
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00005F00 File Offset: 0x00004100
		public override void OnPointerDown(PointerEventData eventData)
		{
			if (!this.CanDrag(eventData))
			{
				return;
			}
			base.OnPointerDown(eventData);
			this.m_Offset = Vector2.zero;
			if (this.m_HandleContainerRect != null && RectTransformUtility.RectangleContainsScreenPoint(this.m_HandleRect, eventData.position, eventData.enterEventCamera))
			{
				Vector2 vector;
				if (RectTransformUtility.ScreenPointToLocalPointInRectangle(this.m_HandleRect, eventData.position, eventData.pressEventCamera, out vector))
				{
					this.m_Offset = vector;
				}
				this.m_Offset.y = -this.m_Offset.y;
				return;
			}
			this.UpdateDrag(eventData, eventData.pressEventCamera);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00005F97 File Offset: 0x00004197
		public virtual void OnDrag(PointerEventData eventData)
		{
			if (!this.CanDrag(eventData))
			{
				return;
			}
			this.UpdateDrag(eventData, eventData.pressEventCamera);
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00005FB0 File Offset: 0x000041B0
		public virtual void OnInitializePotentialDrag(PointerEventData eventData)
		{
			eventData.useDragThreshold = false;
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00005FB9 File Offset: 0x000041B9
		Transform ICanvasElement.get_transform()
		{
			return base.transform;
		}

		// Token: 0x040000C0 RID: 192
		[SerializeField]
		private RectTransform m_HandleRect;

		// Token: 0x040000C1 RID: 193
		[Space(6f)]
		[SerializeField]
		private float m_MinValue;

		// Token: 0x040000C2 RID: 194
		[SerializeField]
		private float m_MaxValue = 1f;

		// Token: 0x040000C3 RID: 195
		[SerializeField]
		private bool m_WholeNumbers;

		// Token: 0x040000C4 RID: 196
		[SerializeField]
		private float m_ValueX = 1f;

		// Token: 0x040000C5 RID: 197
		[SerializeField]
		private float m_ValueY = 1f;

		// Token: 0x040000C6 RID: 198
		[Space(6f)]
		[SerializeField]
		private BoxSlider.BoxSliderEvent m_OnValueChanged = new BoxSlider.BoxSliderEvent();

		// Token: 0x040000C7 RID: 199
		private Transform m_HandleTransform;

		// Token: 0x040000C8 RID: 200
		private RectTransform m_HandleContainerRect;

		// Token: 0x040000C9 RID: 201
		private Vector2 m_Offset = Vector2.zero;

		// Token: 0x040000CA RID: 202
		private DrivenRectTransformTracker m_Tracker;

		// Token: 0x02000105 RID: 261
		public enum Direction
		{
			// Token: 0x04000614 RID: 1556
			LeftToRight,
			// Token: 0x04000615 RID: 1557
			RightToLeft,
			// Token: 0x04000616 RID: 1558
			BottomToTop,
			// Token: 0x04000617 RID: 1559
			TopToBottom
		}

		// Token: 0x02000106 RID: 262
		[Serializable]
		public class BoxSliderEvent : UnityEvent<float, float>
		{
		}

		// Token: 0x02000107 RID: 263
		private enum Axis
		{
			// Token: 0x04000619 RID: 1561
			Horizontal,
			// Token: 0x0400061A RID: 1562
			Vertical
		}
	}
}
