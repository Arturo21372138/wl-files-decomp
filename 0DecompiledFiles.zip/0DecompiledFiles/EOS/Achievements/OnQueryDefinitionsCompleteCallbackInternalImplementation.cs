﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000807 RID: 2055
	internal static class OnQueryDefinitionsCompleteCallbackInternalImplementation
	{
		// Token: 0x17000868 RID: 2152
		// (get) Token: 0x060021CC RID: 8652 RVA: 0x000283E8 File Offset: 0x000265E8
		public static OnQueryDefinitionsCompleteCallbackInternal Delegate
		{
			get
			{
				if (OnQueryDefinitionsCompleteCallbackInternalImplementation.s_Delegate == null)
				{
					OnQueryDefinitionsCompleteCallbackInternalImplementation.s_Delegate = new OnQueryDefinitionsCompleteCallbackInternal(OnQueryDefinitionsCompleteCallbackInternalImplementation.EntryPoint);
				}
				return OnQueryDefinitionsCompleteCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060021CD RID: 8653 RVA: 0x00028408 File Offset: 0x00026608
		[MonoPInvokeCallback(typeof(OnQueryDefinitionsCompleteCallbackInternal))]
		public static void EntryPoint(ref OnQueryDefinitionsCompleteCallbackInfoInternal data)
		{
			OnQueryDefinitionsCompleteCallback onQueryDefinitionsCompleteCallback;
			OnQueryDefinitionsCompleteCallbackInfo onQueryDefinitionsCompleteCallbackInfo;
			if (Helper.TryGetAndRemoveCallback<OnQueryDefinitionsCompleteCallbackInfoInternal, OnQueryDefinitionsCompleteCallback, OnQueryDefinitionsCompleteCallbackInfo>(ref data, out onQueryDefinitionsCompleteCallback, out onQueryDefinitionsCompleteCallbackInfo))
			{
				onQueryDefinitionsCompleteCallback(ref onQueryDefinitionsCompleteCallbackInfo);
			}
		}

		// Token: 0x04001694 RID: 5780
		private static OnQueryDefinitionsCompleteCallbackInternal s_Delegate;
	}
}
