﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007DE RID: 2014
	internal struct AddNotifyAchievementsUnlockedOptionsInternal : ISettable<AddNotifyAchievementsUnlockedOptions>, IDisposable
	{
		// Token: 0x06002134 RID: 8500 RVA: 0x00027B15 File Offset: 0x00025D15
		public void Set(ref AddNotifyAchievementsUnlockedOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x06002135 RID: 8501 RVA: 0x00027B24 File Offset: 0x00025D24
		public void Dispose()
		{
		}

		// Token: 0x04001628 RID: 5672
		private int m_ApiVersion;
	}
}
