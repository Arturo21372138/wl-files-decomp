﻿using System;
using System.Collections.Generic;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000034 RID: 52
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/Dropdown List")]
	public class DropDownList : MonoBehaviour
	{
		// Token: 0x1700001D RID: 29
		// (get) Token: 0x06000112 RID: 274 RVA: 0x00007466 File Offset: 0x00005666
		// (set) Token: 0x06000113 RID: 275 RVA: 0x0000746E File Offset: 0x0000566E
		public DropDownListItem SelectedItem { get; private set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000114 RID: 276 RVA: 0x00007477 File Offset: 0x00005677
		// (set) Token: 0x06000115 RID: 277 RVA: 0x0000747F File Offset: 0x0000567F
		public float ScrollBarWidth
		{
			get
			{
				return this._scrollBarWidth;
			}
			set
			{
				this._scrollBarWidth = value;
				this.RedrawPanel();
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000116 RID: 278 RVA: 0x0000748E File Offset: 0x0000568E
		// (set) Token: 0x06000117 RID: 279 RVA: 0x00007496 File Offset: 0x00005696
		public int ItemsToDisplay
		{
			get
			{
				return this._itemsToDisplay;
			}
			set
			{
				this._itemsToDisplay = value;
				this.RedrawPanel();
			}
		}

		// Token: 0x06000118 RID: 280 RVA: 0x000074A5 File Offset: 0x000056A5
		public void Start()
		{
			this.Initialize();
			if (this.SelectFirstItemOnStart && this.Items.Count > 0)
			{
				this.ToggleDropdownPanel(false);
				this.OnItemClicked(0);
			}
		}

		// Token: 0x06000119 RID: 281 RVA: 0x000074D4 File Offset: 0x000056D4
		private bool Initialize()
		{
			bool flag = true;
			try
			{
				this._rectTransform = base.GetComponent<RectTransform>();
				this._mainButton = new DropDownListButton(this._rectTransform.Find("MainButton").gameObject);
				this._overlayRT = this._rectTransform.Find("Overlay").GetComponent<RectTransform>();
				this._overlayRT.gameObject.SetActive(false);
				this._scrollPanelRT = this._overlayRT.Find("ScrollPanel").GetComponent<RectTransform>();
				this._scrollBarRT = this._scrollPanelRT.Find("Scrollbar").GetComponent<RectTransform>();
				this._slidingAreaRT = this._scrollBarRT.Find("SlidingArea").GetComponent<RectTransform>();
				this._itemsPanelRT = this._scrollPanelRT.Find("Items").GetComponent<RectTransform>();
				this._canvas = base.GetComponentInParent<Canvas>();
				this._canvasRT = this._canvas.GetComponent<RectTransform>();
				this._scrollRect = this._scrollPanelRT.GetComponent<ScrollRect>();
				this._scrollRect.scrollSensitivity = this._rectTransform.sizeDelta.y / 2f;
				this._scrollRect.movementType = ScrollRect.MovementType.Clamped;
				this._scrollRect.content = this._itemsPanelRT;
				this._itemTemplate = this._rectTransform.Find("ItemTemplate").gameObject;
				this._itemTemplate.SetActive(false);
			}
			catch (NullReferenceException ex)
			{
				Debug.LogException(ex);
				Debug.LogError("Something is setup incorrectly with the dropdownlist component causing a Null Reference Exception");
				flag = false;
			}
			this._panelItems = new List<DropDownListButton>();
			this.RebuildPanel();
			this.RedrawPanel();
			return flag;
		}

		// Token: 0x0600011A RID: 282 RVA: 0x00007684 File Offset: 0x00005884
		public void RefreshItems(params object[] list)
		{
			this.Items.Clear();
			List<DropDownListItem> list2 = new List<DropDownListItem>();
			foreach (object obj in list)
			{
				if (obj is DropDownListItem)
				{
					list2.Add((DropDownListItem)obj);
				}
				else if (obj is string)
				{
					list2.Add(new DropDownListItem((string)obj, "", null, false, null));
				}
				else
				{
					if (!(obj is Sprite))
					{
						throw new Exception("Only ComboBoxItems, Strings, and Sprite types are allowed");
					}
					list2.Add(new DropDownListItem("", "", (Sprite)obj, false, null));
				}
			}
			this.Items.AddRange(list2);
			this.RebuildPanel();
		}

		// Token: 0x0600011B RID: 283 RVA: 0x00007733 File Offset: 0x00005933
		public void AddItem(DropDownListItem item)
		{
			this.Items.Add(item);
			this.RebuildPanel();
		}

		// Token: 0x0600011C RID: 284 RVA: 0x00007747 File Offset: 0x00005947
		public void AddItem(string item)
		{
			this.Items.Add(new DropDownListItem(item, "", null, false, null));
			this.RebuildPanel();
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00007768 File Offset: 0x00005968
		public void AddItem(Sprite item)
		{
			this.Items.Add(new DropDownListItem("", "", item, false, null));
			this.RebuildPanel();
		}

		// Token: 0x0600011E RID: 286 RVA: 0x0000778D File Offset: 0x0000598D
		public void RemoveItem(DropDownListItem item)
		{
			this.Items.Remove(item);
			this.RebuildPanel();
		}

		// Token: 0x0600011F RID: 287 RVA: 0x000077A2 File Offset: 0x000059A2
		public void RemoveItem(string item)
		{
			this.Items.Remove(new DropDownListItem(item, "", null, false, null));
			this.RebuildPanel();
		}

		// Token: 0x06000120 RID: 288 RVA: 0x000077C4 File Offset: 0x000059C4
		public void RemoveItem(Sprite item)
		{
			this.Items.Remove(new DropDownListItem("", "", item, false, null));
			this.RebuildPanel();
		}

		// Token: 0x06000121 RID: 289 RVA: 0x000077EA File Offset: 0x000059EA
		public void ResetItems()
		{
			this.Items.Clear();
			this.RebuildPanel();
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00007800 File Offset: 0x00005A00
		private void RebuildPanel()
		{
			if (this.Items.Count == 0)
			{
				return;
			}
			int num = this._panelItems.Count;
			while (this._panelItems.Count < this.Items.Count)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this._itemTemplate);
				gameObject.name = "Item " + num.ToString();
				gameObject.transform.SetParent(this._itemsPanelRT, false);
				this._panelItems.Add(new DropDownListButton(gameObject));
				num++;
			}
			for (int i = 0; i < this._panelItems.Count; i++)
			{
				if (i < this.Items.Count)
				{
					DropDownListItem item = this.Items[i];
					this._panelItems[i].txt.text = item.Caption;
					if (item.IsDisabled)
					{
						this._panelItems[i].txt.color = this.disabledTextColor;
					}
					if (this._panelItems[i].btnImg != null)
					{
						this._panelItems[i].btnImg.sprite = null;
					}
					this._panelItems[i].img.sprite = item.Image;
					this._panelItems[i].img.color = ((item.Image == null) ? new Color(1f, 1f, 1f, 0f) : (item.IsDisabled ? new Color(1f, 1f, 1f, 0.5f) : Color.white));
					int ii = i;
					this._panelItems[i].btn.onClick.RemoveAllListeners();
					this._panelItems[i].btn.onClick.AddListener(delegate
					{
						this.OnItemClicked(ii);
						if (item.OnSelect != null)
						{
							item.OnSelect();
						}
					});
				}
				this._panelItems[i].gameobject.SetActive(i < this.Items.Count);
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x00007A50 File Offset: 0x00005C50
		private void OnItemClicked(int indx)
		{
			if (indx != this._selectedIndex && this.OnSelectionChanged != null)
			{
				this.OnSelectionChanged.Invoke(indx);
			}
			this._selectedIndex = indx;
			this.ToggleDropdownPanel(true);
			this.UpdateSelected();
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00007A84 File Offset: 0x00005C84
		private void UpdateSelected()
		{
			this.SelectedItem = ((this._selectedIndex > -1 && this._selectedIndex < this.Items.Count) ? this.Items[this._selectedIndex] : null);
			if (this.SelectedItem == null)
			{
				return;
			}
			if (this.SelectedItem.Image != null)
			{
				this._mainButton.img.sprite = this.SelectedItem.Image;
				this._mainButton.img.color = Color.white;
			}
			else
			{
				this._mainButton.img.sprite = null;
			}
			this._mainButton.txt.text = this.SelectedItem.Caption;
			if (this.OverrideHighlighted)
			{
				for (int i = 0; i < this._itemsPanelRT.childCount; i++)
				{
					this._panelItems[i].btnImg.color = ((this._selectedIndex == i) ? this._mainButton.btn.colors.highlightedColor : new Color(0f, 0f, 0f, 0f));
				}
			}
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00007BB4 File Offset: 0x00005DB4
		private void RedrawPanel()
		{
			float num = ((this.Items.Count > this.ItemsToDisplay) ? this._scrollBarWidth : 0f);
			if (!this._hasDrawnOnce || this._rectTransform.sizeDelta != this._mainButton.rectTransform.sizeDelta)
			{
				this._hasDrawnOnce = true;
				this._mainButton.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._rectTransform.sizeDelta.x);
				this._mainButton.rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this._rectTransform.sizeDelta.y);
				this._mainButton.txt.rectTransform.offsetMax = new Vector2(4f, 0f);
				this._scrollPanelRT.SetParent(base.transform, true);
				this._scrollPanelRT.anchoredPosition = new Vector2(0f, -this._rectTransform.sizeDelta.y);
				this._overlayRT.SetParent(this._canvas.transform, false);
				this._overlayRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._canvasRT.sizeDelta.x);
				this._overlayRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, this._canvasRT.sizeDelta.y);
				this._overlayRT.SetParent(base.transform, true);
				this._scrollPanelRT.SetParent(this._overlayRT, true);
			}
			if (this.Items.Count < 1)
			{
				return;
			}
			float num2 = this._rectTransform.sizeDelta.y * (float)Mathf.Min(this._itemsToDisplay, this.Items.Count);
			this._scrollPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2);
			this._scrollPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._rectTransform.sizeDelta.x);
			this._itemsPanelRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, this._scrollPanelRT.sizeDelta.x - num - 5f);
			this._itemsPanelRT.anchoredPosition = new Vector2(5f, 0f);
			this._scrollBarRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, num);
			this._scrollBarRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2);
			this._slidingAreaRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, 0f);
			this._slidingAreaRT.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, num2 - this._scrollBarRT.sizeDelta.x);
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00007E10 File Offset: 0x00006010
		public void ToggleDropdownPanel(bool directClick)
		{
			this._overlayRT.transform.localScale = new Vector3(1f, 1f, 1f);
			this._scrollBarRT.transform.localScale = new Vector3(1f, 1f, 1f);
			this._isPanelActive = !this._isPanelActive;
			this._overlayRT.gameObject.SetActive(this._isPanelActive);
			if (this._isPanelActive)
			{
				base.transform.SetAsLastSibling();
				return;
			}
		}

		// Token: 0x0400010D RID: 269
		public Color disabledTextColor;

		// Token: 0x0400010F RID: 271
		public List<DropDownListItem> Items;

		// Token: 0x04000110 RID: 272
		public bool OverrideHighlighted = true;

		// Token: 0x04000111 RID: 273
		private bool _isPanelActive;

		// Token: 0x04000112 RID: 274
		private bool _hasDrawnOnce;

		// Token: 0x04000113 RID: 275
		private DropDownListButton _mainButton;

		// Token: 0x04000114 RID: 276
		private RectTransform _rectTransform;

		// Token: 0x04000115 RID: 277
		private RectTransform _overlayRT;

		// Token: 0x04000116 RID: 278
		private RectTransform _scrollPanelRT;

		// Token: 0x04000117 RID: 279
		private RectTransform _scrollBarRT;

		// Token: 0x04000118 RID: 280
		private RectTransform _slidingAreaRT;

		// Token: 0x04000119 RID: 281
		private RectTransform _itemsPanelRT;

		// Token: 0x0400011A RID: 282
		private Canvas _canvas;

		// Token: 0x0400011B RID: 283
		private RectTransform _canvasRT;

		// Token: 0x0400011C RID: 284
		private ScrollRect _scrollRect;

		// Token: 0x0400011D RID: 285
		private List<DropDownListButton> _panelItems;

		// Token: 0x0400011E RID: 286
		private GameObject _itemTemplate;

		// Token: 0x0400011F RID: 287
		[SerializeField]
		private float _scrollBarWidth = 20f;

		// Token: 0x04000120 RID: 288
		private int _selectedIndex = -1;

		// Token: 0x04000121 RID: 289
		[SerializeField]
		private int _itemsToDisplay;

		// Token: 0x04000122 RID: 290
		public bool SelectFirstItemOnStart;

		// Token: 0x04000123 RID: 291
		public DropDownList.SelectionChangedEvent OnSelectionChanged;

		// Token: 0x0200010F RID: 271
		[Serializable]
		public class SelectionChangedEvent : UnityEvent<int>
		{
		}
	}
}
