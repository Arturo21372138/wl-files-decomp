﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200006D RID: 109
	[ExecuteInEditMode]
	public class SuperellipsePoints : MonoBehaviour
	{
		// Token: 0x0600032A RID: 810 RVA: 0x0001545C File Offset: 0x0001365C
		private void Start()
		{
			this.RecalculateSuperellipse();
			base.GetComponent<MeshRenderer>().material = this.material;
			this.lastXLim = this.xLimits;
			this.lastYLim = this.yLimits;
			this.lastSuper = this.superness;
			this.lastLoD = this.levelOfDetail;
		}

		// Token: 0x0600032B RID: 811 RVA: 0x000154B0 File Offset: 0x000136B0
		private void Update()
		{
			if (this.lastXLim != this.xLimits || this.lastYLim != this.yLimits || this.lastSuper != this.superness || this.lastLoD != this.levelOfDetail)
			{
				this.RecalculateSuperellipse();
			}
			this.lastXLim = this.xLimits;
			this.lastYLim = this.yLimits;
			this.lastSuper = this.superness;
			this.lastLoD = this.levelOfDetail;
		}

		// Token: 0x0600032C RID: 812 RVA: 0x0001552C File Offset: 0x0001372C
		private void RecalculateSuperellipse()
		{
			this.pointList.Clear();
			float num = (float)(this.levelOfDetail * 4);
			for (float num2 = 0f; num2 < this.xLimits; num2 += 1f / num)
			{
				float num3 = this.Superellipse(this.xLimits, this.yLimits, num2, this.superness);
				Vector2 vector = new Vector2(num2, num3);
				this.pointList.Add(vector);
			}
			this.pointList.Add(new Vector2(this.xLimits, 0f));
			this.pointList.Add(Vector2.zero);
			base.GetComponent<MeshCreator>().CreateMesh(this.pointList);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x000155D4 File Offset: 0x000137D4
		private float Superellipse(float a, float b, float x, float n)
		{
			float num = Mathf.Pow(x / a, n);
			return Mathf.Pow(1f - num, 1f / n) * b;
		}

		// Token: 0x040002A2 RID: 674
		public float xLimits = 1f;

		// Token: 0x040002A3 RID: 675
		public float yLimits = 1f;

		// Token: 0x040002A4 RID: 676
		[Range(1f, 96f)]
		public float superness = 4f;

		// Token: 0x040002A5 RID: 677
		private float lastXLim;

		// Token: 0x040002A6 RID: 678
		private float lastYLim;

		// Token: 0x040002A7 RID: 679
		private float lastSuper;

		// Token: 0x040002A8 RID: 680
		[Space]
		[Range(1f, 32f)]
		public int levelOfDetail = 4;

		// Token: 0x040002A9 RID: 681
		private int lastLoD;

		// Token: 0x040002AA RID: 682
		[Space]
		public Material material;

		// Token: 0x040002AB RID: 683
		private List<Vector2> pointList = new List<Vector2>();
	}
}
