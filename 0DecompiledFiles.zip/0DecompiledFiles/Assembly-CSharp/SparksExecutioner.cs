﻿using System;
using UnityEngine;

// Token: 0x02000011 RID: 17
public class SparksExecutioner : MonoBehaviour
{
	// Token: 0x06000029 RID: 41 RVA: 0x00002E57 File Offset: 0x00001057
	private void Start()
	{
		base.Invoke("Kill", this.Lifetime);
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00002E6A File Offset: 0x0000106A
	private void Kill()
	{
		Object.Destroy(base.gameObject);
	}

	// Token: 0x04000024 RID: 36
	public float Lifetime = 1f;
}
