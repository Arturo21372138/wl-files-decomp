﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B9 RID: 185
	public static class ScrollRectExtensions
	{
		// Token: 0x0600061A RID: 1562 RVA: 0x000245C2 File Offset: 0x000227C2
		public static void ScrollToTop(this ScrollRect scrollRect)
		{
			scrollRect.normalizedPosition = new Vector2(0f, 1f);
		}

		// Token: 0x0600061B RID: 1563 RVA: 0x000245D9 File Offset: 0x000227D9
		public static void ScrollToBottom(this ScrollRect scrollRect)
		{
			scrollRect.normalizedPosition = new Vector2(0f, 0f);
		}
	}
}
