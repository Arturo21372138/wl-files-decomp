﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000DF RID: 223
	public enum CutMode
	{
		// Token: 0x0400055A RID: 1370
		Automatic,
		// Token: 0x0400055B RID: 1371
		Manual
	}
}
