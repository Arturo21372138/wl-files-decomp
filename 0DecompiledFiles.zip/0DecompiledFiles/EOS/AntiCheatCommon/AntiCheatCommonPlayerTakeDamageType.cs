﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000777 RID: 1911
	public enum AntiCheatCommonPlayerTakeDamageType
	{
		// Token: 0x040014CC RID: 5324
		None,
		// Token: 0x040014CD RID: 5325
		PointDamage,
		// Token: 0x040014CE RID: 5326
		RadialDamage,
		// Token: 0x040014CF RID: 5327
		DamageOverTime
	}
}
