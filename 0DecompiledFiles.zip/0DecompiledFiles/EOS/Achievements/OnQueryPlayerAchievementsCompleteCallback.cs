﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200080A RID: 2058
	// (Invoke) Token: 0x060021D7 RID: 8663
	public delegate void OnQueryPlayerAchievementsCompleteCallback(ref OnQueryPlayerAchievementsCompleteCallbackInfo data);
}
