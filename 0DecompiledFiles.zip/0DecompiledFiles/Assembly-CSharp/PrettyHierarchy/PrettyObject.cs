﻿using System;
using UnityEngine;

namespace PrettyHierarchy
{
	// Token: 0x02000029 RID: 41
	[DisallowMultipleComponent]
	public class PrettyObject : MonoBehaviour
	{
	}
}
