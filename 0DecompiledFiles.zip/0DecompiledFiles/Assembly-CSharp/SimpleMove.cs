﻿using System;
using UnityEngine;

// Token: 0x02000010 RID: 16
public class SimpleMove : MonoBehaviour
{
	// Token: 0x06000027 RID: 39 RVA: 0x00002DDC File Offset: 0x00000FDC
	private void Update()
	{
		base.transform.RotateAround(Vector3.zero, Vector3.up, Time.deltaTime * this.AngularSpeed);
		RaycastHit raycastHit;
		if (Physics.Raycast(new Ray(base.transform.position + Vector3.up, Vector3.down), out raycastHit))
		{
			base.transform.position = raycastHit.point;
		}
	}

	// Token: 0x04000023 RID: 35
	public float AngularSpeed = 1f;
}
