﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200081C RID: 2076
	public struct StatThresholds
	{
		// Token: 0x17000888 RID: 2184
		// (get) Token: 0x06002228 RID: 8744 RVA: 0x0002895E File Offset: 0x00026B5E
		// (set) Token: 0x06002229 RID: 8745 RVA: 0x00028966 File Offset: 0x00026B66
		public Utf8String Name { readonly get; set; }

		// Token: 0x17000889 RID: 2185
		// (get) Token: 0x0600222A RID: 8746 RVA: 0x0002896F File Offset: 0x00026B6F
		// (set) Token: 0x0600222B RID: 8747 RVA: 0x00028977 File Offset: 0x00026B77
		public int Threshold { readonly get; set; }
	}
}
