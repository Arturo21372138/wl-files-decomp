﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007BD RID: 1981
	internal struct OnClientIntegrityViolatedCallbackInfoInternal : ICallbackInfoInternal, IGettable<OnClientIntegrityViolatedCallbackInfo>
	{
		// Token: 0x17000820 RID: 2080
		// (get) Token: 0x060020BF RID: 8383 RVA: 0x000270F6 File Offset: 0x000252F6
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x060020C0 RID: 8384 RVA: 0x00027100 File Offset: 0x00025300
		public void Get(out OnClientIntegrityViolatedCallbackInfo other)
		{
			other = default(OnClientIntegrityViolatedCallbackInfo);
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
			other.ViolationType = this.m_ViolationType;
			Utf8String utf8String;
			Helper.Get(this.m_ViolationMessage, out utf8String);
			other.ViolationMessage = utf8String;
		}

		// Token: 0x040015D6 RID: 5590
		private IntPtr m_ClientData;

		// Token: 0x040015D7 RID: 5591
		private AntiCheatClientViolationType m_ViolationType;

		// Token: 0x040015D8 RID: 5592
		private IntPtr m_ViolationMessage;
	}
}
