﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007EF RID: 2031
	public struct CopyUnlockedAchievementByIndexOptions
	{
		// Token: 0x17000844 RID: 2116
		// (get) Token: 0x0600215E RID: 8542 RVA: 0x00027DA7 File Offset: 0x00025FA7
		// (set) Token: 0x0600215F RID: 8543 RVA: 0x00027DAF File Offset: 0x00025FAF
		public ProductUserId UserId { readonly get; set; }

		// Token: 0x17000845 RID: 2117
		// (get) Token: 0x06002160 RID: 8544 RVA: 0x00027DB8 File Offset: 0x00025FB8
		// (set) Token: 0x06002161 RID: 8545 RVA: 0x00027DC0 File Offset: 0x00025FC0
		public uint AchievementIndex { readonly get; set; }
	}
}
