﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000055 RID: 85
	[AddComponentMenu("UI/Effects/Extensions/Gradient")]
	public class Gradient : BaseMeshEffect
	{
		// Token: 0x1700006E RID: 110
		// (get) Token: 0x060002A0 RID: 672 RVA: 0x0000FDFC File Offset: 0x0000DFFC
		// (set) Token: 0x060002A1 RID: 673 RVA: 0x0000FE04 File Offset: 0x0000E004
		public GradientMode GradientMode
		{
			get
			{
				return this._gradientMode;
			}
			set
			{
				this._gradientMode = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x060002A2 RID: 674 RVA: 0x0000FE18 File Offset: 0x0000E018
		// (set) Token: 0x060002A3 RID: 675 RVA: 0x0000FE20 File Offset: 0x0000E020
		public GradientDir GradientDir
		{
			get
			{
				return this._gradientDir;
			}
			set
			{
				this._gradientDir = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x060002A4 RID: 676 RVA: 0x0000FE34 File Offset: 0x0000E034
		// (set) Token: 0x060002A5 RID: 677 RVA: 0x0000FE3C File Offset: 0x0000E03C
		public bool OverwriteAllColor
		{
			get
			{
				return this._overwriteAllColor;
			}
			set
			{
				this._overwriteAllColor = value;
				base.graphic.SetVerticesDirty();
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x060002A6 RID: 678 RVA: 0x0000FE50 File Offset: 0x0000E050
		// (set) Token: 0x060002A7 RID: 679 RVA: 0x0000FE58 File Offset: 0x0000E058
		public Color Vertex1
		{
			get
			{
				return this._vertex1;
			}
			set
			{
				this._vertex1 = value;
				base.graphic.SetAllDirty();
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x060002A8 RID: 680 RVA: 0x0000FE6C File Offset: 0x0000E06C
		// (set) Token: 0x060002A9 RID: 681 RVA: 0x0000FE74 File Offset: 0x0000E074
		public Color Vertex2
		{
			get
			{
				return this._vertex2;
			}
			set
			{
				this._vertex2 = value;
				base.graphic.SetAllDirty();
			}
		}

		// Token: 0x060002AA RID: 682 RVA: 0x0000FE88 File Offset: 0x0000E088
		protected override void Awake()
		{
			this.targetGraphic = base.GetComponent<Graphic>();
		}

		// Token: 0x060002AB RID: 683 RVA: 0x0000FE98 File Offset: 0x0000E098
		public override void ModifyMesh(VertexHelper vh)
		{
			int currentVertCount = vh.currentVertCount;
			if (!this.IsActive() || currentVertCount == 0)
			{
				return;
			}
			List<UIVertex> list = new List<UIVertex>();
			vh.GetUIVertexStream(list);
			UIVertex uivertex = default(UIVertex);
			if (this._gradientMode == GradientMode.Global)
			{
				if (this._gradientDir == GradientDir.DiagonalLeftToRight || this._gradientDir == GradientDir.DiagonalRightToLeft)
				{
					this._gradientDir = GradientDir.Vertical;
				}
				float num = ((this._gradientDir == GradientDir.Vertical) ? list[list.Count - 1].position.y : list[list.Count - 1].position.x);
				float num2 = ((this._gradientDir == GradientDir.Vertical) ? list[0].position.y : list[0].position.x) - num;
				for (int i = 0; i < currentVertCount; i++)
				{
					vh.PopulateUIVertex(ref uivertex, i);
					if (this._overwriteAllColor || !(uivertex.color != this.targetGraphic.color))
					{
						uivertex.color *= Color.Lerp(this._vertex2, this._vertex1, (((this._gradientDir == GradientDir.Vertical) ? uivertex.position.y : uivertex.position.x) - num) / num2);
						vh.SetUIVertex(uivertex, i);
					}
				}
				return;
			}
			for (int j = 0; j < currentVertCount; j++)
			{
				vh.PopulateUIVertex(ref uivertex, j);
				if (this._overwriteAllColor || this.CompareCarefully(uivertex.color, this.targetGraphic.color))
				{
					switch (this._gradientDir)
					{
					case GradientDir.Vertical:
						uivertex.color *= ((j % 4 == 0 || (j - 1) % 4 == 0) ? this._vertex1 : this._vertex2);
						break;
					case GradientDir.Horizontal:
						uivertex.color *= ((j % 4 == 0 || (j - 3) % 4 == 0) ? this._vertex1 : this._vertex2);
						break;
					case GradientDir.DiagonalLeftToRight:
						uivertex.color *= ((j % 4 == 0) ? this._vertex1 : (((j - 2) % 4 == 0) ? this._vertex2 : Color.Lerp(this._vertex2, this._vertex1, 0.5f)));
						break;
					case GradientDir.DiagonalRightToLeft:
						uivertex.color *= (((j - 1) % 4 == 0) ? this._vertex1 : (((j - 3) % 4 == 0) ? this._vertex2 : Color.Lerp(this._vertex2, this._vertex1, 0.5f)));
						break;
					}
					vh.SetUIVertex(uivertex, j);
				}
			}
		}

		// Token: 0x060002AC RID: 684 RVA: 0x000101AC File Offset: 0x0000E3AC
		private bool CompareCarefully(Color col1, Color col2)
		{
			return Mathf.Abs(col1.r - col2.r) < 0.003f && Mathf.Abs(col1.g - col2.g) < 0.003f && Mathf.Abs(col1.b - col2.b) < 0.003f && Mathf.Abs(col1.a - col2.a) < 0.003f;
		}

		// Token: 0x04000219 RID: 537
		[SerializeField]
		private GradientMode _gradientMode;

		// Token: 0x0400021A RID: 538
		[SerializeField]
		private GradientDir _gradientDir;

		// Token: 0x0400021B RID: 539
		[SerializeField]
		private bool _overwriteAllColor;

		// Token: 0x0400021C RID: 540
		[SerializeField]
		private Color _vertex1 = Color.white;

		// Token: 0x0400021D RID: 541
		[SerializeField]
		private Color _vertex2 = Color.black;

		// Token: 0x0400021E RID: 542
		private Graphic targetGraphic;
	}
}
