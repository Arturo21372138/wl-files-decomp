﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200005B RID: 91
	[AddComponentMenu("UI/Effects/Extensions/Nicer Outline")]
	public class NicerOutline : BaseMeshEffect
	{
		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060002CB RID: 715 RVA: 0x00011A59 File Offset: 0x0000FC59
		// (set) Token: 0x060002CC RID: 716 RVA: 0x00011A61 File Offset: 0x0000FC61
		public Color effectColor
		{
			get
			{
				return this.m_EffectColor;
			}
			set
			{
				this.m_EffectColor = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060002CD RID: 717 RVA: 0x00011A83 File Offset: 0x0000FC83
		// (set) Token: 0x060002CE RID: 718 RVA: 0x00011A8C File Offset: 0x0000FC8C
		public Vector2 effectDistance
		{
			get
			{
				return this.m_EffectDistance;
			}
			set
			{
				if (value.x > 600f)
				{
					value.x = 600f;
				}
				if (value.x < -600f)
				{
					value.x = -600f;
				}
				if (value.y > 600f)
				{
					value.y = 600f;
				}
				if (value.y < -600f)
				{
					value.y = -600f;
				}
				if (this.m_EffectDistance == value)
				{
					return;
				}
				this.m_EffectDistance = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060002CF RID: 719 RVA: 0x00011B2C File Offset: 0x0000FD2C
		// (set) Token: 0x060002D0 RID: 720 RVA: 0x00011B34 File Offset: 0x0000FD34
		public bool useGraphicAlpha
		{
			get
			{
				return this.m_UseGraphicAlpha;
			}
			set
			{
				this.m_UseGraphicAlpha = value;
				if (base.graphic != null)
				{
					base.graphic.SetVerticesDirty();
				}
			}
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x00011B58 File Offset: 0x0000FD58
		protected void ApplyShadowZeroAlloc(List<UIVertex> verts, Color32 color, int start, int end, float x, float y)
		{
			int num = verts.Count * 2;
			if (verts.Capacity < num)
			{
				verts.Capacity = num;
			}
			for (int i = start; i < end; i++)
			{
				UIVertex uivertex = verts[i];
				verts.Add(uivertex);
				Vector3 position = uivertex.position;
				position.x += x;
				position.y += y;
				uivertex.position = position;
				Color32 color2 = color;
				if (this.m_UseGraphicAlpha)
				{
					color2.a = color2.a * verts[i].color.a / byte.MaxValue;
				}
				uivertex.color = color2;
				verts[i] = uivertex;
			}
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00011C0C File Offset: 0x0000FE0C
		protected void ApplyShadow(List<UIVertex> verts, Color32 color, int start, int end, float x, float y)
		{
			int num = verts.Count * 2;
			if (verts.Capacity < num)
			{
				verts.Capacity = num;
			}
			this.ApplyShadowZeroAlloc(verts, color, start, end, x, y);
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00011C44 File Offset: 0x0000FE44
		public override void ModifyMesh(VertexHelper vh)
		{
			if (!this.IsActive())
			{
				return;
			}
			this.m_Verts.Clear();
			vh.GetUIVertexStream(this.m_Verts);
			Text component = base.GetComponent<Text>();
			float num = 1f;
			if (component && component.resizeTextForBestFit)
			{
				num = (float)component.cachedTextGenerator.fontSizeUsedForBestFit / (float)(component.resizeTextMaxSize - 1);
			}
			float num2 = this.effectDistance.x * num;
			float num3 = this.effectDistance.y * num;
			int num4 = 0;
			int count = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, num2, num3);
			num4 = count;
			int count2 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, num2, -num3);
			num4 = count2;
			int count3 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, -num2, num3);
			num4 = count3;
			int count4 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, -num2, -num3);
			num4 = count4;
			int count5 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, num2, 0f);
			num4 = count5;
			int count6 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, -num2, 0f);
			num4 = count6;
			int count7 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, 0f, num3);
			num4 = count7;
			int count8 = this.m_Verts.Count;
			this.ApplyShadow(this.m_Verts, this.effectColor, num4, this.m_Verts.Count, 0f, -num3);
			vh.Clear();
			vh.AddUIVertexTriangleStream(this.m_Verts);
		}

		// Token: 0x04000233 RID: 563
		[SerializeField]
		private Color m_EffectColor = new Color(0f, 0f, 0f, 0.5f);

		// Token: 0x04000234 RID: 564
		[SerializeField]
		private Vector2 m_EffectDistance = new Vector2(1f, -1f);

		// Token: 0x04000235 RID: 565
		[SerializeField]
		private bool m_UseGraphicAlpha = true;

		// Token: 0x04000236 RID: 566
		private List<UIVertex> m_Verts = new List<UIVertex>();
	}
}
