﻿using System;
using UnityEngine;
using VisualDesignCafe.Rendering.Nature;

namespace NatureRendererDemo
{
	// Token: 0x02000019 RID: 25
	public class RuntimeEditing : MonoBehaviour
	{
		// Token: 0x0600003B RID: 59 RVA: 0x00003514 File Offset: 0x00001714
		private void OnDrawGizmos()
		{
			if (this._cachedPositions == null)
			{
				this.CreateCurve();
			}
			for (int i = 0; i < this.Waypoints.Length; i++)
			{
				if (this.Waypoints[i].position != this._cachedPositions[i])
				{
					this.CreateCurve();
					break;
				}
			}
			if (this._curveX != null)
			{
				float num = 1f / (this._totalLength / 0.25f);
				for (float num2 = 0f; num2 <= 1f; num2 += num)
				{
					Gizmos.DrawLine(new Vector3(this._curveX.Evaluate(num2), this._curveY.Evaluate(num2), this._curveZ.Evaluate(num2)), new Vector3(this._curveX.Evaluate(num2 + num), this._curveY.Evaluate(num2 + num), this._curveZ.Evaluate(num2 + num)));
				}
			}
		}

		// Token: 0x0600003C RID: 60 RVA: 0x000035F9 File Offset: 0x000017F9
		private void OnValidate()
		{
			this.CreateCurve();
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00003601 File Offset: 0x00001801
		private void OnEnable()
		{
			this._startTime = Time.time;
			this.CreateCurve();
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00003614 File Offset: 0x00001814
		private void Update()
		{
			this.UpdatePosition();
			float num = this.Terrain.terrainData.size.x / (float)this.Terrain.terrainData.detailResolution;
			if (Vector3.Distance(this.Target.position, this._erasePosition) >= num)
			{
				this._erasePosition = this.Target.position;
				this.RemoveDetails(this.Terrain, this.Target.position, this.Radius);
			}
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00003698 File Offset: 0x00001898
		private void UpdatePosition()
		{
			float num = Mathf.Clamp01((Time.time - this._startTime) / this.Duration);
			this.Target.position = new Vector3(this._curveX.Evaluate(num), this._curveY.Evaluate(num), this._curveZ.Evaluate(num));
		}

		// Token: 0x06000040 RID: 64 RVA: 0x000036F4 File Offset: 0x000018F4
		private void CreateCurve()
		{
			if (this.Waypoints == null)
			{
				return;
			}
			this._cachedPositions = new Vector3[this.Waypoints.Length];
			this._totalLength = 0f;
			for (int i = 0; i < this.Waypoints.Length; i++)
			{
				this._cachedPositions[i] = this.Waypoints[i].position;
			}
			for (int j = 0; j < this.Waypoints.Length - 1; j++)
			{
				this._totalLength += Vector3.Distance(this.Waypoints[j].position, this.Waypoints[j + 1].position);
			}
			this._curveX = new AnimationCurve();
			this._curveY = new AnimationCurve();
			this._curveZ = new AnimationCurve();
			float num = 0f;
			for (int k = 0; k < this.Waypoints.Length; k++)
			{
				Vector3 position = this.Waypoints[k].position;
				float num2 = num / this._totalLength;
				this._curveX.AddKey(new Keyframe(num2, position.x));
				this._curveY.AddKey(new Keyframe(num2, position.y));
				this._curveZ.AddKey(new Keyframe(num2, position.z));
				if (k < this.Waypoints.Length - 1)
				{
					num += Vector3.Distance(position, this.Waypoints[k + 1].position);
				}
			}
			this._curveX.preWrapMode = WrapMode.ClampForever;
			this._curveY.preWrapMode = WrapMode.ClampForever;
			this._curveZ.preWrapMode = WrapMode.ClampForever;
			this._curveX.postWrapMode = WrapMode.ClampForever;
			this._curveY.postWrapMode = WrapMode.ClampForever;
			this._curveZ.postWrapMode = WrapMode.ClampForever;
			for (int l = 0; l < this.Waypoints.Length - 1; l++)
			{
				this._curveX.SmoothTangents(l, 0f);
				this._curveY.SmoothTangents(l, 0f);
				this._curveZ.SmoothTangents(l, 0f);
			}
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000038FC File Offset: 0x00001AFC
		private void RemoveDetails(Terrain terrain, Vector3 point, float radius)
		{
			TerrainData terrainData = terrain.terrainData;
			point -= terrain.GetPosition();
			TerrainRect terrainRect = new TerrainRect(point.x - radius, point.z - radius, radius * 2f, radius * 2f);
			DetailmapRect detailmapRect = new DetailmapRect(in terrainRect, terrainData, DetailmapRect.RoundingMethod.Cover, 0);
			int[] supportedLayers = terrainData.GetSupportedLayers(detailmapRect.X, detailmapRect.Y, detailmapRect.Width, detailmapRect.Height);
			int[,] array = new int[detailmapRect.Width, detailmapRect.Height];
			for (int i = 0; i < supportedLayers.Length; i++)
			{
				terrainData.SetDetailLayer(detailmapRect.X, detailmapRect.Y, supportedLayers[i], array);
			}
		}

		// Token: 0x04000044 RID: 68
		public Terrain Terrain;

		// Token: 0x04000045 RID: 69
		public float Duration;

		// Token: 0x04000046 RID: 70
		public Transform[] Waypoints;

		// Token: 0x04000047 RID: 71
		public Transform Target;

		// Token: 0x04000048 RID: 72
		public float Radius;

		// Token: 0x04000049 RID: 73
		private float _totalLength;

		// Token: 0x0400004A RID: 74
		private float _startTime;

		// Token: 0x0400004B RID: 75
		private Vector3 _erasePosition;

		// Token: 0x0400004C RID: 76
		private AnimationCurve _curveX;

		// Token: 0x0400004D RID: 77
		private AnimationCurve _curveY;

		// Token: 0x0400004E RID: 78
		private AnimationCurve _curveZ;

		// Token: 0x0400004F RID: 79
		private Vector3[] _cachedPositions;
	}
}
