﻿using System;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000021 RID: 33
	public class BasicBulletHoles : MonoBehaviour
	{
		// Token: 0x06000065 RID: 101 RVA: 0x00004688 File Offset: 0x00002888
		public void Start()
		{
			if (this.DecalPrefab == null)
			{
				Debug.LogError("The DynamicDemo script has no decal prefab attached.");
			}
		}

		// Token: 0x06000066 RID: 102 RVA: 0x000046A4 File Offset: 0x000028A4
		public void Update()
		{
			if (Input.GetMouseButtonUp(0))
			{
				Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
				RaycastHit raycastHit;
				if (Physics.Raycast(ray, out raycastHit, 200f))
				{
					Debug.DrawLine(ray.origin, raycastHit.point, Color.red);
					EasyDecal easyDecal = EasyDecal.ProjectAt(this.DecalPrefab.gameObject, raycastHit.collider.gameObject, raycastHit.point, raycastHit.normal, true);
					this.t = !this.t;
					if (this.t)
					{
						easyDecal.CancelFade();
					}
				}
			}
		}

		// Token: 0x0400008D RID: 141
		public EasyDecal DecalPrefab;

		// Token: 0x0400008E RID: 142
		private bool t;
	}
}
