﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200009F RID: 159
	[AddComponentMenu("UI/Extensions/Primitives/UILineTextureRenderer")]
	public class UILineTextureRenderer : UIPrimitiveBase
	{
		// Token: 0x170000EE RID: 238
		// (get) Token: 0x0600054F RID: 1359 RVA: 0x0001FC62 File Offset: 0x0001DE62
		// (set) Token: 0x06000550 RID: 1360 RVA: 0x0001FC6A File Offset: 0x0001DE6A
		public Rect uvRect
		{
			get
			{
				return this.m_UVRect;
			}
			set
			{
				if (this.m_UVRect == value)
				{
					return;
				}
				this.m_UVRect = value;
				this.SetVerticesDirty();
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x06000551 RID: 1361 RVA: 0x0001FC88 File Offset: 0x0001DE88
		// (set) Token: 0x06000552 RID: 1362 RVA: 0x0001FC90 File Offset: 0x0001DE90
		public Vector2[] Points
		{
			get
			{
				return this.m_points;
			}
			set
			{
				if (this.m_points == value)
				{
					return;
				}
				this.m_points = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x0001FCAC File Offset: 0x0001DEAC
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			if (this.m_points == null || this.m_points.Length < 2)
			{
				this.m_points = new Vector2[]
				{
					new Vector2(0f, 0f),
					new Vector2(1f, 1f)
				};
			}
			int num = 24;
			float num2 = base.rectTransform.rect.width;
			float num3 = base.rectTransform.rect.height;
			float num4 = -base.rectTransform.pivot.x * base.rectTransform.rect.width;
			float num5 = -base.rectTransform.pivot.y * base.rectTransform.rect.height;
			if (!this.relativeSize)
			{
				num2 = 1f;
				num3 = 1f;
			}
			List<Vector2> list = new List<Vector2>();
			list.Add(this.m_points[0]);
			Vector2 vector = this.m_points[0] + (this.m_points[1] - this.m_points[0]).normalized * (float)num;
			list.Add(vector);
			for (int i = 1; i < this.m_points.Length - 1; i++)
			{
				list.Add(this.m_points[i]);
			}
			vector = this.m_points[this.m_points.Length - 1] - (this.m_points[this.m_points.Length - 1] - this.m_points[this.m_points.Length - 2]).normalized * (float)num;
			list.Add(vector);
			list.Add(this.m_points[this.m_points.Length - 1]);
			Vector2[] array = list.ToArray();
			if (this.UseMargins)
			{
				num2 -= this.Margin.x;
				num3 -= this.Margin.y;
				num4 += this.Margin.x / 2f;
				num5 += this.Margin.y / 2f;
			}
			vh.Clear();
			Vector2 vector2 = Vector2.zero;
			Vector2 vector3 = Vector2.zero;
			for (int j = 1; j < array.Length; j++)
			{
				Vector2 vector4 = array[j - 1];
				Vector2 vector5 = array[j];
				vector4 = new Vector2(vector4.x * num2 + num4, vector4.y * num3 + num5);
				vector5 = new Vector2(vector5.x * num2 + num4, vector5.y * num3 + num5);
				float num6 = Mathf.Atan2(vector5.y - vector4.y, vector5.x - vector4.x) * 180f / 3.1415927f;
				Vector2 vector6 = vector4 + new Vector2(0f, -this.LineThickness / 2f);
				Vector2 vector7 = vector4 + new Vector2(0f, this.LineThickness / 2f);
				Vector2 vector8 = vector5 + new Vector2(0f, this.LineThickness / 2f);
				Vector2 vector9 = vector5 + new Vector2(0f, -this.LineThickness / 2f);
				vector6 = this.RotatePointAroundPivot(vector6, vector4, new Vector3(0f, 0f, num6));
				vector7 = this.RotatePointAroundPivot(vector7, vector4, new Vector3(0f, 0f, num6));
				vector8 = this.RotatePointAroundPivot(vector8, vector5, new Vector3(0f, 0f, num6));
				vector9 = this.RotatePointAroundPivot(vector9, vector5, new Vector3(0f, 0f, num6));
				Vector2 zero = Vector2.zero;
				Vector2 vector10 = new Vector2(0f, 1f);
				Vector2 vector11 = new Vector2(0.5f, 0f);
				Vector2 vector12 = new Vector2(0.5f, 1f);
				Vector2 vector13 = new Vector2(1f, 0f);
				Vector2 vector14 = new Vector2(1f, 1f);
				Vector2[] array2 = new Vector2[] { vector11, vector12, vector12, vector11 };
				if (j > 1)
				{
					vh.AddUIVertexQuad(base.SetVbo(new Vector2[] { vector2, vector3, vector6, vector7 }, array2));
				}
				if (j == 1)
				{
					array2 = new Vector2[] { zero, vector10, vector12, vector11 };
				}
				else if (j == array.Length - 1)
				{
					array2 = new Vector2[] { vector11, vector12, vector14, vector13 };
				}
				vh.AddUIVertexQuad(base.SetVbo(new Vector2[] { vector6, vector7, vector8, vector9 }, array2));
				vector2 = vector8;
				vector3 = vector9;
			}
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x0002024C File Offset: 0x0001E44C
		public Vector3 RotatePointAroundPivot(Vector3 point, Vector3 pivot, Vector3 angles)
		{
			Vector3 vector = point - pivot;
			vector = Quaternion.Euler(angles) * vector;
			point = vector + pivot;
			return point;
		}

		// Token: 0x040003EC RID: 1004
		[SerializeField]
		private Rect m_UVRect = new Rect(0f, 0f, 1f, 1f);

		// Token: 0x040003ED RID: 1005
		[SerializeField]
		private Vector2[] m_points;

		// Token: 0x040003EE RID: 1006
		public float LineThickness = 2f;

		// Token: 0x040003EF RID: 1007
		public bool UseMargins;

		// Token: 0x040003F0 RID: 1008
		public Vector2 Margin;

		// Token: 0x040003F1 RID: 1009
		public bool relativeSize;
	}
}
