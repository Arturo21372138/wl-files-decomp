﻿using System;
using UnityEngine;

// Token: 0x02000004 RID: 4
[DisallowMultipleComponent]
public class ArcadeMachineIntro : MonoBehaviour
{
	// Token: 0x06000014 RID: 20 RVA: 0x0000246C File Offset: 0x0000066C
	public void PlayIntro()
	{
		if (this.animator)
		{
			this.animator.Play("Intro");
		}
		this.bIntroCompleted = false;
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002492 File Offset: 0x00000692
	private void AnimationEvent_IntroStarted()
	{
		this.bIntroCompleted = false;
		Action action = this.onIntroStarted;
		if (action == null)
		{
			return;
		}
		action();
	}

	// Token: 0x06000016 RID: 22 RVA: 0x000024AB File Offset: 0x000006AB
	private void AnimationEvent_IntroCompleted()
	{
		this.bIntroCompleted = true;
		Action action = this.onIntroCompleted;
		if (action == null)
		{
			return;
		}
		action();
	}

	// Token: 0x06000017 RID: 23 RVA: 0x000024C4 File Offset: 0x000006C4
	public bool IsIntroCompleted()
	{
		return this.bIntroCompleted;
	}

	// Token: 0x04000010 RID: 16
	public Action onIntroCompleted;

	// Token: 0x04000011 RID: 17
	public Action onIntroStarted;

	// Token: 0x04000012 RID: 18
	[SerializeField]
	private Animator animator;

	// Token: 0x04000013 RID: 19
	private bool bIntroCompleted;
}
