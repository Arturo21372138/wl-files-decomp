﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000066 RID: 102
	[RequireComponent(typeof(RectTransform), typeof(Graphic))]
	[DisallowMultipleComponent]
	[AddComponentMenu("UI/Effects/Extensions/Flippable")]
	public class UIFlippable : BaseMeshEffect
	{
		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000305 RID: 773 RVA: 0x00012FF0 File Offset: 0x000111F0
		// (set) Token: 0x06000306 RID: 774 RVA: 0x00012FF8 File Offset: 0x000111F8
		public bool horizontal
		{
			get
			{
				return this.m_Horizontal;
			}
			set
			{
				this.m_Horizontal = value;
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000307 RID: 775 RVA: 0x00013001 File Offset: 0x00011201
		// (set) Token: 0x06000308 RID: 776 RVA: 0x00013009 File Offset: 0x00011209
		public bool vertical
		{
			get
			{
				return this.m_Veritical;
			}
			set
			{
				this.m_Veritical = value;
			}
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00013014 File Offset: 0x00011214
		public override void ModifyMesh(VertexHelper verts)
		{
			RectTransform rectTransform = base.transform as RectTransform;
			for (int i = 0; i < verts.currentVertCount; i++)
			{
				UIVertex uivertex = default(UIVertex);
				verts.PopulateUIVertex(ref uivertex, i);
				uivertex.position = new Vector3(this.m_Horizontal ? (uivertex.position.x + (rectTransform.rect.center.x - uivertex.position.x) * 2f) : uivertex.position.x, this.m_Veritical ? (uivertex.position.y + (rectTransform.rect.center.y - uivertex.position.y) * 2f) : uivertex.position.y, uivertex.position.z);
				verts.SetUIVertex(uivertex, i);
			}
		}

		// Token: 0x04000258 RID: 600
		[SerializeField]
		private bool m_Horizontal;

		// Token: 0x04000259 RID: 601
		[SerializeField]
		private bool m_Veritical;
	}
}
