﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B4 RID: 1972
	internal struct BeginSessionOptionsInternal : ISettable<BeginSessionOptions>, IDisposable
	{
		// Token: 0x060020A5 RID: 8357 RVA: 0x00026FEC File Offset: 0x000251EC
		public void Set(ref BeginSessionOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 3;
			Helper.Set(other.LocalUserId, ref this.m_LocalUserId);
			this.m_Mode = other.Mode;
		}

		// Token: 0x060020A6 RID: 8358 RVA: 0x00027018 File Offset: 0x00025218
		public void Dispose()
		{
			Helper.Dispose(ref this.m_LocalUserId);
		}

		// Token: 0x040015CB RID: 5579
		private int m_ApiVersion;

		// Token: 0x040015CC RID: 5580
		private IntPtr m_LocalUserId;

		// Token: 0x040015CD RID: 5581
		private AntiCheatClientMode m_Mode;
	}
}
