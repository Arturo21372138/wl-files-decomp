﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000088 RID: 136
	[AddComponentMenu("Layout/Extensions/Flow Layout Group")]
	public class FlowLayoutGroup : LayoutGroup
	{
		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000408 RID: 1032 RVA: 0x00018205 File Offset: 0x00016405
		// (set) Token: 0x06000409 RID: 1033 RVA: 0x0001820D File Offset: 0x0001640D
		public FlowLayoutGroup.Axis startAxis
		{
			get
			{
				return this.m_StartAxis;
			}
			set
			{
				base.SetProperty<FlowLayoutGroup.Axis>(ref this.m_StartAxis, value);
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x0001821C File Offset: 0x0001641C
		public override void CalculateLayoutInputHorizontal()
		{
			if (this.startAxis == FlowLayoutGroup.Axis.Horizontal)
			{
				base.CalculateLayoutInputHorizontal();
				float num = this.GetGreatestMinimumChildWidth() + (float)base.padding.left + (float)base.padding.right;
				base.SetLayoutInputForAxis(num, -1f, -1f, 0);
				return;
			}
			this._layoutWidth = this.SetLayout(0, true);
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00018279 File Offset: 0x00016479
		public override void SetLayoutHorizontal()
		{
			this.SetLayout(0, false);
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00018284 File Offset: 0x00016484
		public override void SetLayoutVertical()
		{
			this.SetLayout(1, false);
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00018290 File Offset: 0x00016490
		public override void CalculateLayoutInputVertical()
		{
			if (this.startAxis == FlowLayoutGroup.Axis.Horizontal)
			{
				this._layoutHeight = this.SetLayout(1, true);
				return;
			}
			base.CalculateLayoutInputHorizontal();
			float num = this.GetGreatestMinimumChildHeigth() + (float)base.padding.bottom + (float)base.padding.top;
			base.SetLayoutInputForAxis(num, -1f, -1f, 1);
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x0600040E RID: 1038 RVA: 0x000182ED File Offset: 0x000164ED
		protected bool IsCenterAlign
		{
			get
			{
				return base.childAlignment == TextAnchor.LowerCenter || base.childAlignment == TextAnchor.MiddleCenter || base.childAlignment == TextAnchor.UpperCenter;
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600040F RID: 1039 RVA: 0x0001830C File Offset: 0x0001650C
		protected bool IsRightAlign
		{
			get
			{
				return base.childAlignment == TextAnchor.LowerRight || base.childAlignment == TextAnchor.MiddleRight || base.childAlignment == TextAnchor.UpperRight;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000410 RID: 1040 RVA: 0x0001832B File Offset: 0x0001652B
		protected bool IsMiddleAlign
		{
			get
			{
				return base.childAlignment == TextAnchor.MiddleLeft || base.childAlignment == TextAnchor.MiddleRight || base.childAlignment == TextAnchor.MiddleCenter;
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x06000411 RID: 1041 RVA: 0x0001834A File Offset: 0x0001654A
		protected bool IsLowerAlign
		{
			get
			{
				return base.childAlignment == TextAnchor.LowerLeft || base.childAlignment == TextAnchor.LowerRight || base.childAlignment == TextAnchor.LowerCenter;
			}
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0001836C File Offset: 0x0001656C
		public float SetLayout(int axis, bool layoutInput)
		{
			float height = base.rectTransform.rect.height;
			float width = base.rectTransform.rect.width;
			float num = 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = 0f;
			float num5 = 0f;
			float num6 = 0f;
			if (this.startAxis == FlowLayoutGroup.Axis.Horizontal)
			{
				num5 = height;
				num6 = width - (float)base.padding.left - (float)base.padding.right;
				if (this.IsLowerAlign)
				{
					num3 = (float)base.padding.bottom;
					num4 = (float)base.padding.top;
				}
				else
				{
					num3 = (float)base.padding.top;
					num4 = (float)base.padding.bottom;
				}
				num = this.SpacingY;
				num2 = this.SpacingX;
			}
			else if (this.startAxis == FlowLayoutGroup.Axis.Vertical)
			{
				num5 = width;
				num6 = height - (float)base.padding.top - (float)base.padding.bottom;
				if (this.IsRightAlign)
				{
					num3 = (float)base.padding.right;
					num4 = (float)base.padding.left;
				}
				else
				{
					num3 = (float)base.padding.left;
					num4 = (float)base.padding.right;
				}
				num = this.SpacingX;
				num2 = this.SpacingY;
			}
			float num7 = 0f;
			float num8 = 0f;
			for (int i = 0; i < base.rectChildren.Count; i++)
			{
				int num9 = i;
				RectTransform rectTransform = base.rectChildren[num9];
				float num10 = 0f;
				float num11 = 0f;
				if (this.startAxis == FlowLayoutGroup.Axis.Horizontal)
				{
					if (this.invertOrder)
					{
						num9 = (this.IsLowerAlign ? (base.rectChildren.Count - 1 - i) : i);
					}
					rectTransform = base.rectChildren[num9];
					num10 = LayoutUtility.GetPreferredSize(rectTransform, 0);
					num10 = Mathf.Min(num10, num6);
					num11 = LayoutUtility.GetPreferredSize(rectTransform, 1);
					num11 = Mathf.Min(num11, num6);
				}
				else if (this.startAxis == FlowLayoutGroup.Axis.Vertical)
				{
					if (this.invertOrder)
					{
						num9 = (this.IsRightAlign ? (base.rectChildren.Count - 1 - i) : i);
					}
					rectTransform = base.rectChildren[num9];
					num10 = LayoutUtility.GetPreferredSize(rectTransform, 1);
					num10 = Mathf.Min(num10, num6);
					num11 = LayoutUtility.GetPreferredSize(rectTransform, 0);
					num11 = Mathf.Min(num11, num6);
				}
				if (num7 + num10 > num6)
				{
					num7 -= num2;
					if (!layoutInput)
					{
						if (this.startAxis == FlowLayoutGroup.Axis.Horizontal)
						{
							float num12 = this.CalculateRowVerticalOffset(num5, num3, num8);
							this.LayoutRow(this._itemList, num7, num8, num6, (float)base.padding.left, num12, axis);
						}
						else if (this.startAxis == FlowLayoutGroup.Axis.Vertical)
						{
							float num13 = this.CalculateColHorizontalOffset(num5, num3, num8);
							this.LayoutCol(this._itemList, num8, num7, num6, num13, (float)base.padding.top, axis);
						}
					}
					this._itemList.Clear();
					num3 += num8;
					num3 += num;
					num8 = 0f;
					num7 = 0f;
				}
				num7 += num10;
				this._itemList.Add(rectTransform);
				if (num11 > num8)
				{
					num8 = num11;
				}
				if (i < base.rectChildren.Count - 1)
				{
					num7 += num2;
				}
			}
			if (!layoutInput)
			{
				if (this.startAxis == FlowLayoutGroup.Axis.Horizontal)
				{
					float num14 = this.CalculateRowVerticalOffset(height, num3, num8);
					num7 -= num2;
					this.LayoutRow(this._itemList, num7, num8, num6 - (this.ChildForceExpandWidth ? 0f : num2), (float)base.padding.left, num14, axis);
				}
				else if (this.startAxis == FlowLayoutGroup.Axis.Vertical)
				{
					float num15 = this.CalculateColHorizontalOffset(width, num3, num8);
					num7 -= num2;
					this.LayoutCol(this._itemList, num8, num7, num6 - (this.ChildForceExpandHeight ? 0f : num2), num15, (float)base.padding.top, axis);
				}
			}
			this._itemList.Clear();
			num3 += num8;
			num3 += num4;
			if (layoutInput)
			{
				base.SetLayoutInputForAxis(num3, num3, -1f, axis);
			}
			return num3;
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00018790 File Offset: 0x00016990
		private float CalculateRowVerticalOffset(float groupHeight, float yOffset, float currentRowHeight)
		{
			if (this.IsLowerAlign)
			{
				return groupHeight - yOffset - currentRowHeight;
			}
			if (this.IsMiddleAlign)
			{
				return groupHeight * 0.5f - this._layoutHeight * 0.5f + yOffset;
			}
			return yOffset;
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x000187C0 File Offset: 0x000169C0
		private float CalculateColHorizontalOffset(float groupWidth, float xOffset, float currentColWidth)
		{
			if (this.IsRightAlign)
			{
				return groupWidth - xOffset - currentColWidth;
			}
			if (this.IsCenterAlign)
			{
				return groupWidth * 0.5f - this._layoutWidth * 0.5f + xOffset;
			}
			return xOffset;
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x000187F0 File Offset: 0x000169F0
		protected void LayoutRow(IList<RectTransform> contents, float rowWidth, float rowHeight, float maxWidth, float xOffset, float yOffset, int axis)
		{
			float num = xOffset;
			if (!this.ChildForceExpandWidth && this.IsCenterAlign)
			{
				num += (maxWidth - rowWidth) * 0.5f;
			}
			else if (!this.ChildForceExpandWidth && this.IsRightAlign)
			{
				num += maxWidth - rowWidth;
			}
			float num2 = 0f;
			float num3 = 0f;
			if (this.ChildForceExpandWidth)
			{
				num2 = (maxWidth - rowWidth) / (float)this._itemList.Count;
			}
			else if (this.ExpandHorizontalSpacing)
			{
				num3 = (maxWidth - rowWidth) / (float)(this._itemList.Count - 1);
				if (this._itemList.Count > 1)
				{
					if (this.IsCenterAlign)
					{
						num -= num3 * 0.5f * (float)(this._itemList.Count - 1);
					}
					else if (this.IsRightAlign)
					{
						num -= num3 * (float)(this._itemList.Count - 1);
					}
				}
			}
			for (int i = 0; i < this._itemList.Count; i++)
			{
				int num4 = (this.IsLowerAlign ? (this._itemList.Count - 1 - i) : i);
				RectTransform rectTransform = this._itemList[num4];
				float num5 = LayoutUtility.GetPreferredSize(rectTransform, 0) + num2;
				float num6 = LayoutUtility.GetPreferredSize(rectTransform, 1);
				if (this.ChildForceExpandHeight)
				{
					num6 = rowHeight;
				}
				num5 = Mathf.Min(num5, maxWidth);
				float num7 = yOffset;
				if (this.IsMiddleAlign)
				{
					num7 += (rowHeight - num6) * 0.5f;
				}
				else if (this.IsLowerAlign)
				{
					num7 += rowHeight - num6;
				}
				if (this.ExpandHorizontalSpacing && i > 0)
				{
					num += num3;
				}
				if (axis == 0)
				{
					base.SetChildAlongAxis(rectTransform, 0, num, num5);
				}
				else
				{
					base.SetChildAlongAxis(rectTransform, 1, num7, num6);
				}
				if (i < this._itemList.Count - 1)
				{
					num += num5 + this.SpacingX;
				}
			}
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x000189B4 File Offset: 0x00016BB4
		protected void LayoutCol(IList<RectTransform> contents, float colWidth, float colHeight, float maxHeight, float xOffset, float yOffset, int axis)
		{
			float num = yOffset;
			if (!this.ChildForceExpandHeight && this.IsMiddleAlign)
			{
				num += (maxHeight - colHeight) * 0.5f;
			}
			else if (!this.ChildForceExpandHeight && this.IsLowerAlign)
			{
				num += maxHeight - colHeight;
			}
			float num2 = 0f;
			float num3 = 0f;
			if (this.ChildForceExpandHeight)
			{
				num2 = (maxHeight - colHeight) / (float)this._itemList.Count;
			}
			else if (this.ExpandHorizontalSpacing)
			{
				num3 = (maxHeight - colHeight) / (float)(this._itemList.Count - 1);
				if (this._itemList.Count > 1)
				{
					if (this.IsMiddleAlign)
					{
						num -= num3 * 0.5f * (float)(this._itemList.Count - 1);
					}
					else if (this.IsLowerAlign)
					{
						num -= num3 * (float)(this._itemList.Count - 1);
					}
				}
			}
			for (int i = 0; i < this._itemList.Count; i++)
			{
				int num4 = (this.IsRightAlign ? (this._itemList.Count - 1 - i) : i);
				RectTransform rectTransform = this._itemList[num4];
				float num5 = LayoutUtility.GetPreferredSize(rectTransform, 0);
				float num6 = LayoutUtility.GetPreferredSize(rectTransform, 1) + num2;
				if (this.ChildForceExpandWidth)
				{
					num5 = colWidth;
				}
				num6 = Mathf.Min(num6, maxHeight);
				float num7 = xOffset;
				if (this.IsCenterAlign)
				{
					num7 += (colWidth - num5) * 0.5f;
				}
				else if (this.IsRightAlign)
				{
					num7 += colWidth - num5;
				}
				if (this.ExpandHorizontalSpacing && i > 0)
				{
					num += num3;
				}
				if (axis == 0)
				{
					base.SetChildAlongAxis(rectTransform, 0, num7, num5);
				}
				else
				{
					base.SetChildAlongAxis(rectTransform, 1, num, num6);
				}
				if (i < this._itemList.Count - 1)
				{
					num += num6 + this.SpacingY;
				}
			}
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00018B78 File Offset: 0x00016D78
		public float GetGreatestMinimumChildWidth()
		{
			float num = 0f;
			for (int i = 0; i < base.rectChildren.Count; i++)
			{
				num = Mathf.Max(LayoutUtility.GetMinWidth(base.rectChildren[i]), num);
			}
			return num;
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x00018BBC File Offset: 0x00016DBC
		public float GetGreatestMinimumChildHeigth()
		{
			float num = 0f;
			for (int i = 0; i < base.rectChildren.Count; i++)
			{
				num = Mathf.Max(LayoutUtility.GetMinHeight(base.rectChildren[i]), num);
			}
			return num;
		}

		// Token: 0x04000309 RID: 777
		public float SpacingX;

		// Token: 0x0400030A RID: 778
		public float SpacingY;

		// Token: 0x0400030B RID: 779
		public bool ExpandHorizontalSpacing;

		// Token: 0x0400030C RID: 780
		public bool ChildForceExpandWidth;

		// Token: 0x0400030D RID: 781
		public bool ChildForceExpandHeight;

		// Token: 0x0400030E RID: 782
		public bool invertOrder;

		// Token: 0x0400030F RID: 783
		private float _layoutHeight;

		// Token: 0x04000310 RID: 784
		private float _layoutWidth;

		// Token: 0x04000311 RID: 785
		[SerializeField]
		protected FlowLayoutGroup.Axis m_StartAxis;

		// Token: 0x04000312 RID: 786
		private readonly IList<RectTransform> _itemList = new List<RectTransform>();

		// Token: 0x02000134 RID: 308
		public enum Axis
		{
			// Token: 0x04000675 RID: 1653
			Horizontal,
			// Token: 0x04000676 RID: 1654
			Vertical
		}
	}
}
