﻿using System;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D2 RID: 210
	public class ColorPickerTester : MonoBehaviour
	{
		// Token: 0x060006FA RID: 1786 RVA: 0x00027A50 File Offset: 0x00025C50
		private void Awake()
		{
			this.pickerRenderer = base.GetComponent<Renderer>();
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00027A5E File Offset: 0x00025C5E
		private void Start()
		{
			this.picker.onValueChanged.AddListener(delegate(Color color)
			{
				this.pickerRenderer.material.color = color;
			});
		}

		// Token: 0x04000524 RID: 1316
		public Renderer pickerRenderer;

		// Token: 0x04000525 RID: 1317
		public ColorPickerControl picker;
	}
}
