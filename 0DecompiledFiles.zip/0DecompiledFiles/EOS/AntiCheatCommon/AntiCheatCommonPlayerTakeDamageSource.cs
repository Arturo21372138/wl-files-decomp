﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000776 RID: 1910
	public enum AntiCheatCommonPlayerTakeDamageSource
	{
		// Token: 0x040014C7 RID: 5319
		None,
		// Token: 0x040014C8 RID: 5320
		Player,
		// Token: 0x040014C9 RID: 5321
		NonPlayerCharacter,
		// Token: 0x040014CA RID: 5322
		World
	}
}
