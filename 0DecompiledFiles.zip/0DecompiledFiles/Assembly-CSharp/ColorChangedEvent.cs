﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000008 RID: 8
[Serializable]
public class ColorChangedEvent : UnityEvent<Color>
{
}
