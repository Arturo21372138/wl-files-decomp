﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D9 RID: 2009
	internal struct UnprotectMessageOptionsInternal : ISettable<UnprotectMessageOptions>, IDisposable
	{
		// Token: 0x0600211B RID: 8475 RVA: 0x00027557 File Offset: 0x00025757
		public void Set(ref UnprotectMessageOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.Data, ref this.m_Data, out this.m_DataLengthBytes);
			this.m_OutBufferSizeBytes = other.OutBufferSizeBytes;
		}

		// Token: 0x0600211C RID: 8476 RVA: 0x00027589 File Offset: 0x00025789
		public void Dispose()
		{
			Helper.Dispose(ref this.m_Data);
		}

		// Token: 0x04001607 RID: 5639
		private int m_ApiVersion;

		// Token: 0x04001608 RID: 5640
		private uint m_DataLengthBytes;

		// Token: 0x04001609 RID: 5641
		private IntPtr m_Data;

		// Token: 0x0400160A RID: 5642
		private uint m_OutBufferSizeBytes;
	}
}
