﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E7 RID: 231
	public enum ImageFormat
	{
		// Token: 0x040005AB RID: 1451
		PNG,
		// Token: 0x040005AC RID: 1452
		TGA,
		// Token: 0x040005AD RID: 1453
		EXR
	}
}
