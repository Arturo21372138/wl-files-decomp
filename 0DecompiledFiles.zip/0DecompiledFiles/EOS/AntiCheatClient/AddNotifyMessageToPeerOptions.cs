﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007A8 RID: 1960
	public struct AddNotifyMessageToPeerOptions
	{
	}
}
