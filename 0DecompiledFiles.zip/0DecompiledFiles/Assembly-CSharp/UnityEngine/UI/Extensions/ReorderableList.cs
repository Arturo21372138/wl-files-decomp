﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200003C RID: 60
	[RequireComponent(typeof(RectTransform))]
	[DisallowMultipleComponent]
	[AddComponentMenu("UI/Extensions/Re-orderable list")]
	public class ReorderableList : MonoBehaviour
	{
		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600019F RID: 415 RVA: 0x00009299 File Offset: 0x00007499
		public RectTransform Content
		{
			get
			{
				if (this._content == null)
				{
					this._content = this.ContentLayout.GetComponent<RectTransform>();
				}
				return this._content;
			}
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x000092C0 File Offset: 0x000074C0
		private Canvas GetCanvas()
		{
			Transform transform = base.transform;
			Canvas canvas = null;
			int num = 100;
			int num2 = 0;
			while (canvas == null && num2 < num)
			{
				canvas = transform.gameObject.GetComponent<Canvas>();
				if (canvas == null)
				{
					transform = transform.parent;
				}
				num2++;
			}
			return canvas;
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x0000930B File Offset: 0x0000750B
		public void Refresh()
		{
			this._listContent = this.ContentLayout.gameObject.GetOrAddComponent<ReorderableListContent>();
			this._listContent.Init(this);
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x00009330 File Offset: 0x00007530
		private void Start()
		{
			if (this.ContentLayout == null)
			{
				Debug.LogError("You need to have a child LayoutGroup content set for the list: " + base.name, base.gameObject);
				return;
			}
			if (this.DraggableArea == null)
			{
				this.DraggableArea = base.transform.root.GetComponentInChildren<Canvas>().GetComponent<RectTransform>();
			}
			if (this.IsDropable && !base.GetComponent<Graphic>())
			{
				Debug.LogError("You need to have a Graphic control (such as an Image) for the list [" + base.name + "] to be droppable", base.gameObject);
				return;
			}
			this.Refresh();
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x000093CC File Offset: 0x000075CC
		public void TestReOrderableListTarget(ReorderableList.ReorderableListEventStruct item)
		{
			Debug.Log("Event Received");
			Debug.Log("Hello World, is my item a clone? [" + item.IsAClone.ToString() + "]");
		}

		// Token: 0x04000166 RID: 358
		[Tooltip("Child container with re-orderable items in a layout group")]
		public LayoutGroup ContentLayout;

		// Token: 0x04000167 RID: 359
		[Tooltip("Parent area to draw the dragged element on top of containers. Defaults to the root Canvas")]
		public RectTransform DraggableArea;

		// Token: 0x04000168 RID: 360
		[Tooltip("Can items be dragged from the container?")]
		public bool IsDraggable = true;

		// Token: 0x04000169 RID: 361
		[Tooltip("Should the draggable components be removed or cloned?")]
		public bool CloneDraggedObject;

		// Token: 0x0400016A RID: 362
		[Tooltip("Can new draggable items be dropped in to the container?")]
		public bool IsDropable = true;

		// Token: 0x0400016B RID: 363
		[Tooltip("Should dropped items displace a current item if the list is full?\n Depending on the dropped items origin list, the displaced item may be added, dropped in space or deleted.")]
		public bool IsDisplacable;

		// Token: 0x0400016C RID: 364
		[Tooltip("Should items being dragged over this list have their sizes equalized?")]
		public bool EqualizeSizesOnDrag;

		// Token: 0x0400016D RID: 365
		public int maxItems = int.MaxValue;

		// Token: 0x0400016E RID: 366
		[Header("UI Re-orderable Events")]
		public ReorderableList.ReorderableListHandler OnElementDropped = new ReorderableList.ReorderableListHandler();

		// Token: 0x0400016F RID: 367
		public ReorderableList.ReorderableListHandler OnElementGrabbed = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000170 RID: 368
		public ReorderableList.ReorderableListHandler OnElementRemoved = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000171 RID: 369
		public ReorderableList.ReorderableListHandler OnElementAdded = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000172 RID: 370
		public ReorderableList.ReorderableListHandler OnElementDisplacedFrom = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000173 RID: 371
		public ReorderableList.ReorderableListHandler OnElementDisplacedTo = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000174 RID: 372
		public ReorderableList.ReorderableListHandler OnElementDisplacedFromReturned = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000175 RID: 373
		public ReorderableList.ReorderableListHandler OnElementDisplacedToReturned = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000176 RID: 374
		public ReorderableList.ReorderableListHandler OnElementDroppedWithMaxItems = new ReorderableList.ReorderableListHandler();

		// Token: 0x04000177 RID: 375
		private RectTransform _content;

		// Token: 0x04000178 RID: 376
		private ReorderableListContent _listContent;

		// Token: 0x02000116 RID: 278
		[Serializable]
		public struct ReorderableListEventStruct
		{
			// Token: 0x060007B6 RID: 1974 RVA: 0x0002BA98 File Offset: 0x00029C98
			public void Cancel()
			{
				this.SourceObject.GetComponent<ReorderableListElement>().isValid = false;
			}

			// Token: 0x04000628 RID: 1576
			public GameObject DroppedObject;

			// Token: 0x04000629 RID: 1577
			public int FromIndex;

			// Token: 0x0400062A RID: 1578
			public ReorderableList FromList;

			// Token: 0x0400062B RID: 1579
			public bool IsAClone;

			// Token: 0x0400062C RID: 1580
			public GameObject SourceObject;

			// Token: 0x0400062D RID: 1581
			public int ToIndex;

			// Token: 0x0400062E RID: 1582
			public ReorderableList ToList;
		}

		// Token: 0x02000117 RID: 279
		[Serializable]
		public class ReorderableListHandler : UnityEvent<ReorderableList.ReorderableListEventStruct>
		{
		}
	}
}
