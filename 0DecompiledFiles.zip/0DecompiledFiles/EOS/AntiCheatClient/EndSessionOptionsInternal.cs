﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007B6 RID: 1974
	internal struct EndSessionOptionsInternal : ISettable<EndSessionOptions>, IDisposable
	{
		// Token: 0x060020A7 RID: 8359 RVA: 0x00027025 File Offset: 0x00025225
		public void Set(ref EndSessionOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
		}

		// Token: 0x060020A8 RID: 8360 RVA: 0x00027034 File Offset: 0x00025234
		public void Dispose()
		{
		}

		// Token: 0x040015CE RID: 5582
		private int m_ApiVersion;
	}
}
