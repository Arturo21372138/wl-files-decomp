﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x0200080F RID: 2063
	// (Invoke) Token: 0x060021ED RID: 8685
	public delegate void OnUnlockAchievementsCompleteCallback(ref OnUnlockAchievementsCompleteCallbackInfo data);
}
