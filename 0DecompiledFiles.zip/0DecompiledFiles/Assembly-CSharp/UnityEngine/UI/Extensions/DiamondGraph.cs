﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000099 RID: 153
	[AddComponentMenu("UI/Extensions/Primitives/Diamond Graph")]
	public class DiamondGraph : UIPrimitiveBase
	{
		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060004EC RID: 1260 RVA: 0x0001D222 File Offset: 0x0001B422
		// (set) Token: 0x060004ED RID: 1261 RVA: 0x0001D22A File Offset: 0x0001B42A
		public float A
		{
			get
			{
				return this.m_a;
			}
			set
			{
				this.m_a = value;
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060004EE RID: 1262 RVA: 0x0001D233 File Offset: 0x0001B433
		// (set) Token: 0x060004EF RID: 1263 RVA: 0x0001D23B File Offset: 0x0001B43B
		public float B
		{
			get
			{
				return this.m_b;
			}
			set
			{
				this.m_b = value;
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060004F0 RID: 1264 RVA: 0x0001D244 File Offset: 0x0001B444
		// (set) Token: 0x060004F1 RID: 1265 RVA: 0x0001D24C File Offset: 0x0001B44C
		public float C
		{
			get
			{
				return this.m_c;
			}
			set
			{
				this.m_c = value;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060004F2 RID: 1266 RVA: 0x0001D255 File Offset: 0x0001B455
		// (set) Token: 0x060004F3 RID: 1267 RVA: 0x0001D25D File Offset: 0x0001B45D
		public float D
		{
			get
			{
				return this.m_d;
			}
			set
			{
				this.m_d = value;
			}
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0001D268 File Offset: 0x0001B468
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			vh.Clear();
			float num = base.rectTransform.rect.width / 2f;
			this.m_a = Math.Min(1f, Math.Max(0f, this.m_a));
			this.m_b = Math.Min(1f, Math.Max(0f, this.m_b));
			this.m_c = Math.Min(1f, Math.Max(0f, this.m_c));
			this.m_d = Math.Min(1f, Math.Max(0f, this.m_d));
			Color32 color = this.color;
			vh.AddVert(new Vector3(-num * this.m_a, 0f), color, new Vector2(0f, 0f));
			vh.AddVert(new Vector3(0f, num * this.m_b), color, new Vector2(0f, 1f));
			vh.AddVert(new Vector3(num * this.m_c, 0f), color, new Vector2(1f, 1f));
			vh.AddVert(new Vector3(0f, -num * this.m_d), color, new Vector2(1f, 0f));
			vh.AddTriangle(0, 1, 2);
			vh.AddTriangle(2, 3, 0);
		}

		// Token: 0x040003A0 RID: 928
		[SerializeField]
		private float m_a = 1f;

		// Token: 0x040003A1 RID: 929
		[SerializeField]
		private float m_b = 1f;

		// Token: 0x040003A2 RID: 930
		[SerializeField]
		private float m_c = 1f;

		// Token: 0x040003A3 RID: 931
		[SerializeField]
		private float m_d = 1f;
	}
}
