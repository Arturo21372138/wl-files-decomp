﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000046 RID: 70
	public interface IBoxSelectable
	{
		// Token: 0x17000050 RID: 80
		// (get) Token: 0x060001FA RID: 506
		// (set) Token: 0x060001FB RID: 507
		bool selected { get; set; }

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x060001FC RID: 508
		// (set) Token: 0x060001FD RID: 509
		bool preSelected { get; set; }

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x060001FE RID: 510
		Transform transform { get; }
	}
}
