﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200076E RID: 1902
	public enum AntiCheatCommonClientPlatform
	{
		// Token: 0x04001484 RID: 5252
		Unknown,
		// Token: 0x04001485 RID: 5253
		Windows,
		// Token: 0x04001486 RID: 5254
		Mac,
		// Token: 0x04001487 RID: 5255
		Linux,
		// Token: 0x04001488 RID: 5256
		Xbox,
		// Token: 0x04001489 RID: 5257
		PlayStation,
		// Token: 0x0400148A RID: 5258
		Nintendo,
		// Token: 0x0400148B RID: 5259
		iOS,
		// Token: 0x0400148C RID: 5260
		Android
	}
}
