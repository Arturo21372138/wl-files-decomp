﻿using System;
using System.Collections;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000AA RID: 170
	[RequireComponent(typeof(RectTransform))]
	[AddComponentMenu("UI/Extensions/Tooltip/Tooltip Trigger")]
	public class TooltipTrigger : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler
	{
		// Token: 0x060005B0 RID: 1456 RVA: 0x00022660 File Offset: 0x00020860
		private void Start()
		{
			Canvas componentInParent = base.GetComponentInParent<Canvas>();
			if (componentInParent && componentInParent.renderMode == RenderMode.ScreenSpaceOverlay)
			{
				this.isChildOfOverlayCanvas = true;
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x060005B1 RID: 1457 RVA: 0x0002268B File Offset: 0x0002088B
		public bool WorldToScreenIsRequired
		{
			get
			{
				return (this.isChildOfOverlayCanvas && ToolTip.Instance.guiMode == RenderMode.ScreenSpaceCamera) || (!this.isChildOfOverlayCanvas && ToolTip.Instance.guiMode == RenderMode.ScreenSpaceOverlay);
			}
		}

		// Token: 0x060005B2 RID: 1458 RVA: 0x000226BC File Offset: 0x000208BC
		public void OnPointerEnter(PointerEventData eventData)
		{
			switch (this.tooltipPositioningType)
			{
			case TooltipTrigger.TooltipPositioningType.mousePosition:
				this.StartHover(UIExtensionsInputManager.MousePosition + this.offset, true);
				return;
			case TooltipTrigger.TooltipPositioningType.mousePositionAndFollow:
				this.StartHover(UIExtensionsInputManager.MousePosition + this.offset, true);
				this.hovered = true;
				base.StartCoroutine(this.HoveredMouseFollowingLoop());
				return;
			case TooltipTrigger.TooltipPositioningType.transformPosition:
				this.StartHover((this.WorldToScreenIsRequired ? ToolTip.Instance.GuiCamera.WorldToScreenPoint(base.transform.position) : base.transform.position) + this.offset, true);
				return;
			default:
				return;
			}
		}

		// Token: 0x060005B3 RID: 1459 RVA: 0x00022768 File Offset: 0x00020968
		private IEnumerator HoveredMouseFollowingLoop()
		{
			while (this.hovered)
			{
				this.StartHover(UIExtensionsInputManager.MousePosition + this.offset, false);
				yield return null;
			}
			yield break;
		}

		// Token: 0x060005B4 RID: 1460 RVA: 0x00022778 File Offset: 0x00020978
		public void OnSelect(BaseEventData eventData)
		{
			this.StartHover((this.WorldToScreenIsRequired ? ToolTip.Instance.GuiCamera.WorldToScreenPoint(base.transform.position) : base.transform.position) + this.offset, true);
		}

		// Token: 0x060005B5 RID: 1461 RVA: 0x000227C6 File Offset: 0x000209C6
		public void OnPointerExit(PointerEventData eventData)
		{
			this.StopHover();
		}

		// Token: 0x060005B6 RID: 1462 RVA: 0x000227CE File Offset: 0x000209CE
		public void OnDeselect(BaseEventData eventData)
		{
			this.StopHover();
		}

		// Token: 0x060005B7 RID: 1463 RVA: 0x000227D6 File Offset: 0x000209D6
		private void StartHover(Vector3 position, bool shouldCanvasUpdate = false)
		{
			ToolTip.Instance.SetTooltip(this.text, position, shouldCanvasUpdate);
		}

		// Token: 0x060005B8 RID: 1464 RVA: 0x000227EA File Offset: 0x000209EA
		private void StopHover()
		{
			this.hovered = false;
			ToolTip.Instance.HideTooltip();
		}

		// Token: 0x04000445 RID: 1093
		[TextArea]
		public string text;

		// Token: 0x04000446 RID: 1094
		[Tooltip("Defines where the tooltip will be placed and how that placement will occur. Transform position will always be used if this element wasn't selected via mouse")]
		public TooltipTrigger.TooltipPositioningType tooltipPositioningType;

		// Token: 0x04000447 RID: 1095
		private bool isChildOfOverlayCanvas;

		// Token: 0x04000448 RID: 1096
		private bool hovered;

		// Token: 0x04000449 RID: 1097
		public Vector3 offset;

		// Token: 0x02000149 RID: 329
		public enum TooltipPositioningType
		{
			// Token: 0x040006B3 RID: 1715
			mousePosition,
			// Token: 0x040006B4 RID: 1716
			mousePositionAndFollow,
			// Token: 0x040006B5 RID: 1717
			transformPosition
		}
	}
}
