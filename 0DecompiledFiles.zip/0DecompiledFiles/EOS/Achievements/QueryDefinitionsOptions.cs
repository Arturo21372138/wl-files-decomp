﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000818 RID: 2072
	public struct QueryDefinitionsOptions
	{
		// Token: 0x17000883 RID: 2179
		// (get) Token: 0x0600221A RID: 8730 RVA: 0x00028848 File Offset: 0x00026A48
		// (set) Token: 0x0600221B RID: 8731 RVA: 0x00028850 File Offset: 0x00026A50
		public ProductUserId LocalUserId { readonly get; set; }

		// Token: 0x17000884 RID: 2180
		// (get) Token: 0x0600221C RID: 8732 RVA: 0x00028859 File Offset: 0x00026A59
		// (set) Token: 0x0600221D RID: 8733 RVA: 0x00028861 File Offset: 0x00026A61
		public EpicAccountId EpicUserId_DEPRECATED { readonly get; set; }

		// Token: 0x17000885 RID: 2181
		// (get) Token: 0x0600221E RID: 8734 RVA: 0x0002886A File Offset: 0x00026A6A
		// (set) Token: 0x0600221F RID: 8735 RVA: 0x00028872 File Offset: 0x00026A72
		public Utf8String[] HiddenAchievementIds_DEPRECATED { readonly get; set; }
	}
}
