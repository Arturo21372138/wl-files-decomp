﻿using System;
using System.Collections.Generic;
using UnityEngine.Sprites;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200009E RID: 158
	[AddComponentMenu("UI/Extensions/Primitives/UILineRendererList")]
	[RequireComponent(typeof(RectTransform))]
	public class UILineRendererList : UIPrimitiveBase
	{
		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000539 RID: 1337 RVA: 0x0001F0AA File Offset: 0x0001D2AA
		// (set) Token: 0x0600053A RID: 1338 RVA: 0x0001F0B2 File Offset: 0x0001D2B2
		public float LineThickness
		{
			get
			{
				return this.lineThickness;
			}
			set
			{
				this.lineThickness = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x0600053B RID: 1339 RVA: 0x0001F0C1 File Offset: 0x0001D2C1
		// (set) Token: 0x0600053C RID: 1340 RVA: 0x0001F0C9 File Offset: 0x0001D2C9
		public bool RelativeSize
		{
			get
			{
				return this.relativeSize;
			}
			set
			{
				this.relativeSize = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x0600053D RID: 1341 RVA: 0x0001F0D8 File Offset: 0x0001D2D8
		// (set) Token: 0x0600053E RID: 1342 RVA: 0x0001F0E0 File Offset: 0x0001D2E0
		public bool LineList
		{
			get
			{
				return this.lineList;
			}
			set
			{
				this.lineList = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x0600053F RID: 1343 RVA: 0x0001F0EF File Offset: 0x0001D2EF
		// (set) Token: 0x06000540 RID: 1344 RVA: 0x0001F0F7 File Offset: 0x0001D2F7
		public bool LineCaps
		{
			get
			{
				return this.lineCaps;
			}
			set
			{
				this.lineCaps = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000541 RID: 1345 RVA: 0x0001F106 File Offset: 0x0001D306
		// (set) Token: 0x06000542 RID: 1346 RVA: 0x0001F10E File Offset: 0x0001D30E
		public int BezierSegmentsPerCurve
		{
			get
			{
				return this.bezierSegmentsPerCurve;
			}
			set
			{
				this.bezierSegmentsPerCurve = value;
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x06000543 RID: 1347 RVA: 0x0001F117 File Offset: 0x0001D317
		// (set) Token: 0x06000544 RID: 1348 RVA: 0x0001F11F File Offset: 0x0001D31F
		public List<Vector2> Points
		{
			get
			{
				return this.m_points;
			}
			set
			{
				if (this.m_points == value)
				{
					return;
				}
				this.m_points = value;
				this.SetAllDirty();
			}
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x0001F138 File Offset: 0x0001D338
		public void AddPoint(Vector2 pointToAdd)
		{
			this.m_points.Add(pointToAdd);
			this.SetAllDirty();
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x0001F14C File Offset: 0x0001D34C
		public void RemovePoint(Vector2 pointToRemove)
		{
			this.m_points.Remove(pointToRemove);
			this.SetAllDirty();
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x0001F161 File Offset: 0x0001D361
		public void ClearPoints()
		{
			this.m_points.Clear();
			this.SetAllDirty();
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0001F174 File Offset: 0x0001D374
		private void PopulateMesh(VertexHelper vh, List<Vector2> pointsToDraw)
		{
			if (this.BezierMode != UILineRendererList.BezierType.None && this.BezierMode != UILineRendererList.BezierType.Catenary && pointsToDraw.Count > 3)
			{
				BezierPath bezierPath = new BezierPath();
				bezierPath.SetControlPoints(pointsToDraw);
				bezierPath.SegmentsPerCurve = this.bezierSegmentsPerCurve;
				UILineRendererList.BezierType bezierMode = this.BezierMode;
				List<Vector2> list;
				if (bezierMode != UILineRendererList.BezierType.Basic)
				{
					if (bezierMode != UILineRendererList.BezierType.Improved)
					{
						list = bezierPath.GetDrawingPoints2();
					}
					else
					{
						list = bezierPath.GetDrawingPoints1();
					}
				}
				else
				{
					list = bezierPath.GetDrawingPoints0();
				}
				pointsToDraw = list;
			}
			if (this.BezierMode == UILineRendererList.BezierType.Catenary && pointsToDraw.Count == 2)
			{
				CableCurve cableCurve = new CableCurve(pointsToDraw);
				cableCurve.slack = base.Resolution;
				cableCurve.steps = this.BezierSegmentsPerCurve;
				pointsToDraw.Clear();
				pointsToDraw.AddRange(cableCurve.Points());
			}
			if (base.ImproveResolution != ResolutionMode.None)
			{
				pointsToDraw = base.IncreaseResolution(pointsToDraw);
			}
			float num = ((!this.relativeSize) ? 1f : base.rectTransform.rect.width);
			float num2 = ((!this.relativeSize) ? 1f : base.rectTransform.rect.height);
			float num3 = -base.rectTransform.pivot.x * num;
			float num4 = -base.rectTransform.pivot.y * num2;
			List<UIVertex[]> list2 = new List<UIVertex[]>();
			if (this.lineList)
			{
				for (int i = 1; i < pointsToDraw.Count; i += 2)
				{
					Vector2 vector = pointsToDraw[i - 1];
					Vector2 vector2 = pointsToDraw[i];
					vector = new Vector2(vector.x * num + num3, vector.y * num2 + num4);
					vector2 = new Vector2(vector2.x * num + num3, vector2.y * num2 + num4);
					if (this.lineCaps)
					{
						list2.Add(this.CreateLineCap(vector, vector2, UILineRendererList.SegmentType.Start));
					}
					list2.Add(this.CreateLineSegment(vector, vector2, UILineRendererList.SegmentType.Middle));
					if (this.lineCaps)
					{
						list2.Add(this.CreateLineCap(vector, vector2, UILineRendererList.SegmentType.End));
					}
				}
			}
			else
			{
				for (int j = 1; j < pointsToDraw.Count; j++)
				{
					Vector2 vector3 = pointsToDraw[j - 1];
					Vector2 vector4 = pointsToDraw[j];
					vector3 = new Vector2(vector3.x * num + num3, vector3.y * num2 + num4);
					vector4 = new Vector2(vector4.x * num + num3, vector4.y * num2 + num4);
					if (this.lineCaps && j == 1)
					{
						list2.Add(this.CreateLineCap(vector3, vector4, UILineRendererList.SegmentType.Start));
					}
					list2.Add(this.CreateLineSegment(vector3, vector4, UILineRendererList.SegmentType.Middle));
					if (this.lineCaps && j == pointsToDraw.Count - 1)
					{
						list2.Add(this.CreateLineCap(vector3, vector4, UILineRendererList.SegmentType.End));
					}
				}
			}
			for (int k = 0; k < list2.Count; k++)
			{
				if (!this.lineList && k < list2.Count - 1)
				{
					Vector3 vector5 = list2[k][1].position - list2[k][2].position;
					Vector3 vector6 = list2[k + 1][2].position - list2[k + 1][1].position;
					float num5 = Vector2.Angle(vector5, vector6) * 0.017453292f;
					float num6 = Mathf.Sign(Vector3.Cross(vector5.normalized, vector6.normalized).z);
					float num7 = this.lineThickness / (2f * Mathf.Tan(num5 / 2f));
					Vector3 vector7 = list2[k][2].position - vector5.normalized * num7 * num6;
					Vector3 vector8 = list2[k][3].position + vector5.normalized * num7 * num6;
					UILineRendererList.JoinType joinType = this.LineJoins;
					if (joinType == UILineRendererList.JoinType.Miter)
					{
						if (num7 < vector5.magnitude / 2f && num7 < vector6.magnitude / 2f && num5 > 0.2617994f)
						{
							list2[k][2].position = vector7;
							list2[k][3].position = vector8;
							list2[k + 1][0].position = vector8;
							list2[k + 1][1].position = vector7;
						}
						else
						{
							joinType = UILineRendererList.JoinType.Bevel;
						}
					}
					if (joinType == UILineRendererList.JoinType.Bevel)
					{
						if (num7 < vector5.magnitude / 2f && num7 < vector6.magnitude / 2f && num5 > 0.5235988f)
						{
							if (num6 < 0f)
							{
								list2[k][2].position = vector7;
								list2[k + 1][1].position = vector7;
							}
							else
							{
								list2[k][3].position = vector8;
								list2[k + 1][0].position = vector8;
							}
						}
						UIVertex[] array = new UIVertex[]
						{
							list2[k][2],
							list2[k][3],
							list2[k + 1][0],
							list2[k + 1][1]
						};
						vh.AddUIVertexQuad(array);
					}
				}
				vh.AddUIVertexQuad(list2[k]);
			}
			if (vh.currentVertCount > 64000)
			{
				Debug.LogError("Max Verticies size is 64000, current mesh verticies count is [" + vh.currentVertCount.ToString() + "] - Cannot Draw");
				vh.Clear();
				return;
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x0001F779 File Offset: 0x0001D979
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			if (this.m_points != null && this.m_points.Count > 0)
			{
				this.GeneratedUVs();
				vh.Clear();
				this.PopulateMesh(vh, this.m_points);
			}
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x0001F7AC File Offset: 0x0001D9AC
		private UIVertex[] CreateLineCap(Vector2 start, Vector2 end, UILineRendererList.SegmentType type)
		{
			if (type == UILineRendererList.SegmentType.Start)
			{
				Vector2 vector = start - (end - start).normalized * this.lineThickness / 2f;
				return this.CreateLineSegment(vector, start, UILineRendererList.SegmentType.Start);
			}
			if (type == UILineRendererList.SegmentType.End)
			{
				Vector2 vector2 = end + (end - start).normalized * this.lineThickness / 2f;
				return this.CreateLineSegment(end, vector2, UILineRendererList.SegmentType.End);
			}
			Debug.LogError("Bad SegmentType passed in to CreateLineCap. Must be SegmentType.Start or SegmentType.End");
			return null;
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x0001F838 File Offset: 0x0001DA38
		private UIVertex[] CreateLineSegment(Vector2 start, Vector2 end, UILineRendererList.SegmentType type)
		{
			Vector2 vector = new Vector2(start.y - end.y, end.x - start.x).normalized * this.lineThickness / 2f;
			Vector2 vector2 = start - vector;
			Vector2 vector3 = start + vector;
			Vector2 vector4 = end + vector;
			Vector2 vector5 = end - vector;
			switch (type)
			{
			case UILineRendererList.SegmentType.Start:
				return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRendererList.startUvs);
			case UILineRendererList.SegmentType.End:
				return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRendererList.endUvs);
			case UILineRendererList.SegmentType.Full:
				return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRendererList.fullUvs);
			}
			return base.SetVbo(new Vector2[] { vector2, vector3, vector4, vector5 }, UILineRendererList.middleUvs);
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x0001F98C File Offset: 0x0001DB8C
		protected override void GeneratedUVs()
		{
			if (base.activeSprite != null)
			{
				Vector4 outerUV = DataUtility.GetOuterUV(base.activeSprite);
				Vector4 innerUV = DataUtility.GetInnerUV(base.activeSprite);
				UILineRendererList.UV_TOP_LEFT = new Vector2(outerUV.x, outerUV.y);
				UILineRendererList.UV_BOTTOM_LEFT = new Vector2(outerUV.x, outerUV.w);
				UILineRendererList.UV_TOP_CENTER_LEFT = new Vector2(innerUV.x, innerUV.y);
				UILineRendererList.UV_TOP_CENTER_RIGHT = new Vector2(innerUV.z, innerUV.y);
				UILineRendererList.UV_BOTTOM_CENTER_LEFT = new Vector2(innerUV.x, innerUV.w);
				UILineRendererList.UV_BOTTOM_CENTER_RIGHT = new Vector2(innerUV.z, innerUV.w);
				UILineRendererList.UV_TOP_RIGHT = new Vector2(outerUV.z, outerUV.y);
				UILineRendererList.UV_BOTTOM_RIGHT = new Vector2(outerUV.z, outerUV.w);
			}
			else
			{
				UILineRendererList.UV_TOP_LEFT = Vector2.zero;
				UILineRendererList.UV_BOTTOM_LEFT = new Vector2(0f, 1f);
				UILineRendererList.UV_TOP_CENTER_LEFT = new Vector2(0.5f, 0f);
				UILineRendererList.UV_TOP_CENTER_RIGHT = new Vector2(0.5f, 0f);
				UILineRendererList.UV_BOTTOM_CENTER_LEFT = new Vector2(0.5f, 1f);
				UILineRendererList.UV_BOTTOM_CENTER_RIGHT = new Vector2(0.5f, 1f);
				UILineRendererList.UV_TOP_RIGHT = new Vector2(1f, 0f);
				UILineRendererList.UV_BOTTOM_RIGHT = Vector2.one;
			}
			UILineRendererList.startUvs = new Vector2[]
			{
				UILineRendererList.UV_TOP_LEFT,
				UILineRendererList.UV_BOTTOM_LEFT,
				UILineRendererList.UV_BOTTOM_CENTER_LEFT,
				UILineRendererList.UV_TOP_CENTER_LEFT
			};
			UILineRendererList.middleUvs = new Vector2[]
			{
				UILineRendererList.UV_TOP_CENTER_LEFT,
				UILineRendererList.UV_BOTTOM_CENTER_LEFT,
				UILineRendererList.UV_BOTTOM_CENTER_RIGHT,
				UILineRendererList.UV_TOP_CENTER_RIGHT
			};
			UILineRendererList.endUvs = new Vector2[]
			{
				UILineRendererList.UV_TOP_CENTER_RIGHT,
				UILineRendererList.UV_BOTTOM_CENTER_RIGHT,
				UILineRendererList.UV_BOTTOM_RIGHT,
				UILineRendererList.UV_TOP_RIGHT
			};
			UILineRendererList.fullUvs = new Vector2[]
			{
				UILineRendererList.UV_TOP_LEFT,
				UILineRendererList.UV_BOTTOM_LEFT,
				UILineRendererList.UV_BOTTOM_RIGHT,
				UILineRendererList.UV_TOP_RIGHT
			};
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x0001FBF0 File Offset: 0x0001DDF0
		protected override void ResolutionToNativeSize(float distance)
		{
			if (base.UseNativeSize)
			{
				this.m_Resolution = distance / (base.activeSprite.rect.width / base.pixelsPerUnit);
				this.lineThickness = base.activeSprite.rect.height / base.pixelsPerUnit;
			}
		}

		// Token: 0x040003D5 RID: 981
		private const float MIN_MITER_JOIN = 0.2617994f;

		// Token: 0x040003D6 RID: 982
		private const float MIN_BEVEL_NICE_JOIN = 0.5235988f;

		// Token: 0x040003D7 RID: 983
		private static Vector2 UV_TOP_LEFT;

		// Token: 0x040003D8 RID: 984
		private static Vector2 UV_BOTTOM_LEFT;

		// Token: 0x040003D9 RID: 985
		private static Vector2 UV_TOP_CENTER_LEFT;

		// Token: 0x040003DA RID: 986
		private static Vector2 UV_TOP_CENTER_RIGHT;

		// Token: 0x040003DB RID: 987
		private static Vector2 UV_BOTTOM_CENTER_LEFT;

		// Token: 0x040003DC RID: 988
		private static Vector2 UV_BOTTOM_CENTER_RIGHT;

		// Token: 0x040003DD RID: 989
		private static Vector2 UV_TOP_RIGHT;

		// Token: 0x040003DE RID: 990
		private static Vector2 UV_BOTTOM_RIGHT;

		// Token: 0x040003DF RID: 991
		private static Vector2[] startUvs;

		// Token: 0x040003E0 RID: 992
		private static Vector2[] middleUvs;

		// Token: 0x040003E1 RID: 993
		private static Vector2[] endUvs;

		// Token: 0x040003E2 RID: 994
		private static Vector2[] fullUvs;

		// Token: 0x040003E3 RID: 995
		[SerializeField]
		[Tooltip("Points to draw lines between\n Can be improved using the Resolution Option")]
		internal List<Vector2> m_points;

		// Token: 0x040003E4 RID: 996
		[SerializeField]
		[Tooltip("Thickness of the line")]
		internal float lineThickness = 2f;

		// Token: 0x040003E5 RID: 997
		[SerializeField]
		[Tooltip("Use the relative bounds of the Rect Transform (0,0 -> 0,1) or screen space coordinates")]
		internal bool relativeSize;

		// Token: 0x040003E6 RID: 998
		[SerializeField]
		[Tooltip("Do the points identify a single line or split pairs of lines")]
		internal bool lineList;

		// Token: 0x040003E7 RID: 999
		[SerializeField]
		[Tooltip("Add end caps to each line\nMultiple caps when used with Line List")]
		internal bool lineCaps;

		// Token: 0x040003E8 RID: 1000
		[SerializeField]
		[Tooltip("Resolution of the Bezier curve, different to line Resolution")]
		internal int bezierSegmentsPerCurve = 10;

		// Token: 0x040003E9 RID: 1001
		[Tooltip("The type of Join used between lines, Square/Mitre or Curved/Bevel")]
		public UILineRendererList.JoinType LineJoins;

		// Token: 0x040003EA RID: 1002
		[Tooltip("Bezier method to apply to line, see docs for options\nCan't be used in conjunction with Resolution as Bezier already changes the resolution")]
		public UILineRendererList.BezierType BezierMode;

		// Token: 0x040003EB RID: 1003
		[HideInInspector]
		public bool drivenExternally;

		// Token: 0x02000144 RID: 324
		private enum SegmentType
		{
			// Token: 0x0400069F RID: 1695
			Start,
			// Token: 0x040006A0 RID: 1696
			Middle,
			// Token: 0x040006A1 RID: 1697
			End,
			// Token: 0x040006A2 RID: 1698
			Full
		}

		// Token: 0x02000145 RID: 325
		public enum JoinType
		{
			// Token: 0x040006A4 RID: 1700
			Bevel,
			// Token: 0x040006A5 RID: 1701
			Miter
		}

		// Token: 0x02000146 RID: 326
		public enum BezierType
		{
			// Token: 0x040006A7 RID: 1703
			None,
			// Token: 0x040006A8 RID: 1704
			Quick,
			// Token: 0x040006A9 RID: 1705
			Basic,
			// Token: 0x040006AA RID: 1706
			Improved,
			// Token: 0x040006AB RID: 1707
			Catenary
		}
	}
}
