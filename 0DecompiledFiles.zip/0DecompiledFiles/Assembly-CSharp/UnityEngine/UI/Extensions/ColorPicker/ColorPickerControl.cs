﻿using System;
using System.Collections.Generic;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D0 RID: 208
	[ExecuteInEditMode]
	public class ColorPickerControl : MonoBehaviour
	{
		// Token: 0x060006D4 RID: 1748 RVA: 0x00027250 File Offset: 0x00025450
		public void SetHSVSlidersOn(bool value)
		{
			this.hsvSlidersOn = value;
			foreach (GameObject gameObject in this.hsvSliders)
			{
				gameObject.SetActive(value);
			}
			if (this.alphaSlider)
			{
				this.alphaSlider.SetActive(this.hsvSlidersOn || this.rgbSlidersOn);
			}
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x000272D4 File Offset: 0x000254D4
		public void SetRGBSlidersOn(bool value)
		{
			this.rgbSlidersOn = value;
			foreach (GameObject gameObject in this.rgbSliders)
			{
				gameObject.SetActive(value);
			}
			if (this.alphaSlider)
			{
				this.alphaSlider.SetActive(this.hsvSlidersOn || this.rgbSlidersOn);
			}
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x00027358 File Offset: 0x00025558
		private void Update()
		{
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x060006D7 RID: 1751 RVA: 0x0002735A File Offset: 0x0002555A
		// (set) Token: 0x060006D8 RID: 1752 RVA: 0x0002737C File Offset: 0x0002557C
		public Color CurrentColor
		{
			get
			{
				return new Color(this._red, this._green, this._blue, this._alpha);
			}
			set
			{
				if (this.CurrentColor == value)
				{
					return;
				}
				this._red = value.r;
				this._green = value.g;
				this._blue = value.b;
				this._alpha = value.a;
				this.RGBChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x000273D4 File Offset: 0x000255D4
		private void Start()
		{
			this.SendChangedEvent();
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x060006DA RID: 1754 RVA: 0x000273DC File Offset: 0x000255DC
		// (set) Token: 0x060006DB RID: 1755 RVA: 0x000273E4 File Offset: 0x000255E4
		public float H
		{
			get
			{
				return this._hue;
			}
			set
			{
				if (this._hue == value)
				{
					return;
				}
				this._hue = value;
				this.HSVChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x060006DC RID: 1756 RVA: 0x00027403 File Offset: 0x00025603
		// (set) Token: 0x060006DD RID: 1757 RVA: 0x0002740B File Offset: 0x0002560B
		public float S
		{
			get
			{
				return this._saturation;
			}
			set
			{
				if (this._saturation == value)
				{
					return;
				}
				this._saturation = value;
				this.HSVChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x060006DE RID: 1758 RVA: 0x0002742A File Offset: 0x0002562A
		// (set) Token: 0x060006DF RID: 1759 RVA: 0x00027432 File Offset: 0x00025632
		public float V
		{
			get
			{
				return this._brightness;
			}
			set
			{
				if (this._brightness == value)
				{
					return;
				}
				this._brightness = value;
				this.HSVChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x060006E0 RID: 1760 RVA: 0x00027451 File Offset: 0x00025651
		// (set) Token: 0x060006E1 RID: 1761 RVA: 0x00027459 File Offset: 0x00025659
		public float R
		{
			get
			{
				return this._red;
			}
			set
			{
				if (this._red == value)
				{
					return;
				}
				this._red = value;
				this.RGBChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x060006E2 RID: 1762 RVA: 0x00027478 File Offset: 0x00025678
		// (set) Token: 0x060006E3 RID: 1763 RVA: 0x00027480 File Offset: 0x00025680
		public float G
		{
			get
			{
				return this._green;
			}
			set
			{
				if (this._green == value)
				{
					return;
				}
				this._green = value;
				this.RGBChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x060006E4 RID: 1764 RVA: 0x0002749F File Offset: 0x0002569F
		// (set) Token: 0x060006E5 RID: 1765 RVA: 0x000274A7 File Offset: 0x000256A7
		public float B
		{
			get
			{
				return this._blue;
			}
			set
			{
				if (this._blue == value)
				{
					return;
				}
				this._blue = value;
				this.RGBChanged();
				this.SendChangedEvent();
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x060006E6 RID: 1766 RVA: 0x000274C6 File Offset: 0x000256C6
		// (set) Token: 0x060006E7 RID: 1767 RVA: 0x000274CE File Offset: 0x000256CE
		private float A
		{
			get
			{
				return this._alpha;
			}
			set
			{
				if (this._alpha == value)
				{
					return;
				}
				this._alpha = value;
				this.SendChangedEvent();
			}
		}

		// Token: 0x060006E8 RID: 1768 RVA: 0x000274E8 File Offset: 0x000256E8
		private void RGBChanged()
		{
			HsvColor hsvColor = HSVUtil.ConvertRgbToHsv(this.CurrentColor);
			this._hue = hsvColor.NormalizedH;
			this._saturation = hsvColor.NormalizedS;
			this._brightness = hsvColor.NormalizedV;
		}

		// Token: 0x060006E9 RID: 1769 RVA: 0x00027528 File Offset: 0x00025728
		private void HSVChanged()
		{
			Color color = HSVUtil.ConvertHsvToRgb((double)(this._hue * 360f), (double)this._saturation, (double)this._brightness, this._alpha);
			this._red = color.r;
			this._green = color.g;
			this._blue = color.b;
		}

		// Token: 0x060006EA RID: 1770 RVA: 0x00027580 File Offset: 0x00025780
		private void SendChangedEvent()
		{
			this.onValueChanged.Invoke(this.CurrentColor);
			this.onHSVChanged.Invoke(this._hue, this._saturation, this._brightness);
		}

		// Token: 0x060006EB RID: 1771 RVA: 0x000275B0 File Offset: 0x000257B0
		public void AssignColor(ColorValues type, float value)
		{
			switch (type)
			{
			case ColorValues.R:
				this.R = value;
				return;
			case ColorValues.G:
				this.G = value;
				return;
			case ColorValues.B:
				this.B = value;
				return;
			case ColorValues.A:
				this.A = value;
				return;
			case ColorValues.Hue:
				this.H = value;
				return;
			case ColorValues.Saturation:
				this.S = value;
				return;
			case ColorValues.Value:
				this.V = value;
				return;
			default:
				return;
			}
		}

		// Token: 0x060006EC RID: 1772 RVA: 0x00027618 File Offset: 0x00025818
		public float GetValue(ColorValues type)
		{
			switch (type)
			{
			case ColorValues.R:
				return this.R;
			case ColorValues.G:
				return this.G;
			case ColorValues.B:
				return this.B;
			case ColorValues.A:
				return this.A;
			case ColorValues.Hue:
				return this.H;
			case ColorValues.Saturation:
				return this.S;
			case ColorValues.Value:
				return this.V;
			default:
				throw new NotImplementedException("");
			}
		}

		// Token: 0x0400050D RID: 1293
		private float _hue;

		// Token: 0x0400050E RID: 1294
		private float _saturation;

		// Token: 0x0400050F RID: 1295
		private float _brightness;

		// Token: 0x04000510 RID: 1296
		private float _red;

		// Token: 0x04000511 RID: 1297
		private float _green;

		// Token: 0x04000512 RID: 1298
		private float _blue;

		// Token: 0x04000513 RID: 1299
		private float _alpha = 1f;

		// Token: 0x04000514 RID: 1300
		public ColorChangedEvent onValueChanged = new ColorChangedEvent();

		// Token: 0x04000515 RID: 1301
		public HSVChangedEvent onHSVChanged = new HSVChangedEvent();

		// Token: 0x04000516 RID: 1302
		[SerializeField]
		private bool hsvSlidersOn = true;

		// Token: 0x04000517 RID: 1303
		[SerializeField]
		private List<GameObject> hsvSliders = new List<GameObject>();

		// Token: 0x04000518 RID: 1304
		[SerializeField]
		private bool rgbSlidersOn = true;

		// Token: 0x04000519 RID: 1305
		[SerializeField]
		private List<GameObject> rgbSliders = new List<GameObject>();

		// Token: 0x0400051A RID: 1306
		[SerializeField]
		private GameObject alphaSlider;
	}
}
