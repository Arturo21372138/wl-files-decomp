﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C5 RID: 197
	[AddComponentMenu("UI/Extensions/UI ScrollTo Selection XY")]
	[RequireComponent(typeof(ScrollRect))]
	public class UIScrollToSelectionXY : MonoBehaviour
	{
		// Token: 0x06000677 RID: 1655 RVA: 0x00025491 File Offset: 0x00023691
		private void Start()
		{
			this.targetScrollRect = base.GetComponent<ScrollRect>();
			this.scrollWindow = this.targetScrollRect.GetComponent<RectTransform>();
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x000254B0 File Offset: 0x000236B0
		private void Update()
		{
			this.ScrollRectToLevelSelection();
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x000254B8 File Offset: 0x000236B8
		private void ScrollRectToLevelSelection()
		{
			EventSystem current = EventSystem.current;
			if (this.targetScrollRect == null || this.layoutListGroup == null || this.scrollWindow == null)
			{
				return;
			}
			RectTransform rectTransform = ((current.currentSelectedGameObject != null) ? current.currentSelectedGameObject.GetComponent<RectTransform>() : null);
			if (rectTransform != this.targetScrollObject)
			{
				this.scrollToSelection = true;
			}
			if (rectTransform == null || !this.scrollToSelection || rectTransform.transform.parent != this.layoutListGroup.transform)
			{
				return;
			}
			bool flag = false;
			bool flag2 = false;
			if (this.targetScrollRect.vertical)
			{
				float num = -rectTransform.anchoredPosition.y;
				float num2 = this.layoutListGroup.anchoredPosition.y - num;
				this.targetScrollRect.verticalNormalizedPosition += num2 / this.layoutListGroup.sizeDelta.y * Time.deltaTime * this.scrollSpeed;
				flag2 = Mathf.Abs(num2) < 2f;
			}
			if (this.targetScrollRect.horizontal)
			{
				float num3 = -rectTransform.anchoredPosition.x;
				float num4 = this.layoutListGroup.anchoredPosition.x - num3;
				this.targetScrollRect.horizontalNormalizedPosition += num4 / this.layoutListGroup.sizeDelta.x * Time.deltaTime * this.scrollSpeed;
				flag = Mathf.Abs(num4) < 2f;
			}
			if (flag && flag2)
			{
				this.scrollToSelection = false;
			}
			this.targetScrollObject = rectTransform;
		}

		// Token: 0x040004A2 RID: 1186
		public float scrollSpeed = 10f;

		// Token: 0x040004A3 RID: 1187
		[SerializeField]
		private RectTransform layoutListGroup;

		// Token: 0x040004A4 RID: 1188
		private RectTransform targetScrollObject;

		// Token: 0x040004A5 RID: 1189
		private bool scrollToSelection = true;

		// Token: 0x040004A6 RID: 1190
		private RectTransform scrollWindow;

		// Token: 0x040004A7 RID: 1191
		private ScrollRect targetScrollRect;
	}
}
