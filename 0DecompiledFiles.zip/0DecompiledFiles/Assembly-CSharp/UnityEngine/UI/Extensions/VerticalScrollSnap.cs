﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000093 RID: 147
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("Layout/Extensions/Vertical Scroll Snap")]
	public class VerticalScrollSnap : ScrollSnapBase
	{
		// Token: 0x060004BE RID: 1214 RVA: 0x0001C640 File Offset: 0x0001A840
		private void Start()
		{
			this._isVertical = true;
			this._childAnchorPoint = new Vector2(0.5f, 0f);
			this._currentPage = this.StartingScreen;
			this.panelDimensions = base.gameObject.GetComponent<RectTransform>().rect;
			this.UpdateLayout();
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0001C694 File Offset: 0x0001A894
		private void Update()
		{
			this.updated = false;
			if (!this._lerp && this._scroll_rect.velocity == Vector2.zero)
			{
				if (!this._settled && !this._pointerDown && !base.IsRectSettledOnaPage(this._screensContainer.anchoredPosition))
				{
					base.ScrollToClosestElement();
				}
				return;
			}
			if (this._lerp)
			{
				this._screensContainer.anchoredPosition = Vector3.Lerp(this._screensContainer.anchoredPosition, this._lerp_target, this.transitionSpeed * (this.UseTimeScale ? Time.deltaTime : Time.unscaledDeltaTime));
				if (Vector3.Distance(this._screensContainer.anchoredPosition, this._lerp_target) < 0.1f)
				{
					this._screensContainer.anchoredPosition = this._lerp_target;
					this._lerp = false;
					base.EndScreenChange();
				}
			}
			if (this.UseHardSwipe)
			{
				return;
			}
			base.CurrentPage = base.GetPageforPosition(this._screensContainer.anchoredPosition);
			if (!this._pointerDown && ((double)this._scroll_rect.velocity.y > 0.01 || (double)this._scroll_rect.velocity.y < -0.01) && this.IsRectMovingSlowerThanThreshold(0f))
			{
				base.ScrollToClosestElement();
			}
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0001C804 File Offset: 0x0001AA04
		private bool IsRectMovingSlowerThanThreshold(float startingSpeed)
		{
			return (this._scroll_rect.velocity.y > startingSpeed && this._scroll_rect.velocity.y < (float)this.SwipeVelocityThreshold) || (this._scroll_rect.velocity.y < startingSpeed && this._scroll_rect.velocity.y > (float)(-(float)this.SwipeVelocityThreshold));
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0001C870 File Offset: 0x0001AA70
		public void DistributePages()
		{
			this._screens = this._screensContainer.childCount;
			this._scroll_rect.verticalNormalizedPosition = 0f;
			float num = 0f;
			Rect rect = base.gameObject.GetComponent<RectTransform>().rect;
			float num2 = 0f;
			float num3 = (this._childSize = (float)((int)rect.height) * ((this.PageStep == 0f) ? 3f : this.PageStep));
			for (int i = 0; i < this._screensContainer.transform.childCount; i++)
			{
				RectTransform component = this._screensContainer.transform.GetChild(i).gameObject.GetComponent<RectTransform>();
				num2 = num + (float)i * num3;
				component.sizeDelta = new Vector2(rect.width, rect.height);
				component.anchoredPosition = new Vector2(0f, num2);
				component.anchorMin = (component.anchorMax = (component.pivot = this._childAnchorPoint));
			}
			float num4 = num2 + num * -1f;
			this._screensContainer.GetComponent<RectTransform>().offsetMax = new Vector2(0f, num4);
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0001C9A9 File Offset: 0x0001ABA9
		public void AddChild(GameObject GO)
		{
			this.AddChild(GO, false);
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0001C9B4 File Offset: 0x0001ABB4
		public void AddChild(GameObject GO, bool WorldPositionStays)
		{
			this._scroll_rect.verticalNormalizedPosition = 0f;
			GO.transform.SetParent(this._screensContainer, WorldPositionStays);
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			this.SetScrollContainerPosition();
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0001CA08 File Offset: 0x0001AC08
		public void RemoveChild(int index, out GameObject ChildRemoved)
		{
			this.RemoveChild(index, false, out ChildRemoved);
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0001CA14 File Offset: 0x0001AC14
		public void RemoveChild(int index, bool WorldPositionStays, out GameObject ChildRemoved)
		{
			ChildRemoved = null;
			if (index < 0 || index > this._screensContainer.childCount)
			{
				return;
			}
			this._scroll_rect.verticalNormalizedPosition = 0f;
			Transform child = this._screensContainer.transform.GetChild(index);
			child.SetParent(null, WorldPositionStays);
			ChildRemoved = child.gameObject;
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			if (this._currentPage > this._screens - 1)
			{
				base.CurrentPage = this._screens - 1;
			}
			this.SetScrollContainerPosition();
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0001CAAC File Offset: 0x0001ACAC
		public void RemoveAllChildren(out GameObject[] ChildrenRemoved)
		{
			this.RemoveAllChildren(false, out ChildrenRemoved);
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0001CAB8 File Offset: 0x0001ACB8
		public void RemoveAllChildren(bool WorldPositionStays, out GameObject[] ChildrenRemoved)
		{
			int childCount = this._screensContainer.childCount;
			ChildrenRemoved = new GameObject[childCount];
			for (int i = childCount - 1; i >= 0; i--)
			{
				ChildrenRemoved[i] = this._screensContainer.GetChild(i).gameObject;
				ChildrenRemoved[i].transform.SetParent(null, WorldPositionStays);
			}
			this._scroll_rect.verticalNormalizedPosition = 0f;
			base.CurrentPage = 0;
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0001CB42 File Offset: 0x0001AD42
		private void SetScrollContainerPosition()
		{
			this._scrollStartPosition = this._screensContainer.anchoredPosition.y;
			this._scroll_rect.verticalNormalizedPosition = (float)this._currentPage / (float)(this._screens - 1);
			base.OnCurrentScreenChange(this._currentPage);
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x0001CB82 File Offset: 0x0001AD82
		public void UpdateLayout()
		{
			this._lerp = false;
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			this.SetScrollContainerPosition();
			base.OnCurrentScreenChange(this._currentPage);
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x0001CBB6 File Offset: 0x0001ADB6
		private void OnRectTransformDimensionsChange()
		{
			if (this._childAnchorPoint != Vector2.zero)
			{
				this.UpdateLayout();
			}
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x0001CBD0 File Offset: 0x0001ADD0
		private void OnEnable()
		{
			base.InitialiseChildObjectsFromScene();
			this.DistributePages();
			if (this.MaskArea)
			{
				base.UpdateVisible();
			}
			if (this.JumpOnEnable || !this.RestartOnEnable)
			{
				this.SetScrollContainerPosition();
			}
			if (this.RestartOnEnable)
			{
				base.GoToScreen(this.StartingScreen);
			}
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x0001CC28 File Offset: 0x0001AE28
		public override void OnEndDrag(PointerEventData eventData)
		{
			if (this.updated)
			{
				return;
			}
			this.updated = true;
			this._pointerDown = false;
			if (this._scroll_rect.vertical)
			{
				if (this.UseSwipeDeltaThreshold && Math.Abs(eventData.delta.y) < this.SwipeDeltaThreshold)
				{
					base.ScrollToClosestElement();
					return;
				}
				float num = Vector3.Distance(this._startPosition, this._screensContainer.anchoredPosition);
				if (this.UseHardSwipe)
				{
					this._scroll_rect.velocity = Vector3.zero;
					if (num <= (float)this.FastSwipeThreshold)
					{
						base.ScrollToClosestElement();
						return;
					}
					if (this._startPosition.y - this._screensContainer.anchoredPosition.y > 0f)
					{
						base.NextScreen();
						return;
					}
					base.PreviousScreen();
					return;
				}
				else if (this.UseFastSwipe && num < this.panelDimensions.height + (float)this.FastSwipeThreshold && num >= 1f)
				{
					this._scroll_rect.velocity = Vector3.zero;
					if (this._startPosition.y - this._screensContainer.anchoredPosition.y > 0f)
					{
						if (this._startPosition.y - this._screensContainer.anchoredPosition.y > this._childSize / 3f)
						{
							base.ScrollToClosestElement();
							return;
						}
						base.NextScreen();
						return;
					}
					else
					{
						if (this._startPosition.y - this._screensContainer.anchoredPosition.y > -this._childSize / 3f)
						{
							base.ScrollToClosestElement();
							return;
						}
						base.PreviousScreen();
					}
				}
			}
		}

		// Token: 0x04000398 RID: 920
		private bool updated = true;
	}
}
