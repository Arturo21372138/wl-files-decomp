﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000F7 RID: 247
	[Serializable]
	public class VersionInfo
	{
		// Token: 0x0600077C RID: 1916 RVA: 0x0002B480 File Offset: 0x00029680
		public static string StaticToString()
		{
			return string.Format("{0}.{1}.{2}", 0, 9, 7) + ((VersionInfo.Revision > 0) ? ("r" + VersionInfo.Revision.ToString()) : "");
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x0600077D RID: 1917 RVA: 0x0002B4D2 File Offset: 0x000296D2
		public static int FullNumber
		{
			get
			{
				return 9700 + (int)VersionInfo.Revision;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600077E RID: 1918 RVA: 0x0002B4E0 File Offset: 0x000296E0
		public static string FullLabel
		{
			get
			{
				return "Version=" + VersionInfo.FullNumber.ToString();
			}
		}

		// Token: 0x040005ED RID: 1517
		public const byte Major = 0;

		// Token: 0x040005EE RID: 1518
		public const byte Minor = 9;

		// Token: 0x040005EF RID: 1519
		public const byte Release = 7;

		// Token: 0x040005F0 RID: 1520
		public static byte Revision = 11;
	}
}
