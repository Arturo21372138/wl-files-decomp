﻿using System;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000039 RID: 57
	[AddComponentMenu("UI/Extensions/MultiTouchScrollRect")]
	public class MultiTouchScrollRect : ScrollRect
	{
		// Token: 0x0600014B RID: 331 RVA: 0x00008326 File Offset: 0x00006526
		public override void OnBeginDrag(PointerEventData eventData)
		{
			this.pid = eventData.pointerId;
			base.OnBeginDrag(eventData);
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000833B File Offset: 0x0000653B
		public override void OnDrag(PointerEventData eventData)
		{
			if (this.pid == eventData.pointerId)
			{
				base.OnDrag(eventData);
			}
		}

		// Token: 0x0600014D RID: 333 RVA: 0x00008352 File Offset: 0x00006552
		public override void OnEndDrag(PointerEventData eventData)
		{
			this.pid = -100;
			base.OnEndDrag(eventData);
		}

		// Token: 0x0400013E RID: 318
		private int pid = -100;
	}
}
