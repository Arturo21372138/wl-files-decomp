﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E8 RID: 232
	public enum TextureChannels
	{
		// Token: 0x040005AF RID: 1455
		RGBA,
		// Token: 0x040005B0 RID: 1456
		RGB
	}
}
