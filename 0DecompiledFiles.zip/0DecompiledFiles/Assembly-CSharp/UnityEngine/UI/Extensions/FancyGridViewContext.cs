﻿using System;
using System.Runtime.CompilerServices;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200007B RID: 123
	public class FancyGridViewContext : IFancyGridViewContext, IFancyScrollRectContext, IFancyCellGroupContext
	{
		// Token: 0x17000099 RID: 153
		// (get) Token: 0x0600039E RID: 926 RVA: 0x0001704E File Offset: 0x0001524E
		// (set) Token: 0x0600039F RID: 927 RVA: 0x00017056 File Offset: 0x00015256
		ScrollDirection IFancyScrollRectContext.ScrollDirection { get; set; }

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060003A0 RID: 928 RVA: 0x0001705F File Offset: 0x0001525F
		// (set) Token: 0x060003A1 RID: 929 RVA: 0x00017067 File Offset: 0x00015267
		[TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
		Func<ValueTuple<float, float>> IFancyScrollRectContext.CalculateScrollSize
		{
			[return: TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
			get;
			[param: TupleElementNames(new string[] { "ScrollSize", "ReuseMargin" })]
			set;
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060003A2 RID: 930 RVA: 0x00017070 File Offset: 0x00015270
		// (set) Token: 0x060003A3 RID: 931 RVA: 0x00017078 File Offset: 0x00015278
		GameObject IFancyCellGroupContext.CellTemplate { get; set; }

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x00017081 File Offset: 0x00015281
		// (set) Token: 0x060003A5 RID: 933 RVA: 0x00017089 File Offset: 0x00015289
		Func<int> IFancyCellGroupContext.GetGroupCount { get; set; }

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060003A6 RID: 934 RVA: 0x00017092 File Offset: 0x00015292
		// (set) Token: 0x060003A7 RID: 935 RVA: 0x0001709A File Offset: 0x0001529A
		Func<float> IFancyGridViewContext.GetStartAxisSpacing { get; set; }

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060003A8 RID: 936 RVA: 0x000170A3 File Offset: 0x000152A3
		// (set) Token: 0x060003A9 RID: 937 RVA: 0x000170AB File Offset: 0x000152AB
		Func<float> IFancyGridViewContext.GetCellSize { get; set; }
	}
}
