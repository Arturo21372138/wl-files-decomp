﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x02000771 RID: 1905
	public enum AntiCheatCommonEventType
	{
		// Token: 0x0400149D RID: 5277
		Invalid,
		// Token: 0x0400149E RID: 5278
		GameEvent,
		// Token: 0x0400149F RID: 5279
		PlayerEvent
	}
}
