﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007BB RID: 1979
	internal static class OnClientIntegrityViolatedCallbackInternalImplementation
	{
		// Token: 0x1700081C RID: 2076
		// (get) Token: 0x060020B5 RID: 8373 RVA: 0x00027064 File Offset: 0x00025264
		public static OnClientIntegrityViolatedCallbackInternal Delegate
		{
			get
			{
				if (OnClientIntegrityViolatedCallbackInternalImplementation.s_Delegate == null)
				{
					OnClientIntegrityViolatedCallbackInternalImplementation.s_Delegate = new OnClientIntegrityViolatedCallbackInternal(OnClientIntegrityViolatedCallbackInternalImplementation.EntryPoint);
				}
				return OnClientIntegrityViolatedCallbackInternalImplementation.s_Delegate;
			}
		}

		// Token: 0x060020B6 RID: 8374 RVA: 0x00027084 File Offset: 0x00025284
		[MonoPInvokeCallback(typeof(OnClientIntegrityViolatedCallbackInternal))]
		public static void EntryPoint(ref OnClientIntegrityViolatedCallbackInfoInternal data)
		{
			OnClientIntegrityViolatedCallback onClientIntegrityViolatedCallback;
			OnClientIntegrityViolatedCallbackInfo onClientIntegrityViolatedCallbackInfo;
			if (Helper.TryGetCallback<OnClientIntegrityViolatedCallbackInfoInternal, OnClientIntegrityViolatedCallback, OnClientIntegrityViolatedCallbackInfo>(ref data, out onClientIntegrityViolatedCallback, out onClientIntegrityViolatedCallbackInfo))
			{
				onClientIntegrityViolatedCallback(ref onClientIntegrityViolatedCallbackInfo);
			}
		}

		// Token: 0x040015D2 RID: 5586
		private static OnClientIntegrityViolatedCallbackInternal s_Delegate;
	}
}
