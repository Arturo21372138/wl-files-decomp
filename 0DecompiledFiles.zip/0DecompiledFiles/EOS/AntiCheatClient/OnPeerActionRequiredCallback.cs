﻿using System;
using Epic.OnlineServices.AntiCheatCommon;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C6 RID: 1990
	// (Invoke) Token: 0x060020DE RID: 8414
	public delegate void OnPeerActionRequiredCallback(ref OnClientActionRequiredCallbackInfo data);
}
