﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000BF RID: 191
	public static class RectTransformExtension
	{
		// Token: 0x0600063D RID: 1597 RVA: 0x00024AD8 File Offset: 0x00022CD8
		public static Vector2 switchToRectTransform(this RectTransform from, RectTransform to)
		{
			Vector2 vector = new Vector2(from.rect.width * from.pivot.x + from.rect.xMin, from.rect.height * from.pivot.y + from.rect.yMin);
			Vector2 vector2 = RectTransformUtility.WorldToScreenPoint(null, from.position);
			vector2 += vector;
			Vector2 vector3;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(to, vector2, null, out vector3);
			Vector2 vector4 = new Vector2(to.rect.width * to.pivot.x + to.rect.xMin, to.rect.height * to.pivot.y + to.rect.yMin);
			return to.anchoredPosition + vector3 - vector4;
		}
	}
}
