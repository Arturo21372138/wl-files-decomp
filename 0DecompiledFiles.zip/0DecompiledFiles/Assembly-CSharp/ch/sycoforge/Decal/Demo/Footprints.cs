﻿using System;
using UnityEngine;

namespace ch.sycoforge.Decal.Demo
{
	// Token: 0x02000023 RID: 35
	public class Footprints : MonoBehaviour
	{
		// Token: 0x0600006B RID: 107 RVA: 0x00004976 File Offset: 0x00002B76
		public void Start()
		{
			if (this.DecalPrefab == null)
			{
				Debug.LogError("The DynamicDemo script has no decal prefab attached.");
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00004990 File Offset: 0x00002B90
		public void Update()
		{
			if (this.DecalPrefab == null)
			{
				return;
			}
			if (this.distance >= this.DistanceThreshold)
			{
				Vector3 vector = ((this.index == 0) ? Vector3.right : Vector3.left) * this.FootDistance * 0.5f;
				Vector3 vector2 = base.transform.TransformPoint(vector);
				RaycastHit raycastHit;
				if (Physics.Raycast(new Ray(vector2 + Vector3.up * 0.1f, Vector3.down), out raycastHit, 200f))
				{
					EasyDecal easyDecal = EasyDecal.ProjectAt(this.DecalPrefab.gameObject, raycastHit.collider.gameObject, raycastHit.point, raycastHit.normal, true);
					easyDecal.AtlasRegionIndex = this.index;
					easyDecal.transform.rotation = Quaternion.Euler(Vector3.up * base.transform.rotation.eulerAngles.y);
				}
				int num = this.index + 1;
				this.index = num;
				this.index = num % 2;
				this.distance = 0f;
			}
			this.distance += Vector3.Distance(this.lastPosition, base.transform.position);
			this.lastPosition = base.transform.position;
		}

		// Token: 0x0400008F RID: 143
		public EasyDecal DecalPrefab;

		// Token: 0x04000090 RID: 144
		public float DistanceThreshold = 0.8f;

		// Token: 0x04000091 RID: 145
		public float FootDistance = 0.5f;

		// Token: 0x04000092 RID: 146
		private float distance;

		// Token: 0x04000093 RID: 147
		private int index;

		// Token: 0x04000094 RID: 148
		private Vector3 lastPosition;
	}
}
