﻿using System;
using System.Collections;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000043 RID: 67
	[AddComponentMenu("UI/Extensions/Segmented Control/Segment")]
	[RequireComponent(typeof(Selectable))]
	public class Segment : UIBehaviour, IPointerClickHandler, IEventSystemHandler, ISubmitHandler, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler, ISelectHandler, IDeselectHandler
	{
		// Token: 0x17000044 RID: 68
		// (get) Token: 0x060001C6 RID: 454 RVA: 0x0000AC24 File Offset: 0x00008E24
		internal bool leftmost
		{
			get
			{
				return this.index == 0;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x0000AC2F File Offset: 0x00008E2F
		internal bool rightmost
		{
			get
			{
				return this.index == this.segmentedControl.segments.Length - 1;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x060001C8 RID: 456 RVA: 0x0000AC48 File Offset: 0x00008E48
		// (set) Token: 0x060001C9 RID: 457 RVA: 0x0000AC60 File Offset: 0x00008E60
		public bool selected
		{
			get
			{
				return this.segmentedControl.selectedSegment == this.button;
			}
			set
			{
				this.SetSelected(value);
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x060001CA RID: 458 RVA: 0x0000AC69 File Offset: 0x00008E69
		internal Selectable button
		{
			get
			{
				return base.GetComponent<Selectable>();
			}
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0000AC71 File Offset: 0x00008E71
		protected Segment()
		{
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0000AC79 File Offset: 0x00008E79
		protected override void Start()
		{
			base.StartCoroutine(this.DelayedInit());
		}

		// Token: 0x060001CD RID: 461 RVA: 0x0000AC88 File Offset: 0x00008E88
		private IEnumerator DelayedInit()
		{
			yield return null;
			yield return null;
			this.button.image.overrideSprite = this.cutSprite;
			if (this.selected)
			{
				this.MaintainSelection();
			}
			yield break;
		}

		// Token: 0x060001CE RID: 462 RVA: 0x0000AC97 File Offset: 0x00008E97
		public virtual void OnPointerClick(PointerEventData eventData)
		{
			if (eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.selected = true;
		}

		// Token: 0x060001CF RID: 463 RVA: 0x0000ACA9 File Offset: 0x00008EA9
		public virtual void OnPointerEnter(PointerEventData eventData)
		{
			this.MaintainSelection();
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x0000ACB1 File Offset: 0x00008EB1
		public virtual void OnPointerExit(PointerEventData eventData)
		{
			this.MaintainSelection();
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0000ACB9 File Offset: 0x00008EB9
		public virtual void OnPointerDown(PointerEventData eventData)
		{
			this.MaintainSelection();
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0000ACC1 File Offset: 0x00008EC1
		public virtual void OnPointerUp(PointerEventData eventData)
		{
			this.MaintainSelection();
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0000ACC9 File Offset: 0x00008EC9
		public virtual void OnSelect(BaseEventData eventData)
		{
			this.MaintainSelection();
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x0000ACD1 File Offset: 0x00008ED1
		public virtual void OnDeselect(BaseEventData eventData)
		{
			this.MaintainSelection();
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x0000ACD9 File Offset: 0x00008ED9
		protected override void OnEnable()
		{
			base.OnEnable();
			if (this.segmentedControl)
			{
				this.MaintainSelection();
			}
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000ACF4 File Offset: 0x00008EF4
		public virtual void OnSubmit(BaseEventData eventData)
		{
			this.selected = true;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000AD00 File Offset: 0x00008F00
		private void SetSelected(bool value)
		{
			if (!value || !this.button.IsActive() || !this.button.IsInteractable())
			{
				if (this.segmentedControl.selectedSegment == this.button)
				{
					this.Deselect();
				}
				return;
			}
			if (!(this.segmentedControl.selectedSegment == this.button))
			{
				if (this.segmentedControl.selectedSegment)
				{
					Segment component = this.segmentedControl.selectedSegment.GetComponent<Segment>();
					this.segmentedControl.selectedSegment = null;
					if (component)
					{
						component.TransitionButton();
					}
				}
				this.segmentedControl.selectedSegment = this.button;
				this.TransitionButton();
				this.segmentedControl.onValueChanged.Invoke(this.index);
				return;
			}
			if (this.segmentedControl.allowSwitchingOff)
			{
				this.Deselect();
				return;
			}
			this.MaintainSelection();
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0000ADEF File Offset: 0x00008FEF
		private void Deselect()
		{
			this.segmentedControl.selectedSegment = null;
			this.TransitionButton();
			this.segmentedControl.onValueChanged.Invoke(-1);
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0000AE14 File Offset: 0x00009014
		private void MaintainSelection()
		{
			if (this.button != this.segmentedControl.selectedSegment)
			{
				return;
			}
			this.TransitionButton(true);
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0000AE36 File Offset: 0x00009036
		internal void TransitionButton()
		{
			this.TransitionButton(false);
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0000AE40 File Offset: 0x00009040
		internal void TransitionButton(bool instant)
		{
			Color color = (this.selected ? this.button.colors.pressedColor : this.button.colors.normalColor);
			Color color2 = (this.selected ? this.button.colors.normalColor : this.button.colors.pressedColor);
			Sprite sprite = (this.selected ? this.button.spriteState.pressedSprite : this.cutSprite);
			string text = (this.selected ? this.button.animationTriggers.pressedTrigger : this.button.animationTriggers.normalTrigger);
			switch (this.button.transition)
			{
			case Selectable.Transition.ColorTint:
				this.button.image.overrideSprite = this.cutSprite;
				this.StartColorTween(color * this.button.colors.colorMultiplier, instant);
				this.ChangeTextColor(color2 * this.button.colors.colorMultiplier);
				return;
			case Selectable.Transition.SpriteSwap:
				if (sprite != this.cutSprite)
				{
					sprite = SegmentedControl.CutSprite(sprite, this.leftmost, this.rightmost);
				}
				this.DoSpriteSwap(sprite);
				return;
			case Selectable.Transition.Animation:
				this.button.image.overrideSprite = this.cutSprite;
				this.TriggerAnimation(text);
				return;
			default:
				return;
			}
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0000AFC4 File Offset: 0x000091C4
		private void StartColorTween(Color targetColor, bool instant)
		{
			if (this.button.targetGraphic == null)
			{
				return;
			}
			this.button.targetGraphic.CrossFadeColor(targetColor, instant ? 0f : this.button.colors.fadeDuration, true, true);
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0000B018 File Offset: 0x00009218
		private void ChangeTextColor(Color targetColor)
		{
			Text componentInChildren = base.GetComponentInChildren<Text>();
			if (!componentInChildren)
			{
				return;
			}
			componentInChildren.color = targetColor;
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0000B03C File Offset: 0x0000923C
		private void DoSpriteSwap(Sprite newSprite)
		{
			if (this.button.image == null)
			{
				return;
			}
			this.button.image.overrideSprite = newSprite;
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0000B064 File Offset: 0x00009264
		private void TriggerAnimation(string triggername)
		{
			if (this.button.animator == null || !this.button.animator.isActiveAndEnabled || !this.button.animator.hasBoundPlayables || string.IsNullOrEmpty(triggername))
			{
				return;
			}
			this.button.animator.ResetTrigger(this.button.animationTriggers.normalTrigger);
			this.button.animator.ResetTrigger(this.button.animationTriggers.pressedTrigger);
			this.button.animator.ResetTrigger(this.button.animationTriggers.highlightedTrigger);
			this.button.animator.ResetTrigger(this.button.animationTriggers.disabledTrigger);
			this.button.animator.SetTrigger(triggername);
		}

		// Token: 0x040001A7 RID: 423
		internal int index;

		// Token: 0x040001A8 RID: 424
		internal SegmentedControl segmentedControl;

		// Token: 0x040001A9 RID: 425
		internal Sprite cutSprite;
	}
}
