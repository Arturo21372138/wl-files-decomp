﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000097 RID: 151
	public static class MenuExtensions
	{
		// Token: 0x060004E8 RID: 1256 RVA: 0x0001D204 File Offset: 0x0001B404
		public static Menu GetMenu(this GameObject go)
		{
			return go.GetComponent<Menu>();
		}
	}
}
