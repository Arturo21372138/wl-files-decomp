﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200004E RID: 78
	public class CUIBezierCurve : MonoBehaviour
	{
		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000266 RID: 614 RVA: 0x0000E2E0 File Offset: 0x0000C4E0
		public Vector3[] ControlPoints
		{
			get
			{
				return this.controlPoints;
			}
		}

		// Token: 0x06000267 RID: 615 RVA: 0x0000E2E8 File Offset: 0x0000C4E8
		public void Refresh()
		{
			if (this.OnRefresh != null)
			{
				this.OnRefresh();
			}
		}

		// Token: 0x06000268 RID: 616 RVA: 0x0000E300 File Offset: 0x0000C500
		public Vector3 GetPoint(float _time)
		{
			float num = 1f - _time;
			return num * num * num * this.controlPoints[0] + 3f * num * num * _time * this.controlPoints[1] + 3f * num * _time * _time * this.controlPoints[2] + _time * _time * _time * this.controlPoints[3];
		}

		// Token: 0x06000269 RID: 617 RVA: 0x0000E388 File Offset: 0x0000C588
		public Vector3 GetTangent(float _time)
		{
			float num = 1f - _time;
			return 3f * num * num * (this.controlPoints[1] - this.controlPoints[0]) + 6f * num * _time * (this.controlPoints[2] - this.controlPoints[1]) + 3f * _time * _time * (this.controlPoints[3] - this.controlPoints[2]);
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0000E428 File Offset: 0x0000C628
		public void ReportSet()
		{
			if (this.controlPoints == null)
			{
				this.controlPoints = new Vector3[CUIBezierCurve.CubicBezierCurvePtNum];
				this.controlPoints[0] = new Vector3(0f, 0f, 0f);
				this.controlPoints[1] = new Vector3(0f, 1f, 0f);
				this.controlPoints[2] = new Vector3(1f, 1f, 0f);
				this.controlPoints[3] = new Vector3(1f, 0f, 0f);
			}
			int num = this.controlPoints.Length;
			int cubicBezierCurvePtNum = CUIBezierCurve.CubicBezierCurvePtNum;
		}

		// Token: 0x04000202 RID: 514
		public static readonly int CubicBezierCurvePtNum = 4;

		// Token: 0x04000203 RID: 515
		[SerializeField]
		protected Vector3[] controlPoints;

		// Token: 0x04000204 RID: 516
		public Action OnRefresh;
	}
}
