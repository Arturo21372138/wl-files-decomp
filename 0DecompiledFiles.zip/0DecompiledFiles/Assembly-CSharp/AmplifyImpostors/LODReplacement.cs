﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000DE RID: 222
	public enum LODReplacement
	{
		// Token: 0x04000552 RID: 1362
		DoNothing,
		// Token: 0x04000553 RID: 1363
		ReplaceCulled,
		// Token: 0x04000554 RID: 1364
		ReplaceLast,
		// Token: 0x04000555 RID: 1365
		ReplaceAllExceptFirst,
		// Token: 0x04000556 RID: 1366
		ReplaceSpecific,
		// Token: 0x04000557 RID: 1367
		ReplaceAfterSpecific,
		// Token: 0x04000558 RID: 1368
		InsertAfter
	}
}
