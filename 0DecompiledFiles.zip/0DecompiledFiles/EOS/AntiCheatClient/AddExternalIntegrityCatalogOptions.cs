﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007A4 RID: 1956
	public struct AddExternalIntegrityCatalogOptions
	{
		// Token: 0x17000818 RID: 2072
		// (get) Token: 0x0600207A RID: 8314 RVA: 0x00026A02 File Offset: 0x00024C02
		// (set) Token: 0x0600207B RID: 8315 RVA: 0x00026A0A File Offset: 0x00024C0A
		public Utf8String PathToBinFile { readonly get; set; }
	}
}
