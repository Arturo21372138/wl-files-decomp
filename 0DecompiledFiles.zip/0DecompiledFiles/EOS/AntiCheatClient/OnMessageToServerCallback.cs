﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007C1 RID: 1985
	// (Invoke) Token: 0x060020CC RID: 8396
	public delegate void OnMessageToServerCallback(ref OnMessageToServerCallbackInfo data);
}
