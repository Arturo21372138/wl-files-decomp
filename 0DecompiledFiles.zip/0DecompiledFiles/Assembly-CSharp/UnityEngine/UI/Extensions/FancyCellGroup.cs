﻿using System;
using System.Linq;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000076 RID: 118
	public abstract class FancyCellGroup<TItemData, TContext> : FancyCell<TItemData[], TContext> where TContext : class, IFancyCellGroupContext, new()
	{
		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000381 RID: 897 RVA: 0x00016B50 File Offset: 0x00014D50
		// (set) Token: 0x06000382 RID: 898 RVA: 0x00016B58 File Offset: 0x00014D58
		private protected virtual FancyCell<TItemData, TContext>[] Cells { protected get; private set; }

		// Token: 0x06000383 RID: 899 RVA: 0x00016B64 File Offset: 0x00014D64
		protected virtual FancyCell<TItemData, TContext>[] InstantiateCells()
		{
			return (from _ in Enumerable.Range(0, base.Context.GetGroupCount())
				select Object.Instantiate<GameObject>(base.Context.CellTemplate, base.transform) into x
				select x.GetComponent<FancyCell<TItemData, TContext>>()).ToArray<FancyCell<TItemData, TContext>>();
		}

		// Token: 0x06000384 RID: 900 RVA: 0x00016BC8 File Offset: 0x00014DC8
		public override void Initialize()
		{
			this.Cells = this.InstantiateCells();
			for (int i = 0; i < this.Cells.Length; i++)
			{
				this.Cells[i].SetContext(base.Context);
				this.Cells[i].Initialize();
			}
		}

		// Token: 0x06000385 RID: 901 RVA: 0x00016C14 File Offset: 0x00014E14
		public override void UpdateContent(TItemData[] contents)
		{
			int num = base.Index * base.Context.GetGroupCount();
			for (int i = 0; i < this.Cells.Length; i++)
			{
				this.Cells[i].Index = i + num;
				this.Cells[i].SetVisible(i < contents.Length);
				if (this.Cells[i].IsVisible)
				{
					this.Cells[i].UpdateContent(contents[i]);
				}
			}
		}

		// Token: 0x06000386 RID: 902 RVA: 0x00016C98 File Offset: 0x00014E98
		public override void UpdatePosition(float position)
		{
			for (int i = 0; i < this.Cells.Length; i++)
			{
				this.Cells[i].UpdatePosition(position);
			}
		}
	}
}
