﻿using System;
using HawkNetworking;
using UnityEngine;
using UnityEngine.Localization;

// Token: 0x02000004 RID: 4
public class TestLocalizeSync : MonoBehaviour
{
	// Token: 0x06000007 RID: 7 RVA: 0x000020B4 File Offset: 0x000002B4
	private void Start()
	{
		ArraySegment<byte> arraySegment = new HawkLocalizedString
		{
			localizedString = this.test
		}.SerializeNonAlloc();
		Debug.Log(default(HawkLocalizedString).Deserialize(arraySegment).localizedString.GetLocalizedString());
	}

	// Token: 0x04000006 RID: 6
	[SerializeField]
	private LocalizedString test;
}
