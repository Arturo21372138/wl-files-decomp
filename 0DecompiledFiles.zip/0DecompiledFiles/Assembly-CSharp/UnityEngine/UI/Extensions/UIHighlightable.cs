﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C2 RID: 194
	[AddComponentMenu("UI/Extensions/UI Highlightable Extension")]
	[RequireComponent(typeof(RectTransform), typeof(Graphic))]
	public class UIHighlightable : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
	{
		// Token: 0x17000115 RID: 277
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x00024D10 File Offset: 0x00022F10
		// (set) Token: 0x0600064F RID: 1615 RVA: 0x00024D18 File Offset: 0x00022F18
		public bool Interactable
		{
			get
			{
				return this.m_Interactable;
			}
			set
			{
				this.m_Interactable = value;
				this.HighlightInteractable(this.m_Graphic);
				this.OnInteractableChanged.Invoke(this.m_Interactable);
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x00024D3E File Offset: 0x00022F3E
		// (set) Token: 0x06000651 RID: 1617 RVA: 0x00024D46 File Offset: 0x00022F46
		public bool ClickToHold
		{
			get
			{
				return this.m_ClickToHold;
			}
			set
			{
				this.m_ClickToHold = value;
			}
		}

		// Token: 0x06000652 RID: 1618 RVA: 0x00024D4F File Offset: 0x00022F4F
		private void Awake()
		{
			this.m_Graphic = base.GetComponent<Graphic>();
		}

		// Token: 0x06000653 RID: 1619 RVA: 0x00024D5D File Offset: 0x00022F5D
		public void OnPointerEnter(PointerEventData eventData)
		{
			if (this.Interactable && !this.m_Pressed)
			{
				this.m_Highlighted = true;
				this.m_Graphic.color = this.HighlightedColor;
			}
		}

		// Token: 0x06000654 RID: 1620 RVA: 0x00024D87 File Offset: 0x00022F87
		public void OnPointerExit(PointerEventData eventData)
		{
			if (this.Interactable && !this.m_Pressed)
			{
				this.m_Highlighted = false;
				this.m_Graphic.color = this.NormalColor;
			}
		}

		// Token: 0x06000655 RID: 1621 RVA: 0x00024DB1 File Offset: 0x00022FB1
		public void OnPointerDown(PointerEventData eventData)
		{
			if (this.Interactable)
			{
				this.m_Graphic.color = this.PressedColor;
				if (this.ClickToHold)
				{
					this.m_Pressed = !this.m_Pressed;
				}
			}
		}

		// Token: 0x06000656 RID: 1622 RVA: 0x00024DE3 File Offset: 0x00022FE3
		public void OnPointerUp(PointerEventData eventData)
		{
			if (!this.m_Pressed)
			{
				this.HighlightInteractable(this.m_Graphic);
			}
		}

		// Token: 0x06000657 RID: 1623 RVA: 0x00024DF9 File Offset: 0x00022FF9
		private void HighlightInteractable(Graphic graphic)
		{
			if (!this.m_Interactable)
			{
				graphic.color = this.DisabledColor;
				return;
			}
			if (this.m_Highlighted)
			{
				graphic.color = this.HighlightedColor;
				return;
			}
			graphic.color = this.NormalColor;
		}

		// Token: 0x0400048A RID: 1162
		private Graphic m_Graphic;

		// Token: 0x0400048B RID: 1163
		private bool m_Highlighted;

		// Token: 0x0400048C RID: 1164
		private bool m_Pressed;

		// Token: 0x0400048D RID: 1165
		[SerializeField]
		[Tooltip("Can this panel be interacted with or is it disabled? (does not affect child components)")]
		private bool m_Interactable = true;

		// Token: 0x0400048E RID: 1166
		[SerializeField]
		[Tooltip("Does the panel remain in the pressed state when clicked? (default false)")]
		private bool m_ClickToHold;

		// Token: 0x0400048F RID: 1167
		[Tooltip("The default color for the panel")]
		public Color NormalColor = Color.grey;

		// Token: 0x04000490 RID: 1168
		[Tooltip("The color for the panel when a mouse is over it or it is in focus")]
		public Color HighlightedColor = Color.yellow;

		// Token: 0x04000491 RID: 1169
		[Tooltip("The color for the panel when it is clicked/held")]
		public Color PressedColor = Color.green;

		// Token: 0x04000492 RID: 1170
		[Tooltip("The color for the panel when it is not interactable (see Interactable)")]
		public Color DisabledColor = Color.gray;

		// Token: 0x04000493 RID: 1171
		[Tooltip("Event for when the panel is enabled / disabled, to enable disabling / enabling of child or other gameobjects")]
		public UIHighlightable.InteractableChangedEvent OnInteractableChanged;

		// Token: 0x02000154 RID: 340
		[Serializable]
		public class InteractableChangedEvent : UnityEvent<bool>
		{
		}
	}
}
