﻿using System;

namespace Epic.OnlineServices.AntiCheatClient
{
	// Token: 0x020007D0 RID: 2000
	public struct ReceiveMessageFromPeerOptions
	{
		// Token: 0x1700082B RID: 2091
		// (get) Token: 0x060020FB RID: 8443 RVA: 0x00027368 File Offset: 0x00025568
		// (set) Token: 0x060020FC RID: 8444 RVA: 0x00027370 File Offset: 0x00025570
		public IntPtr PeerHandle { readonly get; set; }

		// Token: 0x1700082C RID: 2092
		// (get) Token: 0x060020FD RID: 8445 RVA: 0x00027379 File Offset: 0x00025579
		// (set) Token: 0x060020FE RID: 8446 RVA: 0x00027381 File Offset: 0x00025581
		public ArraySegment<byte> Data { readonly get; set; }
	}
}
