﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007F0 RID: 2032
	internal struct CopyUnlockedAchievementByIndexOptionsInternal : ISettable<CopyUnlockedAchievementByIndexOptions>, IDisposable
	{
		// Token: 0x06002162 RID: 8546 RVA: 0x00027DC9 File Offset: 0x00025FC9
		public void Set(ref CopyUnlockedAchievementByIndexOptions other)
		{
			this.Dispose();
			this.m_ApiVersion = 1;
			Helper.Set(other.UserId, ref this.m_UserId);
			this.m_AchievementIndex = other.AchievementIndex;
		}

		// Token: 0x06002163 RID: 8547 RVA: 0x00027DF5 File Offset: 0x00025FF5
		public void Dispose()
		{
			Helper.Dispose(ref this.m_UserId);
		}

		// Token: 0x0400164B RID: 5707
		private int m_ApiVersion;

		// Token: 0x0400164C RID: 5708
		private IntPtr m_UserId;

		// Token: 0x0400164D RID: 5709
		private uint m_AchievementIndex;
	}
}
