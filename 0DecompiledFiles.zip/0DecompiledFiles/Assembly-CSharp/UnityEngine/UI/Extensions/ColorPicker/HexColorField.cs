﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.ColorPicker
{
	// Token: 0x020000D7 RID: 215
	[RequireComponent(typeof(InputField))]
	public class HexColorField : MonoBehaviour
	{
		// Token: 0x06000716 RID: 1814 RVA: 0x00028424 File Offset: 0x00026624
		private void Awake()
		{
			this.hexInputField = base.GetComponent<InputField>();
			this.hexInputField.onEndEdit.AddListener(new UnityAction<string>(this.UpdateColor));
			this.ColorPicker.onValueChanged.AddListener(new UnityAction<Color>(this.UpdateHex));
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x00028475 File Offset: 0x00026675
		private void OnDestroy()
		{
			this.hexInputField.onValueChanged.RemoveListener(new UnityAction<string>(this.UpdateColor));
			this.ColorPicker.onValueChanged.RemoveListener(new UnityAction<Color>(this.UpdateHex));
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x000284AF File Offset: 0x000266AF
		private void UpdateHex(Color newColor)
		{
			this.hexInputField.text = this.ColorToHex(newColor);
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x000284C8 File Offset: 0x000266C8
		private void UpdateColor(string newHex)
		{
			Color32 color;
			if (HexColorField.HexToColor(newHex, out color))
			{
				this.ColorPicker.CurrentColor = color;
				return;
			}
			Debug.Log("hex value is in the wrong format, valid formats are: #RGB, #RGBA, #RRGGBB and #RRGGBBAA (# is optional)");
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x000284FC File Offset: 0x000266FC
		private string ColorToHex(Color32 color)
		{
			if (this.displayAlpha)
			{
				return string.Format("#{0:X2}{1:X2}{2:X2}{3:X2}", new object[] { color.r, color.g, color.b, color.a });
			}
			return string.Format("#{0:X2}{1:X2}{2:X2}", color.r, color.g, color.b);
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x00028588 File Offset: 0x00026788
		public static bool HexToColor(string hex, out Color32 color)
		{
			if (Regex.IsMatch(hex, "^#?(?:[0-9a-fA-F]{3,4}){1,2}$"))
			{
				int num = (hex.StartsWith("#") ? 1 : 0);
				if (hex.Length == num + 8)
				{
					color = new Color32(byte.Parse(hex.Substring(num, 2), NumberStyles.AllowHexSpecifier), byte.Parse(hex.Substring(num + 2, 2), NumberStyles.AllowHexSpecifier), byte.Parse(hex.Substring(num + 4, 2), NumberStyles.AllowHexSpecifier), byte.Parse(hex.Substring(num + 6, 2), NumberStyles.AllowHexSpecifier));
				}
				else if (hex.Length == num + 6)
				{
					color = new Color32(byte.Parse(hex.Substring(num, 2), NumberStyles.AllowHexSpecifier), byte.Parse(hex.Substring(num + 2, 2), NumberStyles.AllowHexSpecifier), byte.Parse(hex.Substring(num + 4, 2), NumberStyles.AllowHexSpecifier), byte.MaxValue);
				}
				else if (hex.Length == num + 4)
				{
					color = new Color32(byte.Parse(hex[num].ToString() + hex[num].ToString(), NumberStyles.AllowHexSpecifier), byte.Parse(hex[num + 1].ToString() + hex[num + 1].ToString(), NumberStyles.AllowHexSpecifier), byte.Parse(hex[num + 2].ToString() + hex[num + 2].ToString(), NumberStyles.AllowHexSpecifier), byte.Parse(hex[num + 3].ToString() + hex[num + 3].ToString(), NumberStyles.AllowHexSpecifier));
				}
				else
				{
					color = new Color32(byte.Parse(hex[num].ToString() + hex[num].ToString(), NumberStyles.AllowHexSpecifier), byte.Parse(hex[num + 1].ToString() + hex[num + 1].ToString(), NumberStyles.AllowHexSpecifier), byte.Parse(hex[num + 2].ToString() + hex[num + 2].ToString(), NumberStyles.AllowHexSpecifier), byte.MaxValue);
				}
				return true;
			}
			color = default(Color32);
			return false;
		}

		// Token: 0x0400053D RID: 1341
		public ColorPickerControl ColorPicker;

		// Token: 0x0400053E RID: 1342
		public bool displayAlpha;

		// Token: 0x0400053F RID: 1343
		private InputField hexInputField;

		// Token: 0x04000540 RID: 1344
		private const string hexRegex = "^#?(?:[0-9a-fA-F]{3,4}){1,2}$";
	}
}
