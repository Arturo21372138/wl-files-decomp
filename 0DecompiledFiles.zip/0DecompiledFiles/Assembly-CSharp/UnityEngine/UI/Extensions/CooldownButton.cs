﻿using System;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000037 RID: 55
	[AddComponentMenu("UI/Extensions/Cooldown Button")]
	public class CooldownButton : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
	{
		// Token: 0x17000024 RID: 36
		// (get) Token: 0x06000132 RID: 306 RVA: 0x00007FE2 File Offset: 0x000061E2
		// (set) Token: 0x06000133 RID: 307 RVA: 0x00007FEA File Offset: 0x000061EA
		public float CooldownTimeout
		{
			get
			{
				return this.cooldownTimeout;
			}
			set
			{
				this.cooldownTimeout = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x06000134 RID: 308 RVA: 0x00007FF3 File Offset: 0x000061F3
		// (set) Token: 0x06000135 RID: 309 RVA: 0x00007FFB File Offset: 0x000061FB
		public float CooldownSpeed
		{
			get
			{
				return this.cooldownSpeed;
			}
			set
			{
				this.cooldownSpeed = value;
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x06000136 RID: 310 RVA: 0x00008004 File Offset: 0x00006204
		public bool CooldownInEffect
		{
			get
			{
				return this.cooldownInEffect;
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x06000137 RID: 311 RVA: 0x0000800C File Offset: 0x0000620C
		// (set) Token: 0x06000138 RID: 312 RVA: 0x00008014 File Offset: 0x00006214
		public bool CooldownActive
		{
			get
			{
				return this.cooldownActive;
			}
			set
			{
				this.cooldownActive = value;
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000139 RID: 313 RVA: 0x0000801D File Offset: 0x0000621D
		// (set) Token: 0x0600013A RID: 314 RVA: 0x00008025 File Offset: 0x00006225
		public float CooldownTimeElapsed
		{
			get
			{
				return this.cooldownTimeElapsed;
			}
			set
			{
				this.cooldownTimeElapsed = value;
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x0600013B RID: 315 RVA: 0x0000802E File Offset: 0x0000622E
		public float CooldownTimeRemaining
		{
			get
			{
				return this.cooldownTimeRemaining;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600013C RID: 316 RVA: 0x00008036 File Offset: 0x00006236
		public int CooldownPercentRemaining
		{
			get
			{
				return this.cooldownPercentRemaining;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x0600013D RID: 317 RVA: 0x0000803E File Offset: 0x0000623E
		public int CooldownPercentComplete
		{
			get
			{
				return this.cooldownPercentComplete;
			}
		}

		// Token: 0x0600013E RID: 318 RVA: 0x00008048 File Offset: 0x00006248
		private void Update()
		{
			if (this.CooldownActive)
			{
				this.cooldownTimeRemaining -= Time.deltaTime * this.cooldownSpeed;
				this.cooldownTimeElapsed = this.CooldownTimeout - this.CooldownTimeRemaining;
				if (this.cooldownTimeRemaining < 0f)
				{
					this.StopCooldown();
					return;
				}
				this.cooldownPercentRemaining = (int)(100f * this.cooldownTimeRemaining * this.CooldownTimeout / 100f);
				this.cooldownPercentComplete = (int)((this.CooldownTimeout - this.cooldownTimeRemaining) / this.CooldownTimeout * 100f);
			}
		}

		// Token: 0x0600013F RID: 319 RVA: 0x000080E1 File Offset: 0x000062E1
		public void PauseCooldown()
		{
			if (this.CooldownInEffect)
			{
				this.CooldownActive = false;
			}
		}

		// Token: 0x06000140 RID: 320 RVA: 0x000080F2 File Offset: 0x000062F2
		public void RestartCooldown()
		{
			if (this.CooldownInEffect)
			{
				this.CooldownActive = true;
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x00008104 File Offset: 0x00006304
		public void StartCooldown()
		{
			PointerEventData pointerEventData = new PointerEventData(EventSystem.current);
			this.buttonSource = pointerEventData;
			this.OnCooldownStart.Invoke(pointerEventData.button);
			this.cooldownTimeRemaining = this.cooldownTimeout;
			this.CooldownActive = (this.cooldownInEffect = true);
		}

		// Token: 0x06000142 RID: 322 RVA: 0x00008150 File Offset: 0x00006350
		public void StopCooldown()
		{
			this.cooldownTimeElapsed = this.CooldownTimeout;
			this.cooldownTimeRemaining = 0f;
			this.cooldownPercentRemaining = 0;
			this.cooldownPercentComplete = 100;
			this.cooldownActive = (this.cooldownInEffect = false);
			if (this.OnCoolDownFinish != null)
			{
				this.OnCoolDownFinish.Invoke(this.buttonSource.button);
			}
		}

		// Token: 0x06000143 RID: 323 RVA: 0x000081B4 File Offset: 0x000063B4
		public void CancelCooldown()
		{
			this.cooldownActive = (this.cooldownInEffect = false);
		}

		// Token: 0x06000144 RID: 324 RVA: 0x000081D4 File Offset: 0x000063D4
		void IPointerDownHandler.OnPointerDown(PointerEventData eventData)
		{
			this.buttonSource = eventData;
			if (this.CooldownInEffect && this.OnButtonClickDuringCooldown != null)
			{
				this.OnButtonClickDuringCooldown.Invoke(eventData.button);
			}
			if (!this.CooldownInEffect)
			{
				if (this.OnCooldownStart != null)
				{
					this.OnCooldownStart.Invoke(eventData.button);
				}
				this.cooldownTimeRemaining = this.cooldownTimeout;
				this.cooldownActive = (this.cooldownInEffect = true);
			}
		}

		// Token: 0x04000130 RID: 304
		[SerializeField]
		private float cooldownTimeout;

		// Token: 0x04000131 RID: 305
		[SerializeField]
		private float cooldownSpeed = 1f;

		// Token: 0x04000132 RID: 306
		[SerializeField]
		[ReadOnly]
		private bool cooldownActive;

		// Token: 0x04000133 RID: 307
		[SerializeField]
		[ReadOnly]
		private bool cooldownInEffect;

		// Token: 0x04000134 RID: 308
		[SerializeField]
		[ReadOnly]
		private float cooldownTimeElapsed;

		// Token: 0x04000135 RID: 309
		[SerializeField]
		[ReadOnly]
		private float cooldownTimeRemaining;

		// Token: 0x04000136 RID: 310
		[SerializeField]
		[ReadOnly]
		private int cooldownPercentRemaining;

		// Token: 0x04000137 RID: 311
		[SerializeField]
		[ReadOnly]
		private int cooldownPercentComplete;

		// Token: 0x04000138 RID: 312
		private PointerEventData buttonSource;

		// Token: 0x04000139 RID: 313
		[Tooltip("Event that fires when a button is initially pressed down")]
		public CooldownButton.CooldownButtonEvent OnCooldownStart;

		// Token: 0x0400013A RID: 314
		[Tooltip("Event that fires when a button is released")]
		public CooldownButton.CooldownButtonEvent OnButtonClickDuringCooldown;

		// Token: 0x0400013B RID: 315
		[Tooltip("Event that continually fires while a button is held down")]
		public CooldownButton.CooldownButtonEvent OnCoolDownFinish;

		// Token: 0x02000111 RID: 273
		[Serializable]
		public class CooldownButtonEvent : UnityEvent<PointerEventData.InputButton>
		{
		}
	}
}
