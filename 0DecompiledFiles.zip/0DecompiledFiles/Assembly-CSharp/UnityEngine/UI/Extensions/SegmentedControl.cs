﻿using System;
using System.Collections;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000044 RID: 68
	[AddComponentMenu("UI/Extensions/Segmented Control/Segmented Control")]
	[RequireComponent(typeof(RectTransform))]
	public class SegmentedControl : UIBehaviour
	{
		// Token: 0x17000048 RID: 72
		// (get) Token: 0x060001E0 RID: 480 RVA: 0x0000B144 File Offset: 0x00009344
		protected float SeparatorWidth
		{
			get
			{
				if (this.m_separatorWidth == 0f && this.separator)
				{
					this.m_separatorWidth = this.separator.rectTransform.rect.width;
					Image component = this.separator.GetComponent<Image>();
					if (component)
					{
						this.m_separatorWidth /= component.pixelsPerUnit;
					}
				}
				return this.m_separatorWidth;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x0000B1B6 File Offset: 0x000093B6
		public Selectable[] segments
		{
			get
			{
				if (this.m_segments == null || this.m_segments.Length == 0)
				{
					this.m_segments = this.GetChildSegments();
				}
				return this.m_segments;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x060001E2 RID: 482 RVA: 0x0000B1DB File Offset: 0x000093DB
		// (set) Token: 0x060001E3 RID: 483 RVA: 0x0000B1E3 File Offset: 0x000093E3
		public Graphic separator
		{
			get
			{
				return this.m_separator;
			}
			set
			{
				this.m_separator = value;
				this.m_separatorWidth = 0f;
				this.LayoutSegments();
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x060001E4 RID: 484 RVA: 0x0000B1FD File Offset: 0x000093FD
		// (set) Token: 0x060001E5 RID: 485 RVA: 0x0000B205 File Offset: 0x00009405
		public bool allowSwitchingOff
		{
			get
			{
				return this.m_allowSwitchingOff;
			}
			set
			{
				this.m_allowSwitchingOff = value;
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0000B20E File Offset: 0x0000940E
		// (set) Token: 0x060001E7 RID: 487 RVA: 0x0000B224 File Offset: 0x00009424
		public int selectedSegmentIndex
		{
			get
			{
				return Array.IndexOf<Selectable>(this.segments, this.selectedSegment);
			}
			set
			{
				value = Math.Max(value, -1);
				value = Math.Min(value, this.segments.Length - 1);
				this.m_selectedSegmentIndex = value;
				if (this.selectedSegment)
				{
					Segment component = this.selectedSegment.GetComponent<Segment>();
					if (component)
					{
						component.selected = false;
					}
					this.selectedSegment = null;
				}
				if (value != -1)
				{
					this.selectedSegment = this.segments[value];
					Segment component2 = this.selectedSegment.GetComponent<Segment>();
					if (component2)
					{
						component2.selected = true;
					}
				}
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x0000B2AF File Offset: 0x000094AF
		// (set) Token: 0x060001E9 RID: 489 RVA: 0x0000B2B7 File Offset: 0x000094B7
		public SegmentedControl.SegmentSelectedEvent onValueChanged
		{
			get
			{
				return this.m_onValueChanged;
			}
			set
			{
				this.m_onValueChanged = value;
			}
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0000B2C0 File Offset: 0x000094C0
		protected SegmentedControl()
		{
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0000B2DA File Offset: 0x000094DA
		protected override void Start()
		{
			base.Start();
			if (base.isActiveAndEnabled)
			{
				base.StartCoroutine(this.DelayedInit());
			}
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0000B2F7 File Offset: 0x000094F7
		protected override void OnEnable()
		{
			base.StartCoroutine(this.DelayedInit());
		}

		// Token: 0x060001ED RID: 493 RVA: 0x0000B306 File Offset: 0x00009506
		private IEnumerator DelayedInit()
		{
			yield return null;
			this.LayoutSegments();
			if (this.m_selectedSegmentIndex != -1)
			{
				this.selectedSegmentIndex = this.m_selectedSegmentIndex;
			}
			yield break;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x0000B318 File Offset: 0x00009518
		private Selectable[] GetChildSegments()
		{
			Selectable[] componentsInChildren = base.GetComponentsInChildren<Selectable>();
			if (componentsInChildren.Length < 2)
			{
				throw new InvalidOperationException("A segmented control must have at least two Button children");
			}
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				Segment component = componentsInChildren[i].GetComponent<Segment>();
				if (component != null)
				{
					component.index = i;
					component.segmentedControl = this;
				}
			}
			return componentsInChildren;
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0000B36C File Offset: 0x0000956C
		private void RecreateSprites()
		{
			for (int i = 0; i < this.segments.Length; i++)
			{
				if (!(this.segments[i].image == null))
				{
					Sprite sprite = SegmentedControl.CutSprite(this.segments[i].image.sprite, i == 0, i == this.segments.Length - 1);
					Segment component = this.segments[i].GetComponent<Segment>();
					if (component)
					{
						component.cutSprite = sprite;
					}
					this.segments[i].image.overrideSprite = sprite;
				}
			}
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x0000B3FC File Offset: 0x000095FC
		internal static Sprite CutSprite(Sprite sprite, bool leftmost, bool rightmost)
		{
			if (sprite.border.x == 0f || sprite.border.z == 0f)
			{
				return sprite;
			}
			Rect rect = sprite.rect;
			Vector4 border = sprite.border;
			if (!leftmost)
			{
				rect.xMin = border.x;
				border.x = 0f;
			}
			if (!rightmost)
			{
				rect.xMax = border.z;
				border.z = 0f;
			}
			return Sprite.Create(sprite.texture, rect, sprite.pivot, sprite.pixelsPerUnit, 0U, SpriteMeshType.FullRect, border);
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0000B490 File Offset: 0x00009690
		public void LayoutSegments()
		{
			this.RecreateSprites();
			RectTransform rectTransform = base.transform as RectTransform;
			float num = rectTransform.rect.width / (float)this.segments.Length - this.SeparatorWidth * (float)(this.segments.Length - 1);
			for (int i = 0; i < this.segments.Length; i++)
			{
				float num2 = (num + this.SeparatorWidth) * (float)i;
				RectTransform component = this.segments[i].GetComponent<RectTransform>();
				component.anchorMin = Vector2.zero;
				component.anchorMax = Vector2.zero;
				component.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, num2, num);
				component.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0f, rectTransform.rect.height);
				if (this.separator && i > 0)
				{
					Transform transform = base.gameObject.transform.Find("Separator " + i.ToString());
					Graphic graphic = ((transform != null) ? transform.GetComponent<Graphic>() : Object.Instantiate<GameObject>(this.separator.gameObject).GetComponent<Graphic>());
					graphic.gameObject.name = "Separator " + i.ToString();
					graphic.gameObject.SetActive(true);
					graphic.rectTransform.SetParent(base.transform, false);
					graphic.rectTransform.anchorMin = Vector2.zero;
					graphic.rectTransform.anchorMax = Vector2.zero;
					graphic.rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Left, num2 - this.SeparatorWidth, this.SeparatorWidth);
					graphic.rectTransform.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Top, 0f, rectTransform.rect.height);
				}
			}
		}

		// Token: 0x040001AA RID: 426
		private Selectable[] m_segments;

		// Token: 0x040001AB RID: 427
		[SerializeField]
		[Tooltip("A GameObject with an Image to use as a separator between segments. Size of the RectTransform will determine the size of the separator used.\nNote, make sure to disable the separator GO so that it does not affect the scene")]
		private Graphic m_separator;

		// Token: 0x040001AC RID: 428
		private float m_separatorWidth;

		// Token: 0x040001AD RID: 429
		[SerializeField]
		[Tooltip("When True, it allows each button to be toggled on/off")]
		private bool m_allowSwitchingOff;

		// Token: 0x040001AE RID: 430
		[SerializeField]
		[Tooltip("The selected default for the control (zero indexed array)")]
		private int m_selectedSegmentIndex = -1;

		// Token: 0x040001AF RID: 431
		[SerializeField]
		[Tooltip("Event to fire once the selection has been changed")]
		private SegmentedControl.SegmentSelectedEvent m_onValueChanged = new SegmentedControl.SegmentSelectedEvent();

		// Token: 0x040001B0 RID: 432
		internal Selectable selectedSegment;

		// Token: 0x0200011A RID: 282
		[Serializable]
		public class SegmentSelectedEvent : UnityEvent<int>
		{
		}
	}
}
