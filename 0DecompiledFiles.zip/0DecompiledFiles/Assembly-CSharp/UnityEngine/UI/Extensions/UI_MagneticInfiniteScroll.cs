﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000C8 RID: 200
	[AddComponentMenu("UI/Extensions/UI Magnetic Infinite Scroll")]
	[RequireComponent(typeof(ScrollRect))]
	public class UI_MagneticInfiniteScroll : UI_InfiniteScroll, IDragHandler, IEventSystemHandler, IEndDragHandler, IScrollHandler
	{
		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600068B RID: 1675 RVA: 0x00025E44 File Offset: 0x00024044
		// (remove) Token: 0x0600068C RID: 1676 RVA: 0x00025E7C File Offset: 0x0002407C
		public event Action<GameObject> OnNewSelect;

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x0600068D RID: 1677 RVA: 0x00025EB1 File Offset: 0x000240B1
		public List<RectTransform> Items { get; }

		// Token: 0x0600068E RID: 1678 RVA: 0x00025EB9 File Offset: 0x000240B9
		protected override void Awake()
		{
			base.Awake();
			base.StartCoroutine(this.SetInitContent());
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x00025ED0 File Offset: 0x000240D0
		private void Update()
		{
			if (this._scrollRect == null || !this._scrollRect.content || !this.pivot || !this._useMagnetic || !this._isMovement || this.items == null)
			{
				return;
			}
			float rightAxis = this.GetRightAxis(this._scrollRect.content.anchoredPosition);
			this._currentSpeed = Mathf.Abs(rightAxis - this._pastPosition);
			this._pastPosition = rightAxis;
			if (Mathf.Abs(this._currentSpeed) > this.maxSpeedForMagnetic)
			{
				return;
			}
			if (this._isStopping)
			{
				Vector2 anchoredPosition = this._scrollRect.content.anchoredPosition;
				this._currentTime += Time.deltaTime;
				float num = this._currentTime / this.timeForDeceleration;
				float num2 = Mathf.Lerp(this.GetRightAxis(anchoredPosition), this._stopValue, num);
				this._scrollRect.content.anchoredPosition = (this._isVertical ? new Vector2(anchoredPosition.x, num2) : new Vector2(num2, anchoredPosition.y));
				if (num2 == this.GetRightAxis(anchoredPosition) && this._nearestIndex > 0 && this._nearestIndex < this.items.Count)
				{
					this._isStopping = false;
					this._isMovement = false;
					RectTransform rectTransform = this.items[this._nearestIndex];
					if (rectTransform != null && this.OnNewSelect != null)
					{
						this.OnNewSelect(rectTransform.gameObject);
						return;
					}
				}
			}
			else
			{
				float num3 = float.PositiveInfinity * -this._initMovementDirection;
				for (int i = 0; i < this.items.Count; i++)
				{
					RectTransform rectTransform2 = this.items[i];
					if (!(rectTransform2 == null))
					{
						float num4 = this.GetRightAxis(rectTransform2.position) - this.GetRightAxis(this.pivot.position);
						if ((this._initMovementDirection <= 0f && num4 < num3 && num4 > 0f) || (this._initMovementDirection > 0f && num4 > num3 && num4 < 0f))
						{
							num3 = num4;
							this._nearestIndex = i;
						}
					}
				}
				this._isStopping = true;
				this._stopValue = this.GetAnchoredPositionForPivot(this._nearestIndex);
				this._scrollRect.StopMovement();
			}
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x00026140 File Offset: 0x00024340
		public override void SetNewItems(ref List<Transform> newItems)
		{
			foreach (Transform transform in newItems)
			{
				RectTransform component = transform.GetComponent<RectTransform>();
				if (component && this.pivot)
				{
					component.sizeDelta = this.pivot.sizeDelta;
				}
			}
			base.SetNewItems(ref newItems);
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x000261BC File Offset: 0x000243BC
		public void SetContentInPivot(int index)
		{
			float anchoredPositionForPivot = this.GetAnchoredPositionForPivot(index);
			Vector2 anchoredPosition = this._scrollRect.content.anchoredPosition;
			if (this._scrollRect.content)
			{
				this._scrollRect.content.anchoredPosition = (this._isVertical ? new Vector2(anchoredPosition.x, anchoredPositionForPivot) : new Vector2(anchoredPositionForPivot, anchoredPosition.y));
				this._pastPosition = this.GetRightAxis(this._scrollRect.content.anchoredPosition);
			}
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00026242 File Offset: 0x00024442
		private IEnumerator SetInitContent()
		{
			yield return new WaitForSeconds(this._waitForContentSet);
			this.SetContentInPivot(this.indexStart);
			yield break;
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x00026254 File Offset: 0x00024454
		private float GetAnchoredPositionForPivot(int index)
		{
			if (!this.pivot || this.items == null || this.items.Count < 0)
			{
				return 0f;
			}
			index = Mathf.Clamp(index, 0, this.items.Count - 1);
			float rightAxis = this.GetRightAxis(this.items[index].anchoredPosition);
			return this.GetRightAxis(this.pivot.anchoredPosition) - rightAxis;
		}

		// Token: 0x06000694 RID: 1684 RVA: 0x000262CB File Offset: 0x000244CB
		private void FinishPrepareMovement()
		{
			this._isMovement = true;
			this._useMagnetic = true;
			this._isStopping = false;
			this._currentTime = 0f;
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x000262ED File Offset: 0x000244ED
		private float GetRightAxis(Vector2 vector)
		{
			if (!this._isVertical)
			{
				return vector.x;
			}
			return vector.y;
		}

		// Token: 0x06000696 RID: 1686 RVA: 0x00026304 File Offset: 0x00024504
		public void OnDrag(PointerEventData eventData)
		{
			float rightAxis = this.GetRightAxis(UIExtensionsInputManager.MousePosition);
			this._initMovementDirection = Mathf.Sign(rightAxis - this._pastPositionMouseSpeed);
			this._pastPositionMouseSpeed = rightAxis;
			this._useMagnetic = false;
			this._isStopping = false;
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x0002634A File Offset: 0x0002454A
		public void OnEndDrag(PointerEventData eventData)
		{
			this.FinishPrepareMovement();
		}

		// Token: 0x06000698 RID: 1688 RVA: 0x00026352 File Offset: 0x00024552
		public void OnScroll(PointerEventData eventData)
		{
			this._initMovementDirection = -UIExtensionsInputManager.MouseScrollDelta.y;
			this.FinishPrepareMovement();
		}

		// Token: 0x040004BF RID: 1215
		[Tooltip("The pointer to the pivot, the visual element for centering objects.")]
		[SerializeField]
		private RectTransform pivot;

		// Token: 0x040004C0 RID: 1216
		[Tooltip("The maximum speed that allows you to activate the magnet to center on the pivot")]
		[SerializeField]
		private float maxSpeedForMagnetic = 10f;

		// Token: 0x040004C1 RID: 1217
		[SerializeField]
		[Tooltip("The index of the object which must be initially centered")]
		private int indexStart;

		// Token: 0x040004C2 RID: 1218
		[SerializeField]
		[Tooltip("The time to decelerate and aim to the pivot")]
		private float timeForDeceleration = 0.05f;

		// Token: 0x040004C3 RID: 1219
		private float _pastPositionMouseSpeed;

		// Token: 0x040004C4 RID: 1220
		private float _initMovementDirection;

		// Token: 0x040004C5 RID: 1221
		private float _pastPosition;

		// Token: 0x040004C6 RID: 1222
		private float _currentSpeed;

		// Token: 0x040004C7 RID: 1223
		private float _stopValue;

		// Token: 0x040004C8 RID: 1224
		private readonly float _waitForContentSet = 0.1f;

		// Token: 0x040004C9 RID: 1225
		private float _currentTime;

		// Token: 0x040004CA RID: 1226
		private int _nearestIndex;

		// Token: 0x040004CB RID: 1227
		private bool _useMagnetic = true;

		// Token: 0x040004CC RID: 1228
		private bool _isStopping;

		// Token: 0x040004CD RID: 1229
		private bool _isMovement;
	}
}
