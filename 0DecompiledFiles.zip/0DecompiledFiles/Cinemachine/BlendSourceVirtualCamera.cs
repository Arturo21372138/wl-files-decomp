﻿using System;
using UnityEngine;

namespace Cinemachine
{
	// Token: 0x02000031 RID: 49
	internal class BlendSourceVirtualCamera : ICinemachineCamera
	{
		// Token: 0x06000248 RID: 584 RVA: 0x00011698 File Offset: 0x0000F898
		public BlendSourceVirtualCamera(CinemachineBlend blend)
		{
			this.Blend = blend;
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000249 RID: 585 RVA: 0x000116A7 File Offset: 0x0000F8A7
		// (set) Token: 0x0600024A RID: 586 RVA: 0x000116AF File Offset: 0x0000F8AF
		public CinemachineBlend Blend { get; set; }

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x0600024B RID: 587 RVA: 0x000116B8 File Offset: 0x0000F8B8
		public string Name
		{
			get
			{
				return "Mid-blend";
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x0600024C RID: 588 RVA: 0x000116BF File Offset: 0x0000F8BF
		public string Description
		{
			get
			{
				if (this.Blend != null)
				{
					return this.Blend.Description;
				}
				return "(null)";
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x0600024D RID: 589 RVA: 0x000116DA File Offset: 0x0000F8DA
		// (set) Token: 0x0600024E RID: 590 RVA: 0x000116E2 File Offset: 0x0000F8E2
		public int Priority { get; set; }

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x0600024F RID: 591 RVA: 0x000116EB File Offset: 0x0000F8EB
		// (set) Token: 0x06000250 RID: 592 RVA: 0x000116F3 File Offset: 0x0000F8F3
		public Transform LookAt { get; set; }

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000251 RID: 593 RVA: 0x000116FC File Offset: 0x0000F8FC
		// (set) Token: 0x06000252 RID: 594 RVA: 0x00011704 File Offset: 0x0000F904
		public Transform Follow { get; set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000253 RID: 595 RVA: 0x0001170D File Offset: 0x0000F90D
		// (set) Token: 0x06000254 RID: 596 RVA: 0x00011715 File Offset: 0x0000F915
		public CameraState State { get; private set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000255 RID: 597 RVA: 0x0001171E File Offset: 0x0000F91E
		public GameObject VirtualCameraGameObject
		{
			get
			{
				return null;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000256 RID: 598 RVA: 0x00011721 File Offset: 0x0000F921
		public bool IsValid
		{
			get
			{
				return this.Blend != null && this.Blend.IsValid;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000257 RID: 599 RVA: 0x00011738 File Offset: 0x0000F938
		public ICinemachineCamera ParentCamera
		{
			get
			{
				return null;
			}
		}

		// Token: 0x06000258 RID: 600 RVA: 0x0001173B File Offset: 0x0000F93B
		public bool IsLiveChild(ICinemachineCamera vcam, bool dominantChildOnly = false)
		{
			return this.Blend != null && (vcam == this.Blend.CamA || vcam == this.Blend.CamB);
		}

		// Token: 0x06000259 RID: 601 RVA: 0x00011765 File Offset: 0x0000F965
		public CameraState CalculateNewState(float deltaTime)
		{
			return this.State;
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0001176D File Offset: 0x0000F96D
		public void UpdateCameraState(Vector3 worldUp, float deltaTime)
		{
			if (this.Blend != null)
			{
				this.Blend.UpdateCameraState(worldUp, deltaTime);
				this.State = this.Blend.State;
			}
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00011795 File Offset: 0x0000F995
		public void InternalUpdateCameraState(Vector3 worldUp, float deltaTime)
		{
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00011797 File Offset: 0x0000F997
		public void OnTransitionFromCamera(ICinemachineCamera fromCam, Vector3 worldUp, float deltaTime)
		{
		}

		// Token: 0x0600025D RID: 605 RVA: 0x00011799 File Offset: 0x0000F999
		public void OnTargetObjectWarped(Transform target, Vector3 positionDelta)
		{
		}
	}
}
