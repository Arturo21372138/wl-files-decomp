﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions.Tweens
{
	// Token: 0x020000DB RID: 219
	public struct FloatTween : ITweenValue
	{
		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000731 RID: 1841 RVA: 0x00028DAB File Offset: 0x00026FAB
		// (set) Token: 0x06000732 RID: 1842 RVA: 0x00028DB3 File Offset: 0x00026FB3
		public float startFloat
		{
			get
			{
				return this.m_StartFloat;
			}
			set
			{
				this.m_StartFloat = value;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000733 RID: 1843 RVA: 0x00028DBC File Offset: 0x00026FBC
		// (set) Token: 0x06000734 RID: 1844 RVA: 0x00028DC4 File Offset: 0x00026FC4
		public float targetFloat
		{
			get
			{
				return this.m_TargetFloat;
			}
			set
			{
				this.m_TargetFloat = value;
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000735 RID: 1845 RVA: 0x00028DCD File Offset: 0x00026FCD
		// (set) Token: 0x06000736 RID: 1846 RVA: 0x00028DD5 File Offset: 0x00026FD5
		public float duration
		{
			get
			{
				return this.m_Duration;
			}
			set
			{
				this.m_Duration = value;
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000737 RID: 1847 RVA: 0x00028DDE File Offset: 0x00026FDE
		// (set) Token: 0x06000738 RID: 1848 RVA: 0x00028DE6 File Offset: 0x00026FE6
		public bool ignoreTimeScale
		{
			get
			{
				return this.m_IgnoreTimeScale;
			}
			set
			{
				this.m_IgnoreTimeScale = value;
			}
		}

		// Token: 0x06000739 RID: 1849 RVA: 0x00028DEF File Offset: 0x00026FEF
		public void TweenValue(float floatPercentage)
		{
			if (!this.ValidTarget())
			{
				return;
			}
			this.m_Target.Invoke(Mathf.Lerp(this.m_StartFloat, this.m_TargetFloat, floatPercentage));
		}

		// Token: 0x0600073A RID: 1850 RVA: 0x00028E17 File Offset: 0x00027017
		public void AddOnChangedCallback(UnityAction<float> callback)
		{
			if (this.m_Target == null)
			{
				this.m_Target = new FloatTween.FloatTweenCallback();
			}
			this.m_Target.AddListener(callback);
		}

		// Token: 0x0600073B RID: 1851 RVA: 0x00028E38 File Offset: 0x00027038
		public void AddOnFinishCallback(UnityAction callback)
		{
			if (this.m_Finish == null)
			{
				this.m_Finish = new FloatTween.FloatFinishCallback();
			}
			this.m_Finish.AddListener(callback);
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x00028E59 File Offset: 0x00027059
		public bool GetIgnoreTimescale()
		{
			return this.m_IgnoreTimeScale;
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x00028E61 File Offset: 0x00027061
		public float GetDuration()
		{
			return this.m_Duration;
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x00028E69 File Offset: 0x00027069
		public bool ValidTarget()
		{
			return this.m_Target != null;
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x00028E74 File Offset: 0x00027074
		public void Finished()
		{
			if (this.m_Finish != null)
			{
				this.m_Finish.Invoke();
			}
		}

		// Token: 0x04000549 RID: 1353
		private float m_StartFloat;

		// Token: 0x0400054A RID: 1354
		private float m_TargetFloat;

		// Token: 0x0400054B RID: 1355
		private float m_Duration;

		// Token: 0x0400054C RID: 1356
		private bool m_IgnoreTimeScale;

		// Token: 0x0400054D RID: 1357
		private FloatTween.FloatTweenCallback m_Target;

		// Token: 0x0400054E RID: 1358
		private FloatTween.FloatFinishCallback m_Finish;

		// Token: 0x0200015B RID: 347
		public class FloatTweenCallback : UnityEvent<float>
		{
		}

		// Token: 0x0200015C RID: 348
		public class FloatFinishCallback : UnityEvent
		{
		}
	}
}
