﻿using System;
using System.Collections;
using UnityEngine.EventSystems;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000BB RID: 187
	[RequireComponent(typeof(ScrollRect))]
	[AddComponentMenu("UI/Extensions/ScrollRectTweener")]
	public class ScrollRectTweener : MonoBehaviour, IDragHandler, IEventSystemHandler
	{
		// Token: 0x0600061F RID: 1567 RVA: 0x00024674 File Offset: 0x00022874
		private void Awake()
		{
			this.scrollRect = base.GetComponent<ScrollRect>();
			this.wasHorizontal = this.scrollRect.horizontal;
			this.wasVertical = this.scrollRect.vertical;
		}

		// Token: 0x06000620 RID: 1568 RVA: 0x000246A4 File Offset: 0x000228A4
		public void ScrollHorizontal(float normalizedX)
		{
			this.Scroll(new Vector2(normalizedX, this.scrollRect.verticalNormalizedPosition));
		}

		// Token: 0x06000621 RID: 1569 RVA: 0x000246BD File Offset: 0x000228BD
		public void ScrollHorizontal(float normalizedX, float duration)
		{
			this.Scroll(new Vector2(normalizedX, this.scrollRect.verticalNormalizedPosition), duration);
		}

		// Token: 0x06000622 RID: 1570 RVA: 0x000246D7 File Offset: 0x000228D7
		public void ScrollVertical(float normalizedY)
		{
			this.Scroll(new Vector2(this.scrollRect.horizontalNormalizedPosition, normalizedY));
		}

		// Token: 0x06000623 RID: 1571 RVA: 0x000246F0 File Offset: 0x000228F0
		public void ScrollVertical(float normalizedY, float duration)
		{
			this.Scroll(new Vector2(this.scrollRect.horizontalNormalizedPosition, normalizedY), duration);
		}

		// Token: 0x06000624 RID: 1572 RVA: 0x0002470A File Offset: 0x0002290A
		public void Scroll(Vector2 normalizedPos)
		{
			this.Scroll(normalizedPos, this.GetScrollDuration(normalizedPos));
		}

		// Token: 0x06000625 RID: 1573 RVA: 0x0002471C File Offset: 0x0002291C
		private float GetScrollDuration(Vector2 normalizedPos)
		{
			Vector2 currentPos = this.GetCurrentPos();
			return Vector2.Distance(this.DeNormalize(currentPos), this.DeNormalize(normalizedPos)) / this.moveSpeed;
		}

		// Token: 0x06000626 RID: 1574 RVA: 0x0002474C File Offset: 0x0002294C
		private Vector2 DeNormalize(Vector2 normalizedPos)
		{
			return new Vector2(normalizedPos.x * this.scrollRect.content.rect.width, normalizedPos.y * this.scrollRect.content.rect.height);
		}

		// Token: 0x06000627 RID: 1575 RVA: 0x0002479C File Offset: 0x0002299C
		private Vector2 GetCurrentPos()
		{
			return new Vector2(this.scrollRect.horizontalNormalizedPosition, this.scrollRect.verticalNormalizedPosition);
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x000247B9 File Offset: 0x000229B9
		public void Scroll(Vector2 normalizedPos, float duration)
		{
			this.startPos = this.GetCurrentPos();
			this.targetPos = normalizedPos;
			if (this.disableDragWhileTweening)
			{
				this.LockScrollability();
			}
			base.StopAllCoroutines();
			base.StartCoroutine(this.DoMove(duration));
		}

		// Token: 0x06000629 RID: 1577 RVA: 0x000247F0 File Offset: 0x000229F0
		private IEnumerator DoMove(float duration)
		{
			if (duration < 0.05f)
			{
				yield break;
			}
			Vector2 posOffset = this.targetPos - this.startPos;
			float currentTime = 0f;
			while (currentTime < duration)
			{
				currentTime += Time.deltaTime;
				this.scrollRect.normalizedPosition = this.EaseVector(currentTime, this.startPos, posOffset, duration);
				yield return null;
			}
			this.scrollRect.normalizedPosition = this.targetPos;
			if (this.disableDragWhileTweening)
			{
				this.RestoreScrollability();
			}
			yield break;
		}

		// Token: 0x0600062A RID: 1578 RVA: 0x00024808 File Offset: 0x00022A08
		public Vector2 EaseVector(float currentTime, Vector2 startValue, Vector2 changeInValue, float duration)
		{
			return new Vector2(changeInValue.x * Mathf.Sin(currentTime / duration * 1.5707964f) + startValue.x, changeInValue.y * Mathf.Sin(currentTime / duration * 1.5707964f) + startValue.y);
		}

		// Token: 0x0600062B RID: 1579 RVA: 0x00024854 File Offset: 0x00022A54
		public void OnDrag(PointerEventData eventData)
		{
			if (!this.disableDragWhileTweening)
			{
				this.StopScroll();
			}
		}

		// Token: 0x0600062C RID: 1580 RVA: 0x00024864 File Offset: 0x00022A64
		private void StopScroll()
		{
			base.StopAllCoroutines();
			if (this.disableDragWhileTweening)
			{
				this.RestoreScrollability();
			}
		}

		// Token: 0x0600062D RID: 1581 RVA: 0x0002487A File Offset: 0x00022A7A
		private void LockScrollability()
		{
			this.scrollRect.horizontal = false;
			this.scrollRect.vertical = false;
		}

		// Token: 0x0600062E RID: 1582 RVA: 0x00024894 File Offset: 0x00022A94
		private void RestoreScrollability()
		{
			this.scrollRect.horizontal = this.wasHorizontal;
			this.scrollRect.vertical = this.wasVertical;
		}

		// Token: 0x0400047C RID: 1148
		private ScrollRect scrollRect;

		// Token: 0x0400047D RID: 1149
		private Vector2 startPos;

		// Token: 0x0400047E RID: 1150
		private Vector2 targetPos;

		// Token: 0x0400047F RID: 1151
		private bool wasHorizontal;

		// Token: 0x04000480 RID: 1152
		private bool wasVertical;

		// Token: 0x04000481 RID: 1153
		public float moveSpeed = 5000f;

		// Token: 0x04000482 RID: 1154
		public bool disableDragWhileTweening;
	}
}
