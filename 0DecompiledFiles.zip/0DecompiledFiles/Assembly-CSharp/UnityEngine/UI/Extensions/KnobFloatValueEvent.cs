﻿using System;
using UnityEngine.Events;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200004C RID: 76
	[Serializable]
	public class KnobFloatValueEvent : UnityEvent<float>
	{
	}
}
