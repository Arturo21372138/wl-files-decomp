﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x0200005E RID: 94
	[AddComponentMenu("UI/Effects/Extensions/UIImageCrop")]
	[ExecuteInEditMode]
	[RequireComponent(typeof(RectTransform))]
	public class UIImageCrop : MonoBehaviour
	{
		// Token: 0x060002DC RID: 732 RVA: 0x0001226B File Offset: 0x0001046B
		private void Start()
		{
			this.SetMaterial();
		}

		// Token: 0x060002DD RID: 733 RVA: 0x00012274 File Offset: 0x00010474
		public void SetMaterial()
		{
			this.mGraphic = base.GetComponent<MaskableGraphic>();
			this.XCropProperty = Shader.PropertyToID("_XCrop");
			this.YCropProperty = Shader.PropertyToID("_YCrop");
			if (this.mGraphic != null)
			{
				if (this.mGraphic.material == null || this.mGraphic.material.name == "Default UI Material")
				{
					this.mGraphic.material = new Material(ShaderLibrary.GetShaderInstance("UI Extensions/UI Image Crop"));
				}
				this.mat = this.mGraphic.material;
				return;
			}
			Debug.LogError("Please attach component to a Graphical UI component");
		}

		// Token: 0x060002DE RID: 734 RVA: 0x00012320 File Offset: 0x00010520
		public void OnValidate()
		{
			this.SetMaterial();
			this.SetXCrop(this.XCrop);
			this.SetYCrop(this.YCrop);
		}

		// Token: 0x060002DF RID: 735 RVA: 0x00012340 File Offset: 0x00010540
		public void SetXCrop(float xcrop)
		{
			this.XCrop = Mathf.Clamp01(xcrop);
			this.mat.SetFloat(this.XCropProperty, this.XCrop);
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x00012365 File Offset: 0x00010565
		public void SetYCrop(float ycrop)
		{
			this.YCrop = Mathf.Clamp01(ycrop);
			this.mat.SetFloat(this.YCropProperty, this.YCrop);
		}

		// Token: 0x0400023A RID: 570
		private MaskableGraphic mGraphic;

		// Token: 0x0400023B RID: 571
		private Material mat;

		// Token: 0x0400023C RID: 572
		private int XCropProperty;

		// Token: 0x0400023D RID: 573
		private int YCropProperty;

		// Token: 0x0400023E RID: 574
		public float XCrop;

		// Token: 0x0400023F RID: 575
		public float YCrop;
	}
}
