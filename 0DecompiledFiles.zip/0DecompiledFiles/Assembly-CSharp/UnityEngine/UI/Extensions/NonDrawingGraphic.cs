﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000B3 RID: 179
	[AddComponentMenu("Layout/Extensions/NonDrawingGraphic")]
	public class NonDrawingGraphic : MaskableGraphic
	{
		// Token: 0x060005F8 RID: 1528 RVA: 0x00023DB9 File Offset: 0x00021FB9
		public override void SetMaterialDirty()
		{
		}

		// Token: 0x060005F9 RID: 1529 RVA: 0x00023DBB File Offset: 0x00021FBB
		public override void SetVerticesDirty()
		{
		}

		// Token: 0x060005FA RID: 1530 RVA: 0x00023DBD File Offset: 0x00021FBD
		protected override void OnPopulateMesh(VertexHelper vh)
		{
			vh.Clear();
		}
	}
}
