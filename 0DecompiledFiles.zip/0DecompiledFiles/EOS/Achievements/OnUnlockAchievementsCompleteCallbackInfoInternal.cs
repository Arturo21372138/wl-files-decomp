﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x02000813 RID: 2067
	internal struct OnUnlockAchievementsCompleteCallbackInfoInternal : ICallbackInfoInternal, IGettable<OnUnlockAchievementsCompleteCallbackInfo>
	{
		// Token: 0x17000877 RID: 2167
		// (get) Token: 0x06002200 RID: 8704 RVA: 0x00028636 File Offset: 0x00026836
		public IntPtr ClientDataPointer
		{
			get
			{
				return this.m_ClientData;
			}
		}

		// Token: 0x06002201 RID: 8705 RVA: 0x00028640 File Offset: 0x00026840
		public void Get(out OnUnlockAchievementsCompleteCallbackInfo other)
		{
			other = default(OnUnlockAchievementsCompleteCallbackInfo);
			other.ResultCode = this.m_ResultCode;
			object obj;
			Helper.Get(this.m_ClientData, out obj);
			other.ClientData = obj;
			ProductUserId productUserId;
			Helper.Get<ProductUserId>(this.m_UserId, out productUserId);
			other.UserId = productUserId;
			other.AchievementsCount = this.m_AchievementsCount;
		}

		// Token: 0x040016A7 RID: 5799
		private Result m_ResultCode;

		// Token: 0x040016A8 RID: 5800
		private IntPtr m_ClientData;

		// Token: 0x040016A9 RID: 5801
		private IntPtr m_UserId;

		// Token: 0x040016AA RID: 5802
		private uint m_AchievementsCount;
	}
}
