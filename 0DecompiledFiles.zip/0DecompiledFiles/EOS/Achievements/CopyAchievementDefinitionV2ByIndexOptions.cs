﻿using System;

namespace Epic.OnlineServices.Achievements
{
	// Token: 0x020007E7 RID: 2023
	public struct CopyAchievementDefinitionV2ByIndexOptions
	{
		// Token: 0x1700083B RID: 2107
		// (get) Token: 0x06002144 RID: 8516 RVA: 0x00027BE1 File Offset: 0x00025DE1
		// (set) Token: 0x06002145 RID: 8517 RVA: 0x00027BE9 File Offset: 0x00025DE9
		public uint AchievementIndex { readonly get; set; }
	}
}
