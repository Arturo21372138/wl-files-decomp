﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000074 RID: 116
	public sealed class NullContext
	{
	}
}
