﻿using System;

namespace Epic.OnlineServices.AntiCheatCommon
{
	// Token: 0x0200076F RID: 1903
	public enum AntiCheatCommonClientType
	{
		// Token: 0x0400148E RID: 5262
		ProtectedClient,
		// Token: 0x0400148F RID: 5263
		UnprotectedClient,
		// Token: 0x04001490 RID: 5264
		AIBot
	}
}
