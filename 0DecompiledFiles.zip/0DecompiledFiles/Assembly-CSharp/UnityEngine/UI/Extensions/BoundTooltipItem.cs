﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x020000A6 RID: 166
	[AddComponentMenu("UI/Extensions/Bound Tooltip/Bound Tooltip Item")]
	public class BoundTooltipItem : MonoBehaviour
	{
		// Token: 0x17000103 RID: 259
		// (get) Token: 0x0600058A RID: 1418 RVA: 0x0002155B File Offset: 0x0001F75B
		public bool IsActive
		{
			get
			{
				return base.gameObject.activeSelf;
			}
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x00021568 File Offset: 0x0001F768
		private void Awake()
		{
			BoundTooltipItem.instance = this;
			if (!this.TooltipText)
			{
				this.TooltipText = base.GetComponentInChildren<Text>();
			}
			this.HideTooltip();
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x00021590 File Offset: 0x0001F790
		public void ShowTooltip(string text, Vector3 pos)
		{
			if (this.TooltipText.text != text)
			{
				this.TooltipText.text = text;
			}
			base.transform.position = pos + this.ToolTipOffset;
			base.gameObject.SetActive(true);
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x000215DF File Offset: 0x0001F7DF
		public void HideTooltip()
		{
			base.gameObject.SetActive(false);
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x0600058E RID: 1422 RVA: 0x000215ED File Offset: 0x0001F7ED
		public static BoundTooltipItem Instance
		{
			get
			{
				if (BoundTooltipItem.instance == null)
				{
					BoundTooltipItem.instance = Object.FindObjectOfType<BoundTooltipItem>();
				}
				return BoundTooltipItem.instance;
			}
		}

		// Token: 0x04000416 RID: 1046
		public Text TooltipText;

		// Token: 0x04000417 RID: 1047
		public Vector3 ToolTipOffset;

		// Token: 0x04000418 RID: 1048
		private static BoundTooltipItem instance;
	}
}
