﻿using System;
using UnityEngine;
using UnityEngine.Playables;

namespace NatureRendererDemo
{
	// Token: 0x02000016 RID: 22
	public class CompileShaders : MonoBehaviour
	{
		// Token: 0x0400002A RID: 42
		public PlayableDirector Director;

		// Token: 0x0400002B RID: 43
		public GameObject NatureRendererTerrain;

		// Token: 0x0400002C RID: 44
		public GameObject UnityTerrain;
	}
}
