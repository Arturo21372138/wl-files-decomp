﻿using System;

namespace AmplifyImpostors
{
	// Token: 0x020000E3 RID: 227
	public enum ImpostorType
	{
		// Token: 0x0400058E RID: 1422
		Spherical,
		// Token: 0x0400058F RID: 1423
		Octahedron,
		// Token: 0x04000590 RID: 1424
		HemiOctahedron
	}
}
