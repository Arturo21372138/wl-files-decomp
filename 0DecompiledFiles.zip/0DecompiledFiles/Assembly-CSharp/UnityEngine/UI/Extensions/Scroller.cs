﻿using System;
using UnityEngine.EventSystems;
using UnityEngine.UI.Extensions.EasingCore;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000081 RID: 129
	public class Scroller : UIBehaviour, IPointerUpHandler, IEventSystemHandler, IPointerDownHandler, IBeginDragHandler, IEndDragHandler, IDragHandler, IScrollHandler
	{
		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060003B3 RID: 947 RVA: 0x000170BC File Offset: 0x000152BC
		public float ViewportSize
		{
			get
			{
				if (this.scrollDirection != ScrollDirection.Horizontal)
				{
					return this.viewport.rect.size.y;
				}
				return this.viewport.rect.size.x;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060003B4 RID: 948 RVA: 0x00017103 File Offset: 0x00015303
		public ScrollDirection ScrollDirection
		{
			get
			{
				return this.scrollDirection;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060003B5 RID: 949 RVA: 0x0001710B File Offset: 0x0001530B
		// (set) Token: 0x060003B6 RID: 950 RVA: 0x00017113 File Offset: 0x00015313
		public MovementType MovementType
		{
			get
			{
				return this.movementType;
			}
			set
			{
				this.movementType = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060003B7 RID: 951 RVA: 0x0001711C File Offset: 0x0001531C
		// (set) Token: 0x060003B8 RID: 952 RVA: 0x00017124 File Offset: 0x00015324
		public float Elasticity
		{
			get
			{
				return this.elasticity;
			}
			set
			{
				this.elasticity = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060003B9 RID: 953 RVA: 0x0001712D File Offset: 0x0001532D
		// (set) Token: 0x060003BA RID: 954 RVA: 0x00017135 File Offset: 0x00015335
		public float ScrollSensitivity
		{
			get
			{
				return this.scrollSensitivity;
			}
			set
			{
				this.scrollSensitivity = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060003BB RID: 955 RVA: 0x0001713E File Offset: 0x0001533E
		// (set) Token: 0x060003BC RID: 956 RVA: 0x00017146 File Offset: 0x00015346
		public bool Inertia
		{
			get
			{
				return this.inertia;
			}
			set
			{
				this.inertia = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060003BD RID: 957 RVA: 0x0001714F File Offset: 0x0001534F
		// (set) Token: 0x060003BE RID: 958 RVA: 0x00017157 File Offset: 0x00015357
		public float DecelerationRate
		{
			get
			{
				return this.decelerationRate;
			}
			set
			{
				this.decelerationRate = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060003BF RID: 959 RVA: 0x00017160 File Offset: 0x00015360
		// (set) Token: 0x060003C0 RID: 960 RVA: 0x0001716D File Offset: 0x0001536D
		public bool SnapEnabled
		{
			get
			{
				return this.snap.Enable;
			}
			set
			{
				this.snap.Enable = value;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x060003C1 RID: 961 RVA: 0x0001717B File Offset: 0x0001537B
		// (set) Token: 0x060003C2 RID: 962 RVA: 0x00017183 File Offset: 0x00015383
		public bool Draggable
		{
			get
			{
				return this.draggable;
			}
			set
			{
				this.draggable = value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x060003C3 RID: 963 RVA: 0x0001718C File Offset: 0x0001538C
		public Scrollbar Scrollbar
		{
			get
			{
				return this.scrollbar;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x060003C4 RID: 964 RVA: 0x00017194 File Offset: 0x00015394
		// (set) Token: 0x060003C5 RID: 965 RVA: 0x0001719C File Offset: 0x0001539C
		public float Position
		{
			get
			{
				return this.currentPosition;
			}
			set
			{
				this.autoScrollState.Reset();
				this.velocity = 0f;
				this.dragging = false;
				this.UpdatePosition(value, true);
			}
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x000171C3 File Offset: 0x000153C3
		protected override void Start()
		{
			base.Start();
			if (this.scrollbar)
			{
				this.scrollbar.onValueChanged.AddListener(delegate(float x)
				{
					this.UpdatePosition(x * ((float)this.totalCount - 1f), false);
				});
			}
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x000171F4 File Offset: 0x000153F4
		public void OnValueChanged(Action<float> callback)
		{
			this.onValueChanged = callback;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x000171FD File Offset: 0x000153FD
		public void OnSelectionChanged(Action<int> callback)
		{
			this.onSelectionChanged = callback;
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00017206 File Offset: 0x00015406
		public void SetTotalCount(int totalCount)
		{
			this.totalCount = totalCount;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0001720F File Offset: 0x0001540F
		public void ScrollTo(float position, float duration, Action onComplete = null)
		{
			this.ScrollTo(position, duration, Ease.OutCubic, onComplete);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0001721C File Offset: 0x0001541C
		public void ScrollTo(float position, float duration, Ease easing, Action onComplete = null)
		{
			this.ScrollTo(position, duration, Easing.Get(easing), onComplete);
		}

		// Token: 0x060003CC RID: 972 RVA: 0x00017230 File Offset: 0x00015430
		public void ScrollTo(float position, float duration, EasingFunction easingFunction, Action onComplete = null)
		{
			if (duration <= 0f)
			{
				this.Position = this.CircularPosition(position, this.totalCount);
				if (onComplete != null)
				{
					onComplete();
				}
				return;
			}
			this.autoScrollState.Reset();
			this.autoScrollState.Enable = true;
			this.autoScrollState.Duration = duration;
			this.autoScrollState.EasingFunction = easingFunction ?? Scroller.DefaultEasingFunction;
			this.autoScrollState.StartTime = Time.unscaledTime;
			this.autoScrollState.EndPosition = this.currentPosition + this.CalculateMovementAmount(this.currentPosition, position);
			this.autoScrollState.OnComplete = onComplete;
			this.velocity = 0f;
			this.scrollStartPosition = this.currentPosition;
			this.UpdateSelection(Mathf.RoundToInt(this.CircularPosition(this.autoScrollState.EndPosition, this.totalCount)));
		}

		// Token: 0x060003CD RID: 973 RVA: 0x00017311 File Offset: 0x00015511
		public void JumpTo(int index)
		{
			if (index < 0 || index > this.totalCount - 1)
			{
				throw new ArgumentOutOfRangeException("index");
			}
			this.UpdateSelection(index);
			this.Position = (float)index;
		}

		// Token: 0x060003CE RID: 974 RVA: 0x0001733C File Offset: 0x0001553C
		public MovementDirection GetMovementDirection(int sourceIndex, int destIndex)
		{
			float num = this.CalculateMovementAmount((float)sourceIndex, (float)destIndex);
			if (this.scrollDirection != ScrollDirection.Horizontal)
			{
				if (num <= 0f)
				{
					return MovementDirection.Down;
				}
				return MovementDirection.Up;
			}
			else
			{
				if (num <= 0f)
				{
					return MovementDirection.Right;
				}
				return MovementDirection.Left;
			}
		}

		// Token: 0x060003CF RID: 975 RVA: 0x00017374 File Offset: 0x00015574
		void IPointerDownHandler.OnPointerDown(PointerEventData eventData)
		{
			if (!this.draggable || eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.hold = true;
			this.velocity = 0f;
			this.autoScrollState.Reset();
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x000173A4 File Offset: 0x000155A4
		void IPointerUpHandler.OnPointerUp(PointerEventData eventData)
		{
			if (!this.draggable || eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			if (this.hold && this.snap.Enable)
			{
				this.UpdateSelection(Mathf.Clamp(Mathf.RoundToInt(this.currentPosition), 0, this.totalCount - 1));
				this.ScrollTo((float)Mathf.RoundToInt(this.currentPosition), this.snap.Duration, this.snap.Easing, null);
			}
			this.hold = false;
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x00017428 File Offset: 0x00015628
		void IScrollHandler.OnScroll(PointerEventData eventData)
		{
			if (!this.draggable)
			{
				return;
			}
			Vector2 scrollDelta = eventData.scrollDelta;
			scrollDelta.y *= -1f;
			float num = ((this.scrollDirection == ScrollDirection.Horizontal) ? ((Mathf.Abs(scrollDelta.y) > Mathf.Abs(scrollDelta.x)) ? scrollDelta.y : scrollDelta.x) : ((Mathf.Abs(scrollDelta.x) > Mathf.Abs(scrollDelta.y)) ? scrollDelta.x : scrollDelta.y));
			if (eventData.IsScrolling())
			{
				this.scrolling = true;
			}
			float num2 = this.currentPosition + num / this.ViewportSize * this.scrollSensitivity;
			if (this.movementType == MovementType.Clamped)
			{
				num2 += this.CalculateOffset(num2);
			}
			if (this.autoScrollState.Enable)
			{
				this.autoScrollState.Reset();
			}
			this.UpdatePosition(num2, true);
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00017508 File Offset: 0x00015708
		void IBeginDragHandler.OnBeginDrag(PointerEventData eventData)
		{
			if (!this.draggable || eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.hold = false;
			RectTransformUtility.ScreenPointToLocalPointInRectangle(this.viewport, eventData.position, eventData.pressEventCamera, out this.beginDragPointerPosition);
			this.scrollStartPosition = this.currentPosition;
			this.dragging = true;
			this.autoScrollState.Reset();
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0001756C File Offset: 0x0001576C
		void IDragHandler.OnDrag(PointerEventData eventData)
		{
			if (!this.draggable || eventData.button != PointerEventData.InputButton.Left || !this.dragging)
			{
				return;
			}
			Vector2 vector;
			if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(this.viewport, eventData.position, eventData.pressEventCamera, out vector))
			{
				return;
			}
			Vector2 vector2 = vector - this.beginDragPointerPosition;
			float num = ((this.scrollDirection == ScrollDirection.Horizontal) ? (-vector2.x) : vector2.y) / this.ViewportSize * this.scrollSensitivity + this.scrollStartPosition;
			float num2 = this.CalculateOffset(num);
			num += num2;
			if (this.movementType == MovementType.Elastic && num2 != 0f)
			{
				num -= this.RubberDelta(num2, this.scrollSensitivity);
			}
			this.UpdatePosition(num, true);
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0001761E File Offset: 0x0001581E
		void IEndDragHandler.OnEndDrag(PointerEventData eventData)
		{
			if (!this.draggable || eventData.button != PointerEventData.InputButton.Left)
			{
				return;
			}
			this.dragging = false;
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00017638 File Offset: 0x00015838
		private float CalculateOffset(float position)
		{
			if (this.movementType == MovementType.Unrestricted)
			{
				return 0f;
			}
			if (position < 0f)
			{
				return -position;
			}
			if (position > (float)(this.totalCount - 1))
			{
				return (float)(this.totalCount - 1) - position;
			}
			return 0f;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00017670 File Offset: 0x00015870
		private void UpdatePosition(float position, bool updateScrollbar = true)
		{
			Action<float> action = this.onValueChanged;
			if (action != null)
			{
				this.currentPosition = position;
				action(position);
			}
			if (this.scrollbar && updateScrollbar)
			{
				this.scrollbar.value = Mathf.Clamp01(position / Mathf.Max((float)this.totalCount - 1f, 0.0001f));
			}
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x000176D0 File Offset: 0x000158D0
		private void UpdateSelection(int index)
		{
			Action<int> action = this.onSelectionChanged;
			if (action == null)
			{
				return;
			}
			action(index);
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x000176E3 File Offset: 0x000158E3
		private float RubberDelta(float overStretching, float viewSize)
		{
			return (1f - 1f / (Mathf.Abs(overStretching) * 0.55f / viewSize + 1f)) * viewSize * Mathf.Sign(overStretching);
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00017710 File Offset: 0x00015910
		private void Update()
		{
			float unscaledDeltaTime = Time.unscaledDeltaTime;
			float num = this.CalculateOffset(this.currentPosition);
			if (this.autoScrollState.Enable)
			{
				float num2;
				if (this.autoScrollState.Elastic)
				{
					num2 = Mathf.SmoothDamp(this.currentPosition, this.currentPosition + num, ref this.velocity, this.elasticity, float.PositiveInfinity, unscaledDeltaTime);
					if (Mathf.Abs(this.velocity) < 0.01f)
					{
						num2 = (float)Mathf.Clamp(Mathf.RoundToInt(num2), 0, this.totalCount - 1);
						this.velocity = 0f;
						this.autoScrollState.Complete();
					}
				}
				else
				{
					float num3 = Mathf.Clamp01((Time.unscaledTime - this.autoScrollState.StartTime) / Mathf.Max(this.autoScrollState.Duration, float.Epsilon));
					num2 = Mathf.LerpUnclamped(this.scrollStartPosition, this.autoScrollState.EndPosition, this.autoScrollState.EasingFunction(num3));
					if (Mathf.Approximately(num3, 1f))
					{
						this.autoScrollState.Complete();
					}
				}
				this.UpdatePosition(num2, true);
			}
			else if (!this.dragging && !this.scrolling && (!Mathf.Approximately(num, 0f) || !Mathf.Approximately(this.velocity, 0f)))
			{
				float num4 = this.currentPosition;
				if (this.movementType == MovementType.Elastic && !Mathf.Approximately(num, 0f))
				{
					this.autoScrollState.Reset();
					this.autoScrollState.Enable = true;
					this.autoScrollState.Elastic = true;
					this.UpdateSelection(Mathf.Clamp(Mathf.RoundToInt(num4), 0, this.totalCount - 1));
				}
				else if (this.inertia)
				{
					this.velocity *= Mathf.Pow(this.decelerationRate, unscaledDeltaTime);
					if (Mathf.Abs(this.velocity) < 0.001f)
					{
						this.velocity = 0f;
					}
					num4 += this.velocity * unscaledDeltaTime;
					if (this.snap.Enable && Mathf.Abs(this.velocity) < this.snap.VelocityThreshold)
					{
						this.ScrollTo((float)Mathf.RoundToInt(this.currentPosition), this.snap.Duration, this.snap.Easing, null);
					}
				}
				else
				{
					this.velocity = 0f;
				}
				if (!Mathf.Approximately(this.velocity, 0f))
				{
					if (this.movementType == MovementType.Clamped)
					{
						num = this.CalculateOffset(num4);
						num4 += num;
						if (Mathf.Approximately(num4, 0f) || Mathf.Approximately(num4, (float)this.totalCount - 1f))
						{
							this.velocity = 0f;
							this.UpdateSelection(Mathf.RoundToInt(num4));
						}
					}
					this.UpdatePosition(num4, true);
				}
			}
			if (!this.autoScrollState.Enable && (this.dragging || this.scrolling) && this.inertia)
			{
				float num5 = (this.currentPosition - this.prevPosition) / unscaledDeltaTime;
				this.velocity = Mathf.Lerp(this.velocity, num5, unscaledDeltaTime * 10f);
			}
			this.prevPosition = this.currentPosition;
			this.scrolling = false;
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00017A4C File Offset: 0x00015C4C
		private float CalculateMovementAmount(float sourcePosition, float destPosition)
		{
			if (this.movementType != MovementType.Unrestricted)
			{
				return Mathf.Clamp(destPosition, 0f, (float)(this.totalCount - 1)) - sourcePosition;
			}
			float num = this.CircularPosition(destPosition, this.totalCount) - this.CircularPosition(sourcePosition, this.totalCount);
			if (Mathf.Abs(num) > (float)this.totalCount * 0.5f)
			{
				num = Mathf.Sign(-num) * ((float)this.totalCount - Mathf.Abs(num));
			}
			return num;
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00017AC1 File Offset: 0x00015CC1
		private float CircularPosition(float p, int size)
		{
			if (size < 1)
			{
				return 0f;
			}
			if (p >= 0f)
			{
				return p % (float)size;
			}
			return (float)(size - 1) + (p + 1f) % (float)size;
		}

		// Token: 0x040002EB RID: 747
		[SerializeField]
		private RectTransform viewport;

		// Token: 0x040002EC RID: 748
		[SerializeField]
		private ScrollDirection scrollDirection;

		// Token: 0x040002ED RID: 749
		[SerializeField]
		private MovementType movementType = MovementType.Elastic;

		// Token: 0x040002EE RID: 750
		[SerializeField]
		private float elasticity = 0.1f;

		// Token: 0x040002EF RID: 751
		[SerializeField]
		private float scrollSensitivity = 1f;

		// Token: 0x040002F0 RID: 752
		[SerializeField]
		private bool inertia = true;

		// Token: 0x040002F1 RID: 753
		[SerializeField]
		private float decelerationRate = 0.03f;

		// Token: 0x040002F2 RID: 754
		[SerializeField]
		private Scroller.Snap snap = new Scroller.Snap
		{
			Enable = true,
			VelocityThreshold = 0.5f,
			Duration = 0.3f,
			Easing = Ease.InOutCubic
		};

		// Token: 0x040002F3 RID: 755
		[SerializeField]
		private bool draggable = true;

		// Token: 0x040002F4 RID: 756
		[SerializeField]
		private Scrollbar scrollbar;

		// Token: 0x040002F5 RID: 757
		private readonly Scroller.AutoScrollState autoScrollState = new Scroller.AutoScrollState();

		// Token: 0x040002F6 RID: 758
		private Action<float> onValueChanged;

		// Token: 0x040002F7 RID: 759
		private Action<int> onSelectionChanged;

		// Token: 0x040002F8 RID: 760
		private Vector2 beginDragPointerPosition;

		// Token: 0x040002F9 RID: 761
		private float scrollStartPosition;

		// Token: 0x040002FA RID: 762
		private float prevPosition;

		// Token: 0x040002FB RID: 763
		private float currentPosition;

		// Token: 0x040002FC RID: 764
		private int totalCount;

		// Token: 0x040002FD RID: 765
		private bool hold;

		// Token: 0x040002FE RID: 766
		private bool scrolling;

		// Token: 0x040002FF RID: 767
		private bool dragging;

		// Token: 0x04000300 RID: 768
		private float velocity;

		// Token: 0x04000301 RID: 769
		private static readonly EasingFunction DefaultEasingFunction = Easing.Get(Ease.OutCubic);

		// Token: 0x02000132 RID: 306
		[Serializable]
		private class Snap
		{
			// Token: 0x04000669 RID: 1641
			public bool Enable;

			// Token: 0x0400066A RID: 1642
			public float VelocityThreshold;

			// Token: 0x0400066B RID: 1643
			public float Duration;

			// Token: 0x0400066C RID: 1644
			public Ease Easing;
		}

		// Token: 0x02000133 RID: 307
		private class AutoScrollState
		{
			// Token: 0x060007FE RID: 2046 RVA: 0x0002C1F0 File Offset: 0x0002A3F0
			public void Reset()
			{
				this.Enable = false;
				this.Elastic = false;
				this.Duration = 0f;
				this.StartTime = 0f;
				this.EasingFunction = Scroller.DefaultEasingFunction;
				this.EndPosition = 0f;
				this.OnComplete = null;
			}

			// Token: 0x060007FF RID: 2047 RVA: 0x0002C23E File Offset: 0x0002A43E
			public void Complete()
			{
				Action onComplete = this.OnComplete;
				if (onComplete != null)
				{
					onComplete();
				}
				this.Reset();
			}

			// Token: 0x0400066D RID: 1645
			public bool Enable;

			// Token: 0x0400066E RID: 1646
			public bool Elastic;

			// Token: 0x0400066F RID: 1647
			public float Duration;

			// Token: 0x04000670 RID: 1648
			public EasingFunction EasingFunction;

			// Token: 0x04000671 RID: 1649
			public float StartTime;

			// Token: 0x04000672 RID: 1650
			public float EndPosition;

			// Token: 0x04000673 RID: 1651
			public Action OnComplete;
		}
	}
}
