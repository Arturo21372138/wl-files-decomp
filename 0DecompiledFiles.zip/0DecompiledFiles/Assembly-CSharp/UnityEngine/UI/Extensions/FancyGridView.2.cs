﻿using System;

namespace UnityEngine.UI.Extensions
{
	// Token: 0x02000078 RID: 120
	public abstract class FancyGridView<TItemData> : FancyGridView<TItemData, FancyGridViewContext>
	{
	}
}
